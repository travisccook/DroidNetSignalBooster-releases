"""
DroidNet Signal Booster - Firmware Handlers
Functions for flashing firmware to Arduino and ESP32 devices
"""

import os
import sys
import subprocess
import logging
import tempfile
import time
from typing import Dict, Any, Optional

from config.constants import PROJECT_ROOT, SCRIPTS_DIR, AVRDUDE_CONFIG_PATH

# Add parent directory to path for imports
sys.path.insert(0, str(PROJECT_ROOT))
sys.path.insert(0, str(SCRIPTS_DIR))

# Get logger
logger = logging.getLogger(__name__)

# Module-level variable (set by server.py after import)
serial_port_manager = None


def _get_active_wcb_listener_baud(port: str) -> Optional[int]:
    """
    Check if there's an active WCB listener on the port and return its baud rate.

    Args:
        port: Serial port path

    Returns:
        Baud rate if listener is active, None otherwise
    """
    if serial_port_manager is None:
        return None

    try:
        handler = serial_port_manager.get_handler(port)
        if handler:
            return handler.baud
    except Exception as e:
        logger.debug(f"Error checking WCB listener for {port}: {e}")

    return None


def _verify_port_available(port: str, max_attempts: int = 5, delay: float = 0.5) -> bool:
    """
    Verify that a serial port is available by attempting to open it.

    Args:
        port: Serial port path
        max_attempts: Maximum number of attempts
        delay: Delay between attempts in seconds

    Returns:
        True if port is available, False otherwise
    """
    import serial

    for attempt in range(max_attempts):
        try:
            # Try to open the port briefly
            ser = serial.Serial(port, 115200, timeout=0.1)
            ser.close()
            logger.debug(f"Port {port} verified available on attempt {attempt + 1}")
            return True
        except serial.SerialException as e:
            if attempt < max_attempts - 1:
                logger.debug(
                    f"Port {port} not yet available (attempt {attempt + 1}): {e}"
                )
                time.sleep(delay)
            else:
                logger.warning(
                    f"Port {port} still not available after {max_attempts} attempts: {e}"
                )
        except Exception as e:
            logger.warning(f"Unexpected error checking port {port}: {e}")
            return False

    return False


def _stop_wcb_listener_for_flash(port: str) -> bool:
    """
    Stop WCB listener on a port before flashing.

    Args:
        port: Serial port path

    Returns:
        True if a listener was stopped, False otherwise
    """
    if serial_port_manager is None:
        return False

    try:
        listener = serial_port_manager.get_wcb_listener(port)
        if listener:
            logger.info(f"Stopping WCB listener on {port} for firmware flash")
            serial_port_manager.stop_wcb_listener_sync(port)
            # Give time for port to be fully released by OS/USB subsystem
            # Pi Zero W needs extra time for USB cleanup
            time.sleep(1.5)
            # Verify the port is actually available
            if not _verify_port_available(port):
                logger.warning(
                    f"Port {port} may not be fully released, proceeding anyway"
                )
            return True
    except Exception as e:
        logger.warning(f"Error stopping WCB listener for {port}: {e}")

    return False


def _restart_wcb_listener(port: str, baud: int):
    """
    Restart WCB listener on a port after flashing.

    Args:
        port: Serial port path
        baud: Baud rate to use
    """
    if serial_port_manager is None:
        return

    try:
        logger.info(f"Restarting WCB listener on {port} @ {baud} baud after flash")
        # Give time for device to boot after flash
        time.sleep(2.0)
        serial_port_manager.start_wcb_listener_sync(port, baud)
    except Exception as e:
        logger.warning(f"Error restarting WCB listener for {port}: {e}")

# Import firmware flasher at module level with error handling
try:
    from firmware_flasher import flash_firmware as enhanced_flash
    ENHANCED_FLASHER_AVAILABLE = True
except ImportError:
    ENHANCED_FLASHER_AVAILABLE = False
    logger.warning("Enhanced firmware flasher not available")


def flash_firmware(
    firmware_data: bytes,
    device_port: str,
    board_type: Optional[str] = None,
    additional_files: Optional[Dict[str, str]] = None,
    flash_address: Optional[str] = None,
) -> Dict[str, Any]:
    """Flash firmware to Arduino or ESP32 using enhanced flasher"""
    # Track if we need to restart WCB listener after flash
    wcb_listener_baud = None

    try:
        logger.info(f"Starting firmware flash to {device_port}, board_type={board_type}")

        # Check for active WCB listener and stop it before flashing
        wcb_listener_baud = _get_active_wcb_listener_baud(device_port)
        if wcb_listener_baud:
            logger.info(f"Found active WCB listener on {device_port} @ {wcb_listener_baud} baud")
            _stop_wcb_listener_for_flash(device_port)

        # Check if enhanced flasher is available
        if not ENHANCED_FLASHER_AVAILABLE:
            raise ImportError("Enhanced flasher not available")

        # Detect file type from data
        file_ext = ".hex" if firmware_data.startswith(b":") else ".bin"
        logger.debug(f"Detected firmware file type: {file_ext}")

        # Save firmware file temporarily
        with tempfile.NamedTemporaryFile(suffix=file_ext, delete=False) as f:
            f.write(firmware_data)
            firmware_file = f.name

        logger.debug(f"Saved firmware to temporary file: {firmware_file}")

        try:
            # Use enhanced flasher with auto-detection
            logger.info("Calling enhanced firmware flasher")
            result = enhanced_flash(
                firmware_file, device_port, board_type, additional_files, flash_address
            )

            if result.get("success"):
                logger.info(f"Firmware flash successful: {result.get('message', 'OK')}")
            else:
                logger.error(f"Firmware flash failed: {result.get('message', 'Unknown error')}")

            return result
        finally:
            # Clean up temp file
            if os.path.exists(firmware_file):
                os.unlink(firmware_file)
                logger.debug(f"Cleaned up temporary file: {firmware_file}")

    except ImportError as e:
        logger.warning(f"Enhanced flasher not available, using legacy method: {e}")
        # Fallback to legacy method if enhanced flasher not available
        return flash_firmware_legacy(firmware_data, device_port, board_type)
    except (OSError, subprocess.CalledProcessError) as e:
        logger.error(f"Flash operation failed: {e}", exc_info=True)
        return {"success": False, "message": f"Flash operation failed: {str(e)}"}
    finally:
        # Restart WCB listener if it was running before flash
        if wcb_listener_baud:
            _restart_wcb_listener(device_port, wcb_listener_baud)


def flash_firmware_legacy(hex_data: bytes, device_port: str, board_type: Optional[str]) -> Dict[str, Any]:
    """Legacy flash firmware method for Arduino only"""
    try:
        logger.info(f"Using legacy flash method for {device_port}, board_type={board_type}")

        # Save hex file temporarily
        with tempfile.NamedTemporaryFile(suffix=".hex", delete=False) as f:
            f.write(hex_data)
            hex_file = f.name

        logger.debug(f"Saved firmware to {hex_file}")

        # Board type to avrdude parameters mapping
        board_configs = {
            "uno": {"mcu": "atmega328p", "programmer": "arduino", "baud": "115200"},
            "nano": {"mcu": "atmega328p", "programmer": "arduino", "baud": "57600"},
            "mega": {"mcu": "atmega2560", "programmer": "wiring", "baud": "115200"},
            "leonardo": {"mcu": "atmega32u4", "programmer": "avr109", "baud": "57600"},
        }

        config = board_configs.get(board_type, board_configs["uno"])
        logger.debug(f"Using board config: {config}")

        # Run avrdude
        cmd = [
            "avrdude",
            "-C",
            str(AVRDUDE_CONFIG_PATH),
            "-v",
            "-p",
            config["mcu"],
            "-c",
            config["programmer"],
            "-P",
            device_port,
            "-b",
            config["baud"],
            "-D",
            "-U",
            f"flash:w:{hex_file}:i",
        ]

        logger.info(f"Running avrdude command: {' '.join(cmd)}")
        result = subprocess.run(cmd, capture_output=True, text=True)

        # Clean up
        os.unlink(hex_file)
        logger.debug("Cleaned up temporary hex file")

        if result.returncode == 0:
            logger.info("Legacy firmware flash successful")
            return {
                "success": True,
                "message": "Firmware flashed successfully",
                "output": result.stdout + result.stderr,  # avrdude outputs to stderr
            }
        else:
            logger.error(f"Legacy firmware flash failed: {result.stderr}")
            return {
                "success": False,
                "message": f"Flash failed: {result.stderr}",
                "output": result.stdout + result.stderr,
            }

    except (OSError, subprocess.CalledProcessError) as e:
        logger.error(f"Legacy flash operation failed: {e}", exc_info=True)
        return {"success": False, "message": f"Flash operation failed: {str(e)}"}
