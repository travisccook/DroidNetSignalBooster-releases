"""
DroidNet Signal Booster - Victron Smart Shunt BLE Handlers
Functions for Victron device configuration, monitoring, and telemetry
"""

import sys
import logging
import subprocess
from dataclasses import asdict
from typing import Dict, Any, Optional

from config.constants import PROJECT_ROOT, SCRIPTS_DIR

# Add parent directory to path for imports
sys.path.insert(0, str(PROJECT_ROOT))
sys.path.insert(0, str(SCRIPTS_DIR))

# Get logger
logger = logging.getLogger(__name__)

# Import victron modules at module level with error handling
try:
    from victron_manager import VictronManager
    from victron_config import (
        load_victron_config,
        update_victron_device,
        update_history_retention,
        update_auto_start,
        save_victron_config,
        delete_victron_device,
        is_victron_feature_enabled,
        update_victron_feature_enabled,
    )
    from victron_storage import clear_telemetry_storage
    VICTRON_MODULES_AVAILABLE = True
except ImportError:
    VICTRON_MODULES_AVAILABLE = False
    logger.warning("victron modules not available")

# Module-level variables (set by server.py after import)
serial_port_manager = None

# Global Victron manager instance (initialized on first use)
_victron_manager = None


def get_victron_manager():
    """Get or create Victron manager instance"""
    global _victron_manager
    if _victron_manager is None:
        if not VICTRON_MODULES_AVAILABLE:
            raise ImportError("victron modules not available")
        from web.event_bus import EventBus

        event_bus = EventBus()
        _victron_manager = VictronManager.get_instance(event_bus)
    return _victron_manager


def get_victron_config() -> Dict[str, Any]:
    """Get Victron device configuration"""
    try:
        if not VICTRON_MODULES_AVAILABLE:
            raise ImportError("victron modules not available")

        config = load_victron_config()
        return {"success": True, "config": config}
    except Exception as e:
        logger.error(f"Error loading Victron config: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def get_victron_feature_config() -> Dict[str, Any]:
    """Get Victron feature configuration (enabled/disabled state)"""
    try:
        if not VICTRON_MODULES_AVAILABLE:
            raise ImportError("victron modules not available")

        enabled = is_victron_feature_enabled()
        return {"success": True, "config": {"enabled": enabled}}
    except Exception as e:
        logger.error(f"Error getting Victron feature config: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def _set_bluetooth_enabled(enabled: bool) -> bool:
    """
    Enable or disable the Bluetooth service.

    Bluetooth is only needed for Victron BLE communication, so it should
    be disabled when Victron is disabled to save CPU resources.

    Args:
        enabled: True to enable Bluetooth, False to disable

    Returns:
        True if successful, False otherwise
    """
    try:
        if enabled:
            # Enable and start Bluetooth
            subprocess.run(
                ["systemctl", "enable", "bluetooth"],
                capture_output=True,
                timeout=10,
            )
            result = subprocess.run(
                ["systemctl", "start", "bluetooth"],
                capture_output=True,
                timeout=10,
            )
            logger.info("Bluetooth service enabled and started")
        else:
            # Stop and disable Bluetooth
            subprocess.run(
                ["systemctl", "stop", "bluetooth"],
                capture_output=True,
                timeout=10,
            )
            result = subprocess.run(
                ["systemctl", "disable", "bluetooth"],
                capture_output=True,
                timeout=10,
            )
            logger.info("Bluetooth service stopped and disabled")

        return result.returncode == 0
    except subprocess.TimeoutExpired:
        logger.error("Timeout while controlling Bluetooth service")
        return False
    except Exception as e:
        logger.error(f"Error controlling Bluetooth service: {e}")
        return False


def update_victron_feature_config(data: Dict[str, Any]) -> Dict[str, Any]:
    """Update Victron feature configuration (enabled/disabled state)"""
    try:
        if not VICTRON_MODULES_AVAILABLE:
            raise ImportError("victron modules not available")

        if "enabled" not in data:
            return {"success": False, "error": "Missing 'enabled' field"}

        enabled = data["enabled"]

        # If disabling, stop any running monitoring first
        if not enabled:
            try:
                stop_victron_monitoring_api()
            except Exception as e:
                logger.warning(f"Error stopping Victron monitoring on disable: {e}")

        success = update_victron_feature_enabled(enabled)

        if success:
            # Control Bluetooth service based on Victron feature state
            # Bluetooth is only needed for Victron BLE, disable it to save CPU
            bt_success = _set_bluetooth_enabled(enabled)
            if not bt_success:
                logger.warning(
                    f"Failed to {'enable' if enabled else 'disable'} Bluetooth service"
                )

            return {"success": True, "config": {"enabled": enabled}}
        else:
            return {"success": False, "error": "Failed to update feature configuration"}
    except Exception as e:
        logger.error(f"Error updating Victron feature config: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def get_victron_status() -> Dict[str, Any]:
    """Get Victron monitoring status"""
    try:
        manager = get_victron_manager()
        status = manager.get_status()
        return {"success": True, "status": status}
    except Exception as e:
        logger.error(f"Error getting Victron status: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def get_victron_latest_telemetry() -> Dict[str, Any]:
    """Get latest telemetry reading"""
    try:
        manager = get_victron_manager()
        telemetry = manager.get_latest_telemetry()

        if telemetry:
            return {"success": True, "telemetry": asdict(telemetry)}
        else:
            return {
                "success": False,
                "error": "No telemetry available",
                "telemetry": None,
            }
    except Exception as e:
        logger.error(f"Error getting Victron telemetry: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def get_victron_telemetry_history(limit: Optional[int] = None, seconds: Optional[int] = None) -> Dict[str, Any]:
    """Get historical telemetry data"""
    try:
        manager = get_victron_manager()
        history = manager.get_telemetry_history(limit=limit, seconds=seconds)

        return {
            "success": True,
            "history": [asdict(t) for t in history],
            "count": len(history),
        }
    except Exception as e:
        logger.error(f"Error getting Victron history: {e}", exc_info=True)
        return {"success": False, "error": str(e), "history": []}


def update_victron_device_config(data: Dict[str, Any]) -> Dict[str, Any]:
    """Update Victron device configuration"""
    try:
        if not VICTRON_MODULES_AVAILABLE:
            raise ImportError("victron modules not available")

        # Validate required fields
        required = ["mac", "encryption_key"]
        for field in required:
            if field not in data:
                return {"success": False, "error": f"Missing required field: {field}"}

        # Update device config
        success = update_victron_device(
            mac=data["mac"],
            encryption_key=data["encryption_key"],
            name=data.get("name", "Smart Shunt"),
            enabled=data.get("enabled", True),
        )

        if not success:
            return {"success": False, "error": "Failed to save device configuration"}

        return {"success": True, "message": "Device configuration updated"}

    except Exception as e:
        logger.error(f"Error updating Victron device: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def update_victron_config(data: Dict[str, Any]) -> Dict[str, Any]:
    """Update Victron configuration settings"""
    try:
        if not VICTRON_MODULES_AVAILABLE:
            raise ImportError("victron modules not available")

        success = True

        # Update history retention
        if "history_retention_seconds" in data:
            if not update_history_retention(data["history_retention_seconds"]):
                success = False

        # Update auto-start
        if "auto_start" in data:
            if not update_auto_start(data["auto_start"]):
                success = False

        # Update other settings
        if success and any(
            key not in ["history_retention_seconds", "auto_start"] for key in data
        ):
            config = load_victron_config()
            for key, value in data.items():
                if key not in ["history_retention_seconds", "auto_start"]:
                    config[key] = value
            success = save_victron_config(config)

        if success:
            return {"success": True, "message": "Configuration updated"}
        else:
            return {"success": False, "error": "Failed to save configuration"}

    except Exception as e:
        logger.error(f"Error updating Victron config: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def start_victron_monitoring_api() -> Dict[str, Any]:
    """Start Victron BLE monitoring (API wrapper)"""
    try:
        if not VICTRON_MODULES_AVAILABLE:
            raise ImportError("victron modules not available")

        config = load_victron_config()
        device = config.get("device")

        if not device:
            return {
                "success": False,
                "error": "No device configured. Please configure a device first.",
            }

        if not device.get("enabled"):
            return {
                "success": False,
                "error": "Device is disabled. Please enable it in configuration.",
            }

        # Start monitoring using event loop thread
        async def _start():
            manager = get_victron_manager()
            return await manager.start_monitoring(
                device["mac"], device["encryption_key"]
            )

        success = serial_port_manager.event_loop_thread.run_coroutine(_start())

        if success:
            return {
                "success": True,
                "message": f"Monitoring started for {device.get('name', 'device')}",
            }
        else:
            return {
                "success": False,
                "error": "Failed to start monitoring. Check logs for details.",
            }

    except Exception as e:
        logger.error(f"Error starting Victron monitoring: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def stop_victron_monitoring_api() -> Dict[str, Any]:
    """Stop Victron BLE monitoring (API wrapper)"""
    try:
        # Stop monitoring using event loop thread
        async def _stop():
            manager = get_victron_manager()
            return await manager.stop_monitoring()

        success = serial_port_manager.event_loop_thread.run_coroutine(_stop())

        if success:
            return {"success": True, "message": "Monitoring stopped"}
        else:
            return {"success": False, "error": "Failed to stop monitoring"}

    except Exception as e:
        logger.error(f"Error stopping Victron monitoring: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def delete_victron_device_api() -> Dict[str, Any]:
    """Delete Victron device configuration (API wrapper)"""
    try:
        if not VICTRON_MODULES_AVAILABLE:
            raise ImportError("victron modules not available")

        # Stop monitoring first
        stop_victron_monitoring_api()

        # Delete device config
        success = delete_victron_device()

        if success:
            # Also clear stored telemetry
            clear_telemetry_storage()
            return {"success": True, "message": "Device configuration deleted"}
        else:
            return {"success": False, "error": "Failed to delete device configuration"}

    except Exception as e:
        logger.error(f"Error deleting Victron device: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def victron_reconnect_api() -> Dict[str, Any]:
    """Manually trigger Victron BLE reconnection (API wrapper)"""
    try:

        async def _reconnect():
            manager = get_victron_manager()
            return await manager.manual_reconnect()

        result = serial_port_manager.event_loop_thread.run_coroutine(_reconnect())
        return result

    except Exception as e:
        logger.error(f"Error in Victron reconnect: {e}", exc_info=True)
        return {"success": False, "error": str(e)}
