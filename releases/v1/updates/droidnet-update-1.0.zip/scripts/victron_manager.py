#!/usr/bin/env python3
"""
Victron BLE Manager

Singleton manager for Victron device lifecycle and telemetry storage.
Follows the SerialPortManager pattern for consistency.
"""

import asyncio
import logging
import sys
from typing import Optional, List, Dict, Any
from dataclasses import asdict
from datetime import datetime

# Setup Python paths
sys.path.insert(0, "/opt/droidnet")
from utils.import_helper import setup_paths

from config.constants import (
    TIMEOUT_HISTORY_HOUR_SECONDS,
    TIMEOUT_DEVICE_INACTIVE_SECONDS,
)
from scripts.victron_listener import (
    VictronListener,
    VictronTelemetry,
    SCAN_INTERVAL_PI_ZERO_W,
    SCAN_DURATION,
)
from scripts.victron_config import load_victron_config
from scripts.victron_storage import (
    save_telemetry_snapshot,
    load_telemetry_snapshot,
    prune_old_telemetry,
)

logger = logging.getLogger(__name__)


class VictronManager:
    """
    Singleton manager for Victron BLE listeners and telemetry storage.

    Manages:
    - Listener lifecycle (start/stop)
    - Telemetry history buffer
    - Periodic disk persistence
    - Event bus integration
    """

    _instance: Optional["VictronManager"] = None
    _lock = asyncio.Lock()

    def __init__(self, event_bus=None):
        """
        Initialize Victron manager.

        Args:
            event_bus: Optional EventBus for publishing telemetry
        """
        if VictronManager._instance is not None:
            raise RuntimeError("VictronManager is a singleton. Use get_instance()")

        self.listener: Optional[VictronListener] = None
        self.event_bus = event_bus

        # Telemetry history (in-memory circular buffer)
        self.telemetry_history: List[VictronTelemetry] = []
        self.max_history = TIMEOUT_HISTORY_HOUR_SECONDS  # Default: 1 hour at 1Hz

        # Persistence task
        self._persist_task: Optional[asyncio.Task] = None
        self._persist_interval = 60  # Save to disk every 60 seconds

        # Health check task for automatic recovery
        # Note: With periodic scanning, data may arrive every 30-40 seconds on Pi Zero W
        # (SCAN_INTERVAL_PI_ZERO_W + SCAN_DURATION = ~33s cycle time)
        self._health_task: Optional[asyncio.Task] = None
        self._health_check_interval = 60  # Check every 60 seconds (was 30)
        # Stale threshold must be > 2x max scan cycle to avoid false positives
        max_scan_cycle = SCAN_INTERVAL_PI_ZERO_W + SCAN_DURATION  # ~33 seconds
        self._stale_threshold = max(120, int(max_scan_cycle * 3))  # ~99s or 120s
        self._startup_timeout = TIMEOUT_DEVICE_INACTIVE_SECONDS  # Recover if no data within 5 min of startup
        self._recovery_attempts = 0
        self._max_recovery_attempts = 3
        self._monitoring_started_at: Optional[float] = None

        # State
        self._running = False
        self.last_update_time: Optional[float] = None

        # Load existing history from disk
        self._load_history_from_disk()

        VictronManager._instance = self
        logger.info("VictronManager initialized")

    @classmethod
    def get_instance(cls, event_bus=None) -> "VictronManager":
        """
        Get or create singleton instance.

        Args:
            event_bus: EventBus (only used on first creation)

        Returns:
            VictronManager instance
        """
        if cls._instance is None:
            cls._instance = VictronManager(event_bus)
        return cls._instance

    async def start_monitoring(
        self, mac_address: str, encryption_key: str, auto_persist: bool = True
    ) -> bool:
        """
        Start monitoring a Victron device.

        Args:
            mac_address: Device MAC address
            encryption_key: 32-character hex encryption key
            auto_persist: Whether to auto-save telemetry to disk

        Returns:
            True if started successfully, False otherwise
        """
        async with self._lock:
            # Stop existing listener if any
            if self.listener:
                logger.info("Stopping existing listener before starting new one")
                await self.stop_monitoring()

            try:
                # Create new listener
                self.listener = VictronListener(
                    mac_address=mac_address,
                    encryption_key=encryption_key,
                    event_bus=self.event_bus,
                    on_telemetry=self._on_telemetry_update,
                )

                # Start listening
                await self.listener.start()

                # Update max history from config
                config = load_victron_config()
                self.max_history = config.get(
                    "history_retention_seconds", TIMEOUT_HISTORY_HOUR_SECONDS
                )

                # Start persistence task
                if auto_persist:
                    self._persist_task = asyncio.create_task(self._persistence_loop())

                # Start health check task for automatic recovery
                import time

                self._health_task = asyncio.create_task(self._health_check_loop())
                self._recovery_attempts = 0
                self._monitoring_started_at = time.time()

                self._running = True
                logger.info(f"Victron monitoring started for {mac_address}")
                return True

            except asyncio.TimeoutError as e:
                logger.error(f"Timeout starting Victron monitoring: {e}", exc_info=True)
                self.listener = None
                self._running = False
                return False
            except (OSError, ConnectionError) as e:
                logger.error(
                    f"Connection error starting Victron monitoring: {e}", exc_info=True
                )
                self.listener = None
                self._running = False
                return False
            except ValueError as e:
                logger.error(
                    f"Invalid configuration for Victron monitoring: {e}", exc_info=True
                )
                self.listener = None
                self._running = False
                return False

    async def stop_monitoring(self) -> bool:
        """
        Stop monitoring Victron device.

        Returns:
            True if stopped successfully, False otherwise
        """
        async with self._lock:
            if not self.listener:
                logger.warning("No active listener to stop")
                return True

            try:
                # Stop health check task
                if self._health_task:
                    self._health_task.cancel()
                    try:
                        await self._health_task
                    except asyncio.CancelledError:
                        pass
                    self._health_task = None

                # Stop persistence task
                if self._persist_task:
                    self._persist_task.cancel()
                    try:
                        await self._persist_task
                    except asyncio.CancelledError:
                        pass
                    self._persist_task = None

                # Stop listener
                await self.listener.stop()
                self.listener = None
                self._running = False

                # Save final snapshot to disk
                await self._save_history_to_disk()

                logger.info("Victron monitoring stopped")
                return True

            except asyncio.TimeoutError as e:
                logger.error(f"Timeout stopping Victron monitoring: {e}", exc_info=True)
                return False
            except (OSError, RuntimeError) as e:
                logger.error(f"Error stopping Victron monitoring: {e}", exc_info=True)
                return False

    async def _on_telemetry_update(self, telemetry: VictronTelemetry):
        """
        Handle new telemetry data.

        Args:
            telemetry: New telemetry reading
        """
        # Add to history buffer
        self.telemetry_history.append(telemetry)

        # Trim history to max size
        if len(self.telemetry_history) > self.max_history:
            self.telemetry_history = self.telemetry_history[-self.max_history :]

        # Update last update time
        self.last_update_time = telemetry.timestamp

        logger.debug(
            f"Telemetry updated: {telemetry.voltage}V, {telemetry.soc}% "
            f"(history: {len(self.telemetry_history)} samples)"
        )

    def get_latest_telemetry(self) -> Optional[VictronTelemetry]:
        """
        Get the most recent telemetry reading.

        Returns:
            Latest VictronTelemetry or None if no data
        """
        if self.telemetry_history:
            return self.telemetry_history[-1]
        return None

    def get_telemetry_history(
        self, limit: Optional[int] = None, seconds: Optional[int] = None
    ) -> List[VictronTelemetry]:
        """
        Get historical telemetry data.

        Args:
            limit: Maximum number of samples to return (from most recent)
            seconds: Only return data from last N seconds

        Returns:
            List of VictronTelemetry objects
        """
        history = self.telemetry_history.copy()

        # Filter by time range if specified
        if seconds:
            cutoff_time = datetime.now().timestamp() - seconds
            history = [t for t in history if t.timestamp >= cutoff_time]

        # Limit number of results if specified
        if limit:
            history = history[-limit:]

        return history

    def get_status(self) -> Dict[str, Any]:
        """
        Get monitoring status.

        Returns:
            Dict with monitoring status and statistics
        """
        import time

        # Determine connection state for UI
        connected = self.listener.is_connected() if self.listener else False
        is_recovering = self._recovery_attempts > 0

        # Calculate time since last data
        time_since_data = None
        if self.listener and self.listener._last_update_time > 0:
            time_since_data = time.time() - self.listener._last_update_time

        status = {
            "monitoring": self._running,
            "connected": connected,
            "last_update": self.last_update_time,
            "history_size": len(self.telemetry_history),
            "max_history": self.max_history,
            # Recovery status for UI
            "recovery": {
                "is_recovering": is_recovering,
                "attempts": self._recovery_attempts,
                "max_attempts": self._max_recovery_attempts,
                "needs_manual": self._recovery_attempts >= self._max_recovery_attempts,
            },
            "time_since_data": time_since_data,
        }

        if self.listener:
            status["stats"] = self.listener.get_stats()
            status["mac_address"] = self.listener.mac_address

        return status

    async def manual_reconnect(self) -> Dict[str, Any]:
        """
        Manually trigger BLE scanner reconnection.

        Resets recovery attempts counter and forces an immediate recovery.

        Returns:
            Dict with success status and message
        """
        if not self._running or not self.listener:
            return {
                "success": False,
                "error": "Monitoring not active",
            }

        logger.info("Manual reconnect requested by user")

        # Reset recovery attempts to allow fresh attempts
        self._recovery_attempts = 0

        try:
            await self._recover_scanner()
            return {
                "success": True,
                "message": "Reconnection initiated successfully",
            }
        except asyncio.TimeoutError as e:
            logger.error(f"Timeout during manual reconnect: {e}", exc_info=True)
            return {
                "success": False,
                "error": f"Reconnection timeout: {e}",
            }
        except (OSError, RuntimeError) as e:
            logger.error(f"Manual reconnect failed: {e}", exc_info=True)
            return {
                "success": False,
                "error": str(e),
            }

    async def _persistence_loop(self):
        """Periodic task to save telemetry to disk."""
        try:
            while True:
                await asyncio.sleep(self._persist_interval)
                await self._save_history_to_disk()
        except asyncio.CancelledError:
            logger.debug("Persistence loop cancelled")
            raise

    async def _health_check_loop(self):
        """Periodic task to check BLE scanner health and recover if needed."""
        import time

        try:
            while True:
                await asyncio.sleep(self._health_check_interval)

                if not self._running or not self.listener:
                    continue

                # Check if data is stale
                now = time.time()
                last_data = self.listener._last_update_time

                if last_data == 0:
                    # No data ever received - check if startup timeout exceeded
                    if self._monitoring_started_at:
                        time_since_start = now - self._monitoring_started_at
                        if time_since_start > self._startup_timeout:
                            # Startup timeout exceeded - trigger recovery
                            if self._recovery_attempts >= self._max_recovery_attempts:
                                logger.error(
                                    "Health check: Max recovery attempts reached "
                                    "during startup, manual intervention required"
                                )
                                continue

                            self._recovery_attempts += 1
                            logger.warning(
                                f"Health check: No data after {time_since_start:.0f}s "
                                f"(startup timeout: {self._startup_timeout}s), "
                                f"attempt {self._recovery_attempts}/"
                                f"{self._max_recovery_attempts}"
                            )
                            await self._recover_scanner()
                            # Reset start time after recovery attempt
                            self._monitoring_started_at = now
                            continue

                    # Still within startup timeout, keep waiting
                    if self._recovery_attempts == 0:
                        logger.debug("Health check: No data received yet, waiting...")
                    continue

                time_since_data = now - last_data

                if time_since_data < self._stale_threshold:
                    # Data is fresh, reset recovery counter
                    if self._recovery_attempts > 0:
                        logger.info(
                            f"Health check: Data flowing again, "
                            f"resetting recovery counter from {self._recovery_attempts}"
                        )
                        self._recovery_attempts = 0
                    continue

                # Data is stale - need recovery
                attempt = self._recovery_attempts + 1
                logger.warning(
                    f"Health check: No data for {time_since_data:.0f}s "
                    f"(threshold: {self._stale_threshold}s), "
                    f"attempt {attempt}/{self._max_recovery_attempts}"
                )

                if self._recovery_attempts >= self._max_recovery_attempts:
                    logger.error(
                        "Health check: Max recovery attempts reached, "
                        "manual intervention may be required"
                    )
                    continue

                self._recovery_attempts += 1
                await self._recover_scanner()

        except asyncio.CancelledError:
            logger.debug("Health check loop cancelled")
            raise
        except asyncio.TimeoutError as e:
            logger.error(f"Timeout in health check loop: {e}", exc_info=True)
        except (OSError, RuntimeError) as e:
            logger.error(f"Health check loop error: {e}", exc_info=True)

    async def _recover_scanner(self):
        """Attempt to recover the BLE scanner by restarting Bluetooth."""
        import subprocess

        logger.info("Attempting BLE scanner recovery...")

        try:
            # Save current config before recovery
            mac_address = self.listener.mac_address if self.listener else None
            encryption_key = self.listener.encryption_key if self.listener else None

            if not mac_address or not encryption_key:
                logger.error("Cannot recover: missing MAC or encryption key")
                return

            # Stop current listener
            if self.listener:
                try:
                    await self.listener.stop()
                except (OSError, RuntimeError, asyncio.TimeoutError) as e:
                    logger.warning(f"Error stopping listener during recovery: {e}")
                self.listener = None

            # Restart Bluetooth service to clear stuck state
            logger.info("Restarting Bluetooth service...")
            try:
                result = subprocess.run(
                    ["systemctl", "restart", "bluetooth"],
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                if result.returncode != 0:
                    logger.error(f"Failed to restart bluetooth: {result.stderr}")
                else:
                    logger.info("Bluetooth service restarted successfully")
            except subprocess.TimeoutExpired:
                logger.error("Bluetooth restart timed out")
            except subprocess.CalledProcessError as e:
                logger.error(f"Subprocess error restarting bluetooth: {e}")
            except OSError as e:
                logger.error(f"OS error restarting bluetooth: {e}")

            # Wait for Bluetooth to initialize
            await asyncio.sleep(3)

            # Create and start new listener
            logger.info("Creating new BLE listener...")
            self.listener = VictronListener(
                mac_address=mac_address,
                encryption_key=encryption_key,
                event_bus=self.event_bus,
                on_telemetry=self._on_telemetry_update,
            )

            await self.listener.start()
            logger.info("BLE scanner recovery completed successfully")

        except asyncio.TimeoutError as e:
            logger.error(f"Timeout during BLE recovery: {e}", exc_info=True)
        except (OSError, RuntimeError, ConnectionError) as e:
            logger.error(f"BLE scanner recovery failed: {e}", exc_info=True)

    async def _save_history_to_disk(self):
        """Save current telemetry history to disk."""
        try:
            latest = self.get_latest_telemetry()
            history = self.telemetry_history

            if latest or history:
                save_telemetry_snapshot(latest, history)
                logger.debug(
                    f"Saved telemetry snapshot ({len(history)} samples) to disk"
                )
        except (OSError, IOError) as e:
            logger.error(f"File error saving telemetry to disk: {e}", exc_info=True)
        except (TypeError, ValueError) as e:
            logger.error(f"Data serialization error saving telemetry: {e}", exc_info=True)

    def _load_history_from_disk(self):
        """Load telemetry history from disk on startup."""
        try:
            snapshot = load_telemetry_snapshot()
            if snapshot:
                # Restore history
                self.telemetry_history = snapshot.get("history", [])

                # Update last update time from latest
                latest = snapshot.get("latest")
                if latest:
                    self.last_update_time = latest.get("timestamp")

                logger.info(
                    f"Loaded {len(self.telemetry_history)} telemetry samples from disk"
                )

                # Prune old data
                config = load_victron_config()
                max_age = config.get(
                    "history_retention_seconds", TIMEOUT_HISTORY_HOUR_SECONDS
                )
                prune_old_telemetry(max_age)

        except (OSError, IOError) as e:
            logger.warning(f"File error loading telemetry from disk: {e}")
        except (ValueError, KeyError) as e:
            logger.warning(f"Invalid data loading telemetry from disk: {e}")

    def clear_history(self):
        """Clear all telemetry history."""
        self.telemetry_history.clear()
        self.last_update_time = None
        logger.info("Telemetry history cleared")

    def to_dict(self) -> Dict[str, Any]:
        """
        Serialize manager state to dictionary.

        Returns:
            Dict representation of manager state
        """
        return {
            "status": self.get_status(),
            "latest_telemetry": (
                asdict(self.get_latest_telemetry())
                if self.get_latest_telemetry()
                else None
            ),
            "history_count": len(self.telemetry_history),
        }
