#!/usr/bin/env python3
"""
DroidNet LED Control Script
Controls the onboard LED to indicate system status
"""

import sys
import time
import os
import traceback
import datetime


class LEDController:
    def __init__(self):
        # Find the LED path - varies by Pi model
        self.led_path = self.find_led_path()
        if not self.led_path:
            print("No LED found - running in no-LED mode")
            self.no_led_mode = True
            return

        self.no_led_mode = False
        self.trigger_path = f"{self.led_path}/trigger"
        self.brightness_path = f"{self.led_path}/brightness"

        # Detect Pi model for LED logic
        self.is_pi_zero = self.detect_pi_zero()

    def find_led_path(self):
        """Find the LED path - varies by Pi model"""
        # Pi Zero W typically uses led0 or ACT
        possible_paths = [
            "/sys/class/leds/led0",  # Common on Pi Zero W
            "/sys/class/leds/ACT",  # Alternative name
        ]

        for path in possible_paths:
            if os.path.exists(path):
                print(f"Found LED at {path}")
                return path

        # If no LED found, check what's available
        led_dir = "/sys/class/leds"
        if os.path.exists(led_dir):
            leds = os.listdir(led_dir)
            print(f"Available LEDs: {leds}")
            # Don't use input* or other non-LED devices
            for led in leds:
                if not led.startswith("input"):
                    path = os.path.join(led_dir, led)
                    print(f"Trying LED at {path}")
                    return path

        return None

    def detect_pi_zero(self):
        """Detect if this is a Pi Zero (which has inverted LED logic)"""
        try:
            with open("/proc/device-tree/model", "r") as f:
                model = f.read().strip().lower()
                return "zero" in model
        except (FileNotFoundError, IOError):
            # Default to Pi Zero behavior if we can't detect
            return True

    def set_trigger(self, trigger="none"):
        """Set LED trigger mode"""
        if self.no_led_mode:
            return
        try:
            # First, read current trigger to see if change is needed
            with open(self.trigger_path, "r") as f:
                current = f.read().strip()
                # Triggers are listed with [current] in brackets
                if f"[{trigger}]" in current:
                    return  # Already set

            with open(self.trigger_path, "w") as f:
                f.write(trigger)
        except Exception as e:
            print(f"Failed to set trigger: {e}")
            # Non-fatal - continue anyway
            pass

    def set_brightness(self, value):
        """Set LED brightness (0 or 1)
        Note: Pi Zero W uses inverted logic: 0=ON, 1=OFF
        """
        if self.no_led_mode:
            return
        try:
            # Invert value for Pi Zero W
            if self.is_pi_zero:
                actual_value = 1 - value  # Convert 1->0 (ON), 0->1 (OFF)
            else:
                actual_value = value

            with open(self.brightness_path, "w") as f:
                f.write(str(actual_value))
        except Exception as e:
            print(f"Failed to set brightness: {e}")

    def blink_pattern(self, pattern):
        """Execute a blink pattern
        Pattern is a list of (on_time, off_time) tuples
        """
        if self.no_led_mode:
            # Just sleep for the pattern duration
            total_time = sum(on + off for on, off in pattern)
            time.sleep(total_time)
            return

        self.set_trigger("none")  # Take manual control

        for on_time, off_time in pattern:
            self.set_brightness(1)
            time.sleep(on_time)
            self.set_brightness(0)
            time.sleep(off_time)

    def status_booting(self):
        """Fast blinking - system is booting"""
        print("LED Status: Booting (fast blink)")
        self.set_trigger("none")
        while True:
            self.blink_pattern([(0.1, 0.1)])

    def status_setup(self):
        """Medium blinking - running firstrun setup"""
        print("LED Status: Setup in progress (medium blink)")
        self.set_trigger("none")
        while True:
            self.blink_pattern([(0.5, 0.5)])

    def status_ready(self):
        """Slow heartbeat - system ready"""
        print("LED Status: System ready (heartbeat)")
        self.set_trigger("none")
        while True:
            # Heartbeat pattern: 2 quick blinks, then pause
            self.blink_pattern(
                [
                    (0.1, 0.1),  # First quick blink
                    (0.1, 0.9),  # Second quick blink with longer pause
                ]
            )

    def status_error(self):
        """Rapid blinking - error state"""
        print("LED Status: Error (rapid blink)")

        # Log error state to boot partition
        try:
            import subprocess

            # Ensure log directory exists and is writable
            log_dir = "/boot/firmware/droidnet-logs"
            if not os.path.exists(log_dir):
                os.makedirs(log_dir, exist_ok=True)

            # Remount boot partition as rw if needed
            subprocess.run(
                ["mount", "-o", "remount,rw", "/boot/firmware"],
                capture_output=True,
                text=True,
            )

            # Create timestamped error log
            timestamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
            error_file = f"{log_dir}/led-error-{timestamp}.log"

            with open(error_file, "w") as f:
                f.write(
                    f"=== LED ERROR STATE TRIGGERED - {datetime.datetime.now()} ===\n"
                )
                f.write("\nStack Trace:\n")
                traceback.print_stack(file=f)

                f.write("\n=== System State ===\n")

                # Check critical services
                f.write("\nService Status:\n")
                for service in [
                    "hostapd",
                    "dnsmasq",
                    "droidnet-web",
                    "droidnet-monitor",
                ]:
                    result = subprocess.run(
                        ["systemctl", "is-active", service],
                        capture_output=True,
                        text=True,
                    )
                    f.write(f"{service}: {result.stdout.strip()}\n")

                # Network status
                f.write("\nNetwork Status:\n")
                result = subprocess.run(
                    ["ip", "addr", "show", "wlan0"], capture_output=True, text=True
                )
                f.write(result.stdout)

                # Failed services details
                f.write("\nFailed Services:\n")
                result = subprocess.run(
                    ["systemctl", "--failed", "--no-pager"],
                    capture_output=True,
                    text=True,
                )
                f.write(result.stdout)

                # Recent errors (last 5 minutes)
                f.write("\nRecent Errors (last 5 min):\n")
                result = subprocess.run(
                    [
                        "journalctl",
                        "-p",
                        "err",
                        "--since",
                        "5 minutes ago",
                        "--no-pager",
                    ],
                    capture_output=True,
                    text=True,
                )
                f.write(result.stdout[:2000])  # Limit to 2000 chars

                # Memory status
                f.write("\nMemory Status:\n")
                result = subprocess.run(["free", "-h"], capture_output=True, text=True)
                f.write(result.stdout)

                f.write("\n=== END ERROR LOG ===\n")

            # Also append to main error log
            with open(f"{log_dir}/led-errors.log", "a") as f:
                f.write(
                    f"\n[{datetime.datetime.now()}] "
                    f"Error state logged to {error_file}\n"
                )
        except Exception as e:
            print(f"Failed to log error state: {e}")
            pass  # Don't fail LED control if logging fails

        # Continue with LED blinking
        if self.no_led_mode:
            # Just run without LED
            while True:
                time.sleep(1)
        else:
            self.set_trigger("none")
            while True:
                self.blink_pattern([(0.05, 0.05)])

    def status_ap_active(self):
        """Special pattern for AP mode active"""
        print("LED Status: AP mode active (triple blink)")
        self.set_trigger("none")
        while True:
            # 3 blinks, then pause
            self.blink_pattern(
                [
                    (0.2, 0.2),
                    (0.2, 0.2),
                    (0.2, 1.0),
                ]
            )

    def status_solid(self):
        """Solid on - system ready"""
        print("LED Status: Solid on")
        self.set_trigger("none")
        self.set_brightness(1)  # ON
        while True:
            time.sleep(60)  # Just keep running

    def daemon_mode(self):
        """Run as systemd daemon, monitoring system state"""
        print("LED Daemon: Starting in daemon mode")

        # Loop to monitor system state
        while True:
            # Check boot stage
            if os.path.exists("/boot/firmware/firstrun.sh"):
                # Still in first boot
                print("LED Daemon: First boot detected")
                self.status_setup()  # Medium blink
            elif not os.path.exists(
                "/var/run/droidnet-configured"
            ) and not os.path.exists("/boot/firmware/droidnet-logs/SETUP_COMPLETE"):
                # Normal boot, not configured yet
                print("LED Daemon: Boot in progress")
                self.status_booting()  # Fast blink
            elif os.path.exists("/var/run/droidnet-boot-complete"):
                # System fully ready
                print("LED Daemon: System ready")
                self.status_solid()  # Solid on
            else:
                # Default to ready pattern
                print("LED Daemon: Default ready state")
                self.status_ready()  # Heartbeat

            # Check every 10 seconds (power optimization)
            # Note: This line won't be reached in normal operation since
            # status methods have their own infinite loops
            time.sleep(10)


def main():
    if len(sys.argv) < 2:
        print("Usage: led_control.py <status>")
        print("Status options: booting, setup, ready, error, ap-active, off, daemon")
        print("Or: led_control.py --boot (starts booting pattern)")
        print("Or: led_control.py --solid (turns LED solid on)")
        print("Or: led_control.py daemon (runs as systemd daemon)")
        sys.exit(1)

    status = sys.argv[1].lower()

    # Handle special arguments
    if status == "--boot":
        status = "booting"
        # Write PID file for systemd
        try:
            with open("/var/run/droidnet-led.pid", "w") as f:
                f.write(str(os.getpid()))
        except (OSError, IOError):
            pass  # Continue even if PID file can't be written
    elif status == "--solid":
        status = "solid"

    try:
        led = LEDController()
        print(f"LED Controller initialized - Pi Zero detected: {led.is_pi_zero}")
    except Exception as e:
        # If LED initialization fails, try to log the error
        error_msg = f"LED initialization failed: {e}\n{traceback.format_exc()}"
        print(error_msg)

        # Try multiple locations for error logging
        log_locations = [
            "/boot/firmware/droidnet-logs/led-init-error.log",
            "/var/log/droidnet/led-init-error.log",
            "/tmp/led-init-error.log",
        ]

        for log_path in log_locations:
            try:
                os.makedirs(os.path.dirname(log_path), exist_ok=True)
                with open(log_path, "w") as f:
                    f.write(f"[{datetime.datetime.now()}] LED Initialization Error\n")
                    f.write(error_msg)
                print(f"Error logged to {log_path}")
                break
            except (OSError, IOError):
                continue

        # Exit with error
        sys.exit(1)

    # Debug info

    try:
        if status == "daemon":
            led.daemon_mode()
        elif status == "booting":
            led.status_booting()
        elif status == "setup":
            led.status_setup()
        elif status == "ready":
            led.status_ready()
        elif status == "solid":
            led.status_solid()
        elif status == "error":
            led.status_error()
        elif status == "ap-active":
            led.status_ap_active()
        elif status == "off":
            print("Turning LED off")
            led.set_brightness(0)
            led.set_trigger("none")
        else:
            print(f"Unknown status: {status}")
            sys.exit(1)
    except KeyboardInterrupt:
        # Reset LED to default (OFF for Pi Zero W)
        led.set_brightness(0)  # Turn OFF
        led.set_trigger("none")  # Keep manual control
        print("\nLED control stopped")


if __name__ == "__main__":
    main()
