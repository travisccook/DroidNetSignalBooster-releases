#!/usr/bin/env python3
"""
MCC Parser - Maestro Control Center XML Import/Export

Standalone module for parsing and generating MCC-compatible XML files.
This module has no dependencies on the web server, making it testable.
"""

import xml.etree.ElementTree as ET
from typing import List, Dict, Optional


def parse_mcc_settings(xml_content: str) -> dict:
    """Parse Maestro Control Center XML export file.

    MCC exports contain:
    - Device settings (serial mode, baud rate, timeouts)
    - Channel configurations with names
    - Sequences (frames with positions and durations)
    - Scripts (source code)

    Args:
        xml_content: Raw XML string from MCC export file

    Returns:
        Dictionary with settings, channels, sequences, and script

    Raises:
        ValueError: If XML is malformed or invalid
    """
    try:
        root = ET.fromstring(xml_content)

        result = {
            "settings": {},
            "channels": [],
            "sequences": [],
            "script": None,
        }

        # Parse device settings
        for setting_name in ["NeverSuspend", "SerialMode", "FixedBaudRate",
                            "SerialTimeout", "EnableCrc", "SerialDeviceNumber",
                            "SerialMiniSscOffset"]:
            elem = root.find(setting_name)
            if elem is not None:
                value = elem.text
                # Convert boolean strings
                if value == "true":
                    value = True
                elif value == "false":
                    value = False
                # Convert numeric strings
                elif value and value.isdigit():
                    value = int(value)
                result["settings"][setting_name] = value

        # Parse channels
        channels_elem = root.find("Channels")
        if channels_elem is not None:
            # Get MiniMaestro-specific attributes
            result["settings"]["MiniMaestroServoPeriod"] = int(
                channels_elem.get("MiniMaestroServoPeriod", "80000")
            )
            result["settings"]["ServoMultiplier"] = int(
                channels_elem.get("ServoMultiplier", "1")
            )

            for idx, ch in enumerate(channels_elem.findall("Channel")):
                channel = {
                    "index": idx,
                    "name": ch.get("name", ""),
                    "mode": ch.get("mode", "Servo"),
                    "min": int(ch.get("min", "3968")),
                    "max": int(ch.get("max", "8000")),
                    "homemode": ch.get("homemode", "Off"),
                    "home": int(ch.get("home", "6000")),
                    "speed": int(ch.get("speed", "0")),
                    "acceleration": int(ch.get("acceleration", "0")),
                    "neutral": int(ch.get("neutral", "6000")),
                    "range": int(ch.get("range", "1905")),
                }
                result["channels"].append(channel)

        # Parse sequences
        sequences_elem = root.find("Sequences")
        if sequences_elem is not None:
            for seq in sequences_elem.findall("Sequence"):
                sequence = {
                    "name": seq.get("name", ""),
                    "frames": [],
                }
                for frame in seq.findall("Frame"):
                    positions_text = frame.text or ""
                    positions = [int(p) for p in positions_text.split() if p]
                    sequence["frames"].append({
                        "name": frame.get("name", ""),
                        "duration": int(frame.get("duration", "500")),
                        "positions": positions,
                    })
                result["sequences"].append(sequence)

        # Parse script
        script_elem = root.find("Script")
        if script_elem is not None and script_elem.text:
            result["script"] = {
                "source": script_elem.text.strip(),
                "done": script_elem.get("ScriptDone") == "true",
            }

        return result

    except ET.ParseError as e:
        raise ValueError(f"Invalid XML format: {e}")
    except Exception as e:
        raise ValueError(f"Error parsing MCC settings: {e}")


def generate_mcc_xml(settings: dict, channels: List[dict],
                     sequences: List[dict], script: Optional[str] = None) -> str:
    """Generate MCC-compatible XML export.

    This creates an XML file that can be imported by Maestro Control Center.

    Args:
        settings: Device settings dict
        channels: List of channel configuration dicts
        sequences: List of sequence dicts with frames
        script: Optional script source code

    Returns:
        XML string compatible with MCC
    """
    root = ET.Element("UscSettings", version="1")

    # Add comment
    root.insert(0, ET.Comment(
        "Pololu Maestro servo controller settings file, "
        "http://www.pololu.com/catalog/product/1350"
    ))

    # Add device settings
    for name, value in settings.items():
        if name in ["MiniMaestroServoPeriod", "ServoMultiplier"]:
            continue  # These go in Channels element
        elem = ET.SubElement(root, name)
        if isinstance(value, bool):
            elem.text = "true" if value else "false"
        else:
            elem.text = str(value)

    # Add channels
    channels_elem = ET.SubElement(root, "Channels",
        MiniMaestroServoPeriod=str(settings.get("MiniMaestroServoPeriod", 80000)),
        ServoMultiplier=str(settings.get("ServoMultiplier", 1))
    )

    for idx, ch in enumerate(channels):
        # Add channel comment
        channels_elem.append(ET.Comment(f"Channel {idx}"))
        ET.SubElement(channels_elem, "Channel",
            name=ch.get("name", ""),
            mode=ch.get("mode", "Servo"),
            min=str(ch.get("min", 3968)),
            max=str(ch.get("max", 8000)),
            homemode=ch.get("homemode", "Off"),
            home=str(ch.get("home", 6000)),
            speed=str(ch.get("speed", 0)),
            acceleration=str(ch.get("acceleration", 0)),
            neutral=str(ch.get("neutral", 6000)),
            range=str(ch.get("range", 1905))
        )

    # Add sequences
    sequences_elem = ET.SubElement(root, "Sequences")
    for seq in sequences:
        seq_elem = ET.SubElement(sequences_elem, "Sequence", name=seq.get("name", ""))
        for frame in seq.get("frames", []):
            frame_elem = ET.SubElement(seq_elem, "Frame",
                name=frame.get("name", ""),
                duration=str(frame.get("duration", 500))
            )
            # Convert positions to space-separated string
            positions = frame.get("positions", [])
            if isinstance(positions, dict):
                # Handle dict format: {"0": 4000, "1": 5000, ...}
                max_ch = max(int(k) for k in positions.keys()) if positions else -1
                pos_list = [str(positions.get(str(i), 0)) for i in range(max_ch + 1)]
            else:
                # Handle list format
                pos_list = [str(p) for p in positions]
            frame_elem.text = " ".join(pos_list)

    # Add script
    script_elem = ET.SubElement(root, "Script", ScriptDone="true")
    if script:
        script_elem.text = script

    # Convert to string with proper formatting
    return ET.tostring(root, encoding="unicode", xml_declaration=False)


def convert_sequences_to_library_format(sequences: List[dict]) -> List[dict]:
    """Convert MCC-parsed sequences to library format.

    MCC format uses position lists, library format uses position dicts.

    Args:
        sequences: Sequences from parse_mcc_settings

    Returns:
        Sequences in library format (with dict positions)
    """
    converted = []
    for seq in sequences:
        converted_frames = []
        for frame in seq.get("frames", []):
            positions = frame.get("positions", [])
            # Convert list to dict with string keys
            positions_dict = {str(i): pos for i, pos in enumerate(positions)}
            converted_frames.append({
                "name": frame.get("name", ""),
                "duration": frame.get("duration", 500),
                "positions": positions_dict
            })
        converted.append({
            "name": seq.get("name", ""),
            "frames": converted_frames
        })
    return converted


if __name__ == "__main__":
    # Example usage
    import sys

    if len(sys.argv) > 1:
        with open(sys.argv[1], 'r') as f:
            content = f.read()

        result = parse_mcc_settings(content)
        print(f"Settings: {result['settings']}")
        print(f"Channels: {len(result['channels'])}")
        print(f"Sequences: {len(result['sequences'])}")
        for seq in result['sequences']:
            print(f"  - {seq['name']}: {len(seq['frames'])} frames")
        if result['script']:
            print(f"Script: {len(result['script']['source'])} chars")
