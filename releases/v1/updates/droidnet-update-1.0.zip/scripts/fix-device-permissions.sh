#!/bin/bash
# DroidNet Device Permission Fixer
# Called by udev when USB devices are connected

DEVICE=$1
DEVPATH=$2
LOGFILE="/var/log/droidnet-permissions.log"

# Ensure log directory exists
mkdir -p "$(dirname "$LOGFILE")"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOGFILE"
}

fix_tty_permissions() {
    local tty_device=$1
    if [[ -c "$tty_device" ]]; then
        chmod 666 "$tty_device" 2>> "$LOGFILE" && \
            log "Fixed permissions for $tty_device" || \
            log "ERROR: Failed to fix permissions for $tty_device"
    fi
}

# Handle different call modes
if [[ "$DEVICE" == "check-tty" ]]; then
    # Called on USB bind - check for any new tty devices
    log "USB bind event - checking for new tty devices"
    
    # Brief delay to allow tty device creation
    sleep 0.5
    
    # Fix any tty devices that need it
    for tty in /dev/ttyUSB* /dev/ttyACM*; do
        if [[ -c "$tty" ]]; then
            # Check if permissions need fixing
            perms=$(stat -c "%a" "$tty" 2>/dev/null)
            if [[ "$perms" != "666" ]]; then
                fix_tty_permissions "$tty"
            fi
        fi
    done
else
    # Direct device specified
    log "Device event for: $DEVICE (devpath: $DEVPATH)"
    
    # If it's already a tty device
    if [[ "$DEVICE" =~ ^tty ]]; then
        fix_tty_permissions "/dev/$DEVICE"
    fi
    
    # For USB devices, wait a moment for tty to appear
    if [[ -n "$DEVPATH" ]]; then
        sleep 0.5
        # Try to find associated tty devices
        for tty in /dev/ttyUSB* /dev/ttyACM*; do
            if [[ -c "$tty" ]]; then
                # Get the device path for this tty
                tty_devpath=$(udevadm info -q path -n "$tty" 2>/dev/null)
                if [[ "$tty_devpath" == *"$DEVPATH"* ]]; then
                    fix_tty_permissions "$tty"
                fi
            fi
        done
    fi
fi

# Notify web server to refresh device list (non-blocking)
if command -v curl &> /dev/null; then
    curl -s -X POST http://localhost/api/devices/refresh \
        --connect-timeout 2 \
        --max-time 5 \
        2>&1 >> "$LOGFILE" &
fi

exit 0