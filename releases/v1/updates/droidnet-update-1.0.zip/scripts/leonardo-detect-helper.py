#!/usr/bin/env python3
"""
Helper script to test Leonardo detection with dynamic port finding
"""
import glob
import sys

# Add parent directory to path
sys.path.insert(0, "/opt/droidnet/scripts")

from firmware_flasher import detect_arduino_board


def find_current_acm_port():
    """Find the current ACM port"""
    ports = sorted(glob.glob("/dev/ttyACM*"))
    if ports:
        return ports[0]
    return None


def main():
    port = find_current_acm_port()
    if not port:
        print("No ACM port found!")
        return

    print(f"Found ACM port: {port}")
    board, config = detect_arduino_board(port)
    print(f"Detected board: {board}")
    print(f"Config: {config}")


if __name__ == "__main__":
    main()
