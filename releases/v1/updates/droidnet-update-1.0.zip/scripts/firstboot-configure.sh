#!/bin/bash
# /opt/droidnet/scripts/firstboot-configure.sh
# DroidNet First Boot Configuration - Runs as systemd service
# This replaces the systemd.run=/boot/firmware/firstrun.sh approach

set -e  # Exit on error
exec 2>&1  # Redirect stderr to stdout

LOG_FILE="/var/log/droidnet/firstboot.log"
MARKER_FILE="/var/lib/droidnet/firstboot-complete"

# Ensure log directory exists
mkdir -p /var/log/droidnet

# Function to log with timestamp
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

# Function to enable a service safely
enable_service() {
    local service="$1"
    log "Enabling $service..."
    if systemctl enable "$service" 2>&1 | tee -a "$LOG_FILE"; then
        log "✓ $service enabled"
    else
        log "✗ Failed to enable $service"
    fi
}

log "=== DroidNet First Boot Configuration Started ==="

# Expand root partition if needed (do this first)
if [ -x /opt/droidnet/scripts/expand-root-partition.sh ]; then
    log "Checking root partition size..."
    /opt/droidnet/scripts/expand-root-partition.sh 2>&1 | tee -a "$LOG_FILE"
else
    log "WARNING: Partition expansion script not found"
fi

# Install esptool dependencies if needed
if [ -x /opt/droidnet/scripts/install-esptool-deps.sh ] && [ ! -f /var/lib/droidnet/esptool-deps-installed ]; then
    log "Installing esptool v5.0.0 dependencies..."
    /opt/droidnet/scripts/install-esptool-deps.sh 2>&1 | tee -a "$LOG_FILE"
elif [ -x /opt/droidnet/scripts/install-esptool-pipx.sh ] && [ ! -f /var/lib/droidnet/esptool-installed ]; then
    # Fallback to pipx method for devices that still have the old script
    log "Installing esptool v5.0.0 via pipx (this may take a while)..."
    nohup /opt/droidnet/scripts/install-esptool-pipx.sh > /var/log/droidnet/esptool-install.log 2>&1 &
    log "esptool installation started in background (PID: $!)"
fi

# Set hostname - default to 'droidnet', only add suffix on collision
log "Setting hostname..."
OLD_HOSTNAME=$(hostname)
NEW_HOSTNAME="droidnet"

# Check if hostname collision detection is available and get available hostname
if [ -x /opt/droidnet/scripts/check-hostname-collision.sh ]; then
    log "Checking for available hostname..."
    # The script returns an available hostname
    AVAILABLE_HOSTNAME=$(/opt/droidnet/scripts/check-hostname-collision.sh "$NEW_HOSTNAME")
    if [ -n "$AVAILABLE_HOSTNAME" ]; then
        NEW_HOSTNAME="$AVAILABLE_HOSTNAME"
        log "Using available hostname: $NEW_HOSTNAME"
    else
        log "WARNING: Hostname check failed, using default with MAC suffix"
        # Use last 4 characters of MAC address (not 5)
        MAC_SUFFIX=$(cat /sys/class/net/wlan0/address 2>/dev/null | tr -d ':' | tail -c 4 | tr '[:lower:]' '[:upper:]')
        if [ -n "$MAC_SUFFIX" ]; then
            NEW_HOSTNAME="droidnet-${MAC_SUFFIX}"
            log "Using MAC-based hostname: $NEW_HOSTNAME"
        else
            log "WARNING: Could not determine MAC address for unique hostname"
            # Use a random suffix as fallback
            RANDOM_SUFFIX=$(tr -dc 'A-Z0-9' < /dev/urandom | head -c 4)
            NEW_HOSTNAME="droidnet-${RANDOM_SUFFIX}"
            log "Using random hostname: $NEW_HOSTNAME"
        fi
    fi
else
    log "Hostname collision detection not available, using default: $NEW_HOSTNAME"
fi

# Update hostname
echo "$NEW_HOSTNAME" > /etc/hostname
hostname "$NEW_HOSTNAME"

# Update /etc/hosts
sed -i "s/127.0.1.1.*$/127.0.1.1\t$NEW_HOSTNAME/" /etc/hosts
if ! grep -q "127.0.1.1" /etc/hosts; then
    echo "127.0.1.1\t$NEW_HOSTNAME" >> /etc/hosts
fi

# Restart services that depend on hostname if they're already running
if systemctl is-active --quiet avahi-daemon; then
    systemctl restart avahi-daemon
fi

log "Hostname changed from $OLD_HOSTNAME to $NEW_HOSTNAME"

# Use the comprehensive hostname script for additional configuration
log "Running comprehensive hostname configuration..."
if [ -x /opt/droidnet/scripts/set-unique-hostname.sh ]; then
    /opt/droidnet/scripts/set-unique-hostname.sh
fi

# Update dhcpcd.conf hostname setting
if [ -f /etc/dhcpcd.conf ]; then
    sed -i 's/^hostname$/hostname droidnet/' /etc/dhcpcd.conf
    grep -q "^hostname" /etc/dhcpcd.conf || echo "hostname droidnet" >> /etc/dhcpcd.conf
fi

# Stage 1: Basic Configuration
log "Stage 1: Basic system configuration..."
(
    # Set timezone
    timedatectl set-timezone UTC || true
    
    # Set system time
    log "Setting system time..."
    timedatectl set-ntp true 2>/dev/null || {
        log "NTP sync failed, setting to build date"
        # BUILD_DATE format is "YYYY-MM-DD HH:MM:SS"
        if [ -f /opt/droidnet/BUILD_DATE ]; then
            BUILD_TIME=$(cat /opt/droidnet/BUILD_DATE)
            # Convert format for date command
            date -s "$BUILD_TIME" 2>/dev/null || {
                log "Failed to set date from BUILD_DATE, trying alternate format"
                # Try setting with explicit format
                date -s "$(echo $BUILD_TIME | sed 's/-/\//g')" || log "Failed to set system time"
            }
        else
            # Fallback to current time if BUILD_DATE is missing
            log "BUILD_DATE file missing, keeping current time"
        fi
    }
    
    # Verify time was set reasonably
    YEAR=$(date +%Y)
    if [ "$YEAR" -lt "2024" ] || [ "$YEAR" -gt "2030" ]; then
        log "WARNING: System time appears incorrect: $(date)"
    fi
    
    # Set root password (already done in build)
    log "Root password already configured during build"
) || log "Stage 1 completed with errors"

# Fix-Plan-10: Check for failed mode switch and recover
check_network_recovery() {
    log "Checking for network recovery needs..."
    
    local mode_file="/boot/firmware/droidnet-mode"
    local state_file="/var/lib/droidnet/network-state"
    
    # If mode is client but state shows failure, force AP
    if [ -f "$mode_file" ] && [ -f "$state_file" ]; then
        local mode=$(cat "$mode_file" 2>/dev/null)
        local state=$(cat "$state_file" 2>/dev/null)
        
        if [ "$mode" = "client" ] && [[ "$state" == *"failed"* ]]; then
            log "Detected failed client mode - forcing AP recovery"
            echo "ap" > "$mode_file"
            rm -f "$state_file"
        fi
    fi
}

# Add this check early in firstboot
check_network_recovery

# Stage 2: Network Configuration
log "Stage 2: Network configuration..."
(
    # Fix-Plan-32: Network is now handled by unified controller
    log "Network configuration delegated to droidnet-network-controller"
    
    # The network controller service should already be enabled by the build process
    if systemctl is-enabled --quiet droidnet-network-controller; then
        log "Network controller already enabled"
    else
        log "Enabling network controller..."
        enable_service droidnet-network-controller
    fi
    
    # Fix-Plan-35: RF-kill unblock handled by dedicated service
    # No need to unblock here
    
    # Fix-Plan-05: Clean any conflicting rfkill state files
    log "Cleaning rfkill state files to prevent conflicts..."
    rm -f /var/lib/systemd/rfkill/*
    
    log "Network configuration stage complete"
) || log "Stage 2 completed with errors"

# Stage 3: Enable DroidNet Services (Priority Order)
log "Stage 3: Enabling DroidNet services..."
(
    # Priority 1: Web Interface (network is handled by controller)
    log "Enabling critical services..."
    enable_service droidnet-web         # Web interface
    
    # Priority 2: Supporting services
    log "Enabling supporting services..."
    enable_service droidnet-monitor
    enable_service droidnet-wifi-monitor
    
    # Priority 3: Optional services (check if binaries exist)
    if [ -f /opt/droidnet/bin/vhusbdarm ] || [ -f /opt/droidnet/bin/vhusbdpin ]; then
        enable_service droidnet-virtualhere
    fi
    
    # LED service for visual feedback
    enable_service droidnet-led
    
    # Boot completion service
    enable_service droidnet-boot-complete
    
    log "Service enablement complete"
) || log "Stage 3 completed with errors"

# Stage 4: Cleanup
log "Stage 4: Cleanup..."
(
    # Create firstboot complete marker
    mkdir -p /var/lib/droidnet
    date > "$MARKER_FILE"
    
    # Disable firstboot service
    systemctl disable droidnet-firstboot || true
    
    log "Firstboot configuration complete"
) || log "Stage 4 completed with errors"

log "=== DroidNet First Boot Configuration Completed ==="