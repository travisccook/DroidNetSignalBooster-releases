#!/usr/bin/env python3
"""
DroidNet Signal Booster - Enhanced Firmware Flasher
Supports Arduino auto-detection and ESP32 binary flashing
"""

import os
import sys
import subprocess
import argparse
import re
import time
import glob
import struct
import json
import shlex

try:
    import serial

    HAS_SERIAL = True
except ImportError:
    HAS_SERIAL = False
from typing import Dict, Optional, Tuple, List

# MCU signatures for Arduino board detection
MCU_SIGNATURES = {
    "1e9516": {"mcu": "atmega328p", "boards": ["uno", "nano"], "default": "uno"},
    "1e9514": {"mcu": "atmega328p", "boards": ["nano"], "default": "nano"},
    "1e9801": {"mcu": "atmega2560", "boards": ["mega"], "default": "mega"},
    "1e9587": {
        "mcu": "atmega32u4",
        "boards": ["leonardo", "micro"],
        "default": "leonardo",
    },
    "1e9489": {"mcu": "atmega32u4", "boards": ["micro"], "default": "micro"},
}

# Board configurations for avrdude
BOARD_CONFIGS = {
    "uno": {"mcu": "atmega328p", "programmer": "arduino", "baud": "115200"},
    "nano": {"mcu": "atmega328p", "programmer": "arduino", "baud": "57600"},
    "mega": {"mcu": "atmega2560", "programmer": "wiring", "baud": "115200"},
    "leonardo": {"mcu": "atmega32u4", "programmer": "avr109", "baud": "57600"},
    "micro": {"mcu": "atmega32u4", "programmer": "avr109", "baud": "57600"},
    "pro": {"mcu": "atmega328p", "programmer": "arduino", "baud": "57600"},
}

# ESP32 configurations
ESP32_CONFIGS = {
    "esp32": {
        "chip": "esp32",
        "baud": "115200",
        "flash_freq": "40m",
        "flash_mode": "dio",
        "flash_size": "4MB",
    },
    "esp32s2": {
        "chip": "esp32s2",
        "baud": "115200",
        "flash_freq": "40m",
        "flash_mode": "qio",
        "flash_size": "4MB",
    },
    "esp32s3": {
        "chip": "esp32s3",
        "baud": "115200",
        "flash_freq": "80m",
        "flash_mode": "qio",
        "flash_size": "8MB",
    },
    "esp32c3": {
        "chip": "esp32c3",
        "baud": "115200",
        "flash_freq": "80m",
        "flash_mode": "qio",
        "flash_size": "4MB",
    },
    # WCB-specific ESP32 configurations
    "wcb": {
        "chip": "esp32",
        "baud": "115200",
        "flash_freq": "40m",
        "flash_mode": "dio",
        "flash_size": "detect",
        "before": "default_reset",
        "after": "hard_reset",
        "no_stub": True,  # Use ROM bootloader directly
    },
    "esp32-pico": {
        "chip": "esp32",
        "baud": "115200",
        "flash_freq": "40m",
        "flash_mode": "dio",
        "flash_size": "detect",
    },
}

# ESP32 binary type detection
ESP32_BINARY_MAGIC = {
    0xE9: "esp32_image",  # ESP32 app/bootloader image
    0xAA: "partition_table",  # Partition table magic (0xAA50)
    0xFF: "ota_data",  # OTA data (usually starts with 0xFF)
}

# Standard ESP32 flash offsets
ESP32_FLASH_OFFSETS = {
    "bootloader": 0x1000,
    "partition_table": 0x8000,
    "otadata": 0xE000,
    "app": 0x10000,  # Default, can vary based on partition table
    "factory": 0x10000,
    "ota_0": 0x10000,  # These are common but need partition table parsing
    "ota_1": 0x150000,
    "spiffs": 0x290000,
    "nvs": 0x9000,
}


def analyze_esp32_binary(file_path: str) -> Dict[str, any]:
    """Analyze an ESP32 binary file to determine its type and characteristics"""
    try:
        with open(file_path, "rb") as f:
            # Check if this is a merged binary by looking for bootloader at 0x1000
            # First check if file is large enough to contain merged content
            f.seek(0, 2)  # Seek to end
            file_size = f.tell()
            f.seek(0)  # Back to start

            # Merged binaries are typically > 100KB (contain bootloader + app)
            if file_size > 100000:
                # Check for bootloader magic at offset 0x1000
                f.seek(0x1000)
                bootloader_magic = f.read(1)

                if bootloader_magic == b"\xe9":
                    # This looks like a merged binary
                    # Verify by checking for partition table at 0x8000
                    f.seek(0x8000)
                    partition_header = f.read(2)

                    if partition_header == b"\xaa\x50":  # Partition table magic
                        return {
                            "type": "merged_binary",
                            "size": file_size,
                            "contains": ["bootloader", "partitions", "application"],
                            "flash_offset": 0x0,
                            "message": "Complete ESP32 firmware package",
                        }

            # Not merged, analyze as single binary
            f.seek(0)
            header = f.read(4096)

            if len(header) < 16:
                return {"type": "unknown", "error": "File too small"}

            # Check magic byte
            magic = header[0]

            # ESP32 image header (app or bootloader)
            if magic == 0xE9:
                # Parse image header
                segments = header[1]
                entry_addr = struct.unpack("<I", header[4:8])[0]

                # Determine if bootloader or app based on entry address
                if entry_addr < 0x40000000:
                    return {
                        "type": "bootloader",
                        "entry_point": hex(entry_addr),
                        "segments": segments,
                        "suggested_offset": ESP32_FLASH_OFFSETS["bootloader"],
                    }
                else:
                    # Check for OTA or factory app
                    f.seek(0, 2)  # Seek to end
                    file_size = f.tell()

                    return {
                        "type": "application",
                        "entry_point": hex(entry_addr),
                        "segments": segments,
                        "size": file_size,
                        "suggested_offset": ESP32_FLASH_OFFSETS["app"],
                    }

            # Partition table
            elif header[0:2] == b"\xaa\x50":
                partitions = parse_partition_table(header)
                return {
                    "type": "partition_table",
                    "partitions": partitions,
                    "suggested_offset": ESP32_FLASH_OFFSETS["partition_table"],
                }

            # OTA data
            elif header[0:8] == b"\xff" * 8:
                # Check for OTADATA marker
                if b"OTADATA" in header:
                    return {
                        "type": "ota_data",
                        "suggested_offset": ESP32_FLASH_OFFSETS["otadata"],
                    }

            # Check if it's a merged binary (contains multiple images)
            if b"\xE9" in header and b"\xaa\x50" in header:
                return {
                    "type": "merged_binary",
                    "contains": ["bootloader", "partition_table", "app"],
                    "suggested_offset": 0x0,  # Merged binaries start at 0
                }

            return {"type": "unknown", "magic": hex(magic)}

    except (IOError, OSError, struct.error, ValueError) as e:
        return {"type": "error", "error": str(e)}


def parse_partition_table(data: bytes) -> List[Dict]:
    """Parse ESP32 partition table binary"""
    partitions = []
    offset = 0

    while offset < len(data) - 32:
        if data[offset : offset + 2] == b"\xaa\x50":
            # Found partition entry
            try:
                (
                    magic,
                    type_val,
                    subtype,
                    part_offset,
                    size,
                    name_bytes,
                    flags,
                ) = struct.unpack("<2sBBII20sI", data[offset : offset + 32])

                if type_val != 0xFF:  # Valid partition
                    name = name_bytes.decode("utf-8").strip("\x00")

                    # Partition type names
                    type_names = {0: "app", 1: "data"}
                    subtype_names = {
                        # App subtypes
                        0x00: "factory",
                        0x10: "ota_0",
                        0x11: "ota_1",
                        0x20: "test",
                        # Data subtypes
                        0x01: "nvs",
                        0x02: "phy",
                        0x80: "spiffs",
                        0x81: "fat",
                    }

                    partition_info = {
                        "name": name,
                        "type": type_names.get(type_val, f"type_{type_val}"),
                        "subtype": subtype_names.get(subtype, f"subtype_{subtype}"),
                        "offset": part_offset,
                        "size": size,
                        "flags": flags,
                    }
                    partitions.append(partition_info)
            except (struct.error, ValueError, UnicodeDecodeError):
                pass

        offset += 32

    return partitions


def detect_missing_esp32_binaries(
    detected_binaries: Dict[str, Dict], partition_info: Optional[List[Dict]] = None
) -> Dict[str, List]:
    """Identify missing ESP32 binaries needed for complete flash"""
    missing = []
    warnings = []
    recommendations = []

    # Check for bootloader
    has_bootloader = any(
        b.get("type") == "bootloader" for b in detected_binaries.values()
    )
    if not has_bootloader:
        missing.append(
            {
                "component": "bootloader",
                "critical": True,
                "offset": ESP32_FLASH_OFFSETS["bootloader"],
                "description": "ESP32 bootloader required for device to boot",
            }
        )

    # Check for partition table
    has_partition = any(
        b.get("type") == "partition_table" for b in detected_binaries.values()
    )
    if not has_partition:
        missing.append(
            {
                "component": "partition_table",
                "critical": True,
                "offset": ESP32_FLASH_OFFSETS["partition_table"],
                "description": "Partition table defines memory layout",
            }
        )

    # Check for OTA data if partition table indicates OTA
    if partition_info:
        has_ota_partitions = any("ota" in p.get("subtype", "") for p in partition_info)
        has_ota_data = any(
            b.get("type") == "ota_data" for b in detected_binaries.values()
        )

        if has_ota_partitions and not has_ota_data:
            missing.append(
                {
                    "component": "ota_data",
                    "critical": True,
                    "offset": ESP32_FLASH_OFFSETS["otadata"],
                    "description": (
                        "OTA data (boot_app0.bin) required for OTA-enabled apps"
                    ),
                }
            )

    # Check for application
    has_app = any(b.get("type") == "application" for b in detected_binaries.values())
    if not has_app:
        warnings.append("No application binary provided")

    # Recommendations
    if missing:
        recommendations.append(
            "Consider using a complete firmware package or merged binary"
        )
        recommendations.append(
            "Missing binaries can be extracted from ESP32 development tools"
        )

    return {
        "missing": missing,
        "warnings": warnings,
        "recommendations": recommendations,
    }


def locate_system_binary(component: str, chip_type: str = "esp32") -> Optional[str]:
    """Locate system binary files in the esp32_binaries directory"""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    binaries_dir = os.path.join(script_dir, "esp32_binaries")

    search_patterns = {
        "bootloader": [
            f"bootloader_{chip_type}.bin",
            "bootloader_dio_40m.bin",
            "bootloader.bin",
        ],
        "partition_table": ["default_4MB.bin", "partitions.bin", "default.bin"],
        "ota_data": ["boot_app0.bin", "ota_data_initial.bin"],
    }

    patterns = search_patterns.get(component, [])

    for pattern in patterns:
        # Check in specific subdirectory
        subdir = {
            "bootloader": "bootloaders",
            "partition_table": "partitions",
            "ota_data": "ota",
        }.get(component, "")

        file_path = os.path.join(binaries_dir, subdir, pattern)
        if os.path.exists(file_path):
            print(f"Found system binary: {file_path}")
            return file_path

    return None


def create_flash_map_from_binaries(
    binary_files: Dict[str, str], chip_type: str = "esp32", auto_locate: bool = True
) -> Dict[int, str]:
    """Create a flash offset map from analyzed binary files"""
    flash_map = {}
    partition_info = None

    # First pass: analyze all binaries
    analyzed = {}
    for name, file_path in binary_files.items():
        analysis = analyze_esp32_binary(file_path)
        analyzed[name] = analysis

        # Extract partition info if found
        if analysis.get("type") == "partition_table":
            partition_info = analysis.get("partitions", [])

    # Second pass: assign offsets
    for name, analysis in analyzed.items():
        file_path = binary_files[name]

        if analysis["type"] == "bootloader":
            flash_map[ESP32_FLASH_OFFSETS["bootloader"]] = file_path
        elif analysis["type"] == "partition_table":
            flash_map[ESP32_FLASH_OFFSETS["partition_table"]] = file_path
        elif analysis["type"] == "ota_data":
            flash_map[ESP32_FLASH_OFFSETS["otadata"]] = file_path
        elif analysis["type"] == "application":
            # Determine app offset from partition table if available
            app_offset = ESP32_FLASH_OFFSETS["app"]

            if partition_info:
                # Find first app partition
                for partition in partition_info:
                    if partition["type"] == "app":
                        app_offset = partition["offset"]
                        break

            flash_map[app_offset] = file_path
        elif analysis["type"] == "merged_binary":
            # Merged binary contains everything, flash from offset 0
            flash_map[0x0] = file_path
            break  # Don't process other files if we have a merged binary

    # Auto-locate missing system binaries if enabled
    if auto_locate and analysis.get("type") != "merged_binary":
        missing_info = detect_missing_esp32_binaries(analyzed, partition_info)

        for missing in missing_info["missing"]:
            component = missing["component"]
            offset = missing["offset"]

            # Try to locate system binary
            system_binary = locate_system_binary(component, chip_type)
            if system_binary:
                print(f"Auto-located {component}: {os.path.basename(system_binary)}")
                flash_map[offset] = system_binary
            else:
                print(f"Warning: Could not auto-locate {component}")

    return flash_map


def detect_file_type(file_path: str) -> str:
    """Detect whether file is Arduino hex or ESP32 binary"""
    try:
        with open(file_path, "rb") as f:
            # Read first few bytes
            header = f.read(16)

            # Intel HEX files start with ':' (0x3A)
            if header[0:1] == b":":
                return "hex"

            # ESP32 binaries have magic byte 0xE9 at start
            elif header[0:1] == b"\xe9":
                return "esp32"

            # Additional check - hex files are ASCII text
            try:
                header.decode("ascii")
                if ":" in header.decode("ascii"):
                    return "hex"
            except UnicodeDecodeError:
                pass

            # Default to binary for ESP32
            return "esp32"

    except (IOError, OSError, UnicodeDecodeError) as e:
        print(f"Error detecting file type: {e}")
        return "unknown"


def reset_leonardo_bootloader(device_port: str) -> Optional[str]:
    """Reset Leonardo/Pro Micro into bootloader mode using 1200 baud touch."""
    if not HAS_SERIAL:
        return None

    # Check if port exists
    if not os.path.exists(device_port):
        print(f"Port {device_port} does not exist")
        return None

    try:
        # Touch at 1200 baud to trigger bootloader
        ser = serial.Serial(device_port, 1200)
        ser.setDTR(False)
        time.sleep(0.1)
        ser.close()

        # Wait for bootloader
        time.sleep(2)

        # Find available ACM ports (Leonardo uses CDC ACM)
        for i in range(10):
            ports = sorted(glob.glob("/dev/ttyACM*"))
            if ports:
                # Return first available port (usually same as original)
                return ports[0]
            time.sleep(0.5)

    except (serial.SerialException, OSError) as e:
        print(f"Leonardo reset failed: {e}")

    return None


def read_mcu_signature(device_port: str, board_hint: str = None) -> Optional[str]:
    """Read MCU signature from Arduino board"""
    # For Leonardo/Micro boards on ACM ports, try special handling first
    if "ttyACM" in device_port and board_hint != "skip_leonardo":
        # Try Leonardo protocol first
        cmd = [
            "avrdude",
            "-c",
            "avr109",
            "-p",
            "m32u4",
            "-P",
            device_port,
            "-b",
            "57600",
            "-U",
            "signature:r:-:h",
            "-v",
        ]

        try:
            # Quick attempt without reset
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=2)
            if result.returncode == 0:
                # Extract signature
                match = re.search(
                    r"device signature = 0x([0-9a-fA-F]{6})",
                    result.stderr,
                    re.IGNORECASE,
                )
                if match:
                    return match.group(1).lower()
        except (subprocess.TimeoutExpired, subprocess.CalledProcessError):
            pass

        # Try with reset
        print("Attempting Leonardo bootloader reset...")
        bootloader_port = reset_leonardo_bootloader(device_port)
        if bootloader_port:
            cmd[5] = bootloader_port  # Update port
            try:
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=3)
                if result.returncode == 0:
                    match = re.search(
                        r"device signature = 0x([0-9a-fA-F]{6})",
                        result.stderr,
                        re.IGNORECASE,
                    )
                    if match:
                        return match.group(1).lower()
            except (subprocess.TimeoutExpired, subprocess.CalledProcessError):
                pass

    # Standard detection for other boards
    cmd = [
        "avrdude",
        "-c",
        "arduino",
        "-p",
        "m328p",  # Use generic ATmega328P
        "-P",
        device_port,
        "-b",
        "115200",
        "-U",
        "signature:r:-:h",
        "-v",
    ]

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=3)

        # Look for signature in output
        for line in result.stderr.split("\n"):
            if "signature" in line.lower() and "0x" in line:
                # Extract hex values
                hex_values = re.findall(r"0x([0-9a-fA-F]{2})", line)
                if len(hex_values) >= 3:
                    signature = "".join(hex_values[:3]).lower()
                    return signature

        # Alternative pattern
        match = re.search(r"Device signature = 0x([0-9a-fA-F]{6})", result.stderr)
        if match:
            return match.group(1).lower()

    except subprocess.TimeoutExpired:
        print("Timeout reading MCU signature")
    except (subprocess.CalledProcessError, OSError) as e:
        print(f"Error reading signature: {e}")

    return None


def detect_arduino_board(device_port: str) -> Tuple[str, Dict]:
    """Auto-detect Arduino board type by reading MCU signature"""
    print(f"Detecting Arduino board on {device_port}...")

    # For ACM ports, try Leonardo detection first without the standard loop
    if "ttyACM" in device_port:
        signature = read_mcu_signature(device_port)
        if signature:
            print(f"MCU signature: 0x{signature}")

            # Look up board type from signature
            if signature in MCU_SIGNATURES:
                sig_info = MCU_SIGNATURES[signature]
                board_type = sig_info["default"]
                print(f"Detected MCU: {sig_info['mcu']}")
                print(f"Compatible boards: {', '.join(sig_info['boards'])}")
                print(f"Using board type: {board_type}")
                return board_type, BOARD_CONFIGS[board_type]
    else:
        # Try different baud rates for non-ACM ports
        baud_rates = ["115200", "57600", "9600"]

        for baud in baud_rates:
            signature = read_mcu_signature(device_port, board_hint="skip_leonardo")
            if signature:
                print(f"MCU signature: 0x{signature}")

                # Look up board type from signature
                if signature in MCU_SIGNATURES:
                    sig_info = MCU_SIGNATURES[signature]
                    board_type = sig_info["default"]
                    print(f"Detected MCU: {sig_info['mcu']}")
                    print(f"Compatible boards: {', '.join(sig_info['boards'])}")
                    print(f"Using board type: {board_type}")
                    return board_type, BOARD_CONFIGS[board_type]

    # If detection fails, try common boards by testing communication
    print("Could not read MCU signature, trying common board types...")

    test_boards = ["uno", "nano", "mega", "leonardo"]
    for board_type in test_boards:
        config = BOARD_CONFIGS[board_type]

        test_port = device_port

        # Special handling for Leonardo/Micro
        if board_type in ["leonardo", "micro"] and "ttyACM" in device_port:
            print(f"Trying {board_type} with bootloader reset...")
            bootloader_port = reset_leonardo_bootloader(device_port)
            if bootloader_port:
                test_port = bootloader_port
            else:
                continue

        cmd = [
            "avrdude",
            "-C",
            "/etc/avrdude.conf",
            "-p",
            config["mcu"],
            "-c",
            config["programmer"],
            "-P",
            test_port,
            "-b",
            config["baud"],
            "-n",  # No-write mode, just test connection
        ]

        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=3)
            if result.returncode == 0:
                print(f"Successfully connected as {board_type}")
                return board_type, config
        except (subprocess.TimeoutExpired, subprocess.CalledProcessError):
            continue

    print("Warning: Could not auto-detect board type")
    return "unknown", {}


def execute_esptool_command(cmd, timeout=10):
    """Execute esptool command with proper handling for script vs binary"""
    # Check if esptool is a script that needs shell execution
    use_shell = False
    if (
        os.path.exists("/usr/local/bin/esptool")
        and len(cmd) > 0
        and (cmd[0] == "esptool" or cmd[0] == "/usr/local/bin/esptool")
    ):
        try:
            with open("/usr/local/bin/esptool", "rb") as f:
                first_bytes = f.read(2)
                if first_bytes == b"#!":  # Shebang indicates script
                    use_shell = True
        except (OSError, IOError):
            pass

    try:
        if use_shell:
            # For script-based esptool, use shell execution
            cmd_str = " ".join(shlex.quote(arg) for arg in cmd)
            result = subprocess.run(
                cmd_str, shell=True, capture_output=True, text=True, timeout=timeout
            )
        else:
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=timeout
            )
        return result
    except subprocess.TimeoutExpired:
        return None
    except OSError as e:
        if e.errno == 8:  # Exec format error
            # Retry with shell=True as fallback
            try:
                cmd_str = " ".join(shlex.quote(arg) for arg in cmd)
                result = subprocess.run(
                    cmd_str, shell=True, capture_output=True, text=True, timeout=timeout
                )
                return result
            except (subprocess.CalledProcessError, OSError):
                pass
        return None


def detect_esp32_chip(device_port: str, retry_count: int = 2) -> Tuple[str, Dict]:
    """Auto-detect ESP32 chip type with retry logic"""
    print(f"Detecting ESP32 chip on {device_port}...")

    for attempt in range(retry_count + 1):
        try:
            # Add a small delay between attempts to let the board settle
            if attempt > 0:
                print(f"Retry attempt {attempt}/{retry_count}...")
                time.sleep(1)

            # Run esptool chip detection
            # Use new esptool if available
            esptool_cmd = (
                "/usr/local/bin/esptool"
                if os.path.exists("/usr/local/bin/esptool")
                else "esptool.py"
            )
            chip_id_cmd = (
                "chip-id" if os.path.exists("/usr/local/bin/esptool") else "chip_id"
            )

            cmd = [esptool_cmd, "--port", device_port, chip_id_cmd]
            result = execute_esptool_command(cmd, timeout=10)

            if result is None:
                if attempt < retry_count:
                    print("Error: esptool execution failed, retrying...")
                    continue
                else:
                    print("Error: esptool execution failed after all retries")
                    return "unknown", {}

            if result.returncode == 0:
                output = result.stdout + result.stderr
                output_lower = output.lower()

                # Detect chip type from output
                if "esp32-s3" in output_lower:
                    chip_type = "esp32s3"
                elif "esp32-s2" in output_lower:
                    chip_type = "esp32s2"
                elif "esp32-c3" in output_lower:
                    chip_type = "esp32c3"
                elif "esp32-pico" in output_lower:
                    chip_type = "esp32"
                    print("Detected ESP32-PICO variant (WCB board)")
                elif "esp32" in output_lower:
                    chip_type = "esp32"
                else:
                    # Cannot identify chip type - don't proceed
                    print("\nERROR: Unable to identify ESP32 chip type")
                    print("Output:", output)
                    return "unidentified", {}

                print(f"Detected ESP32 chip: {chip_type}")
                return chip_type, ESP32_CONFIGS[chip_type]

        except FileNotFoundError:
            print(f"Error: {esptool_cmd} not found. Install: pip install esptool")
            return "error", {}
        except subprocess.TimeoutExpired:
            if attempt < retry_count:
                print("Timeout detecting ESP32 chip, retrying...")
                continue
            else:
                print("Timeout detecting ESP32 chip after all retries")
                return "unknown", {}
        except (subprocess.CalledProcessError, OSError, ValueError) as e:
            if attempt < retry_count:
                print(f"Error detecting ESP32: {e}, retrying...")
                continue
            else:
                print(f"Error detecting ESP32 after all retries: {e}")
                return "unknown", {}

    # If we get here, all attempts failed
    print("No ESP32 chip detected on this port after all attempts")
    return "unknown", {}


def flash_arduino(
    hex_file: str, device_port: str, board_type: str = None, config: Dict = None
):
    """Flash Arduino firmware using avrdude"""
    if not board_type or board_type == "unknown":
        # Try auto-detection
        board_type, config = detect_arduino_board(device_port)
        if board_type == "unknown":
            return {"success": False, "message": "Could not detect Arduino board type"}

    if not config and board_type in BOARD_CONFIGS:
        config = BOARD_CONFIGS[board_type]

    print(f"\nFlashing Arduino {board_type} on {device_port}...")

    flash_port = device_port

    # Special handling for Leonardo/Micro boards
    if board_type in ["leonardo", "micro"] and "ttyACM" in device_port:
        print("Resetting Leonardo/Micro into bootloader mode...")
        bootloader_port = reset_leonardo_bootloader(device_port)
        if bootloader_port:
            flash_port = bootloader_port
            print(f"Using bootloader port: {flash_port}")
        else:
            print("Warning: Could not reset Leonardo, trying anyway...")

    # Build avrdude command
    cmd = [
        "avrdude",
        "-C",
        "/etc/avrdude.conf",
        "-v",
        "-p",
        config["mcu"],
        "-c",
        config["programmer"],
        "-P",
        flash_port,
        "-b",
        config["baud"],
        "-D",  # Disable auto erase
        "-U",
        f"flash:w:{hex_file}:i",
    ]

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)

        if result.returncode == 0:
            return {
                "success": True,
                "message": f"Successfully flashed {board_type}",
                "output": result.stderr,  # avrdude outputs to stderr
            }
        else:
            return {
                "success": False,
                "message": f"Flash failed for {board_type}",
                "output": result.stderr,
            }

    except subprocess.TimeoutExpired:
        return {"success": False, "message": "Flash operation timed out"}
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired, OSError) as e:
        return {"success": False, "message": f"Flash error: {str(e)}"}


def flash_esp32_multiple(
    binary_files: Dict[str, str],
    device_port: str,
    chip_type: str = None,
    config: Dict = None,
):
    """Flash multiple ESP32 binaries to their correct offsets"""
    if not chip_type:
        chip_type, config = detect_esp32_chip(device_port)
        if chip_type == "error":
            return {"success": False, "message": "esptool.py not installed"}

    if not config and chip_type in ESP32_CONFIGS:
        config = ESP32_CONFIGS[chip_type]

    # If we still don't have config, use default ESP32 config
    if not config:
        if chip_type == "unknown":
            print("Warning: Using default ESP32 settings")
            chip_type = "esp32"
            config = ESP32_CONFIGS["esp32"]
        else:
            return {
                "success": False,
                "message": (f"No configuration available for chip type: {chip_type}"),
            }

    print(f"\nFlashing ESP32 ({chip_type}) on {device_port}...")

    # Create flash map from binaries
    flash_map = create_flash_map_from_binaries(binary_files, chip_type)

    if not flash_map:
        return {"success": False, "message": "No valid ESP32 binaries found"}

    # Check for missing critical components
    analyzed = {name: analyze_esp32_binary(path) for name, path in binary_files.items()}
    missing_info = detect_missing_esp32_binaries(analyzed)

    if missing_info["missing"]:
        print("\nWarning: Missing critical components:")
        for missing in missing_info["missing"]:
            print(f"  - {missing['component']}: {missing['description']}")

        # For now, continue with warning - in future could try to locate system binaries
        print("\nContinuing with partial flash - device may not boot properly!")

    # Build esptool command with all binaries
    esptool_cmd = (
        "/usr/local/bin/esptool"
        if os.path.exists("/usr/local/bin/esptool")
        else "esptool.py"
    )

    cmd = [
        esptool_cmd,
        "--chip",
        config["chip"],
        "--port",
        device_port,
        "--baud",
        config["baud"],
    ]

    # Add reset options if specified
    if "before" in config:
        cmd.extend(["--before", config["before"]])
    if "after" in config:
        cmd.extend(["--after", config["after"]])

    # Add no-stub option for problematic boards
    if config.get("no_stub", False):
        cmd.append("--no-stub")

    cmd.extend(
        [
            "write_flash",
            "-z",  # Compress
            "--flash_mode",
            config["flash_mode"],
            "--flash_freq",
            config["flash_freq"],
            "--flash_size",
            config["flash_size"],
        ]
    )

    # Add each binary with its offset
    for offset, file_path in sorted(flash_map.items()):
        cmd.extend([hex(offset), file_path])
        print(f"  Will flash {os.path.basename(file_path)} to {hex(offset)}")

    try:
        # First, try to connect
        print("\nConnecting to ESP32...")
        esptool_cmd = (
            "/usr/local/bin/esptool"
            if os.path.exists("/usr/local/bin/esptool")
            else "esptool.py"
        )
        chip_id_cmd = (
            "chip-id" if os.path.exists("/usr/local/bin/esptool") else "chip_id"
        )
        test_cmd = [esptool_cmd, "--port", device_port, chip_id_cmd]
        test_result = execute_esptool_command(test_cmd, timeout=10)

        if test_result is None:
            return {
                "success": False,
                "message": "Failed to execute esptool - check installation",
            }

        # Check if it's the WCB "unknown ESP32" case
        wcb_board = "unknown esp32" in (test_result.stdout + test_result.stderr).lower()

        if test_result.returncode != 0 and not wcb_board:
            # Try to enter bootloader mode automatically
            print("Initial connection failed, attempting to enter bootloader mode...")
            if enter_bootloader_mode(device_port):
                print("Bootloader mode sequence sent, retrying connection...")
                test_result = execute_esptool_command(test_cmd, timeout=10)
                if test_result is None:
                    return {
                        "success": False,
                        "message": "Failed to execute esptool after bootloader mode",
                    }
                if test_result.returncode != 0:
                    return {
                        "success": False,
                        "message": (
                            "Could not connect to ESP32. "
                            "Try pressing BOOT button during connection."
                        ),
                        "output": test_result.stderr,
                    }
            else:
                return {
                    "success": False,
                    "message": (
                        "Could not connect to ESP32. "
                        "Check connections and try pressing BOOT button."
                    ),
                    "output": test_result.stderr,
                }

        if wcb_board:
            print("Detected WCB board")

        # Flash the firmware
        print("Erasing flash and writing firmware...")
        result = execute_esptool_command(cmd, timeout=120)

        if result is None:
            return {
                "success": False,
                "message": "Failed to execute esptool flash command",
            }

        if result.returncode == 0:
            flash_summary = f"Flashed {len(flash_map)} components"
            if missing_info["missing"]:
                flash_summary += (
                    f" (Warning: {len(missing_info['missing'])} components missing)"
                )

            return {
                "success": True,
                "message": (
                    f"Successfully flashed ESP32 ({chip_type}) - {flash_summary}"
                ),
                "output": result.stdout,
                "flash_map": {hex(k): v for k, v in flash_map.items()},
                "missing": missing_info,
            }
        else:
            return {
                "success": False,
                "message": "ESP32 flash failed",
                "output": result.stderr,
            }

    except subprocess.TimeoutExpired:
        return {"success": False, "message": "Flash operation timed out"}
    except FileNotFoundError:
        return {
            "success": False,
            "message": "esptool.py not found. Install with: pip install esptool",
        }
    except (subprocess.CalledProcessError, OSError, ValueError) as e:
        return {"success": False, "message": f"Flash error: {str(e)}"}


def enter_bootloader_mode(device_port: str) -> bool:
    """Try to enter ESP32 bootloader mode using Arduino-style reset"""
    if not HAS_SERIAL:
        return False

    try:
        # Use Arduino IDE reset sequence
        # This sequence works for most ESP32 boards with auto-reset circuit
        ser = serial.Serial(device_port)
        ser.setDTR(False)  # IO0=HIGH
        ser.setRTS(True)  # EN=LOW (hold in reset)
        time.sleep(0.1)
        ser.setDTR(True)  # IO0=LOW (bootloader mode)
        ser.setRTS(False)  # EN=HIGH (release reset)
        time.sleep(0.05)
        ser.setDTR(False)  # IO0=HIGH (normal mode)
        ser.close()

        # Give bootloader time to start
        time.sleep(0.5)
        return True
    except (serial.SerialException, OSError) as e:
        print(f"Auto-reset failed: {e}")
        return False


def flash_esp32_with_address(
    bin_file: str, device_port: str, flash_address: str, chip_type: str = None
):
    """Flash ESP32 firmware to a specific address"""
    config = None
    if not chip_type:
        chip_type, config = detect_esp32_chip(device_port)
        if chip_type == "error":
            return {"success": False, "message": "esptool.py not installed"}

    if not config and chip_type in ESP32_CONFIGS:
        config = ESP32_CONFIGS[chip_type]

    # If we still don't have config, use default ESP32 config
    if not config:
        if chip_type == "unknown" or chip_type is None:
            print("Warning: Using default ESP32 settings")
            chip_type = "esp32"
            config = ESP32_CONFIGS["esp32"]
        else:
            return {
                "success": False,
                "message": f"No configuration available for chip type: {chip_type}",
            }

    print(f"Flashing {bin_file} to {flash_address} on {device_port}")

    # Convert flash address string to int
    try:
        if flash_address.startswith("0x") or flash_address.startswith("0X"):
            address = int(flash_address, 16)
        else:
            address = int(flash_address)
    except ValueError:
        return {"success": False, "message": f"Invalid flash address: {flash_address}"}

    # Flash map would be: {address: bin_file}
    # But we build the command directly instead

    # Build esptool command
    # Use new esptool if available
    esptool_cmd = (
        "/usr/local/bin/esptool"
        if os.path.exists("/usr/local/bin/esptool")
        else "esptool.py"
    )

    cmd = [esptool_cmd, "--chip", chip_type, "--port", device_port]

    # Add baud rate if specified
    if config and "baud" in config:
        cmd.extend(["--baud", str(config["baud"])])

    # Add write_flash command
    cmd.append("write_flash")

    # Add flash mode and size if specified
    if config:
        if "flash_mode" in config:
            cmd.extend(["--flash_mode", config["flash_mode"]])
        if "flash_size" in config:
            cmd.extend(["--flash_size", config["flash_size"]])
        if "flash_freq" in config:
            cmd.extend(["--flash_freq", config["flash_freq"]])

    # Add file with address
    cmd.extend([str(address), bin_file])

    print(f"Flashing command: {' '.join(cmd)}")

    try:
        # Execute flash command - esptool will handle reset sequence
        result = execute_esptool_command(cmd, timeout=120)

        if result is None:
            return {
                "success": False,
                "message": "Flash operation failed - could not execute esptool",
            }

        # Check for fatal errors in output even if return code is 0
        combined_output = result.stdout + result.stderr
        if (
            "fatal error occurred" in combined_output.lower()
            or "timed out" in combined_output.lower()
        ):
            return {
                "success": False,
                "message": "Flash failed - ESP32 communication error",
                "output": combined_output,
            }

        if result.returncode == 0:
            return {
                "success": True,
                "message": f"ESP32 firmware flashed successfully to {flash_address}",
                "output": result.stdout,
            }
        else:
            return {
                "success": False,
                "message": "Flash failed",
                "output": result.stderr or result.stdout,
            }

    except FileNotFoundError:
        return {
            "success": False,
            "message": "esptool.py not found. Please install: pip install esptool",
        }
    except (subprocess.CalledProcessError, OSError, ValueError) as e:
        return {"success": False, "message": f"Flash error: {str(e)}"}


def flash_esp32(
    bin_file: str, device_port: str, chip_type: str = None, config: Dict = None
):
    """Flash ESP32 firmware using esptool.py - legacy single file support"""
    # Check if this is a merged binary or just application
    analysis = analyze_esp32_binary(bin_file)

    if analysis.get("type") == "merged_binary":
        # Flash merged binary from address 0x0
        return flash_esp32_with_address(bin_file, device_port, "0x0", chip_type)
    else:
        # Single binary - try to flash as app only
        print(f"Single binary detected: {analysis.get('type', 'unknown')}")

        if analysis.get("type") not in ["application", "unknown"]:
            print(
                f"Warning: File appears to be {analysis['type']}, "
                f"not an application binary"
            )

        # Use multi-flash function with single file
        return flash_esp32_multiple({"app": bin_file}, device_port, chip_type, config)


def flash_firmware(
    firmware_file: str,
    device_port: str,
    board_type: str = None,
    additional_files: Optional[Dict[str, str]] = None,
    flash_address: Optional[str] = None,
):
    """Main function to flash firmware - auto-detects file type and board

    Args:
        firmware_file: Main firmware file (.hex or .bin)
        device_port: Serial device port
        board_type: Optional board type override
        additional_files: Optional dict of additional binary files for ESP32
                          e.g., {'bootloader': 'bootloader.bin',
                                 'partitions': 'partitions.bin'}
    """

    # Check file exists
    if not os.path.exists(firmware_file):
        return {
            "success": False,
            "message": f"Firmware file not found: {firmware_file}",
        }

    # Check device port exists
    if not os.path.exists(device_port):
        return {"success": False, "message": f"Device port not found: {device_port}"}

    # Detect file type
    file_type = detect_file_type(firmware_file)
    print(f"Detected file type: {file_type}")

    if file_type == "hex":
        # Arduino hex file
        return flash_arduino(firmware_file, device_port, board_type)
    elif file_type == "esp32":
        # ESP32 binary file(s)
        if additional_files:
            # Multiple files provided - use enhanced multi-flash
            all_files = {"main": firmware_file}
            all_files.update(additional_files)
            return flash_esp32_multiple(all_files, device_port)
        else:
            # Single file - check if we have a specific flash address
            if flash_address:
                # Use the provided flash address
                return flash_esp32_with_address(
                    firmware_file, device_port, flash_address, board_type
                )
            else:
                # Use legacy mode with auto-detection
                return flash_esp32(firmware_file, device_port)
    else:
        return {"success": False, "message": "Unknown firmware file type"}


def main():
    """Command line interface"""
    parser = argparse.ArgumentParser(description="Flash Arduino or ESP32 firmware")
    parser.add_argument("firmware_file", help="Path to firmware file (.hex or .bin)")
    parser.add_argument("device_port", help="Serial device port (e.g., /dev/ttyUSB0)")
    parser.add_argument(
        "-b",
        "--board",
        help="Force specific board type",
        choices=list(BOARD_CONFIGS.keys()) + list(ESP32_CONFIGS.keys()),
    )
    parser.add_argument(
        "-d",
        "--detect-only",
        action="store_true",
        help="Only detect board type, do not flash",
    )
    parser.add_argument("--bootloader", help="ESP32 bootloader binary")
    parser.add_argument("--partitions", help="ESP32 partition table binary")
    parser.add_argument("--otadata", help="ESP32 OTA data binary")
    parser.add_argument(
        "--analyze",
        action="store_true",
        help="Analyze ESP32 binary files without flashing",
    )

    args = parser.parse_args()

    if args.analyze:
        # Analyze binary files
        print(f"Analyzing {args.firmware_file}...")
        analysis = analyze_esp32_binary(args.firmware_file)
        print(f"Main file: {json.dumps(analysis, indent=2)}")

        # Analyze additional files if provided
        if args.bootloader:
            print(f"\nAnalyzing bootloader {args.bootloader}...")
            print(json.dumps(analyze_esp32_binary(args.bootloader), indent=2))
        if args.partitions:
            print(f"\nAnalyzing partition table {args.partitions}...")
            pt_analysis = analyze_esp32_binary(args.partitions)
            print(json.dumps(pt_analysis, indent=2))
            if pt_analysis.get("partitions"):
                print("\nPartition Layout:")
                for p in pt_analysis["partitions"]:
                    print(
                        f"  {p['name']:12} {p['type']:6} {p['subtype']:8} "
                        f"@ {hex(p['offset']):10} size: {p['size']:10}"
                    )

        sys.exit(0)

    if args.detect_only:
        # Just detect and report
        file_type = detect_file_type(args.firmware_file)
        print(f"File type: {file_type}")

        if file_type == "hex":
            board_type, config = detect_arduino_board(args.device_port)
            if board_type != "unknown":
                print(f"Detected Arduino board: {board_type}")
                print(f"Configuration: {config}")
            else:
                print("Could not detect Arduino board type")
        elif file_type == "esp32":
            # Analyze the binary
            analysis = analyze_esp32_binary(args.firmware_file)
            print(f"Binary analysis: {json.dumps(analysis, indent=2)}")

            # Detect chip
            chip_type, config = detect_esp32_chip(args.device_port)
            print(f"Detected ESP32 chip: {chip_type}")
            print(f"Configuration: {config}")

        sys.exit(0)

    # Prepare additional files for ESP32
    additional_files = {}
    if args.bootloader:
        additional_files["bootloader"] = args.bootloader
    if args.partitions:
        additional_files["partitions"] = args.partitions
    if args.otadata:
        additional_files["otadata"] = args.otadata

    # Flash firmware
    result = flash_firmware(
        args.firmware_file, args.device_port, args.board, additional_files
    )

    if result["success"]:
        print(f"\n✓ {result['message']}")
        if "flash_map" in result:
            print("\nFlashed components:")
            for offset, file in result["flash_map"].items():
                print(f"  {offset}: {os.path.basename(file)}")
        if "missing" in result and result["missing"].get("missing"):
            print("\n⚠ Warning: Missing components may prevent proper boot")
    else:
        print(f"\n✗ {result['message']}")
        if "output" in result and result["output"]:
            print("\nDetailed output:")
            print(result["output"])
        sys.exit(1)


if __name__ == "__main__":
    main()
