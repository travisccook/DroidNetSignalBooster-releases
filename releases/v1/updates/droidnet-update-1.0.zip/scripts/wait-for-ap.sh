#!/bin/bash
# Wait for network mode (AP or Client) to be fully active before starting

MAX_WAIT=60
WAIT_COUNT=0

while [ $WAIT_COUNT -lt $MAX_WAIT ]; do
    # Check if network state file exists
    if [ -f /var/lib/droidnet/network-state ]; then
        STATE=$(cat /var/lib/droidnet/network-state)
        # Accept either ap_active OR client_active states
        if [ "$STATE" = "ap_active" ] || [ "$STATE" = "client_active" ]; then
            echo "[$(date)] Network is active in $STATE mode" | logger -t droidnet-web
            exit 0
        fi
    fi
    
    # Also check if hostapd is running and has AP-ENABLED status
    if systemctl is-active --quiet hostapd && journalctl -u hostapd -n 50 | grep -q "AP-ENABLED"; then
        echo "[$(date)] hostapd reports AP enabled" | logger -t droidnet-web
        exit 0
    fi
    
    sleep 2
    WAIT_COUNT=$((WAIT_COUNT + 2))
done

echo "[$(date)] Timeout waiting for network mode after ${MAX_WAIT} seconds" | logger -t droidnet-web
exit 1