#!/usr/bin/env python3
"""
DroidNet Device Permission Monitor
Monitors USB device connections and ensures proper permissions
"""

import os
import sys
import time
import logging
import subprocess
import signal
from pathlib import Path

try:
    import pyudev
except ImportError:
    print(
        "ERROR: pyudev not installed. Installing it during provisioning.",
        file=sys.stderr,
    )
    sys.exit(1)

# Configure logging
LOG_FILE = "/var/log/droidnet-device-monitor.log"
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[logging.FileHandler(LOG_FILE), logging.StreamHandler()],
)

logger = logging.getLogger(__name__)


class DevicePermissionMonitor:
    def __init__(self):
        self.context = pyudev.Context()
        self.monitor = pyudev.Monitor.from_netlink(self.context)
        self.monitor.filter_by(subsystem="tty")
        self.running = True

    def fix_device_permissions(self, device_path):
        """Fix permissions for a serial device"""
        try:
            # Check if device exists
            if not os.path.exists(device_path):
                return False

            # Get current permissions
            current_perms = oct(os.stat(device_path).st_mode)[-3:]

            # Fix if needed
            if current_perms != "666":
                os.chmod(device_path, 0o666)
                logger.info(
                    f"Fixed permissions for {device_path}: {current_perms} -> 666"
                )
                return True
            else:
                logger.debug(f"Permissions already correct for {device_path}")
                return False

        except Exception as e:
            logger.error(f"Failed to fix permissions for {device_path}: {e}")
            return False

    def notify_web_server(self):
        """Notify web server to refresh device list"""
        try:
            # Use subprocess to avoid blocking
            subprocess.Popen(
                [
                    "curl",
                    "-s",
                    "-X",
                    "POST",
                    "http://localhost/api/devices/refresh",
                    "--connect-timeout",
                    "2",
                    "--max-time",
                    "5",
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        except Exception as e:
            logger.debug(f"Failed to notify web server: {e}")

    def check_existing_devices(self):
        """Check and fix permissions for existing devices on startup"""
        logger.info("Checking existing serial devices...")
        fixed_count = 0

        # Check all ttyUSB and ttyACM devices
        for pattern in ["/dev/ttyUSB*", "/dev/ttyACM*"]:
            for device_path in Path("/dev").glob(pattern.split("/")[-1]):
                if self.fix_device_permissions(str(device_path)):
                    fixed_count += 1

        if fixed_count > 0:
            logger.info(f"Fixed permissions for {fixed_count} existing devices")
            self.notify_web_server()
        else:
            logger.info("All existing devices have correct permissions")

    def handle_device_event(self, device):
        """Handle device add/change events"""
        if device.action in ["add", "change"] and device.device_node:
            device_path = device.device_node

            # Only handle ttyUSB and ttyACM devices
            if "/dev/ttyUSB" in device_path or "/dev/ttyACM" in device_path:
                logger.info(f"Device event: {device.action} - {device_path}")

                # Small delay to ensure device is fully initialized
                time.sleep(0.5)

                # Fix permissions
                if self.fix_device_permissions(device_path):
                    self.notify_web_server()

                    # Log device details for debugging
                    try:
                        parent = device.find_parent("usb", "usb_device")
                        if parent:
                            vendor = parent.get("ID_VENDOR_ID", "unknown")
                            product = parent.get("ID_MODEL_ID", "unknown")
                            logger.info(f"Device info: VID={vendor}, PID={product}")
                    except Exception:
                        pass

    def signal_handler(self, signum, frame):
        """Handle shutdown signals"""
        logger.info("Received shutdown signal, stopping monitor...")
        self.running = False

    def run(self):
        """Main monitoring loop"""
        # Set up signal handlers
        signal.signal(signal.SIGTERM, self.signal_handler)
        signal.signal(signal.SIGINT, self.signal_handler)

        logger.info("DroidNet Device Permission Monitor starting...")

        # Check existing devices first
        self.check_existing_devices()

        # Start monitoring for new devices
        logger.info("Monitoring for device changes...")

        # Use poll with timeout to allow for clean shutdown
        while self.running:
            try:
                device = self.monitor.poll(timeout=1)
                if device:
                    self.handle_device_event(device)
            except KeyboardInterrupt:
                break
            except Exception as e:
                logger.error(f"Error in monitor loop: {e}")
                time.sleep(1)  # Prevent rapid error loops

        logger.info("Device Permission Monitor stopped")


def main():
    """Main entry point"""
    monitor = DevicePermissionMonitor()

    try:
        monitor.run()
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
