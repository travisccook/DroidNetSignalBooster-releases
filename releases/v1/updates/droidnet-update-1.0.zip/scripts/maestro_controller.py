#!/usr/bin/env python3
"""
Pololu Maestro Serial Controller
Implements Compact and Pololu protocols for real-time servo control
"""

import serial
import struct
import logging
import threading
from typing import Optional, List, Tuple
from enum import IntEnum

from config.constants import BAUD_RATE_MAESTRO, TIMEOUT_SERIAL_DEFAULT

logger = logging.getLogger(__name__)


class MaestroCommand(IntEnum):
    """Maestro Compact Protocol command bytes"""
    SET_TARGET = 0x84
    SET_MULTIPLE_TARGETS = 0x9F  # Mini only
    SET_SPEED = 0x87
    SET_ACCELERATION = 0x89
    SET_PWM = 0x8A  # Mini only
    GET_POSITION = 0x90
    GET_MOVING_STATE = 0x93  # Mini only
    GET_ERRORS = 0xA1
    GO_HOME = 0xA2
    STOP_SCRIPT = 0xA4
    RESTART_SCRIPT = 0xA7
    RESTART_SCRIPT_AT_SUBROUTINE = 0xA7
    GET_SCRIPT_STATUS = 0xAE


class MaestroError(IntEnum):
    """Maestro error bit flags"""
    SERIAL_SIGNAL = 0x0001
    SERIAL_OVERRUN = 0x0002
    SERIAL_BUFFER_FULL = 0x0004
    SERIAL_CRC = 0x0008
    SERIAL_PROTOCOL = 0x0010
    SERIAL_TIMEOUT = 0x0020
    SCRIPT_STACK = 0x0040
    SCRIPT_CALL_STACK = 0x0080
    SCRIPT_PROGRAM_COUNTER = 0x0100


class MaestroController:
    """
    Serial controller for Pololu Maestro servo controllers.

    Uses Compact Protocol by default (single device).
    Supports Pololu Protocol for daisy-chained devices.

    Target values are in quarter-microseconds:
    - 4000 = 1000µs (typical minimum)
    - 6000 = 1500µs (center/neutral)
    - 8000 = 2000µs (typical maximum)
    - 0 = disable PWM output
    """

    def __init__(
        self,
        port: str,
        device_number: Optional[int] = None,
        baud: int = BAUD_RATE_MAESTRO,
        timeout: float = TIMEOUT_SERIAL_DEFAULT
    ):
        """
        Initialize Maestro controller.

        Args:
            port: Serial port path (e.g., '/dev/ttyACM0')
            device_number: Device ID for Pololu Protocol (None = Compact Protocol)
            baud: Baud rate (default 9600, can use higher with UART)
            timeout: Read timeout in seconds
        """
        self.port = port
        self.device_number = device_number
        self.baud = baud
        self.timeout = timeout
        self.serial: Optional[serial.Serial] = None
        self.max_channels: int = 24  # Default to max, can be set after detection
        self._serial_lock = threading.Lock()  # Thread safety for serial operations
        self._use_pololu_protocol = device_number is not None

    def connect(self) -> bool:
        """Open serial connection to Maestro."""
        try:
            self.serial = serial.Serial(
                port=self.port,
                baudrate=self.baud,
                timeout=self.timeout,
                write_timeout=self.timeout
            )
            logger.info(f"Connected to Maestro on {self.port}")
            return True
        except serial.SerialException as e:
            logger.error(f"Failed to connect to Maestro: {e}")
            return False

    def disconnect(self):
        """Close serial connection."""
        if self.serial and self.serial.is_open:
            self.serial.close()
            logger.info(f"Disconnected from Maestro on {self.port}")

    def _encode_target(self, value: int) -> Tuple[int, int]:
        """
        Encode 14-bit target value into two 7-bit bytes.

        Args:
            value: Target in quarter-microseconds (0-16383)

        Returns:
            Tuple of (low_byte, high_byte)
        """
        value = max(0, min(16383, value))  # Clamp to 14 bits
        low = value & 0x7F
        high = (value >> 7) & 0x7F
        return (low, high)

    def _build_command(self, cmd: int, data: bytes = b'') -> bytes:
        """
        Build command packet using Compact or Pololu Protocol.

        Args:
            cmd: Command byte (0x80-0xFF range)
            data: Additional data bytes

        Returns:
            Complete command packet
        """
        if self._use_pololu_protocol:
            # Pololu Protocol: 0xAA, device_number, command (MSB cleared), data
            return bytes([0xAA, self.device_number, cmd & 0x7F]) + data
        else:
            # Compact Protocol: command, data
            return bytes([cmd]) + data

    def _send_command(self, cmd: int, data: bytes = b'') -> bool:
        """Send command to Maestro (thread-safe)."""
        if not self.serial or not self.serial.is_open:
            logger.error("Serial port not connected")
            return False

        try:
            with self._serial_lock:
                packet = self._build_command(cmd, data)
                self.serial.write(packet)
            return True
        except serial.SerialException as e:
            logger.error(f"Failed to send command: {e}")
            return False

    def _read_response(self, length: int) -> Optional[bytes]:
        """Read response bytes from Maestro (thread-safe)."""
        if not self.serial or not self.serial.is_open:
            return None

        try:
            with self._serial_lock:
                # Response bytes are full 8-bit (not 7-bit encoded)
                data = self.serial.read(length)
            if len(data) < length:
                logger.warning(f"Short read: expected {length}, got {len(data)}")
                return None
            return data
        except serial.SerialException as e:
            logger.error(f"Failed to read response: {e}")
            return None

    # ─────────────────────────────────────────────────────────────────
    # Servo Control Commands
    # ─────────────────────────────────────────────────────────────────

    def _validate_channel(self, channel: int) -> bool:
        """Validate channel number against device limits."""
        if channel < 0 or channel >= self.max_channels:
            logger.error(f"Invalid channel {channel}: must be 0-{self.max_channels - 1}")
            return False
        return True

    def set_target(self, channel: int, target: int) -> bool:
        """
        Set servo target position.

        Args:
            channel: Channel number (0-23 depending on model)
            target: Position in quarter-microseconds (4000-8000 typical)
                    Use 0 to disable PWM output

        Returns:
            True if command sent successfully
        """
        if not self._validate_channel(channel):
            return False
        low, high = self._encode_target(target)
        data = bytes([channel, low, high])
        return self._send_command(MaestroCommand.SET_TARGET, data)

    def set_target_microseconds(self, channel: int, microseconds: float) -> bool:
        """
        Set servo target in microseconds (convenience method).

        Args:
            channel: Channel number
            microseconds: Pulse width in microseconds (500-2500 typical)
        """
        target = int(microseconds * 4)  # Convert to quarter-microseconds
        return self.set_target(channel, target)

    def set_multiple_targets(
        self,
        first_channel: int,
        targets: List[int]
    ) -> bool:
        """
        Set multiple contiguous channel targets in one command.

        Mini Maestro only - more efficient than individual set_target calls.

        Args:
            first_channel: Starting channel number
            targets: List of target values for consecutive channels
        """
        num_targets = len(targets)
        data = bytes([num_targets, first_channel])

        for target in targets:
            low, high = self._encode_target(target)
            data += bytes([low, high])

        return self._send_command(MaestroCommand.SET_MULTIPLE_TARGETS, data)

    def set_speed(self, channel: int, speed: int) -> bool:
        """
        Set servo speed limit.

        Args:
            channel: Channel number
            speed: Speed limit (0 = unlimited, 1 = slowest)
                   Units: 0.25µs per 10ms
                   Example: speed=140 means 3.5µs/ms = 1000µs/286ms
        """
        if not self._validate_channel(channel):
            return False
        low, high = self._encode_target(speed)
        data = bytes([channel, low, high])
        return self._send_command(MaestroCommand.SET_SPEED, data)

    def set_acceleration(self, channel: int, acceleration: int) -> bool:
        """
        Set servo acceleration limit.

        Args:
            channel: Channel number
            acceleration: Acceleration limit (0 = unlimited, 1 = slowest)
                         Units: 0.25µs per 10ms per 80ms
        """
        if not self._validate_channel(channel):
            return False
        low, high = self._encode_target(acceleration)
        data = bytes([channel, low, high])
        return self._send_command(MaestroCommand.SET_ACCELERATION, data)

    def set_pwm(self, on_time: int, period: int) -> bool:
        """
        Set PWM output parameters (Mini Maestro only).

        Args:
            on_time: PWM on time in units of 1/48 µs
            period: PWM period in units of 1/48 µs

        Returns:
            True if command sent successfully
        """
        on_low, on_high = self._encode_target(on_time)
        period_low, period_high = self._encode_target(period)
        data = bytes([on_low, on_high, period_low, period_high])
        return self._send_command(MaestroCommand.SET_PWM, data)

    def get_position(self, channel: int) -> Optional[int]:
        """
        Get current servo position.

        Returns the actual position, which may differ from target
        if speed/acceleration limits are active.

        Args:
            channel: Channel number

        Returns:
            Position in quarter-microseconds, or None on error
        """
        if not self._validate_channel(channel):
            return None
        if not self._send_command(MaestroCommand.GET_POSITION, bytes([channel])):
            return None

        response = self._read_response(2)
        if response is None:
            return None

        # Response is little-endian 16-bit integer
        return struct.unpack('<H', response)[0]

    def get_position_microseconds(self, channel: int) -> Optional[float]:
        """Get current position in microseconds."""
        pos = self.get_position(channel)
        return pos / 4.0 if pos is not None else None

    def get_moving_state(self) -> Optional[bool]:
        """
        Check if any servos are still moving to their targets.

        Mini Maestro only. May be unreliable on Micro Maestro.

        Returns:
            True if servos are moving, False if at targets, None on error
        """
        if not self._send_command(MaestroCommand.GET_MOVING_STATE):
            return None

        response = self._read_response(1)
        if response is None:
            return None

        return response[0] != 0

    def go_home(self) -> bool:
        """
        Send all servos to their home positions.

        Home positions are configured via native USB.
        """
        return self._send_command(MaestroCommand.GO_HOME)

    # ─────────────────────────────────────────────────────────────────
    # Error Handling
    # ─────────────────────────────────────────────────────────────────

    def get_errors(self) -> Optional[int]:
        """
        Get and clear error flags.

        Returns:
            Bitmask of MaestroError flags, or None on error
        """
        if not self._send_command(MaestroCommand.GET_ERRORS):
            return None

        response = self._read_response(2)
        if response is None:
            return None

        return struct.unpack('<H', response)[0]

    def get_error_list(self) -> List[str]:
        """Get list of current error names."""
        errors = self.get_errors()
        if errors is None:
            return ["Communication error"]

        error_names = []
        for error in MaestroError:
            if errors & error.value:
                error_names.append(error.name)

        return error_names if error_names else []

    # ─────────────────────────────────────────────────────────────────
    # Script Control
    # ─────────────────────────────────────────────────────────────────

    def stop_script(self) -> bool:
        """Stop currently running script."""
        return self._send_command(MaestroCommand.STOP_SCRIPT)

    def restart_script(self) -> bool:
        """Restart script from the beginning."""
        return self._send_command(MaestroCommand.RESTART_SCRIPT, bytes([0]))

    def restart_script_at_subroutine(self, subroutine: int) -> bool:
        """
        Start script at a specific subroutine.

        Enables host-triggered script subroutines.

        Args:
            subroutine: Subroutine number (0-127)
        """
        return self._send_command(
            MaestroCommand.RESTART_SCRIPT_AT_SUBROUTINE,
            bytes([subroutine])
        )

    def get_script_status(self) -> Optional[bool]:
        """
        Check if a script is running.

        Returns:
            True if script is running, False if stopped, None on error
        """
        if not self._send_command(MaestroCommand.GET_SCRIPT_STATUS):
            return None

        response = self._read_response(1)
        if response is None:
            return None

        return response[0] != 0  # Non-zero = running, 0 = stopped

    # ─────────────────────────────────────────────────────────────────
    # Convenience Methods
    # ─────────────────────────────────────────────────────────────────

    def center_servo(self, channel: int) -> bool:
        """Move servo to center position (1500µs)."""
        return self.set_target(channel, 6000)

    def disable_servo(self, channel: int) -> bool:
        """Disable PWM output on channel."""
        return self.set_target(channel, 0)

    def is_connected(self) -> bool:
        """Check if serial connection is active."""
        return self.serial is not None and self.serial.is_open


# ─────────────────────────────────────────────────────────────────────
# Context Manager Support
# ─────────────────────────────────────────────────────────────────────

class MaestroConnection:
    """Context manager for MaestroController connections."""

    def __init__(self, port: str, **kwargs):
        self.controller = MaestroController(port, **kwargs)

    def __enter__(self) -> MaestroController:
        if not self.controller.connect():
            raise ConnectionError(f"Failed to connect to {self.controller.port}")
        return self.controller

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.controller.disconnect()
        return False
