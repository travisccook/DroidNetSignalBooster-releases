#!/bin/bash
#
# Expand root partition to use full SD card
# Safe for Raspberry Pi systems
#

set -e

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
   echo "This script must be run as root"
   exit 1
fi

# Get the root partition info
ROOT_PART=$(findmnt -n -o SOURCE /)
ROOT_DEV=$(lsblk -n -o PKNAME $ROOT_PART)
ROOT_PART_NUM=$(echo $ROOT_PART | grep -o '[0-9]*$')

echo "=== Current Partition Layout ==="
fdisk -l /dev/$ROOT_DEV

echo -e "\n=== Current Filesystem Usage ==="
df -h /

# Get partition start sector
PART_START=$(fdisk -l /dev/$ROOT_DEV | grep "^$ROOT_PART" | awk '{print $2}')

echo -e "\n=== Expanding Partition ==="
echo "Root partition: $ROOT_PART"
echo "Root device: /dev/$ROOT_DEV"
echo "Partition number: $ROOT_PART_NUM"
echo "Partition start: $PART_START"

# Confirm before proceeding
read -p "This will expand $ROOT_PART to use all available space. Continue? [y/N] " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Aborted."
    exit 1
fi

# Use sfdisk to resize the partition
echo "Resizing partition..."
echo ", +" | sfdisk -N $ROOT_PART_NUM /dev/$ROOT_DEV --force

# Reload partition table
partprobe /dev/$ROOT_DEV

# Resize the filesystem
echo -e "\n=== Resizing Filesystem ==="
resize2fs $ROOT_PART

echo -e "\n=== New Partition Layout ==="
fdisk -l /dev/$ROOT_DEV

echo -e "\n=== New Filesystem Usage ==="
df -h /

echo -e "\n=== Expansion Complete! ==="
echo "No reboot required - filesystem is already expanded."