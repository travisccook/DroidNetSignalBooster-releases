#!/usr/bin/env python3
"""
DroidNet Discovery Service

Ensures at least one DroidNet device on the network is accessible at
droidnet.local, providing a predictable entry point for users.

Key behaviors:
- On startup, probe for existing droidnet.local
- If unreachable, claim the alias via avahi-publish
- Periodically re-check in case the owner goes offline
- Release gracefully on shutdown

Can run as:
- Daemon: python3 droidnet_discovery.py (default)
- Oneshot: python3 droidnet_discovery.py --check
"""

import argparse
import logging
import os
import random
import signal
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from config.constants import RUNTIME_DIR

# Configuration
ALIAS_NAME = "droidnet.local"
PROBE_INTERVAL = 30  # Seconds between checks when not owner
OWNER_CHECK_INTERVAL = 60  # Seconds between checks when owner (verify still working)
CLAIM_DELAY_BASE = 3  # Base seconds to wait before claiming
CLAIM_DELAY_JITTER = 4  # Random jitter to avoid simultaneous claims
STARTUP_DELAY = 10  # Seconds to wait on startup for network to settle
STATE_FILE = RUNTIME_DIR / "discovery-state.json"

# Exponential backoff configuration for claim failures
BACKOFF_INITIAL = 5  # Initial backoff delay in seconds
BACKOFF_MULTIPLIER = 2  # Multiply delay by this on each failure
BACKOFF_MAX = 300  # Maximum backoff delay (5 minutes)
BACKOFF_RESET_AFTER = 600  # Reset backoff after this many seconds of success

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("droidnet_discovery")


class DiscoveryService:
    """Manages claiming and releasing the droidnet.local alias."""

    def __init__(self):
        self.publisher_process: Optional[subprocess.Popen] = None
        self.is_owner = False
        self.running = True
        self.own_ip: Optional[str] = None
        self.own_hostname: Optional[str] = None

        # Exponential backoff state
        self.backoff_delay = 0  # Current backoff delay (0 = no backoff)
        self.last_claim_failure: float = 0  # Timestamp of last failure
        self.last_successful_claim: float = 0  # Timestamp of last success

    def get_own_ip(self) -> Optional[str]:
        """Get our IP address on wlan0."""
        try:
            result = subprocess.run(
                ["ip", "-4", "addr", "show", "wlan0"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            for line in result.stdout.split("\n"):
                if "inet " in line:
                    # Format: inet 192.168.4.1/24 brd ...
                    return line.split()[1].split("/")[0]
        except (subprocess.TimeoutExpired, Exception) as e:
            logger.warning(f"Failed to get own IP: {e}")
        return None

    def get_own_hostname(self) -> str:
        """Get our actual hostname."""
        try:
            result = subprocess.run(
                ["hostname"], capture_output=True, text=True, timeout=5
            )
            return result.stdout.strip()
        except Exception as e:
            logger.warning(f"Failed to get hostname: {e}")
            return "unknown"

    def probe_alias(self) -> Optional[str]:
        """
        Check if droidnet.local exists on the network.
        Returns the IP address if found, None otherwise.
        """
        try:
            result = subprocess.run(
                ["avahi-resolve", "-n", "-4", ALIAS_NAME],
                capture_output=True,
                text=True,
                timeout=3,
            )
            if result.returncode == 0 and result.stdout.strip():
                # Output format: "droidnet.local\t192.168.x.x"
                parts = result.stdout.strip().split()
                if len(parts) >= 2:
                    resolved_ip = parts[-1]
                    logger.debug(f"Probed {ALIAS_NAME} -> {resolved_ip}")
                    return resolved_ip
        except subprocess.TimeoutExpired:
            logger.debug(f"Probe for {ALIAS_NAME} timed out")
        except Exception as e:
            logger.warning(f"Probe failed: {e}")
        return None

    def claim_alias(self) -> bool:
        """
        Start advertising droidnet.local pointing to our IP.
        Returns True if successful.
        """
        if self.publisher_process:
            logger.debug("Already have publisher process running")
            return True

        self.own_ip = self.get_own_ip()
        if not self.own_ip:
            logger.error("Cannot get own IP address, not claiming alias")
            return False

        try:
            # -a: publish address record
            # -R: no reverse lookup (allows multiple hosts with same IP)
            # Use DEVNULL for stdout/stderr to avoid pipe buffer blocking
            self.publisher_process = subprocess.Popen(
                ["avahi-publish", "-a", "-R", ALIAS_NAME, self.own_ip],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
            )

            # Give it a moment to start
            time.sleep(0.5)

            # Check if it's still running (didn't immediately fail)
            if self.publisher_process.poll() is not None:
                _, stderr = self.publisher_process.communicate()
                logger.error(f"avahi-publish failed: {stderr.decode()}")
                self.publisher_process = None
                return False

            self.is_owner = True
            self.own_hostname = self.get_own_hostname()
            logger.info(
                f"Claimed {ALIAS_NAME} -> {self.own_ip} (hostname: {self.own_hostname})"
            )

            # Also update dnsmasq for AP mode if applicable
            self._update_dnsmasq(claim=True)

            return True

        except Exception as e:
            logger.error(f"Failed to start avahi-publish: {e}")
            self.publisher_process = None
            return False

    def release_alias(self):
        """Stop advertising droidnet.local."""
        if self.publisher_process:
            logger.info(f"Releasing {ALIAS_NAME}")
            try:
                self.publisher_process.terminate()
                self.publisher_process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.publisher_process.kill()
                self.publisher_process.wait()
            except Exception as e:
                logger.warning(f"Error terminating publisher: {e}")

            self.publisher_process = None
            self.is_owner = False

            # Remove dnsmasq entry
            self._update_dnsmasq(claim=False)

    def _is_ap_mode(self) -> bool:
        """Check if we're currently in AP mode."""
        mode_file = Path("/boot/firmware/droidnet-mode")
        try:
            if mode_file.exists():
                return mode_file.read_text().strip().lower() == "ap"
        except Exception as e:
            logger.debug(f"Error reading mode file: {e}")
        return False

    def _update_dnsmasq(self, claim: bool):
        """
        Update dnsmasq configuration for client mode only.

        In AP mode, the network-controller.sh already adds an entry for
        droidnet.local, so we skip updates to avoid duplication.
        In client mode, dnsmasq isn't running, so this is a no-op anyway.
        """
        # Skip in AP mode - network-controller handles droidnet.local there
        if self._is_ap_mode():
            logger.debug("Skipping dnsmasq update in AP mode (handled by network-controller)")
            return

        dnsmasq_conf = Path("/etc/dnsmasq.d/droidnet-discovery.conf")

        try:
            if claim and self.own_ip:
                # Add entry (mainly useful if dnsmasq is running in client mode)
                dnsmasq_conf.write_text(f"address=/{ALIAS_NAME}/{self.own_ip}\n")
                logger.debug("Added dnsmasq entry")
            else:
                # Remove entry
                if dnsmasq_conf.exists():
                    dnsmasq_conf.unlink()
                    logger.debug("Removed dnsmasq entry")

            # Reload dnsmasq if it's running
            result = subprocess.run(
                ["systemctl", "is-active", "dnsmasq"],
                capture_output=True,
                text=True,
            )
            if result.stdout.strip() == "active":
                subprocess.run(
                    ["systemctl", "reload", "dnsmasq"],
                    capture_output=True,
                    check=False,
                )
                logger.debug("Reloaded dnsmasq")

        except PermissionError:
            logger.debug("No permission to update dnsmasq (normal in client mode)")
        except Exception as e:
            logger.warning(f"Failed to update dnsmasq: {e}")

    def check_publisher_health(self) -> bool:
        """
        Verify our publisher process is still running.
        Also reaps zombie processes via poll().
        """
        if self.publisher_process is None:
            return False

        # poll() returns None if still running, exit code if terminated
        # This also reaps the zombie process
        exit_code = self.publisher_process.poll()
        if exit_code is not None:
            # Process died - log and clean up
            logger.warning(f"Publisher process exited with code {exit_code}")
            self.publisher_process = None
            self.is_owner = False
            return False

        return True

    def _get_backoff_delay(self) -> float:
        """
        Get the current backoff delay, resetting if enough time has passed
        since the last failure.
        """
        now = time.time()

        # Reset backoff if we've been successful long enough
        if self.last_successful_claim > 0:
            time_since_success = now - self.last_successful_claim
            if time_since_success > BACKOFF_RESET_AFTER:
                self.backoff_delay = 0
                return 0

        # Reset backoff if it's been a long time since last failure
        if self.last_claim_failure > 0:
            time_since_failure = now - self.last_claim_failure
            if time_since_failure > BACKOFF_RESET_AFTER:
                self.backoff_delay = 0
                return 0

        return self.backoff_delay

    def _record_claim_failure(self):
        """Record a claim failure and increase backoff delay."""
        self.last_claim_failure = time.time()
        if self.backoff_delay == 0:
            self.backoff_delay = BACKOFF_INITIAL
        else:
            self.backoff_delay = min(self.backoff_delay * BACKOFF_MULTIPLIER, BACKOFF_MAX)
        logger.info(f"Claim failed, backoff delay now {self.backoff_delay}s")

    def _record_claim_success(self):
        """Record a successful claim and reset backoff."""
        self.last_successful_claim = time.time()
        if self.backoff_delay > 0:
            logger.info("Claim succeeded, resetting backoff")
            self.backoff_delay = 0

    def run_once(self) -> dict:
        """
        Run a single check cycle. Useful for debugging.
        Returns status dict.
        """
        self.own_ip = self.get_own_ip()
        self.own_hostname = self.get_own_hostname()
        resolved_ip = self.probe_alias()

        status = {
            "own_ip": self.own_ip,
            "own_hostname": self.own_hostname,
            "alias": ALIAS_NAME,
            "resolved_ip": resolved_ip,
            "is_available": resolved_ip is None,
            "we_own_it": resolved_ip == self.own_ip if resolved_ip else False,
        }

        return status

    def run(self):
        """Main service loop."""
        logger.info("DroidNet Discovery Service starting...")

        # Initial delay for network to settle
        logger.info(f"Waiting {STARTUP_DELAY}s for network to settle...")
        time.sleep(STARTUP_DELAY)

        # Get initial state
        self.own_hostname = self.get_own_hostname()
        logger.info(f"Our hostname: {self.own_hostname}")

        # If our hostname is already "droidnet", we don't need to do anything special
        # as we're already the canonical droidnet.local
        if self.own_hostname.lower() == "droidnet":
            logger.info(
                "Our hostname is 'droidnet' - we are the canonical droidnet.local"
            )
            # Still run the loop to handle any edge cases, but we won't claim
            # since avahi already handles this

        while self.running:
            try:
                self.own_ip = self.get_own_ip()
                if not self.own_ip:
                    logger.warning("No IP address on wlan0, waiting...")
                    time.sleep(PROBE_INTERVAL)
                    continue

                resolved_ip = self.probe_alias()

                if resolved_ip is None:
                    # No one owns it - we should claim it
                    if not self.is_owner:
                        # Check if we're in backoff period
                        backoff = self._get_backoff_delay()
                        if backoff > 0:
                            logger.debug(f"In backoff period, waiting {backoff}s")
                            time.sleep(backoff)
                            continue

                        # Wait with jitter to avoid races
                        delay = CLAIM_DELAY_BASE + random.uniform(0, CLAIM_DELAY_JITTER)
                        logger.info(
                            f"{ALIAS_NAME} not found, claiming in {delay:.1f}s..."
                        )
                        time.sleep(delay)

                        # Re-check in case someone else claimed during delay
                        if self.probe_alias() is None:
                            if self.claim_alias():
                                self._record_claim_success()
                            else:
                                self._record_claim_failure()

                elif resolved_ip == self.own_ip:
                    # We own it
                    if not self.is_owner:
                        # We own it but didn't know - probably from previous run
                        logger.info(f"We already own {ALIAS_NAME}")
                        self.is_owner = True
                        self._record_claim_success()

                    # Verify our publisher is healthy
                    if not self.check_publisher_health():
                        logger.warning("Publisher process died, reclaiming...")
                        self.publisher_process = None
                        self.is_owner = False
                        if self.claim_alias():
                            self._record_claim_success()
                        else:
                            self._record_claim_failure()

                else:
                    # Someone else owns it
                    if self.is_owner:
                        # We thought we owned it but another device does
                        # This could be a conflict or network partition healing
                        logger.info(
                            f"Another device ({resolved_ip}) now owns {ALIAS_NAME}"
                        )
                        self.release_alias()
                    else:
                        logger.debug(
                            f"{ALIAS_NAME} owned by {resolved_ip}, we're on standby"
                        )

                # Sleep interval depends on whether we're owner
                interval = OWNER_CHECK_INTERVAL if self.is_owner else PROBE_INTERVAL
                time.sleep(interval)

            except Exception as e:
                logger.error(f"Error in main loop: {e}")
                time.sleep(PROBE_INTERVAL)

    def shutdown(self, signum=None, frame=None):
        """Clean shutdown handler."""
        logger.info("Shutting down...")
        self.running = False
        self.release_alias()
        sys.exit(0)


def main():
    parser = argparse.ArgumentParser(
        description="DroidNet Discovery Service - ensures droidnet.local is available"
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="Run once and print status (don't claim)",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable debug logging",
    )
    args = parser.parse_args()

    if args.debug:
        logging.getLogger().setLevel(logging.DEBUG)

    service = DiscoveryService()

    if args.check:
        # One-shot mode for debugging
        status = service.run_once()
        print(f"Own IP: {status['own_ip']}")
        print(f"Own hostname: {status['own_hostname']}")
        print(f"Alias: {status['alias']}")
        print(f"Resolved IP: {status['resolved_ip']}")
        print(f"Available to claim: {status['is_available']}")
        print(f"We own it: {status['we_own_it']}")
        return

    # Daemon mode
    signal.signal(signal.SIGTERM, service.shutdown)
    signal.signal(signal.SIGINT, service.shutdown)

    try:
        service.run()
    except KeyboardInterrupt:
        service.shutdown()


if __name__ == "__main__":
    main()
