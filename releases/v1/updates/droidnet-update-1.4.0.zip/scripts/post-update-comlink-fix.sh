#!/bin/bash
# Post-update script to fix corrupted Comlink JSON history
# This script is run automatically after update installation

echo "Running Comlink JSON history recovery..."

# Check if the fix script exists
if [ -f "/opt/droidnet/updates/fix_comlink_json_v2.py" ]; then
    # Run the fix script on the history file
    python3 /opt/droidnet/updates/fix_comlink_json_v2.py /opt/droidnet/data/comlink_history.json
    
    # Check if successful
    if [ $? -eq 0 ]; then
        echo "✓ Comlink history recovery completed"
    else
        echo "✗ Comlink history recovery failed - creating new empty history"
        echo '{"commands": []}' > /opt/droidnet/data/comlink_history.json
    fi
else
    # If fix script doesn't exist, just verify JSON is valid
    python3 -c "import json; json.load(open('/opt/droidnet/data/comlink_history.json'))" 2>/dev/null
    if [ $? -ne 0 ]; then
        echo "Creating new empty Comlink history file"
        echo '{"commands": []}' > /opt/droidnet/data/comlink_history.json
    fi
fi

echo "Comlink JSON fix complete"