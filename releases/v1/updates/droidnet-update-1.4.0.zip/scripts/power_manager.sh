#!/bin/bash
# DroidNet Power Manager - CPU frequency scaling and power optimization
# Configures power-saving features based on Pi model

LOG_FILE="/var/log/droidnet-power.log"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

# Detect Pi model (matches logic in web/server.py)
detect_pi_model() {
    local cpuinfo
    cpuinfo=$(cat /proc/cpuinfo 2>/dev/null)

    # Check for specific models by name
    if echo "$cpuinfo" | grep -q "Pi Zero W" && echo "$cpuinfo" | grep -q "BCM2835"; then
        echo "pi_zero_w"
        return
    elif echo "$cpuinfo" | grep -q "Pi Zero 2"; then
        echo "pi_zero_2"
        return
    elif echo "$cpuinfo" | grep -q "Pi 3"; then
        echo "pi_3"
        return
    elif echo "$cpuinfo" | grep -q "Pi 4"; then
        echo "pi_4"
        return
    elif echo "$cpuinfo" | grep -q "Pi 5"; then
        echo "pi_5"
        return
    fi

    # Fallback: check revision codes
    local revision
    revision=$(echo "$cpuinfo" | grep "^Revision" | cut -d: -f2 | tr -d ' ')

    case "$revision" in
        9000c1|900092|900093)
            echo "pi_zero_w"
            ;;
        902120)
            echo "pi_zero_2"
            ;;
        a02082|a22082|a32082|a52082)
            echo "pi_3"
            ;;
        a03111|b03111|c03111|c03112|c03114)
            echo "pi_4"
            ;;
        *)
            echo "unknown"
            ;;
    esac
}

# Get the appropriate CPU governor for this Pi model
get_governor_for_model() {
    local model="$1"

    case "$model" in
        pi_4|pi_5)
            # Pi 4/5 have plenty of headroom - use conservative governor
            # Scales frequency based on load, but more slowly than ondemand
            echo "conservative"
            ;;
        pi_3)
            # Pi 3 - use ondemand for better responsiveness
            echo "ondemand"
            ;;
        pi_zero_2)
            # Pi Zero 2 - use ondemand, it needs quick scaling
            echo "ondemand"
            ;;
        pi_zero_w)
            # Pi Zero W - keep at performance, it's already slow
            # Frequency scaling overhead isn't worth it on single-core
            echo "ondemand"
            ;;
        *)
            # Unknown - use safe ondemand
            echo "ondemand"
            ;;
    esac
}

# Set CPU governor for all cores
set_cpu_governor() {
    local governor="$1"
    local success=true

    # Check if cpufreq is available
    if [ ! -d /sys/devices/system/cpu/cpufreq ]; then
        log "WARNING: cpufreq not available on this system"
        return 1
    fi

    # Check available governors
    local available
    available=$(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors 2>/dev/null)

    if [ -z "$available" ]; then
        log "WARNING: Cannot read available governors"
        return 1
    fi

    log "Available governors: $available"

    # Verify requested governor is available
    if ! echo "$available" | grep -qw "$governor"; then
        log "WARNING: Governor '$governor' not available, falling back to ondemand"
        governor="ondemand"

        if ! echo "$available" | grep -qw "$governor"; then
            log "WARNING: ondemand not available either, trying powersave"
            governor="powersave"

            if ! echo "$available" | grep -qw "$governor"; then
                log "ERROR: No suitable governor available"
                return 1
            fi
        fi
    fi

    # Apply governor to all CPU cores
    for cpu_dir in /sys/devices/system/cpu/cpu[0-9]*; do
        local scaling_gov="$cpu_dir/cpufreq/scaling_governor"
        if [ -f "$scaling_gov" ]; then
            if echo "$governor" > "$scaling_gov" 2>/dev/null; then
                log "Set $(basename "$cpu_dir") governor to $governor"
            else
                log "WARNING: Failed to set governor for $(basename "$cpu_dir")"
                success=false
            fi
        fi
    done

    $success
}

# Configure governor-specific parameters
configure_governor_params() {
    local governor="$1"
    local model="$2"

    case "$governor" in
        conservative)
            # Conservative governor parameters
            # up_threshold: CPU usage % before scaling up (default 80)
            # down_threshold: CPU usage % before scaling down (default 20)
            # freq_step: % of max freq to step (default 5)
            # sampling_rate: how often to check usage in microseconds

            local params_dir="/sys/devices/system/cpu/cpufreq/conservative"
            if [ -d "$params_dir" ]; then
                # More aggressive power saving for Pi 4
                echo 95 > "$params_dir/up_threshold" 2>/dev/null && \
                    log "Set conservative up_threshold to 95%"
                echo 40 > "$params_dir/down_threshold" 2>/dev/null && \
                    log "Set conservative down_threshold to 40%"
                echo 10 > "$params_dir/freq_step" 2>/dev/null && \
                    log "Set conservative freq_step to 10%"
            fi
            ;;
        ondemand)
            # Ondemand governor parameters
            local params_dir="/sys/devices/system/cpu/cpufreq/ondemand"
            if [ -d "$params_dir" ]; then
                # Slightly higher threshold before ramping up
                echo 85 > "$params_dir/up_threshold" 2>/dev/null && \
                    log "Set ondemand up_threshold to 85%"
                # Sampling rate in microseconds (default is usually 10000)
                echo 50000 > "$params_dir/sampling_rate" 2>/dev/null && \
                    log "Set ondemand sampling_rate to 50ms"
            fi
            ;;
    esac
}

# Display current CPU frequency info
show_cpu_info() {
    log "=== CPU Frequency Information ==="

    for cpu_dir in /sys/devices/system/cpu/cpu[0-9]*; do
        local cpu=$(basename "$cpu_dir")
        local cur_freq=$(cat "$cpu_dir/cpufreq/scaling_cur_freq" 2>/dev/null)
        local min_freq=$(cat "$cpu_dir/cpufreq/scaling_min_freq" 2>/dev/null)
        local max_freq=$(cat "$cpu_dir/cpufreq/scaling_max_freq" 2>/dev/null)
        local governor=$(cat "$cpu_dir/cpufreq/scaling_governor" 2>/dev/null)

        if [ -n "$cur_freq" ]; then
            # Convert kHz to MHz for readability
            cur_mhz=$((cur_freq / 1000))
            min_mhz=$((min_freq / 1000))
            max_mhz=$((max_freq / 1000))
            log "$cpu: ${cur_mhz}MHz (range: ${min_mhz}-${max_mhz}MHz, governor: $governor)"
        fi
    done
}

# Main execution
main() {
    log "=== DroidNet Power Manager Starting ==="

    # Detect Pi model
    local model
    model=$(detect_pi_model)
    log "Detected Pi model: $model"

    # Get appropriate governor
    local governor
    governor=$(get_governor_for_model "$model")
    log "Selected governor for $model: $governor"

    # Set the governor
    if set_cpu_governor "$governor"; then
        log "Successfully configured CPU governor"
        configure_governor_params "$governor" "$model"
    else
        log "Failed to configure CPU governor"
    fi

    # Show final state
    show_cpu_info

    log "=== Power Manager Configuration Complete ==="
}

# Run main function
main "$@"
