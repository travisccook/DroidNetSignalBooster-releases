#!/bin/bash
# Install esptool.py for ESP32 flashing support

echo "Installing esptool.py for ESP32 support..."

# Check if pip3 is installed
if ! command -v pip3 &> /dev/null; then
    echo "Installing python3-pip..."
    sudo apt-get update
    sudo apt-get install -y python3-pip
fi

# Install esptool
echo "Installing esptool.py..."
sudo pip3 install --break-system-packages esptool

# Verify installation
if command -v esptool.py &> /dev/null; then
    echo "✓ esptool.py installed successfully"
    esptool.py version
else
    echo "✗ Failed to install esptool.py"
    exit 1
fi

# Make sure it's accessible system-wide
sudo ln -sf /usr/local/bin/esptool.py /usr/bin/esptool.py 2>/dev/null || true

echo "ESP32 flashing support enabled!"