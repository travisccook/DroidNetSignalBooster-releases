#!/bin/bash
# Diagnostic script for esptool issues

echo "=== ESPTool Diagnostic ==="
echo

# Check esptool locations
echo "1. Checking esptool locations:"
echo -n "   /usr/local/bin/esptool: "
if [ -f /usr/local/bin/esptool ]; then
    echo "EXISTS"
    echo -n "   File type: "
    file /usr/local/bin/esptool
    echo -n "   First line: "
    head -1 /usr/local/bin/esptool
    echo -n "   Executable: "
    [ -x /usr/local/bin/esptool ] && echo "YES" || echo "NO"
else
    echo "NOT FOUND"
fi

echo
echo -n "   esptool.py in PATH: "
which esptool.py 2>/dev/null || echo "NOT FOUND"

echo
echo -n "   esptool in PATH: "
which esptool 2>/dev/null || echo "NOT FOUND"

# Test esptool execution
echo
echo "2. Testing esptool execution:"
if [ -f /usr/local/bin/esptool ]; then
    echo "   Running: /usr/local/bin/esptool version"
    /usr/local/bin/esptool version 2>&1 | head -5
elif command -v esptool.py >/dev/null 2>&1; then
    echo "   Running: esptool.py version"
    esptool.py version 2>&1 | head -5
elif command -v esptool >/dev/null 2>&1; then
    echo "   Running: esptool version"
    esptool version 2>&1 | head -5
else
    echo "   ERROR: No esptool found!"
fi

# Check Python and dependencies
echo
echo "3. Python environment:"
echo -n "   Python3: "
python3 --version 2>&1
echo -n "   esptool module: "
python3 -c "import esptool; print(esptool.__version__)" 2>&1 || echo "NOT INSTALLED"

# Check serial ports
echo
echo "4. Serial ports:"
ls -la /dev/ttyUSB* /dev/ttyACM* 2>/dev/null || echo "   No USB serial ports found"

echo
echo "=== End Diagnostic ==="