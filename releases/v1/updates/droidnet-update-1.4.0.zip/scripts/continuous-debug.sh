#!/bin/bash
# Continuous debug logger that runs independently of systemd complexities
# This provides backup logging if unified_monitor.sh fails

LOG_DIR="/boot/firmware/droidnet-logs"
mkdir -p "$LOG_DIR"

# Function to log with Louisville timestamp
log_event() {
    local log_file="$1"
    local message="$2"
    echo "[$(TZ='America/Kentucky/Louisville' date '+%Y-%m-%d %H:%M:%S')] $message" >> "$LOG_DIR/$log_file"
}

# Check if another instance is running
if [ $(pgrep -f "$(basename $0)" | wc -l) -gt 2 ]; then
    log_event "continuous-debug.log" "Another instance already running, exiting"
    exit 0
fi

# Create marker file to indicate we're running
touch /var/run/continuous-debug.active

log_event "continuous-debug.log" "Continuous debug logger started"

# Function to check log size and rotate if needed
check_log_size() {
    local log_file="$1"
    if [ -f "$log_file" ] && [ $(stat -c%s "$log_file" 2>/dev/null || echo 0) -gt 10485760 ]; then
        mv "$log_file" "${log_file}.old"
        gzip "${log_file}.old" &
        log_event "continuous-debug.log" "Rotated log: $log_file"
    fi
}

# Fix-Plan-22: Ensure debug logs are written to latest-debug.log
# Create initial debug log
{
    echo "=== DroidNet Debug Collection Started - $(date) ==="
    /opt/droidnet/scripts/debug-init.sh 2>&1 || echo "debug-init.sh not available"
    echo "=== End Initial Debug Collection ==="
} > /boot/firmware/latest-debug.log 2>&1

# Main loop
while true; do
    TIMESTAMP=$(date +%Y%m%d-%H%M%S)
    DATE_ONLY=$(date +%Y%m%d)
    
    # Check log size
    check_log_size "$LOG_DIR/continuous-$DATE_ONLY.log"
    
    # System state snapshot
    {
        echo "=== System State at $(TZ='America/Kentucky/Louisville' date) ==="
        echo "Uptime: $(uptime)"
        echo "Memory: $(free -h | grep Mem)"
        echo ""
        echo "DroidNet Services Status:"
        for service in droidnet-web droidnet-ap droidnet-led droidnet-monitor droidnet-virtualhere hostapd dnsmasq; do
            if systemctl is-active --quiet $service; then
                echo "  ✓ $service: active"
            else
                echo "  ✗ $service: $(systemctl is-active $service)"
            fi
        done
        echo ""
        echo "Network Interfaces:"
        ip -brief addr show
        echo ""
        echo "WiFi Status:"
        if command -v iw >/dev/null 2>&1; then
            iw dev 2>/dev/null | grep -E "(Interface|type|channel|txpower)" || echo "  No WiFi info available"
        fi
        echo ""
        echo "Critical Processes:"
        ps aux | grep -E "(hostapd|dnsmasq|python|server.py|vhusbd)" | grep -v grep || echo "  No critical processes found"
        echo ""
        echo "Recent Errors (last 10):"
        journalctl -p err -n 10 --no-pager --no-hostname 2>/dev/null || echo "  No recent errors"
        echo "---"
    } >> "$LOG_DIR/continuous-$DATE_ONLY.log"
    
    # Check for service failures and log separately
    if systemctl --failed --no-pager | grep -q "droidnet"; then
        log_event "service-failures.log" "Detected failed DroidNet services"
        {
            echo "=== Service Failures at $(TZ='America/Kentucky/Louisville' date) ==="
            systemctl --failed --no-pager
            echo ""
            for service in $(systemctl --failed --no-pager | grep droidnet | awk '{print $2}'); do
                echo "Details for $service:"
                systemctl status $service --no-pager -n 20
                echo ""
            done
            echo "---"
        } >> "$LOG_DIR/service-failures.log"
    fi
    
    # Check if we're in LED error state
    if [ -f /tmp/led-error-state ] || [ -f /var/run/led-error ]; then
        log_event "led-errors.log" "LED error state detected"
        # Capture more detailed state
        {
            echo "=== LED Error State at $(TZ='America/Kentucky/Louisville' date) ==="
            echo "Memory usage:"
            free -m
            echo ""
            echo "Top memory consumers:"
            ps aux --sort=-%mem | head -10
            echo ""
            echo "System load:"
            uptime
            echo ""
            echo "All service status:"
            systemctl status --no-pager
            echo "---"
        } >> "$LOG_DIR/led-errors.log"
    fi
    
    # Fix-Plan-22: Also update latest-debug.log periodically
    # Append current state to latest-debug.log every 5 iterations (2.5 minutes)
    if [ $(($(date +%s) % 150)) -lt 30 ]; then
        {
            echo ""
            echo "=== Debug Update - $(date) ==="
            echo "System uptime: $(uptime)"
            echo "WiFi interface: $(ip -brief addr show wlan0 2>/dev/null || echo 'wlan0 not found')"
            echo "Active services: $(systemctl list-units --type=service --state=active | grep -c droidnet)"
            echo "Failed services: $(systemctl --failed --no-pager | grep -c droidnet || echo '0')"
        } >> /boot/firmware/latest-debug.log 2>&1
        
        # Keep file size reasonable
        if [ -f /boot/firmware/latest-debug.log ] && [ $(stat -c%s /boot/firmware/latest-debug.log 2>/dev/null || echo 0) -gt 1048576 ]; then
            tail -n 1000 /boot/firmware/latest-debug.log > /boot/firmware/latest-debug.log.tmp
            mv /boot/firmware/latest-debug.log.tmp /boot/firmware/latest-debug.log
        fi
    fi
    
    # Sleep for 30 seconds
    sleep 30
done