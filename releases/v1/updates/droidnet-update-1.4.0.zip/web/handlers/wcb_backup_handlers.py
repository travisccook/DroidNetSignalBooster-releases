"""
DroidNet Signal Booster - WCB Backup Handlers
API handlers for WCB configuration backup, restore, and history management
"""

import asyncio
import logging
import sys
from typing import Any, Dict, Optional

# Timeout for async operations (seconds)
ASYNC_OPERATION_TIMEOUT = 30.0

from config.constants import PROJECT_ROOT, SCRIPTS_DIR

# Add parent directory to path for imports
sys.path.insert(0, str(PROJECT_ROOT))
sys.path.insert(0, str(SCRIPTS_DIR))

logger = logging.getLogger(__name__)

# Import backup manager with error handling
try:
    from wcb_backup_manager import get_backup_manager

    BACKUP_MANAGER_AVAILABLE = True
except ImportError:
    BACKUP_MANAGER_AVAILABLE = False
    logger.warning("wcb_backup_manager module not available")

# Module-level variable (set by server.py after import)
backup_manager = None
serial_port_manager = None


def _require_backup_manager():
    """
    Get backup manager instance.

    Returns:
        WCBBackupManager instance

    Raises:
        RuntimeError: If backup manager not available
    """
    global backup_manager
    if backup_manager is None:
        if BACKUP_MANAGER_AVAILABLE:
            backup_manager = get_backup_manager()
        else:
            raise RuntimeError("Backup manager not available")
    return backup_manager


def _require_serial_port_manager():
    """
    Validate serial_port_manager is available.

    Raises:
        RuntimeError: If serial_port_manager is not initialized
    """
    if serial_port_manager is None:
        raise RuntimeError("SerialPortManager not initialized")
    return serial_port_manager


def _validate_filename(filename: str) -> Optional[str]:
    """
    Validate backup filename parameter.

    Args:
        filename: Backup filename to validate

    Returns:
        Error message if invalid, None if valid
    """
    if not filename:
        return "Filename is required"
    # Length check
    if len(filename) > 255:
        return "Invalid filename: too long"
    # Prevent path traversal and null bytes
    if "/" in filename or ".." in filename or "\\" in filename or "\x00" in filename:
        return "Invalid filename: path traversal not allowed"
    # Must be JSON file
    if not filename.endswith(".json"):
        return "Invalid filename: must be .json file"
    return None


def _validate_device_id(device_id: Optional[str]) -> Optional[str]:
    """
    Validate device_id parameter.

    Args:
        device_id: Device ID to validate (optional)

    Returns:
        Error message if invalid, None if valid
    """
    if device_id is None:
        return None  # Optional field
    if not device_id:
        return "device_id cannot be empty"
    if len(device_id) > 100:
        return "device_id too long"
    # Allowlist of safe characters
    allowed_chars = set(
        "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_:."
    )
    if not all(c in allowed_chars for c in device_id):
        return "device_id contains invalid characters"
    return None


def _sanitize_error(error: Exception) -> str:
    """
    Sanitize exception message for user display.

    Args:
        error: Exception to sanitize

    Returns:
        Safe error message without internal paths
    """
    msg = str(error)
    # Remove file paths that might leak internal structure
    if "/opt/droidnet" in msg or "/dev/" in msg:
        # Generic message for path-related errors
        return "An internal error occurred"
    return msg


def _validate_page(page: Any) -> int:
    """
    Validate and convert page parameter.

    Args:
        page: Page number (string or int)

    Returns:
        Validated page number (minimum 1)
    """
    try:
        p = int(page)
        return max(1, p)
    except (TypeError, ValueError):
        return 1


# ─────────────────────────────────────────────────────────────────
# Configuration Endpoints
# ─────────────────────────────────────────────────────────────────


def handle_get_backup_config() -> Dict[str, Any]:
    """
    Get backup configuration settings.

    Returns:
        Dict with config or error
    """
    try:
        manager = _require_backup_manager()
        return {
            "success": True,
            "config": {
                "backup_interval_hours": manager.config.backup_interval_hours,
                "max_backups": manager.config.max_backups,
                "enabled": manager.config.enabled,
                "save_all_backups": manager.config.save_all_backups,
            },
        }
    except Exception as e:
        logger.error(f"Error getting backup config: {e}")
        return {"success": False, "error": _sanitize_error(e)}


def handle_set_backup_config(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Update backup configuration settings.

    Args:
        data: Dict with backup_interval_hours, max_backups, enabled

    Returns:
        Dict with success status
    """
    try:
        manager = _require_backup_manager()

        # Validate and update interval
        if "backup_interval_hours" in data:
            interval = float(data["backup_interval_hours"])
            if interval < 0.5 or interval > 24:
                return {
                    "success": False,
                    "error": "backup_interval_hours must be between 0.5 and 24",
                }
            manager.config.backup_interval_hours = interval

        # Validate and update max_backups (count-based retention)
        if "max_backups" in data:
            max_backups = int(data["max_backups"])
            if max_backups < 5 or max_backups > 500:
                return {
                    "success": False,
                    "error": "max_backups must be between 5 and 500",
                }
            manager.config.max_backups = max_backups

        # Update enabled flag
        if "enabled" in data:
            manager.config.enabled = bool(data["enabled"])

        # Update save_all_backups flag
        if "save_all_backups" in data:
            manager.config.save_all_backups = bool(data["save_all_backups"])

        # Save configuration
        if manager.save_config():
            return {"success": True}
        else:
            return {"success": False, "error": "Failed to save configuration"}

    except ValueError as e:
        return {"success": False, "error": f"Invalid value: {_sanitize_error(e)}"}
    except Exception as e:
        logger.error(f"Error setting backup config: {e}")
        return {"success": False, "error": _sanitize_error(e)}


# ─────────────────────────────────────────────────────────────────
# Backup List and History Endpoints
# ─────────────────────────────────────────────────────────────────


def handle_get_backup_list(device_id: Optional[str], page: Any) -> Dict[str, Any]:
    """
    Get paginated list of successful backups.

    Args:
        device_id: Filter by device (optional)
        page: Page number

    Returns:
        Dict with backups list and pagination info
    """
    try:
        # Validate device_id if provided
        error = _validate_device_id(device_id)
        if error:
            return {"success": False, "error": error}

        manager = _require_backup_manager()
        page_num = _validate_page(page)

        result = manager.get_backup_list(device_id=device_id, page=page_num)
        return {"success": True, **result}

    except Exception as e:
        logger.error(f"Error getting backup list: {e}")
        return {"success": False, "error": _sanitize_error(e)}


def handle_get_backup_history(device_id: Optional[str], page: Any) -> Dict[str, Any]:
    """
    Get paginated backup history (including errors).

    Args:
        device_id: Filter by device (optional)
        page: Page number

    Returns:
        Dict with history entries and pagination info
    """
    try:
        # Validate device_id if provided
        error = _validate_device_id(device_id)
        if error:
            return {"success": False, "error": error}

        manager = _require_backup_manager()
        page_num = _validate_page(page)

        result = manager.get_backup_history(device_id=device_id, page=page_num)
        return {"success": True, **result}

    except Exception as e:
        logger.error(f"Error getting backup history: {e}")
        return {"success": False, "error": _sanitize_error(e)}


# ─────────────────────────────────────────────────────────────────
# Backup Content and Restore Endpoints
# ─────────────────────────────────────────────────────────────────


def handle_get_backup_content(filename: str) -> Dict[str, Any]:
    """
    Get full content of a backup file.

    Args:
        filename: Backup filename

    Returns:
        Dict with backup content or error
    """
    try:
        # Validate filename
        error = _validate_filename(filename)
        if error:
            return {"success": False, "error": error}

        manager = _require_backup_manager()
        content = manager.get_backup_content(filename)

        if content is None:
            return {"success": False, "error": "Backup not found"}

        return {"success": True, "backup": content}

    except Exception as e:
        logger.error(f"Error getting backup content: {e}")
        return {"success": False, "error": _sanitize_error(e)}


def handle_delete_backup(filename: str) -> Dict[str, Any]:
    """
    Delete a backup file.

    Args:
        filename: Backup filename

    Returns:
        Dict with success status
    """
    try:
        # Validate filename
        error = _validate_filename(filename)
        if error:
            return {"success": False, "error": error}

        manager = _require_backup_manager()
        success = manager.delete_backup(filename)

        if success:
            return {"success": True, "message": "Backup deleted successfully"}
        else:
            return {"success": False, "error": "Failed to delete backup"}

    except Exception as e:
        logger.error(f"Error deleting backup: {e}")
        return {"success": False, "error": _sanitize_error(e)}


def handle_clear_all_backups() -> Dict[str, Any]:
    """
    Delete all backup files and clear history.

    Returns:
        Dict with success status and count of deleted files
    """
    try:
        manager = _require_backup_manager()
        result = manager.clear_all_backups()
        return result

    except Exception as e:
        logger.error(f"Error clearing all backups: {e}")
        return {"success": False, "error": _sanitize_error(e)}


def handle_get_restore_commands(filename: str, mode: str) -> Dict[str, Any]:
    """
    Get restore commands from a backup.

    Args:
        filename: Backup filename
        mode: "configured" or "factory_reset"

    Returns:
        Dict with restore commands or error
    """
    try:
        # Validate filename
        error = _validate_filename(filename)
        if error:
            return {"success": False, "error": error}

        # Validate mode
        if mode not in ("configured", "factory_reset"):
            return {
                "success": False,
                "error": "mode must be 'configured' or 'factory_reset'",
            }

        manager = _require_backup_manager()
        commands = manager.get_restore_commands(filename, mode)

        if commands is None:
            return {"success": False, "error": "Backup not found or no restore commands"}

        return {"success": True, "commands": commands, "mode": mode}

    except Exception as e:
        logger.error(f"Error getting restore commands: {e}")
        return {"success": False, "error": _sanitize_error(e)}


def handle_get_restore_info(filename: str) -> Dict[str, Any]:
    """
    Get restore information and recommendations for a backup.

    Returns info about which restore mode to use based on the backup's
    delimiter configuration.

    Args:
        filename: Backup filename

    Returns:
        Dict with restore info or error
    """
    try:
        # Validate filename
        error = _validate_filename(filename)
        if error:
            return {"success": False, "error": error}

        manager = _require_backup_manager()
        info = manager.get_restore_info(filename)

        if info is None:
            return {"success": False, "error": "Backup not found"}

        return {"success": True, "restore_info": info}

    except Exception as e:
        logger.error(f"Error getting restore info: {e}")
        return {"success": False, "error": _sanitize_error(e)}


def handle_compare_backups(file1: str, file2: str) -> Dict[str, Any]:
    """
    Compare two backup files.

    Args:
        file1: First backup filename
        file2: Second backup filename

    Returns:
        Dict with comparison or error
    """
    try:
        # Validate filenames
        for filename in (file1, file2):
            error = _validate_filename(filename)
            if error:
                return {"success": False, "error": f"{filename}: {error}"}

        manager = _require_backup_manager()
        comparison = manager.compare_backups(file1, file2)

        if comparison is None:
            return {"success": False, "error": "One or both backups not found"}

        return {"success": True, "comparison": comparison}

    except Exception as e:
        logger.error(f"Error comparing backups: {e}")
        return {"success": False, "error": _sanitize_error(e)}


# ─────────────────────────────────────────────────────────────────
# Trigger Backup Endpoint
# ─────────────────────────────────────────────────────────────────


def handle_trigger_backup(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Trigger a manual backup for a device.

    Args:
        data: Dict with port and device_id

    Returns:
        Dict with success status
    """
    try:
        port = data.get("port")
        device_id = data.get("device_id")

        if not port:
            return {"success": False, "error": "port is required"}
        if not device_id:
            return {"success": False, "error": "device_id is required"}

        # Validate device_id
        error = _validate_device_id(device_id)
        if error:
            return {"success": False, "error": error}

        # Validate port
        if not port.startswith("/dev/"):
            return {"success": False, "error": "Invalid port path"}
        if ".." in port:
            return {"success": False, "error": "Invalid port path: path traversal not allowed"}

        manager = _require_backup_manager()
        spm = _require_serial_port_manager()

        # Run async trigger in event loop thread with timeout
        async def _trigger():
            return await asyncio.wait_for(
                manager.trigger_manual_backup(port, device_id),
                timeout=ASYNC_OPERATION_TIMEOUT,
            )

        success, message = spm.event_loop_thread.run_coroutine(_trigger())

        return {"success": success, "message": message}

    except asyncio.TimeoutError:
        logger.error("Backup trigger timed out")
        return {"success": False, "error": "Backup operation timed out"}
    except Exception as e:
        logger.error(f"Error triggering backup: {e}")
        return {"success": False, "error": _sanitize_error(e)}


# ─────────────────────────────────────────────────────────────────
# Restore Endpoint
# ─────────────────────────────────────────────────────────────────


def _build_restore_commands_from_parsed(parsed_config: Dict[str, Any]) -> list:
    """
    Build individual restore commands from parsed backup config.

    Instead of using the concatenated restore string (which gets split on ^
    and truncates ?CS values), we build commands from the parsed config
    where stored command values are preserved intact.

    Args:
        parsed_config: The parsed_config dict from a backup file

    Returns:
        List of command strings to send individually
    """
    commands = []

    # Hardware version
    if parsed_config.get("hw_version"):
        commands.append(f"?HW{parsed_config['hw_version']}")

    # MAC octets
    if parsed_config.get("mac_octet2"):
        commands.append(f"?M2{parsed_config['mac_octet2']}")
    if parsed_config.get("mac_octet3"):
        commands.append(f"?M3{parsed_config['mac_octet3']}")

    # WCB number and quantity
    if parsed_config.get("wcb_number"):
        commands.append(f"?WCB{parsed_config['wcb_number']}")
    if parsed_config.get("wcb_quantity"):
        commands.append(f"?WCBQ{parsed_config['wcb_quantity']}")

    # ESP-NOW password
    if parsed_config.get("esp_now_password"):
        commands.append(f"?EPASS{parsed_config['esp_now_password']}")

    # Command characters (only if non-default)
    if parsed_config.get("command_delimiter"):
        commands.append(f"?D{parsed_config['command_delimiter']}")
    if parsed_config.get("local_function_id"):
        commands.append(f"?LF{parsed_config['local_function_id']}")
    if parsed_config.get("command_character"):
        commands.append(f"?CC{parsed_config['command_character']}")

    # Baud rates
    baud_rates = parsed_config.get("baud_rates", {})
    for port_num in sorted(baud_rates.keys()):
        commands.append(f"?S{port_num}{baud_rates[port_num]}")

    # Broadcast settings (WCB v5.6+ uses ?SBO/?SBI, older uses broadcast_enabled)
    broadcast_output = parsed_config.get("broadcast_output", {})
    broadcast_input = parsed_config.get("broadcast_input", {})
    broadcast_enabled = parsed_config.get("broadcast_enabled", {})

    # Use new format if available, otherwise fall back to legacy broadcast_enabled
    if broadcast_output or broadcast_input:
        # WCB v5.6+ format: separate OUTPUT and INPUT settings
        for port_num in sorted(broadcast_output.keys()):
            commands.append(f"?SBO{port_num}{1 if broadcast_output[port_num] else 0}")
        for port_num in sorted(broadcast_input.keys()):
            commands.append(f"?SBI{port_num}{1 if broadcast_input[port_num] else 0}")
    elif broadcast_enabled:
        # Legacy format: only had output control, use new ?SBO command
        for port_num in sorted(broadcast_enabled.keys()):
            commands.append(f"?SBO{port_num}{1 if broadcast_enabled[port_num] else 0}")

    # Serial labels
    serial_labels = parsed_config.get("serial_labels", {})
    for port_num, label in serial_labels.items():
        if label:
            commands.append(f"?SL{port_num},{label}")

    # Serial monitor mappings (WCB v5.3+ HCR_Port_Mirror)
    # Format: ?SM<input_port>,<output1>,<output2>,...
    serial_monitor_mappings = parsed_config.get("serial_monitor_mappings", [])
    for mapping in serial_monitor_mappings:
        input_port = mapping.get("input_port", "")
        outputs = mapping.get("outputs", [])
        if input_port and outputs:
            cmd = f"?SM{input_port},{','.join(outputs)}"
            commands.append(cmd)

    # Kyber settings - check new "status" field first, fall back to legacy "enabled"
    kyber = parsed_config.get("kyber_settings", {})
    kyber_status = kyber.get("status")
    if kyber_status == "local":
        commands.append("?KYBER_LOCAL")
    elif kyber_status == "remote":
        commands.append("?KYBER_REMOTE")
    elif kyber_status == "clear":
        commands.append("?KYBER_CLEAR")
    elif kyber.get("enabled") is True:
        # Legacy format fallback
        commands.append("?KYBER_LOCAL")
    elif kyber.get("enabled") is False:
        commands.append("?KYBER_CLEAR")

    # Stored commands - sent INDIVIDUALLY to preserve ^ in values
    # This is the key fix: each ?CS command is sent as its own message,
    # so the WCB won't split on ^ delimiters within the value
    stored_commands = parsed_config.get("stored_commands", [])
    for sc in stored_commands:
        key = sc.get("key", "")
        value = sc.get("value", "")
        if key and value:
            commands.append(f"?CS{key},{value}")

    # PWM output ports (?PO) - must come before PWM mappings
    pwm_output_port = parsed_config.get("pwm_output_port", "")
    if pwm_output_port:
        # Can be single port or comma-separated list
        for port in pwm_output_port.split(","):
            if port.strip():
                commands.append(f"?PO{port.strip()}")

    # PWM port mappings (?PMS) - WCB v5.6+ format
    # Format: ?PMS<input_port>,<output1>,<output2>,...
    pwm_port_mappings = parsed_config.get("pwm_port_mappings", [])
    for mapping in pwm_port_mappings:
        input_port = mapping.get("input_port", "")
        outputs = mapping.get("outputs", [])
        if input_port and outputs:
            cmd = f"?PMS{input_port},{','.join(outputs)}"
            commands.append(cmd)

    # Legacy PWM mappings (?PWM) - older format
    pwm_mappings = parsed_config.get("pwm_mappings", [])
    for mapping in pwm_mappings:
        if mapping.get("active", True):
            cmd = f"?PWM{mapping.get('channel', 0)},{mapping.get('pin', 0)}"
            cmd += f",{mapping.get('min', 0)},{mapping.get('max', 180)}"
            commands.append(cmd)

    return commands


def handle_restore_backup(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Restore a backup to a WCB device.

    Sends commands individually rather than as a single ^-chained string.
    This preserves stored command values that contain ^ delimiters.

    Args:
        data: Dict with port, filename, mode

    Returns:
        Dict with success status
    """
    try:
        port = data.get("port")
        filename = data.get("filename")
        mode = data.get("mode", "configured")

        if not port:
            return {"success": False, "error": "port is required"}
        if not filename:
            return {"success": False, "error": "filename is required"}

        # Validate port
        if not port.startswith("/dev/"):
            return {"success": False, "error": "Invalid port path"}
        if ".." in port:
            return {"success": False, "error": "Invalid port path: path traversal not allowed"}

        # Validate filename
        error = _validate_filename(filename)
        if error:
            return {"success": False, "error": error}

        # Validate mode (kept for API compatibility, though we use parsed_config)
        if mode not in ("configured", "factory_reset"):
            return {
                "success": False,
                "error": "mode must be 'configured' or 'factory_reset'",
            }

        # Get full backup content (not just restore_commands string)
        manager = _require_backup_manager()
        backup = manager.get_backup_content(filename)

        if not backup:
            return {"success": False, "error": "Backup not found"}

        parsed_config = backup.get("parsed_config")
        if not parsed_config:
            return {"success": False, "error": "Backup has no parsed config"}

        # Build individual commands from parsed config
        commands = _build_restore_commands_from_parsed(parsed_config)

        if not commands:
            return {"success": False, "error": "No commands to restore"}

        logger.info(f"Restoring {len(commands)} commands to {port} from {filename}")

        # Get serial handler
        spm = _require_serial_port_manager()
        handler = spm.get_handler(port)

        if not handler:
            return {"success": False, "error": "No handler for specified port"}

        # Send commands individually with delays
        # This prevents queue overflow and preserves ?CS values with ^ in them
        async def _restore():
            for i, cmd in enumerate(commands):
                logger.debug(f"Restore {i+1}/{len(commands)}: {cmd[:60]}...")
                await asyncio.wait_for(
                    handler.write(cmd),
                    timeout=ASYNC_OPERATION_TIMEOUT,
                )
                # Delay between commands to let WCB process each one
                if cmd.startswith("?CS"):
                    await asyncio.sleep(0.25)  # NVS writes for stored commands
                else:
                    await asyncio.sleep(0.1)

        spm.event_loop_thread.run_coroutine(_restore())

        stored_count = len([c for c in commands if c.startswith("?CS")])
        config_count = len(commands) - stored_count

        logger.info(f"Restore sent to {port}: {config_count} config, {stored_count} stored")
        return {
            "success": True,
            "message": f"Restore sent: {config_count} config + {stored_count} stored commands",
        }

    except asyncio.TimeoutError:
        logger.error("Restore operation timed out")
        return {"success": False, "error": "Restore operation timed out"}
    except Exception as e:
        logger.error(f"Error restoring backup: {e}")
        return {"success": False, "error": _sanitize_error(e)}
