"""
DroidNet Signal Booster - Device Handlers
Functions for device detection, management, and locking
"""

import sys
import subprocess
import logging
import glob
import io
import contextlib
from typing import List, Dict, Any, Optional

from config.constants import PROJECT_ROOT, SCRIPTS_DIR

# Add parent directory to path for imports
sys.path.insert(0, str(PROJECT_ROOT))
sys.path.insert(0, str(SCRIPTS_DIR))

# Get logger (must be before any logger.warning calls)
logger = logging.getLogger(__name__)

# Import USBManager at module level with error handling
try:
    from usb_manager import USBManager
    USB_MANAGER_AVAILABLE = True
except ImportError:
    USB_MANAGER_AVAILABLE = False
    logger.warning("USBManager not available, using fallback detection")

# Import firmware_flasher functions at module level with error handling
try:
    from firmware_flasher import detect_arduino_board, detect_esp32_chip
    FIRMWARE_FLASHER_AVAILABLE = True
except ImportError:
    FIRMWARE_FLASHER_AVAILABLE = False
    logger.warning("firmware_flasher not available")


def get_usb_devices() -> List[Dict[str, Any]]:
    """Get list of USB devices with enhanced Arduino detection"""
    try:
        logger.debug("Getting USB device list")
        # Use the USBManager for better detection if available
        if not USB_MANAGER_AVAILABLE:
            raise ImportError("USBManager not available")

        manager = USBManager()
        devices = manager.get_usb_devices()

        # Convert to web API format
        device_list = []
        for device in devices:
            device_info = device.to_dict()
            # Add web-specific fields
            web_device = {
                "port": device_info["port"],
                "name": device_info["name"],
                "vendor": device_info["vendor_id"],
                "product": device_info["product_id"],
                "vendor_id": device_info["vendor_id"],
                "product_id": device_info["product_id"],
                "vendor_name": device_info["vendor_name"],
                "product_name": device_info["product_name"],
                "serial_number": device_info.get("serial_number", ""),
                "unique_id": device_info["unique_id"],
                "id_type": device_info.get("id_type", "unknown"),
                "status": device_info["status"],
                "locked": device_info["locked"],
                "type": device_info["type"],
                "serial_port": device_info.get("serial_port"),
            }
            device_list.append(web_device)

        logger.debug(f"Found {len(device_list)} USB devices")
        return device_list
    except (ImportError, subprocess.CalledProcessError) as e:
        logger.error(f"Error getting USB devices from USBManager: {e}", exc_info=True)
        # Fallback to basic lsusb parsing
        try:
            result = subprocess.run(["lsusb"], capture_output=True, text=True)
            devices = []

            for line in result.stdout.strip().split("\n"):
                if line:
                    parts = line.split()
                    if len(parts) >= 6:
                        bus = parts[1].rstrip(":")
                        device = parts[3].rstrip(":")
                        vendor_product = " ".join(parts[6:])

                        device_info = {
                            "port": f"/dev/bus/usb/{bus}/{device}",
                            "name": vendor_product,
                            "vendor": parts[5].split(":")[0]
                            if ":" in parts[5]
                            else "Unknown",
                            "product": parts[5].split(":")[1]
                            if ":" in parts[5]
                            else "Unknown",
                            "status": "available",
                            "locked": False,
                            "type": "unknown",
                        }

                        # Check if device is locked by VirtualHere
                        if is_device_locked(device_info["port"]):
                            device_info["status"] = "locked"
                            device_info["locked"] = True

                        devices.append(device_info)

            return devices
        except (subprocess.CalledProcessError, FileNotFoundError) as e2:
            return [{"error": f"lsusb command failed: {str(e2)}"}]


def get_arduino_devices() -> List[Dict[str, Any]]:
    """Get Arduino-compatible devices with enhanced detection"""
    devices = []
    try:
        # Use the USBManager for better detection if available
        if not USB_MANAGER_AVAILABLE:
            raise ImportError("USBManager not available")

        manager = USBManager()
        arduino_devices = manager.get_arduino_devices()

        for device in arduino_devices:
            device_info = device.to_dict()
            # For Arduino devices, we need the serial port for programming
            if device_info.get("serial_port"):
                devices.append(
                    {
                        "port": device_info["serial_port"],
                        "name": device_info["name"],
                        "type": "arduino",
                        "vendor_id": device_info["vendor_id"],
                        "product_id": device_info["product_id"],
                        "serial_number": device_info.get("serial_number", ""),
                        "unique_id": device_info["unique_id"],
                        "id_type": device_info.get("id_type", "unknown"),
                        "usb_port": device_info["port"],
                    }
                )

        # Fallback: Also check for serial ports that might not be detected via USB
        if not devices:
            # Use glob instead of shell=True for security
            ports = glob.glob("/dev/ttyUSB*") + glob.glob("/dev/ttyACM*")
            for port in ports:
                # Don't add if already detected
                if not any(d["port"] == port for d in devices):
                    devices.append(
                        {
                            "port": port,
                            "name": f"Serial Device ({port})",
                            "type": "serial",
                        }
                    )
    except (ImportError, subprocess.CalledProcessError) as e:
        logger.error(f"Error getting Arduino devices from USBManager: {e}", exc_info=True)
        # Fallback to simple detection using glob
        try:
            ports = glob.glob("/dev/ttyUSB*") + glob.glob("/dev/ttyACM*")
            for port in ports:
                devices.append(
                    {
                        "port": port,
                        "name": f"Arduino ({port})",
                        "type": "arduino",
                    }
                )
        except (OSError, IOError):
            pass

    return devices


def get_serial_devices() -> List[Dict[str, Any]]:
    """Get serial devices for monitoring"""
    try:
        # Use the USBManager for better detection if available
        if not USB_MANAGER_AVAILABLE:
            raise ImportError("USBManager not available")

        manager = USBManager()
        all_devices = manager.get_usb_devices()

        # Get devices that are either arduino or serial type and have a serial port
        serial_devices = []
        for device in all_devices:
            device_info = device.to_dict()
            if device_info.get("serial_port") and device_info.get("type") in [
                "arduino",
                "serial",
            ]:
                serial_devices.append(
                    {
                        "port": device_info["serial_port"],
                        "name": device_info["name"],
                        "type": device_info["type"],
                        "vendor_id": device_info["vendor_id"],
                        "product_id": device_info["product_id"],
                        "serial_number": device_info.get("serial_number", ""),
                        "unique_id": device_info["unique_id"],
                        "id_type": device_info.get("id_type", "unknown"),
                        "usb_port": device_info.get("port", ""),
                    }
                )

        logger.debug(f"Found {len(serial_devices)} serial/arduino devices")
        return serial_devices
    except Exception as e:
        logger.error(f"Error in get_serial_devices: {e}", exc_info=True)
        return []


def is_device_locked(port: str) -> bool:
    """Check if device is locked by VirtualHere"""
    try:
        # Check VirtualHere status
        result = subprocess.run(
            ["vhclient", "-t", "LIST"], capture_output=True, text=True
        )
        return port in result.stdout
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False


def lock_device(port: str) -> Dict[str, Any]:
    """Lock device with VirtualHere"""
    try:
        subprocess.run(["vhclient", "-t", f"USE,{port}"], check=True)
        return {"success": True, "message": "Device locked"}
    except subprocess.CalledProcessError as e:
        return {"success": False, "message": f"Failed to lock device: {e}"}


def unlock_device(port: str) -> Dict[str, Any]:
    """Unlock device from VirtualHere"""
    try:
        subprocess.run(["vhclient", "-t", f"STOP USING,{port}"], check=True)
        return {"success": True, "message": "Device unlocked"}
    except subprocess.CalledProcessError as e:
        return {"success": False, "message": f"Failed to unlock device: {e}"}


def detect_board_type(device_port: str) -> Dict[str, Any]:
    """Detect board type for a given port"""
    try:
        # Check if firmware flasher is available
        if not FIRMWARE_FLASHER_AVAILABLE:
            raise ImportError("firmware_flasher module not available")

        # Capture output for debugging
        output_buffer = io.StringIO()

        # First try Arduino detection with output capture
        with contextlib.redirect_stdout(output_buffer):
            board_type, config = detect_arduino_board(device_port)

        detection_output = output_buffer.getvalue()

        if board_type != "unknown":
            return {
                "success": True,
                "type": "arduino",
                "board": board_type,
                "config": config,
                "output": detection_output,
            }

        # Try ESP32 detection
        output_buffer = io.StringIO()
        with contextlib.redirect_stdout(output_buffer):
            chip_type, config = detect_esp32_chip(device_port)

        esp_output = output_buffer.getvalue()

        if chip_type not in ["error", "unknown"]:
            return {
                "success": True,
                "type": "esp32",
                "chip": chip_type,
                "config": config,
                "output": esp_output,
            }

        # Combine outputs for error message
        full_output = detection_output + "\n" + esp_output

        return {
            "success": False,
            "message": (
                "Could not detect board type. " "Check device connection and try again."
            ),
            "output": full_output,
        }

    except Exception as e:
        return {
            "success": False,
            "message": f"Detection error: {str(e)}",
            "output": str(e),
        }
