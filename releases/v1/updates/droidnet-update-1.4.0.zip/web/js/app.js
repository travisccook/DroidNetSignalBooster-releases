// DroidNet Signal Booster - Main JavaScript
console.log('app.js: Starting to load...');

// CRC32 implementation matching Python's zlib.crc32 (IEEE 802.3 polynomial)
// Used for WebSocket message integrity verification
const CRC32 = (function() {
    const table = new Uint32Array(256);
    for (let i = 0; i < 256; i++) {
        let c = i;
        for (let k = 0; k < 8; k++) {
            c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
        }
        table[i] = c;
    }
    return function(str) {
        const encoder = new TextEncoder();
        const bytes = encoder.encode(str);
        let crc = 0xFFFFFFFF;
        for (let i = 0; i < bytes.length; i++) {
            crc = table[(crc ^ bytes[i]) & 0xFF] ^ (crc >>> 8);
        }
        return ((crc ^ 0xFFFFFFFF) >>> 0).toString(16).padStart(8, '0');
    };
})();

/**
 * Reassemble chunked WebSocket messages
 * Large messages are split by the server to prevent WebSocket frame corruption.
 * This function buffers chunks and reassembles them into complete messages.
 *
 * @param {Object} data - Parsed JSON message from WebSocket
 * @param {Object} chunkBuffers - Buffer object to store partial chunks
 * @returns {Object|null} - Complete message or null if still buffering chunks
 */
function reassembleChunks(data, chunkBuffers) {
    // Not a chunked message - return as-is
    if (!data.chunk) {
        return data;
    }

    const { id, index, total, final } = data.chunk;

    // Initialize buffer for this chunk ID
    if (!chunkBuffers[id]) {
        chunkBuffers[id] = {
            chunks: new Array(total),
            total: total,
            received: 0,
            seq: data.seq,
            direction: data.direction
        };
    }

    const buffer = chunkBuffers[id];

    // Store chunk at correct index (ignore duplicates)
    if (!buffer.chunks[index]) {
        buffer.chunks[index] = data.line;
        buffer.received++;
    }

    // Check if all chunks received
    if (buffer.received === buffer.total) {
        // Reassemble complete line
        const completeLine = buffer.chunks.join('');

        // Clean up buffer
        delete chunkBuffers[id];

        // Return complete message with hash/len from final chunk
        return {
            seq: buffer.seq,
            line: completeLine,
            direction: buffer.direction,
            hash: data.hash,
            len: data.len
        };
    }

    // Still waiting for more chunks
    return null;
}

// Detect Pi model early for hardware-adaptive polling
// Uses lightweight /api/status instead of heavy /api/dashboard/status
(function detectPiModel() {
    fetch('/api/status')
        .then(response => response.json())
        .then(data => {
            if (data.pi_model) {
                DroidNet.state.hardware.piModel = data.pi_model;
                console.log('Pi model detected early: ' + DroidNet.state.hardware.piModel);
            }
        })
        .catch(() => {
            console.log('Failed to detect Pi model early, will use defaults');
        });
})();

// DroidNet Application State
const DroidNet = window.DroidNet || {};
DroidNet.state = {
    serial: {
        socket: null,
        isConnected: false,
        commandHistory: [],
        historyPosition: -1,
        tempCommand: '',
        chunkBuffers: {}  // For reassembling chunked WebSocket messages
    },
    wcb: {
        socket: null,
        isConnected: false,
        selectedPort: null,  // Currently selected WCB port
        selectedDeviceId: null,  // Currently selected device ID
        commandHistory: [],
        historyPosition: -1,
        tempCommand: '',
        commandTable: [],
        updateInProgress: false,
        unsavedChanges: false,
        configBuffer: '',
        buffering: false,
        bufferingType: null,  // 'config' or 'backup'
        chunkBuffers: {},  // For reassembling chunked WebSocket messages
        expectedSeq: null  // Track expected sequence number for gap detection
    },
    polling: {
        refreshInterval: null,
        deviceDiscoveryInterval: null,
        comlinkRefreshInterval: null,
        healthCheckInterval: null,
        wcbPollingInterval: null,
        victronPollingInterval: null,
        victronChartPollingInterval: null,
        updateStatusPoller: null,
        apModeCountdown: null,
        rebootCountdown: null
    },
    ui: {
        deviceCustomNames: {},
        currentTab: null,
        eventLogMaxItems: 100
    },
    update: {
        eventSource: null,
        logBuffer: [],
        // GitHub update state
        available: false,
        availableVersion: null,
        currentVersion: null,
        changelog: [],
        downloadProgress: 0,
        isDownloading: false,
        downloadedPackage: null,
        checkInProgress: false
    },
    victron: {
        charts: {},
        chartRange: 3600,
        expandedChart: null,
        lastBluetoothState: true,
        bluetoothUnavailableNotified: false
    },
    templates: {
        list: [],
        selected: null,
        editingId: null
    },
    config: {
        retryCount: 0,
        delimiterParsing: true,
        autoSent: false
    },
    discovery: {
        isDiscovering: false
    },
    display: {
        status: null,
        imageStatus: null
    },
    hardware: {
        piModel: null
    },
    esp32: {
        currentBinaryAnalysis: null
    },
    droid: {
        devices: [],
        selectedFirmware: null,
        selectedFirmwareData: null,
        selectedTargets: [],
        updateInProgress: false,
        flashInProgress: false,
        updatePollingId: null,
        flashPollingId: null,
        showSingleDevices: true,  // Show all compatible devices, not just multi-Pi
        flashStartTimes: {}  // Track flash start time per device for elapsed display
    }
};

// Note: All global variables have been moved to DroidNet.state for better organization

// Resize handle event listeners (to prevent memory leaks)
let resizeMouseMoveHandler = null;
let resizeMouseUpHandler = null;

// Utility Functions for UI Improvements

// Show loading state on button
function setButtonLoading(button, loading, loadingText) {
    if (loading) {
        button.disabled = true;
        button.classList.add('loading');
        const originalText = button.getAttribute('data-original-text') || button.textContent;
        button.setAttribute('data-original-text', originalText);
        // Use textContent for the text to prevent XSS, then append spinner
        button.textContent = loadingText || 'Loading...';
        const spinner = document.createElement('span');
        spinner.className = 'spinner';
        button.appendChild(spinner);
    } else {
        button.disabled = false;
        button.classList.remove('loading');
        const originalText = button.getAttribute('data-original-text');
        if (originalText) {
            button.textContent = originalText;
            button.removeAttribute('data-original-text');
        }
    }
}

// Unified copy-to-clipboard helper with visual feedback
function copyToClipboard(text, buttonElement, successMessage = 'Copied!') {
    // Create a temporary textarea element to copy the text
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);

    // Select and copy the text
    textarea.select();
    textarea.setSelectionRange(0, 99999); // For mobile devices

    try {
        document.execCommand('copy');
        // Provide visual feedback on the button if provided
        if (buttonElement) {
            const originalText = buttonElement.textContent;
            buttonElement.textContent = successMessage;
            setTimeout(() => {
                buttonElement.textContent = originalText;
            }, 1500);
        }
    } catch (err) {
        console.error('Failed to copy text: ', err);
        showStatusMessage('Failed to copy text', 'error', 8000);
    } finally {
        document.body.removeChild(textarea);
    }
}

// Show confirmation dialog
function showConfirmDialog(title, message, onConfirm, confirmText = 'Confirm', confirmClass = 'confirm-btn') {
    // Remove any existing dialogs
    const existingDialog = document.querySelector('.dialog-overlay');
    if (existingDialog) {
        existingDialog.remove();
    }
    
    // Create overlay
    const overlay = document.createElement('div');
    overlay.className = 'dialog-overlay active';
    
    // Create dialog
    const dialog = document.createElement('div');
    dialog.className = 'confirm-dialog';
    dialog.innerHTML = `
        <h3>${title}</h3>
        <p>${message}</p>
        <div class="dialog-buttons">
            <button class="cancel-btn">Cancel</button>
            <button class="${confirmClass}">${confirmText}</button>
        </div>
    `;
    
    // Add event handlers
    const cancelBtn = dialog.querySelector('.cancel-btn');
    const confirmBtn = dialog.querySelector(`.${confirmClass}`);
    
    const closeDialog = () => {
        overlay.remove();
    };
    
    cancelBtn.addEventListener('click', closeDialog);
    confirmBtn.addEventListener('click', () => {
        closeDialog();
        if (onConfirm) onConfirm();
    });
    
    // Click outside to close
    overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
            closeDialog();
        }
    });
    
    // Add to page
    overlay.appendChild(dialog);
    document.body.appendChild(overlay);
    
    // Focus confirm button
    confirmBtn.focus();
}

// Enhanced status message display
function showStatusMessage(message, type = 'info', duration = 5000) {
    const container = document.getElementById('status-container') || createStatusContainer();
    
    const statusDiv = document.createElement('div');
    statusDiv.className = `status-message ${type}`;
    statusDiv.textContent = message;
    
    container.appendChild(statusDiv);
    
    // Auto-remove after duration
    if (duration > 0) {
        setTimeout(() => {
            statusDiv.style.opacity = '0';
            statusDiv.style.transform = 'translateY(-10px)';
            setTimeout(() => statusDiv.remove(), 300);
        }, duration);
    }
    
    return statusDiv;
}

// Create status container if it doesn't exist
function createStatusContainer() {
    const container = document.createElement('div');
    container.id = 'status-container';
    container.style.cssText = 'position: fixed; top: 20px; right: 20px; z-index: 999; max-width: 400px;';
    document.body.appendChild(container);
    return container;
}

// Success animation helper
function animateSuccess(element) {
    element.classList.add('success-animation');
    setTimeout(() => element.classList.remove('success-animation'), 300);
}

// Device discovery state (now using DroidNet.state.polling.deviceDiscoveryInterval and DroidNet.state.discovery.isDiscovering)

// Load device selector and update page title
async function loadDeviceSelector() {
    await refreshDeviceList();
}

// Refresh the device list from mDNS discovery
async function refreshDeviceList() {
    if (DroidNet.state.discovery.isDiscovering) return;

    const selector = document.getElementById('device-selector');
    const refreshBtn = document.getElementById('device-refresh-btn');

    if (!selector) return;

    DroidNet.state.discovery.isDiscovering = true;
    if (refreshBtn) {
        refreshBtn.classList.add('scanning');
    }

    try {
        const response = await fetch('/api/network/discover-devices');
        if (!response.ok) {
            throw new Error(`HTTP error ${response.status}`);
        }
        const data = await response.json();

        // Clear existing options
        selector.innerHTML = '';

        if (data.success && data.devices && data.devices.length > 0) {
            data.devices.forEach(device => {
                const option = document.createElement('option');
                option.value = device.ip;
                option.textContent = `${device.hostname} (${device.ip})`;
                option.dataset.hostname = device.hostname;
                if (device.is_current) {
                    option.selected = true;
                    // Update page title with current device hostname
                    document.title = `${device.hostname} - DroidNet`;
                }
                selector.appendChild(option);
            });
        } else {
            // Fallback: show current device from /api/device/name
            try {
                const nameResponse = await fetch('/api/device/name');
                const nameData = await nameResponse.json();
                if (nameData.success && nameData.hostname) {
                    const option = document.createElement('option');
                    option.value = window.location.hostname;
                    option.textContent = `${nameData.hostname} (${window.location.hostname})`;
                    option.dataset.hostname = nameData.hostname;
                    option.selected = true;
                    selector.appendChild(option);
                    document.title = `${nameData.hostname} - DroidNet`;
                } else {
                    selector.innerHTML = '<option value="">No devices found</option>';
                }
            } catch (e) {
                selector.innerHTML = '<option value="">Discovery unavailable</option>';
            }
        }
    } catch (error) {
        console.error('Failed to discover devices:', error);
        selector.innerHTML = '<option value="">Discovery failed</option>';
    } finally {
        DroidNet.state.discovery.isDiscovering = false;
        if (refreshBtn) {
            refreshBtn.classList.remove('scanning');
        }
    }
}

// Handle device selection change - navigate to selected device
function handleDeviceSelection(event) {
    const selectedOption = event.target.selectedOptions[0];

    if (!selectedOption) return;

    const hostname = selectedOption.dataset.hostname;
    if (!hostname) return;

    // Check if this is the current device
    const currentHost = window.location.hostname;
    const targetHost = `${hostname}.local`;
    if (targetHost === currentHost || hostname === currentHost) return;

    // Navigate to the selected device using mDNS hostname
    // Check if we should preserve current tab/path
    const preserveTab = typeof window.getPreserveTabOnSwitch === 'function'
        ? window.getPreserveTabOnSwitch()
        : true;
    const currentPath = preserveTab ? (window.location.pathname + window.location.search + window.location.hash) : '/';
    const newUrl = `http://${targetHost}${currentPath}`;
    window.location.href = newUrl;
}

// Initialize device selector event listener
function initDeviceSelector() {
    const selector = document.getElementById('device-selector');
    if (selector) {
        selector.addEventListener('change', handleDeviceSelection);
    }

    // Initial load
    loadDeviceSelector();

    // Periodic refresh every 30 seconds
    DroidNet.state.polling.deviceDiscoveryInterval = setInterval(refreshDeviceList, 30000);
}

// Initialize app when DOM loads
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    // Initialize device selector (also updates page title)
    initDeviceSelector();

    // Show initial tab (dashboard is the new default)
    showTab('dashboard');
    
    // Load initial device list
    refreshDevices();
    
    // Load VirtualHere status
    loadVirtualHereStatus();
    
    // Load Comlink settings
    loadComlinkSettings();
    
    // Set up periodic refresh for device status (every 60 seconds)
    // USB devices rarely change, and users can manually refresh when needed
    DroidNet.state.polling.refreshInterval = setInterval(refreshDevices, 60000);
    
    // Load serial devices
    loadSerialDevices();
    
    // Check system status
    updateSystemStatus();

    // Load WCB configuration
    loadWCBConfig();

    // Load Display status (will show tab if supported)
    loadDisplayStatus();

    // Load Maestro configuration (shows tab if enabled in config)
    loadMaestroConfig();

    // Load Victron feature configuration (shows tab if enabled in config)
    loadVictronFeatureConfig();

    // Load system info (including version)
    loadSystemInfo();

    // Load GitHub update status
    loadGitHubUpdateStatus();

    // Initialize Droid tab event delegation
    initDroidTab();

    // Set up keyboard navigation for serial input
    document.getElementById('serial-command').addEventListener('keydown', function(e) {
        if (e.key === 'Enter') {
            sendSerial();
        } else if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
            e.preventDefault();
            navigateSerialHistory(e.key === 'ArrowUp' ? 'up' : 'down');
        }
    });
    
    // Set up keyboard navigation for WCB serial input
    const wcbSerialInput = document.getElementById('wcb-serial-command');
    if (wcbSerialInput) {
        wcbSerialInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                sendWCBSerial();
            } else if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
                e.preventDefault();
                navigateWCBHistory(e.key === 'ArrowUp' ? 'up' : 'down');
            }
        });
    }
    
    // ESP32 advanced options handlers
    document.getElementById('firmware-file').addEventListener('change', handleFirmwareFileChange);
    
    document.getElementById('esp32-advanced-toggle').addEventListener('change', function(e) {
        const content = document.getElementById('esp32-advanced-content');
        if (e.target.checked) {
            content.classList.remove('hidden');
        } else {
            content.classList.add('hidden');
        }
    });
    
    // Additional file handlers for ESP32
    ['bootloader-file', 'partitions-file', 'otadata-file'].forEach(id => {
        const element = document.getElementById(id);
        if (element) {
            element.addEventListener('change', async function(e) {
                if (e.target.files[0]) {
                    const fileType = await detectESP32FileType(e.target.files[0]);
                    const slot = id.replace('-file', '');
                    updateBinaryAnalysis(slot, e.target.files[0].name, fileType);
                }
            });
        }
    });
}

// Tab Management
function showTab(tabName) {
    // Get the currently active tab before switching
    const currentActiveTab = document.querySelector('.tab-content.active');
    let currentTabName = null;
    if (currentActiveTab && currentActiveTab.id) {
        currentTabName = currentActiveTab.id.replace('-tab', '');
    }

    // Clean up intervals when leaving specific tabs
    if (currentTabName === 'comlink' && tabName !== 'comlink') {
        stopComlinkAutoRefresh();
    }
    if (currentTabName === 'dashboard' && tabName !== 'dashboard') {
        if (DroidNet.state.polling.healthCheckInterval) {
            clearInterval(DroidNet.state.polling.healthCheckInterval);
            DroidNet.state.polling.healthCheckInterval = null;
        }
        if (DroidNet.state.polling.wcbPollingInterval) {
            clearInterval(DroidNet.state.polling.wcbPollingInterval);
            DroidNet.state.polling.wcbPollingInterval = null;
        }
    }
    if (currentTabName === 'victron' && tabName !== 'victron') {
        stopVictronPolling();
    }

    // Hide all tab contents
    const tabs = document.querySelectorAll('.tab-content');
    tabs.forEach(tab => tab.classList.remove('active'));

    // Remove active class from all buttons (support both old and new class names)
    const buttons = document.querySelectorAll('.nav-tab, .tab-button');
    buttons.forEach(btn => btn.classList.remove('active'));

    // Show selected tab
    const selectedTab = document.getElementById(tabName + '-tab');
    if (selectedTab) {
        selectedTab.classList.add('active');
    } else {
        console.error('Tab not found:', tabName + '-tab');
        return;
    }

    // Mark button as active - find button by tab name
    const activeButton = Array.from(buttons).find(btn =>
        btn.textContent.toLowerCase().includes(tabName) ||
        (tabName === 'devices' && btn.textContent.includes('USB')) ||
        (tabName === 'flash' && btn.textContent.includes('Firmware'))
    );
    if (activeButton) {
        activeButton.classList.add('active');
    }
    
    // Re-initialize resize handles after tab switch
    setTimeout(initializeResizeHandles, 10);
    
    // Load tab-specific data
    if (tabName === 'flash') {
        loadFlashDevices();
    } else if (tabName === 'serial') {
        loadSerialDevices();
    } else if (tabName === 'templates') {
        loadTemplates();
        loadTemplateDevices();
    } else if (tabName === 'wifi') {
        loadWifiStatus();
        loadDeviceName();
        loadAPConfig();
        loadNetworkSettings();
        loadWCBConfig();
    } else if (tabName === 'wcb') {
        initializeWCBTab();
    } else if (tabName === 'comlink') {
        loadComlinkStatus();
        loadComlinkHistory();
        loadComlinkConfig();
        startComlinkAutoRefresh();
    } else if (tabName === 'display') {
        initDisplayTab();
    } else if (tabName === 'maestro') {
        // Maestro tab - refresh device list when opened
        if (typeof refreshMaestroDevices !== 'undefined') {
            refreshMaestroDevices();
        }
    } else if (tabName === 'victron') {
        // Victron tab - resize charts after tab becomes visible
        // Charts initialized while hidden have 0x0 dimensions
        setTimeout(() => {
            if (DroidNet.state.victron.charts.voltage) {
                DroidNet.state.victron.charts.voltage.resize();
                DroidNet.state.victron.charts.current.resize();
                DroidNet.state.victron.charts.soc.resize();
            }
        }, 50);
    } else if (tabName === 'droid') {
        // Droid tab - refresh device list when opened
        initDroidTab();
    }
}
// Make showTab immediately available on window for onclick handlers
window.showTab = showTab;

// USB Device Management
async function refreshDevices() {
    try {
        // Fetch devices and custom names in parallel
        const [devicesResponse, namesResponse] = await Promise.all([
            fetch('/api/devices'),
            fetch('/api/devices/names')
        ]);
        
        const devices = await devicesResponse.json();
        DroidNet.state.ui.deviceCustomNames = await namesResponse.json();
        
        const deviceList = document.getElementById('device-list');
        const hubSection = document.getElementById('hub-section');
        const hubList = document.getElementById('hub-list');
        
        // Separate hubs from other devices
        const hubs = [];
        const normalDevices = [];
        
        devices.forEach(device => {
            if (device.name && device.name.toLowerCase().includes('hub')) {
                hubs.push(device);
            } else {
                normalDevices.push(device);
            }
        });
        
        // Update device count badge
        const countBadge = document.getElementById('device-count-badge');
        if (countBadge) {
            countBadge.textContent = `${normalDevices.length} device${normalDevices.length !== 1 ? 's' : ''}`;
        }

        // Display normal devices
        if (normalDevices.length === 0) {
            deviceList.innerHTML = `
                <div class="device-card">
                    <div class="device-header">
                        <span class="device-name">No USB devices found</span>
                        <span class="device-status unknown">None</span>
                    </div>
                    <div class="device-info">Connect an Arduino or other USB device to get started.</div>
                </div>
            `;
        } else {
            deviceList.innerHTML = normalDevices.map(device => {
                // Use unique_id if available, fallback to vendor:product
                const deviceId = device.unique_id || `${device.vendor_id}:${device.product_id}`;
                
                const customName = DroidNet.utils.getDeviceDisplayName(device, DroidNet.state.ui.deviceCustomNames);
                
                return `
                    <div class="device-card">
                        <div class="device-header">
                            <div class="device-name-container">
                                <span class="device-name">${customName}</span>
                                <span class="edit-icon" onclick="editDeviceName('${deviceId.replace(/'/g, "\\'")}', '${customName.replace(/'/g, "\\'")}')">✏️</span>
                            </div>
                            <span class="device-status ${device.status}">${device.status}</span>
                        </div>
                        <div class="device-info">
                            <div><strong>Port:</strong> ${device.port}</div>
                            <div><strong>Vendor:</strong> ${device.vendor_name || device.vendor_id || 'Unknown'}</div>
                            <div><strong>Product:</strong> ${device.product_name || device.product_id || 'Unknown'}</div>
                            ${device.serial_number ? 
                                `<div><strong>Serial:</strong> ${device.serial_number}</div>` : 
                                (device.usb_port_path ? 
                                    `<div><strong>USB Port:</strong> ${device.usb_port_path} <span class="text-muted">(Physical port)</span></div>` :
                                    '<div class="text-muted"><em>No serial number (name may not persist)</em></div>'
                                )
                            }
                            ${device.id_type === 'usb_port' ? 
                                '<div class="text-success"><em>✓ Name will persist for this physical USB port</em></div>' : 
                                (device.id_type === 'serial' ? 
                                    '<div class="text-success"><em>✓ Name will persist by serial number</em></div>' : 
                                    ''
                                )
                            }
                        </div>
                    </div>
                `;
            }).join('');
        }
        
        // Display hubs if any
        if (hubs.length > 0) {
            hubSection.classList.remove('hidden');
            hubList.innerHTML = hubs.map(hub => `
                <div class="hub-item">
                    <strong>${hub.name}</strong> - Port: ${hub.port}
                </div>
            `).join('');
        } else {
            hubSection.classList.add('hidden');
        }
        
    } catch (error) {
        console.error('Failed to refresh devices:', error);
        showStatusMessage('Failed to load USB devices', 'error', 8000);
    }
}

function editDeviceName(deviceId, currentName) {
    const newName = prompt('Enter a custom name for this device:', currentName);
    if (newName !== null && newName !== currentName) {
        updateDeviceCustomName(deviceId, newName);
    }
}

async function updateDeviceCustomName(deviceId, name) {
    try {
        const response = await fetch('/api/devices/names', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ device_id: deviceId, name: name })
        });
        
        if (response.ok) {
            // Refresh all device lists
            refreshDevices();
            
            // Check which tab is active and refresh its device list too
            const activeTab = document.querySelector('.tab-pane.active');
            if (activeTab) {
                if (activeTab.id === 'flash-tab') {
                    loadFlashDevices();
                } else if (activeTab.id === 'serial-tab') {
                    loadSerialDevices();
                }
            }
        } else {
            showStatusMessage('Failed to update device name', 'error', 8000);
        }
    } catch (error) {
        showStatusMessage('Error updating device name', 'error', 8000);
    }
}

// VirtualHere Status Management
async function loadVirtualHereStatus() {
    console.log('Loading VirtualHere status...');
    try {
        const response = await fetch('/api/virtualhere/status');
        const status = await response.json();
        console.log('VirtualHere status:', status);
        
        const statusSection = document.getElementById('virtualhere-status');
        if (!statusSection) return;
        
        const statusHtml = `
            <div class="status-info">
                <div><strong>Status:</strong> <span class="${status.running ? 'status-active' : 'status-inactive'}">${status.running ? 'Running' : 'Stopped'}</span></div>
                <div><strong>Build Type:</strong> ${status.build_type || 'Unknown'}</div>
                <div><strong>Version:</strong> ${status.version || 'Unknown'}</div>
                ${status.port ? `<div><strong>Port:</strong> ${status.port}</div>` : ''}
                ${status.clients ? `<div><strong>Connected Clients:</strong> ${status.clients}</div>` : ''}
                ${status.devices ? `<div><strong>Shared Devices:</strong> ${status.devices}</div>` : ''}
            </div>
            <div class="mt-20">
                ${status.running ? 
                    '<button onclick="toggleVirtualHere(false)" class="btn btn-secondary">Stop VirtualHere</button>' :
                    '<button onclick="toggleVirtualHere(true)" class="btn btn-primary">Start VirtualHere</button>'
                }
            </div>
        `;
        
        statusSection.innerHTML = statusHtml;
    } catch (error) {
        console.error('Failed to load VirtualHere status:', error);
    }
}

async function toggleVirtualHere(enable) {
    try {
        const response = await fetch('/api/virtualhere/toggle', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ enable: enable })
        });
        
        if (response.ok) {
            showSuccess(enable ? 'Starting VirtualHere...' : 'Stopping VirtualHere...');
            setTimeout(() => {
                loadVirtualHereStatus();
                refreshDevices();
            }, 2000);
        } else {
            showStatusMessage('Failed to toggle VirtualHere', 'error', 8000);
        }
    } catch (error) {
        showStatusMessage('Error toggling VirtualHere', 'error', 8000);
    }
}

// Firmware Flashing
async function loadFlashDevices() {
    try {
        // Fetch devices and custom names in parallel
        const [devicesResponse, namesResponse] = await Promise.all([
            fetch('/api/devices/arduino'),
            fetch('/api/devices/names')
        ]);
        
        const devices = await devicesResponse.json();
        const customNames = await namesResponse.json();
        
        const select = document.getElementById('device-select');
        select.innerHTML = '<option value="">Select Arduino device...</option>';
        
        devices.forEach(device => {
            const displayName = DroidNet.utils.getDeviceDisplayName(device, customNames);
            
            const option = document.createElement('option');
            option.value = device.port;
            option.textContent = `${displayName} (${device.port})`;
            select.appendChild(option);
        });
        
    } catch (error) {
        console.error('Failed to load Arduino devices:', error);
    }
}

// ESP32 file type detection
function detectESP32FileType(file) {
    return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onload = function(e) {
            const buffer = e.target.result;
            const view = new DataView(buffer);
            
            if (view.byteLength < 1) {
                resolve('unknown');
                return;
            }
            
            const magic = view.getUint8(0);
            
            if (magic === 0xE9) {
                // Check if bootloader or app based on entry point
                if (view.byteLength >= 8) {
                    const entryPoint = view.getUint32(4, true);
                    resolve(entryPoint < 0x40000000 ? 'bootloader' : 'application');
                } else {
                    resolve('esp32_binary');
                }
            } else if (magic === 0xAA && view.byteLength > 1 && view.getUint8(1) === 0x50) {
                resolve('partition_table');
            } else if (magic === 0xFF) {
                // Check for OTA data pattern
                let allFF = true;
                for (let i = 0; i < Math.min(8, view.byteLength); i++) {
                    if (view.getUint8(i) !== 0xFF) {
                        allFF = false;
                        break;
                    }
                }
                resolve(allFF ? 'ota_data' : 'unknown');
            } else {
                resolve('unknown');
            }
        };
        reader.readAsArrayBuffer(file.slice(0, 4096));
    });
}

// Update UI based on file selection
async function handleFirmwareFileChange() {
    const firmwareFile = document.getElementById('firmware-file').files[0];
    const esp32Section = document.getElementById('esp32-advanced');
    
    if (!firmwareFile) {
        esp32Section.classList.add('hidden');
        return;
    }
    
    const fileName = firmwareFile.name.toLowerCase();
    
    if (fileName.endsWith('.bin')) {
        // Show ESP32 advanced options
        esp32Section.classList.remove('hidden');
        
        // Analyze the file
        const fileType = await detectESP32FileType(firmwareFile);
        updateBinaryAnalysis('main', firmwareFile.name, fileType);
    } else {
        esp32Section.classList.add('hidden');
    }
}

// Update binary analysis display
function updateBinaryAnalysis(slot, fileName, fileType) {
    const analysisDiv = document.getElementById('binary-analysis');
    
    if (!analysisDiv.dataset.files) {
        analysisDiv.dataset.files = JSON.stringify({});
    }
    
    const files = JSON.parse(analysisDiv.dataset.files);
    files[slot] = { name: fileName, type: fileType };
    analysisDiv.dataset.files = JSON.stringify(files);
    
    // Update display
    let html = '<div class="analysis-header">Binary Analysis:</div>';
    
    for (const [key, file] of Object.entries(files)) {
        const typeClass = file.type === 'unknown' ? 'warning' : '';
        html += `<div class="analysis-item ${typeClass}">
            <strong>${key}:</strong> ${file.name} - Type: ${file.type}
        </div>`;
    }
    
    // Check for missing components
    const hasBootloader = Object.values(files).some(f => f.type === 'bootloader');
    const hasPartitions = Object.values(files).some(f => f.type === 'partition_table');
    const hasApp = Object.values(files).some(f => f.type === 'application');
    
    if (!hasBootloader) {
        html += '<div class="analysis-item warning">⚠ Missing bootloader - will try to use system default</div>';
    }
    if (!hasPartitions) {
        html += '<div class="analysis-item warning">⚠ Missing partition table - will try to use system default</div>';
    }
    
    analysisDiv.innerHTML = html;
}

// ESP32 Binary Analysis
async function analyzeBinary(file) {
    return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onload = function(e) {
            const buffer = new Uint8Array(e.target.result);
            const analysis = {
                type: 'unknown',
                suggestedAddress: null,
                partitions: null,
                warning: null
            };
            
            // First check if it's a merged binary (before checking individual components)
            console.log('Analyzing binary - size:', buffer.length);
            if (buffer.length > 100000 && containsMultipleImages(buffer)) {
                console.log('Detected as merged binary');
                analysis.type = 'merged_binary';
                analysis.suggestedAddress = 0x0;
                analysis.warning = null; // No warning for merged binaries - they're safe
                analysis.info = 'Complete ESP32 firmware package with bootloader, partitions, and application';
            }
            // Check if it's ESP32 binary (magic byte 0xE9)
            else if (buffer[0] === 0xE9) {
                // Check segment count
                const segmentCount = buffer[1];
                
                // Read more of the header to identify type
                const header = buffer.slice(0, 128);
                
                // Check for bootloader signature
                if (segmentCount === 2 || segmentCount === 3) {
                    // Bootloader typically has 2-3 segments
                    analysis.type = 'bootloader';
                    analysis.suggestedAddress = 0x1000;
                    analysis.warning = 'This appears to be a bootloader binary. Flashing incorrect bootloader can brick your device!';
                } 
                // Check for partition table (magic bytes 0xAA 0x50)
                else if (buffer.length >= 32) {
                    let hasPartitionMagic = false;
                    for (let i = 0; i < Math.min(buffer.length - 32, 0x1000); i += 32) {
                        if (buffer[i] === 0xAA && buffer[i + 1] === 0x50) {
                            hasPartitionMagic = true;
                            break;
                        }
                    }
                    
                    if (hasPartitionMagic) {
                        analysis.type = 'partition_table';
                        analysis.suggestedAddress = 0x8000;
                        analysis.warning = 'This is a partition table. Incorrect partition table will prevent device from booting!';
                        
                        // Parse partitions
                        analysis.partitions = parsePartitionTable(buffer);
                    } else {
                        // Likely application
                        analysis.type = 'application';
                        analysis.suggestedAddress = 0x10000;
                        
                        // Check if it's a merged binary (contains multiple images)
                        if (buffer.length > 0x10000 && containsMultipleImages(buffer)) {
                            analysis.type = 'merged_binary';
                            analysis.suggestedAddress = 0x0;
                            analysis.warning = 'This appears to be a merged binary containing bootloader, partition table, and application.';
                        }
                    }
                }
            }
            // Check for OTA data (all 0xFF at start)
            else if (buffer.length >= 8 && buffer.slice(0, 8).every(b => b === 0xFF)) {
                analysis.type = 'ota_data';
                analysis.suggestedAddress = 0xE000;
                analysis.warning = 'This is OTA data configuration. Only needed for OTA-enabled applications.';
            }
            
            resolve(analysis);
        };
        reader.readAsArrayBuffer(file);
    });
}

function parsePartitionTable(buffer) {
    const partitions = [];
    let offset = 0;
    
    while (offset < buffer.length - 32) {
        if (buffer[offset] === 0xAA && buffer[offset + 1] === 0x50) {
            const type = buffer[offset + 2];
            const subtype = buffer[offset + 3];
            const partOffset = buffer[offset + 4] | (buffer[offset + 5] << 8) | 
                             (buffer[offset + 6] << 16) | (buffer[offset + 7] << 24);
            const size = buffer[offset + 8] | (buffer[offset + 9] << 8) | 
                        (buffer[offset + 10] << 16) | (buffer[offset + 11] << 24);
            
            // Extract name (20 bytes starting at offset 12)
            let name = '';
            for (let i = 0; i < 20; i++) {
                if (buffer[offset + 12 + i] === 0) break;
                name += String.fromCharCode(buffer[offset + 12 + i]);
            }
            
            if (type !== 0xFF) {
                const typeNames = {0: 'app', 1: 'data'};
                partitions.push({
                    name: name,
                    type: typeNames[type] || `type_${type}`,
                    offset: '0x' + partOffset.toString(16).toUpperCase(),
                    size: Math.floor(size / 1024) + 'KB'
                });
            }
        }
        offset += 32;
    }
    
    return partitions.length > 0 ? partitions : null;
}

function containsMultipleImages(buffer) {
    // Check for bootloader at 0x1000 and partition table at 0x8000
    // This is more reliable than checking magic at 0x0 since merged binaries start with padding
    
    console.log('containsMultipleImages - checking offsets');
    console.log('  0x1000:', buffer.length > 0x1000 ? '0x' + buffer[0x1000].toString(16) : 'too small');
    console.log('  0x8000:', buffer.length > 0x8000 ? '0x' + buffer[0x8000].toString(16) + ' 0x' + buffer[0x8001].toString(16) : 'too small');
    
    // Check for bootloader magic at 0x1000
    if (buffer.length > 0x1000 && buffer[0x1000] === 0xE9) {
        // Check for partition table magic at 0x8000
        if (buffer.length > 0x8000 && buffer[0x8000] === 0xAA && buffer[0x8001] === 0x50) {
            console.log('  -> Detected bootloader at 0x1000 and partition table at 0x8000');
            return true;
        }
    }
    
    // Fallback: Check for multiple ESP32 magic bytes at any expected offsets
    let magicCount = 0;
    const checkOffsets = [0x0, 0x1000, 0x8000, 0x10000];
    
    for (const offset of checkOffsets) {
        if (offset < buffer.length && buffer[offset] === 0xE9) {
            magicCount++;
        }
    }
    
    return magicCount >= 2;
}

async function handleFirmwareSelect() {
    const fileInput = document.getElementById('firmware-file');
    const file = fileInput.files[0];
    
    if (!file) {
        document.getElementById('esp32-analysis').classList.add('hidden');
        return;
    }
    
    const fileName = file.name.toLowerCase();
    
    // Hide analysis for .hex files
    if (fileName.endsWith('.hex')) {
        document.getElementById('esp32-analysis').classList.add('hidden');
        document.getElementById('esp32-advanced').classList.add('hidden');
        return;
    }
    
    // Show ESP32 advanced options for .bin files
    if (fileName.endsWith('.bin')) {
        document.getElementById('esp32-advanced').classList.remove('hidden');
        
        // Analyze the binary
        const analysis = await analyzeBinary(file);
        
        // Show analysis section
        document.getElementById('esp32-analysis').classList.remove('hidden');
        
        // Update analysis display
        const typeDisplay = {
            'bootloader': 'Bootloader',
            'partition_table': 'Partition Table',
            'application': 'Application',
            'ota_data': 'OTA Data',
            'merged_binary': 'Merged Binary',
            'unknown': 'Unknown'
        };
        
        document.getElementById('binary-type').textContent = typeDisplay[analysis.type];
        document.getElementById('flash-address').textContent = 
            analysis.suggestedAddress !== null ? '0x' + analysis.suggestedAddress.toString(16).toUpperCase() : 'Unknown';
        
        // Show partitions if available
        if (analysis.partitions) {
            document.getElementById('partition-info').classList.remove('hidden');
            let partitionText = '';
            analysis.partitions.forEach(p => {
                partitionText += `${p.name} (${p.type}) at ${p.offset}, ${p.size}\n`;
            });
            document.getElementById('partition-details').textContent = partitionText.trim();
        } else {
            document.getElementById('partition-info').classList.add('hidden');
        }
        
        // Show warning or info if needed
        if (analysis.warning) {
            document.getElementById('esp32-warning').classList.remove('hidden');
            document.getElementById('warning-text').textContent = analysis.warning;
            document.getElementById('confirm-flash').checked = false;
        } else if (analysis.info) {
            // Show info message without warning icon for merged binaries
            document.getElementById('esp32-warning').classList.remove('hidden');
            document.getElementById('esp32-warning').classList.add('info-box');
            document.getElementById('warning-text').textContent = analysis.info;
            // Hide the checkbox for info messages
            const checkbox = document.getElementById('esp32-warning').querySelector('.checkbox-container');
            if (checkbox) checkbox.style.display = 'none';
        } else {
            document.getElementById('esp32-warning').classList.add('hidden');
            document.getElementById('esp32-warning').classList.remove('info-box');
        }
        
        // Store analysis for use during flashing
        DroidNet.state.esp32.currentBinaryAnalysis = analysis;
    }
}

async function flashFirmware() {
    const devicePort = document.getElementById('device-select').value;
    const firmwareFile = document.getElementById('firmware-file').files[0];
    const boardType = document.getElementById('board-type').value;
    
    if (!devicePort || !firmwareFile) {
        showStatusMessage('Please select a device and firmware file', 'error', 8000);
        return;
    }
    
    // Check file extension
    const fileName = firmwareFile.name.toLowerCase();
    if (!fileName.endsWith('.hex') && !fileName.endsWith('.bin')) {
        showStatusMessage('Please select a .hex file (Arduino) or .bin file (ESP32)', 'error', 8000);
        return;
    }
    
    // Check if warning confirmation is required for ESP32
    if (fileName.endsWith('.bin') && DroidNet.state.esp32.currentBinaryAnalysis) {
        const analysis = DroidNet.state.esp32.currentBinaryAnalysis;
        if (analysis.warning && !document.getElementById('confirm-flash').checked) {
            showStatusMessage('Please confirm that you understand the risks before flashing', 'error', 8000);
            return;
        }
    }
    
    // Disconnect any active serial connections to avoid port conflicts
    let disconnectedConnections = [];
    
    if (DroidNet.state.serial.socket && DroidNet.state.serial.socket.readyState === WebSocket.OPEN) {
        console.log('Disconnecting serial monitor for firmware flash...');
        DroidNet.state.serial.socket.close();
        DroidNet.state.serial.socket = null;
        DroidNet.state.serial.isConnected = false;
        document.getElementById('serial-btn').textContent = 'Connect';
        addSerialLog('Disconnected for firmware flash');
        disconnectedConnections.push('Serial Monitor');
    }
    
    // Also disconnect WCB if it's using the same device
    if (DroidNet.state.wcb.socket && DroidNet.state.wcb.socket.readyState === WebSocket.OPEN) {
        // Get the WCB device port
        const wcbDevice = document.getElementById('wcb-device-select')?.value;
        if (wcbDevice === devicePort) {
            console.log('Disconnecting WCB serial for firmware flash...');
            DroidNet.state.wcb.socket.close();
            DroidNet.state.wcb.socket = null;
            DroidNet.state.wcb.isConnected = false;
            updateWCBConnectionStatus(false);
            addWCBSerialLog('Disconnected for firmware flash');
            disconnectedConnections.push('WCB');
        }
    }
    
    // Show notification if connections were closed
    if (disconnectedConnections.length > 0) {
        showStatusMessage(`Disconnected ${disconnectedConnections.join(' and ')} to free serial port for flashing`, 'info', 3000);
    }
    
    const formData = new FormData();
    formData.append('firmware_file', firmwareFile);
    formData.append('device_port', devicePort);
    formData.append('board_type', boardType);
    
    // Add binary analysis info for ESP32
    if (fileName.endsWith('.bin') && DroidNet.state.esp32.currentBinaryAnalysis) {
        const analysis = DroidNet.state.esp32.currentBinaryAnalysis;
        formData.append('binary_type', analysis.type);
        if (analysis.suggestedAddress !== null) {
            formData.append('flash_address', '0x' + analysis.suggestedAddress.toString(16));
        }
    }
    
    // Add ESP32 additional files if provided
    if (fileName.endsWith('.bin') && document.getElementById('esp32-advanced-toggle').checked) {
        const bootloaderFile = document.getElementById('bootloader-file').files[0];
        const partitionsFile = document.getElementById('partitions-file').files[0];
        const otadataFile = document.getElementById('otadata-file').files[0];
        
        if (bootloaderFile) formData.append('bootloader_file', bootloaderFile);
        if (partitionsFile) formData.append('partitions_file', partitionsFile);
        if (otadataFile) formData.append('otadata_file', otadataFile);
    }
    
    // Show progress section and console
    document.getElementById('flash-progress').classList.remove('hidden');
    document.getElementById('flash-console').classList.remove('hidden');
    document.getElementById('flash-btn').disabled = true;
    document.getElementById('flash-status').textContent = 'Uploading firmware...';
    
    // Clear previous console output
    clearFlashConsole();
    addFlashLog('Starting firmware upload...', 'info');
    
    try {
        const response = await fetch('/api/flash', {
            method: 'POST',
            body: formData
        });
        
        if (response.ok) {
            const result = await response.json();
            
            // Show avrdude output if available
            if (result.output) {
                const lines = result.output.split('\n');
                lines.forEach(line => {
                    if (line.trim()) {
                        // Skip misleading error messages if flash was successful
                        if (result.success && line.includes('esptool.py not installed')) {
                            // Don't show this error if flash succeeded
                            return;
                        }
                        
                        if (line.includes('error') || line.includes('Error')) {
                            // Only show as error if the overall operation failed
                            if (!result.success) {
                                addFlashLog(line, 'error');
                            } else {
                                addFlashLog(line, 'warning');
                            }
                        } else if (line.includes('done') || line.includes('complete')) {
                            addFlashLog(line, 'success');
                        } else if (line.includes('ESP32') || line.includes('Chip is')) {
                            addFlashLog(line, 'info');
                        } else {
                            addFlashLog(line);
                        }
                    }
                });
            }
            
            // Check if flash actually succeeded
            if (result.success) {
                const message = result.message || 'Firmware flashed successfully!';
                updateFlashProgress(100, message);
                addFlashLog('Flash completed successfully!', 'success');
                
                // Show board type if detected
                if (message.includes('ESP32') || message.includes('Arduino')) {
                    addFlashLog(`Board type: ${message}`, 'info');
                }
            } else {
                // Flash failed even though HTTP request succeeded
                showStatusMessage('Flash failed: ' + result.message, 'error', 8000);
                addFlashLog('Flash failed: ' + result.message, 'error');
                updateFlashProgress(100, 'Flash failed');
                document.getElementById('flash-progress').classList.add('hidden');
            }
            
            setTimeout(() => {
                document.getElementById('flash-btn').disabled = false;
            }, 3000);
        } else {
            const error = await response.json();
            showStatusMessage('Flash failed: ' + error.message, 'error', 8000);
            addFlashLog('Flash failed: ' + error.message, 'error');
            if (error.output) {
                addFlashLog(error.output, 'error');
            }
            document.getElementById('flash-progress').classList.add('hidden');
            document.getElementById('flash-btn').disabled = false;
        }
    } catch (error) {
        showStatusMessage('Flash error: ' + error.message, 'error', 8000);
        addFlashLog('Flash error: ' + error.message, 'error');
        document.getElementById('flash-progress').classList.add('hidden');
        document.getElementById('flash-btn').disabled = false;
    }
}

function addFlashLog(message, type = '') {
    const log = document.getElementById('flash-log');
    const timestamp = new Date().toLocaleTimeString();
    const entry = document.createElement('div');
    
    const timestampSpan = document.createElement('span');
    timestampSpan.className = 'timestamp';
    timestampSpan.textContent = `[${timestamp}] `;
    
    const messageSpan = document.createElement('span');
    if (type) messageSpan.className = type;
    messageSpan.textContent = message;
    
    entry.appendChild(timestampSpan);
    entry.appendChild(messageSpan);
    log.appendChild(entry);
    
    // Auto-scroll to bottom
    log.scrollTop = log.scrollHeight;
}

function clearFlashConsole() {
    document.getElementById('flash-log').innerHTML = '';
}

function copyFlashLog() {
    const log = document.getElementById('flash-log');
    const text = log.textContent || log.innerText;
    copyToClipboard(text, event.target);
}

function updateFlashProgress(percent, status) {
    document.getElementById('progress-fill').style.width = percent + '%';
    document.getElementById('flash-status').textContent = status;
}

// Serial Monitor
async function loadSerialDevices() {
    try {
        // Fetch devices, custom names, and serial config in parallel
        const [devicesResponse, namesResponse, configResponse] = await Promise.all([
            fetch('/api/devices/serial'),
            fetch('/api/devices/names'),
            fetch('/api/device-serial-config').catch(() => ({ ok: false }))
        ]);
        
        const devices = await devicesResponse.json();
        const customNames = await namesResponse.json();
        let deviceSerialConfig = {};
        
        if (configResponse.ok) {
            try {
                const configData = await configResponse.json();
                deviceSerialConfig = configData.devices || {};
            } catch (e) {
                console.warn('Could not parse device serial config:', e);
            }
        }
        
        const select = document.getElementById('serial-device');
        select.innerHTML = '<option value="">Select device...</option>';
        
        devices.forEach(device => {
            const displayName = DroidNet.utils.getDeviceDisplayName(device, customNames);
            
            // Check if device has saved baud rate
            const deviceConfig = Object.values(deviceSerialConfig).find(
                config => config.port === device.port
            );
            const savedBaud = deviceConfig?.last_successful_baud;
            
            const option = document.createElement('option');
            option.value = device.port;
            option.dataset.savedBaud = savedBaud || '';
            
            let optionText = `${displayName} (${device.port})`;
            if (savedBaud) {
                optionText += ` - ${savedBaud} baud`;
            }
            option.textContent = optionText;
            
            select.appendChild(option);
        });
        
        // Add change handler to update baud rate
        select.onchange = function() {
            const selectedOption = this.options[this.selectedIndex];
            if (selectedOption && selectedOption.dataset.savedBaud) {
                document.getElementById('baud-rate').value = selectedOption.dataset.savedBaud;
            }
        };
        
    } catch (error) {
        console.error('Failed to load serial devices:', error);
    }
}

async function toggleSerial() {
    const button = document.getElementById('serial-btn');
    const devicePort = document.getElementById('serial-device').value;
    const baudRate = document.getElementById('baud-rate').value;

    console.log('Toggle serial - port:', devicePort, 'baud:', baudRate);

    if (!DroidNet.state.serial.isConnected) {
        if (!devicePort) {
            showStatusMessage('Please select a device', 'error', 8000);
            return;
        }

        // Check if device has always-on WCB listener
        try {
            const response = await fetch('/api/wcb/listeners');
            const data = await response.json();

            if (data.success && data.listeners) {
                const hasListener = data.listeners.some(l => l.port === devicePort && l.connected);
                if (hasListener) {
                    showStatusMessage('This device has an always-on WCB listener. Please use the WCB tab to monitor it.', 'error', 8000);
                    return;
                }
            }
        } catch (error) {
            console.error('Error checking for WCB listeners:', error);
            // Continue with connection if check fails
        }

        connectSerial(devicePort, baudRate);
    } else {
        disconnectSerial();
    }
}

function connectSerial(port, baud) {
    // Disconnect any existing WCB connection first
    if (DroidNet.state.wcb.socket && DroidNet.state.wcb.socket.readyState === WebSocket.OPEN) {
        console.log('Closing WCB connection to use serial monitor');
        DroidNet.state.wcb.socket.close();
    }
    
    const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
    // WebSocket server runs on port 8080
    const wsHost = location.hostname + ':8080';
    const wsUrl = `${protocol}//${wsHost}/api/serial/ws?port=${encodeURIComponent(port)}&baud=${encodeURIComponent(baud)}`;
    
    console.log('Connecting to WebSocket:', wsUrl);
    DroidNet.state.serial.socket = new WebSocket(wsUrl);
    
    DroidNet.state.serial.socket.onopen = function() {
        DroidNet.state.serial.isConnected = true;
        DroidNet.state.serial.expectedSeq = 1;  // Track expected sequence number
        document.getElementById('serial-btn').textContent = 'Disconnect';
        addSerialLog('Connected to ' + port + ' at ' + baud + ' baud');
    };

    DroidNet.state.serial.socket.onmessage = function(event) {
        const data = event.data;

        // Try to parse as JSON (new format with sequence numbers)
        try {
            const parsed = JSON.parse(data);
            if (parsed.seq !== undefined && parsed.line !== undefined) {
                // Reassemble chunked messages first
                const msg = reassembleChunks(parsed, DroidNet.state.serial.chunkBuffers);
                if (!msg) {
                    // Still buffering chunks, wait for more
                    return;
                }

                // Check for sequence gaps (potential data loss)
                if (DroidNet.state.serial.expectedSeq && msg.seq > DroidNet.state.serial.expectedSeq) {
                    const missed = msg.seq - DroidNet.state.serial.expectedSeq;
                    addSerialLog(`⚠️ Possible data loss: ${missed} message(s) missed`, 'warning');
                }
                DroidNet.state.serial.expectedSeq = msg.seq + 1;

                // Diagnostic: Verify hash integrity for all messages with hash
                if (msg.hash && msg.len !== undefined) {
                    const receivedLen = msg.line.length;
                    const calculatedHash = CRC32(msg.line);

                    // Log diagnostics for long lines or hash mismatches
                    if (receivedLen > 1000 || calculatedHash !== msg.hash || receivedLen !== msg.len) {
                        const first50 = msg.line.substring(0, 50);
                        const last50 = msg.line.substring(Math.max(0, msg.line.length - 50));

                        console.log(`[WS-DIAG] seq=${msg.seq} serverLen=${msg.len} clientLen=${receivedLen} serverHash=${msg.hash} clientHash=${calculatedHash}`);
                        console.log(`[WS-DIAG] first50: ${first50}`);
                        console.log(`[WS-DIAG] last50: ${last50}`);

                        // Check for corruption
                        if (calculatedHash !== msg.hash) {
                            console.error(`[WS-DIAG] ❌ HASH MISMATCH! Data corrupted in transit.`);
                            addSerialLog(`⚠️ DATA CORRUPTION DETECTED: seq=${msg.seq} expected hash ${msg.hash}, got ${calculatedHash}`, 'warning');
                        }
                        if (receivedLen !== msg.len) {
                            console.error(`[WS-DIAG] ❌ LENGTH MISMATCH! Server sent ${msg.len} chars, received ${receivedLen} chars.`);
                            addSerialLog(`⚠️ LENGTH MISMATCH: seq=${msg.seq} expected ${msg.len} chars, got ${receivedLen} chars`, 'warning');
                        }
                    }
                }

                // Display the line with appropriate type
                addSerialLog(msg.line, msg.direction || 'received');
                return;
            }
        } catch (e) {
            // Not JSON - fall through to plain text handling
        }

        // Plain text message (connection info, status, etc.)
        addSerialLog(data);
    };
    
    DroidNet.state.serial.socket.onclose = function() {
        DroidNet.state.serial.isConnected = false;
        document.getElementById('serial-btn').textContent = 'Connect';
        addSerialLog('Serial connection closed');
    };
    
    DroidNet.state.serial.socket.onerror = function(error) {
        showStatusMessage('Serial connection error', 'error', 8000);
        DroidNet.state.serial.isConnected = false;
        document.getElementById('serial-btn').textContent = 'Connect';
    };
}

function disconnectSerial() {
    if (DroidNet.state.serial.socket) {
        DroidNet.state.serial.socket.close();
    }
}

function sendSerial() {
    const input = document.getElementById('serial-command');
    const command = input.value.trim();
    
    if (command && DroidNet.state.serial.isConnected && DroidNet.state.serial.socket) {
        DroidNet.state.serial.socket.send(command);
        addSerialLog('> ' + command, 'sent');
        
        // Add to command history
        if (DroidNet.state.serial.commandHistory.length === 0 || DroidNet.state.serial.commandHistory[DroidNet.state.serial.commandHistory.length - 1] !== command) {
            DroidNet.state.serial.commandHistory.push(command);
            // Limit history to 50 commands
            if (DroidNet.state.serial.commandHistory.length > 50) {
                DroidNet.state.serial.commandHistory.shift();
            }
        }
        
        // Reset history position
        DroidNet.state.serial.historyPosition = -1;
        DroidNet.state.serial.tempCommand = '';
        
        input.value = '';
    }
}

function navigateSerialHistory(direction) {
    const input = document.getElementById('serial-command');
    
    if (direction === 'up') {
        // Save current input if starting to navigate
        if (DroidNet.state.serial.historyPosition === -1 && input.value.trim()) {
            DroidNet.state.serial.tempCommand = input.value;
        }
        
        // Move up in history
        if (DroidNet.state.serial.historyPosition < DroidNet.state.serial.commandHistory.length - 1) {
            DroidNet.state.serial.historyPosition++;
            const historyIndex = DroidNet.state.serial.commandHistory.length - 1 - DroidNet.state.serial.historyPosition;
            input.value = DroidNet.state.serial.commandHistory[historyIndex];
        }
    } else if (direction === 'down') {
        // Move down in history
        if (DroidNet.state.serial.historyPosition > -1) {
            DroidNet.state.serial.historyPosition--;
            
            if (DroidNet.state.serial.historyPosition === -1) {
                // Restore temporary command
                input.value = DroidNet.state.serial.tempCommand;
            } else {
                const historyIndex = DroidNet.state.serial.commandHistory.length - 1 - DroidNet.state.serial.historyPosition;
                input.value = DroidNet.state.serial.commandHistory[historyIndex];
            }
        }
    }
    
    // Move cursor to end of input
    input.setSelectionRange(input.value.length, input.value.length);
}

function addSerialLog(message, type = 'received') {
    const output = document.getElementById('serial-output');
    const log = output.querySelector('.serial-log');

    const timestamp = new Date().toLocaleTimeString();
    let prefix = type === 'sent' ? '> ' : '';
    let displayMessage = message;

    // Check if this is a Comlink command
    if (message.startsWith('[COMLINK] ')) {
        displayMessage = message.substring(10); // Remove [COMLINK] prefix
        prefix = '⚡ '; // Lightning bolt for Comlink commands
        type = 'comlink';
    } else if (type === 'warning') {
        prefix = '';  // Warning messages include their own prefix
    }

    // Create a span element for better styling
    const logEntry = document.createElement('div');
    logEntry.className = `serial-log-entry ${type}`;
    logEntry.textContent = `[${timestamp}] ${prefix}${displayMessage}`;

    // Add styling based on type
    if (type === 'comlink') {
        logEntry.style.color = '#00ff00';
        logEntry.style.fontWeight = 'bold';
    } else if (type === 'warning') {
        logEntry.style.color = '#ffaa00';
        logEntry.style.fontWeight = 'bold';
    } else if (type === 'sent') {
        logEntry.style.color = '#88aaff';
    }

    log.appendChild(logEntry);
    output.scrollTop = output.scrollHeight;
}

function clearSerial() {
    const log = document.querySelector('.serial-log');
    log.innerHTML = '';
    const clearMessage = document.createElement('div');
    clearMessage.className = 'serial-log-entry';
    clearMessage.textContent = 'Serial log cleared.';
    log.appendChild(clearMessage);
}

function copySerial() {
    const log = document.querySelector('.serial-log');
    const text = log.textContent;
    copyToClipboard(text, event.target);
}

// Wi-Fi Configuration
async function loadWifiStatus() {
    try {
        const [statusResponse, savedResponse, modeResponse, prioritiesResponse] = await Promise.all([
            fetch('/api/wifi/status'),
            fetch('/api/wifi/saved'),
            fetch('/api/wifi/mode'),
            fetch('/api/wifi/priorities')
        ]);
        
        const status = await statusResponse.json();
        const savedNetworks = await savedResponse.json();
        const wifiMode = await modeResponse.json();
        const priorities = prioritiesResponse.ok ? await prioritiesResponse.json() : {};
        
        console.log('Loaded priorities:', priorities);
        console.log('Saved networks:', savedNetworks);
        
        // Update current status
        document.getElementById('current-ssid').textContent = status.ssid || 'DroidNet-AP';
        document.getElementById('current-ip').textContent = status.ip || '192.168.4.1';
        document.getElementById('network-mode').textContent = status.mode || 'Access Point Mode';
        
        // Update mode buttons visibility
        const apModeBtn = document.getElementById('ap-mode-btn');
        const clientModeBtn = document.getElementById('client-mode-btn');
        
        if (status.mode === 'Access Point Mode' || wifiMode.mode === 'ap') {
            apModeBtn.style.display = 'none';
            clientModeBtn.style.display = 'inline-block';
        } else {
            apModeBtn.style.display = 'inline-block';
            clientModeBtn.style.display = 'none';
        }
        
        // Check if we're in AP mode
        const isAPMode = status.mode === 'Access Point Mode' || wifiMode.mode === 'ap';
        
        // Display saved networks sorted by priority
        const savedNetworkList = document.getElementById('saved-network-list');
        if (savedNetworks.length === 0) {
            savedNetworkList.innerHTML = '<div class="network-item">No saved networks</div>';
        } else {
            // Sort networks by priority (descending)
            const networksWithPriority = savedNetworks.sort((a, b) => (b.priority || 0) - (a.priority || 0));
            
            savedNetworkList.innerHTML = networksWithPriority.map(network => `
                <div class="saved-network-item">
                    <div>
                        <div class="network-name">${network.ssid}</div>
                        <div class="network-priority">
                            Priority: 
                            <input type="number" 
                                   class="priority-input" 
                                   id="priority-${network.ssid.replace(/[^a-zA-Z0-9]/g, '_')}" 
                                   value="${network.priority}" 
                                   min="1" 
                                   max="999">
                            <button onclick="updateNetworkPriority('${network.ssid.replace(/'/g, "\\'")}')" class="priority-save-btn">Save</button>
                        </div>
                    </div>
                    <div class="network-status">
                        ${!isAPMode ? `<span class="availability-indicator ${network.available ? 'available' : ''}"></span>` : ''}
                        <span>${isAPMode ? 'Saved' : (network.available ? 'In range' : 'Not in range')}</span>
                        ${network.available && !isAPMode ? 
                            `<button onclick="connectToSaved('${network.ssid.replace(/'/g, "\\'")}')" class="btn btn-primary" style="padding: 4px 12px; font-size: 0.85em;">Connect</button>` : 
                            ''
                        }
                        <button onclick="forgetNetwork('${network.ssid.replace(/'/g, "\\'")}')" class="forget-btn">Forget</button>
                    </div>
                </div>
            `).join('');
        }
        
    } catch (error) {
        console.error('Failed to load Wi-Fi status:', error);
    }
}

async function connectToSaved(ssid) {
    // No password needed for saved networks
    try {
        const response = await fetch('/api/wifi/connect', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ssid: ssid, password: '' })
        });
        
        if (response.ok) {
            const result = await response.json();
            if (result.success) {
                showSuccess('Connecting to ' + ssid + '...');
                setTimeout(loadWifiStatus, 5000);
            } else {
                // Show error with debug info if available
                if (result.debug) {
                    console.error('Wi-Fi Connection Debug Info:', result.debug);
                }
                showStatusMessage('Connection failed: ' + result.message, 'error', 8000);
            }
        } else {
            const error = await response.json();
            if (error.debug) {
                console.error('Wi-Fi Connection Debug Info:', error.debug);
            }
            showStatusMessage('Connection failed: ' + error.message, 'error', 8000);
        }
    } catch (error) {
        showStatusMessage('Connection error', 'error', 8000);
    }
}

async function forgetNetwork(ssid) {
    showConfirmDialog(
        'Forget Network',
        `Are you sure you want to forget the network "${ssid}"? You will need to re-enter the password to connect again.`,
        async () => {
            try {
                const response = await fetch('/api/wifi/forget', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ ssid: ssid })
                });
                
                const result = await response.json();
                if (result.success) {
                    showSuccess('Network forgotten');
                    loadWifiStatus();
                    loadRememberedNetworks();
                } else {
                    showStatusMessage('Failed to forget network: ' + result.error, 'error', 8000);
                }
            } catch (error) {
                showStatusMessage('Error forgetting network', 'error', 8000);
            }
        },
        'Forget',
        'confirm-btn'
    );
}

async function switchToAPMode() {
    showConfirmDialog(
        'Switch to Access Point Mode',
        'This will disconnect from the current WiFi network and create a hotspot. You will need to connect to the DroidNet access point to continue using the device.',
        async () => {
            const button = event.target;
            setButtonLoading(button, true, 'Switching');
            
            try {
                const response = await fetch('/api/wifi/mode', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ mode: 'ap' })
                });
                
                const result = await response.json();
                if (result.success) {
                    showSuccess('Switching to Access Point mode...');
                    
                    // Show countdown before redirect
                    let countdown = 5;
                    const statusMsg = showStatusMessage(`Redirecting to AP interface in ${countdown} seconds...`, 'info', 0);

                    DroidNet.state.polling.apModeCountdown = setInterval(() => {
                        countdown--;
                        if (countdown > 0) {
                            statusMsg.textContent = `Redirecting to AP interface in ${countdown} seconds...`;
                        } else {
                            clearInterval(DroidNet.state.polling.apModeCountdown);
                            DroidNet.state.polling.apModeCountdown = null;
                            window.location.href = 'http://192.168.4.1';
                        }
                    }, 1000);
                } else {
                    showStatusMessage('Failed to switch mode: ' + result.error, 'error', 8000);
                    setButtonLoading(button, false);
                }
            } catch (error) {
                showStatusMessage('Error switching mode', 'error', 8000);
                setButtonLoading(button, false);
            }
        },
        'Switch to AP Mode',
        'confirm-btn'
    );
}

async function switchToClientMode() {
    showConfirmDialog(
        'Switch to Client Mode',
        'This will stop the access point and attempt to connect to saved WiFi networks in priority order.',
        async () => {
            const button = event.target;
            setButtonLoading(button, true, 'Switching');
            
            try {
                const response = await fetch('/api/wifi/mode', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ mode: 'client' })
                });
                
                const result = await response.json();
                if (result.success) {
                    showSuccess('Switching to Client mode. The device will attempt to connect to saved networks...');
                    // Reload status after a delay
                    setTimeout(() => {
                        loadWifiStatus();
                    }, 10000);
                } else {
                    showStatusMessage('Failed to switch mode: ' + result.error, 'error', 8000);
                }
            } catch (error) {
                showStatusMessage('Error switching mode', 'error', 8000);
            } finally {
                setButtonLoading(button, false);
            }
        },
        'Switch to Client Mode',
        'confirm-btn'
    );
}

async function scanNetworks() {
    const button = event.target;
    setButtonLoading(button, true, 'Scanning');

    try {
        const response = await fetch('/api/wifi/scan');
        if (!response.ok) {
            throw new Error(`HTTP error ${response.status}`);
        }
        const networks = await response.json();
        
        const networkList = document.getElementById('network-list');
        
        if (networks.length === 0) {
            networkList.innerHTML = '<div class="network-item">No networks found</div>';
        } else {
            networkList.innerHTML = networks.map(network => `
                <div class="network-item" onclick="selectNetwork('${network.ssid}')">
                    <span>${network.ssid}</span>
                    <span class="signal-strength">${network.signal}%</span>
                </div>
            `).join('');
        }
        
    } catch (error) {
        showStatusMessage('Failed to scan networks', 'error', 8000);
    } finally {
        setButtonLoading(button, false);
    }
}

function selectNetwork(ssid) {
    document.getElementById('wifi-ssid').value = ssid;
    document.getElementById('network-config').classList.remove('hidden');
}

async function connectWifi() {
    const ssid = document.getElementById('wifi-ssid').value;
    const password = document.getElementById('wifi-password').value;
    const connectBtn = document.querySelector('#network-config button[onclick="connectWifi()"]');
    
    if (!ssid) {
        showStatusMessage('Please enter network name', 'error', 8000);
        return;
    }
    
    // Disable button and show connecting state
    if (connectBtn) {
        connectBtn.disabled = true;
        connectBtn.textContent = 'Connecting...';
    }
    
    try {
        const response = await fetch('/api/wifi/connect', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ssid: ssid, password: password })
        });
        
        const result = await response.json();
        
        if (response.ok && result.success) {
            // Check if this is a mode switch scenario
            if (result.mode_switch) {
                showSuccess(`Switching to client mode and connecting to ${ssid}. You will lose connection to this interface. The device will be available on your network shortly.`);
                document.getElementById('network-config').classList.add('hidden');
                document.getElementById('wifi-password').value = '';
                
                // Don't try to refresh status since we're losing connection
                return;
            } else {
                showSuccess('Connected to ' + ssid + '! The device may restart to complete the switch to client mode.');
                document.getElementById('network-config').classList.add('hidden');
                document.getElementById('wifi-password').value = '';
                
                // Refresh WiFi status and remembered networks after a delay
                setTimeout(() => {
                    loadWifiStatus();
                    loadRememberedNetworks();
                }, 5000);
            }
        } else {
            // Show specific error message
            const errorMsg = result.message || 'Connection failed';
            
            // Check if debug info is available
            if (result.debug) {
                console.error('Wi-Fi Connection Debug Info:', result.debug);
                
                // Create detailed error message with debug info
                let detailsHtml = `<div style="text-align: left; margin-top: 10px;">
                    <strong>Debug Information:</strong><br>
                    <small style="font-family: monospace;">`;
                
                // Add key debug details
                if (result.debug.current_mode) {
                    detailsHtml += `Mode: ${result.debug.current_mode}<br>`;
                }
                if (result.debug.current_state) {
                    detailsHtml += `State: ${result.debug.current_state}<br>`;
                }
                if (result.debug.target_network_found !== undefined) {
                    detailsHtml += `Network Found: ${result.debug.target_network_found}<br>`;
                }
                if (result.debug.wifi_radio) {
                    detailsHtml += `Wi-Fi Radio: ${result.debug.wifi_radio}<br>`;
                }
                if (result.debug.nmcli_stderr) {
                    detailsHtml += `Error: ${result.debug.nmcli_stderr}<br>`;
                }
                
                detailsHtml += `</small></div>`;
                
                // Show error with debug details
                showStatusMessage(errorMsg + detailsHtml, 'error', 8000);
            } else {
                showStatusMessage(errorMsg, 'error', 8000);
            }
            
            // If it's a password error, keep the dialog open
            if (errorMsg.includes('password') || errorMsg.includes('Invalid')) {
                document.getElementById('wifi-password').focus();
                document.getElementById('wifi-password').select();
            }
        }
    } catch (error) {
        console.error('Connection error:', error);
        // Check if we might have lost connection due to mode switch
        // If the device was in AP mode and we're connecting to WiFi, 
        // the connection loss is expected
        const isLikelyModeSwitch = window.location.hostname === '192.168.4.1';
        if (isLikelyModeSwitch) {
            showSuccess(`Connection initiated. The device is switching to your network. You will lose connection to this interface.`);
            document.getElementById('network-config').classList.add('hidden');
            document.getElementById('wifi-password').value = '';
        } else {
            showStatusMessage('Connection error - please check if the device is responding', 'error', 8000);
        }
    } finally {
        // Re-enable button
        if (connectBtn) {
            connectBtn.disabled = false;
            connectBtn.textContent = 'Connect';
        }
    }
}

function cancelWifi() {
    document.getElementById('network-config').classList.add('hidden');
    document.getElementById('wifi-password').value = '';
}

// System Status
async function updateSystemStatus() {
    try {
        const response = await fetch('/api/status');
        if (!response.ok) {
            throw new Error(`HTTP error ${response.status}`);
        }
        const status = await response.json();
        
        // Update status indicators
        const connectionStatus = document.getElementById('connection-status');
        const apMode = document.getElementById('ap-mode');

        connectionStatus.textContent = status.connected ? 'Connected' : 'Disconnected';
        connectionStatus.className = 'status-indicator ' + (status.connected ? '' : 'error');

        // Check for fallback mode
        if (status.is_fallback && status.ap_mode) {
            apMode.textContent = 'AP Mode (Temporary)';
            apMode.className = 'status-indicator warning';

            // Show fallback notice
            document.getElementById('fallback-notice').style.display = 'block';
        } else {
            apMode.textContent = status.ap_mode ? 'AP Mode' : 'Client Mode';
            apMode.className = 'status-indicator ' + (status.ap_mode ? '' : 'warning');

            // Hide fallback notice
            document.getElementById('fallback-notice').style.display = 'none';
        }
        
    } catch (error) {
        console.error('Failed to update system status:', error);
    }
}

// Device Name Management
async function loadDeviceName() {
    try {
        const response = await fetch('/api/device/name');
        const data = await response.json();
        
        if (data.success) {
            const input = document.getElementById('device-name');
            if (data.user_configured) {
                input.value = data.hostname;
                input.placeholder = data.hostname;
            } else {
                input.value = '';
                input.placeholder = data.hostname + ' (automatic)';
            }
        }
    } catch (error) {
        console.error('Failed to load device name:', error);
    }
}

async function updateDeviceName() {
    const name = document.getElementById('device-name').value.trim();
    const button = event.target;
    
    setButtonLoading(button, true, 'Updating');
    
    try {
        const response = await fetch('/api/device/name', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name })
        });
        
        const result = await response.json();
        
        if (result.success) {
            showSuccess(result.message || 'Device name updated successfully');
            // Update placeholder
            const input = document.getElementById('device-name');
            if (name) {
                input.placeholder = result.hostname;
            } else {
                input.placeholder = result.hostname + ' (automatic)';
            }
            animateSuccess(input);
        } else {
            showStatusMessage(result.error || 'Failed to update device name', 'error', 8000);
        }
    } catch (error) {
        showStatusMessage('Failed to update device name', 'error', 8000);
    } finally {
        setButtonLoading(button, false);
    }
}

async function resetDeviceName() {
    showConfirmDialog(
        'Reset Device Name',
        'Reset to automatic device name based on MAC address?',
        async () => {
            const button = document.querySelector('button[onclick="resetDeviceName()"]');
            setButtonLoading(button, true, 'Resetting');
            
            try {
                const response = await fetch('/api/device/name', {
                    method: 'DELETE'
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showSuccess('Device name reset to automatic');
                    // Clear input and update placeholder
                    const input = document.getElementById('device-name');
                    input.value = '';
                    input.placeholder = result.hostname + ' (automatic)';
                    animateSuccess(input);
                } else {
                    showStatusMessage(result.error || 'Failed to reset device name', 'error', 8000);
                }
            } catch (error) {
                showStatusMessage('Failed to reset device name', 'error', 8000);
            } finally {
                setButtonLoading(button, false);
            }
        },
        'Reset',
        'cancel-btn'
    );
}

async function rebootDevice() {
    showConfirmDialog(
        'Reboot Device',
        'Are you sure you want to reboot the device? You will lose connection temporarily and need to wait 30-60 seconds before reconnecting.',
        async () => {
            const statusDiv = document.getElementById('reboot-status');
            statusDiv.classList.remove('hidden');
            statusDiv.className = 'status-message info';
            statusDiv.textContent = 'Sending reboot command...';
            
            try {
                const response = await fetch('/api/system/reboot', {
                    method: 'POST'
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showSuccess('Device is rebooting. Please wait 30-60 seconds and refresh the page.');
                    statusDiv.className = 'status-message success';
                    statusDiv.textContent = 'Device is rebooting...';
                    
                    // Show countdown
                    let countdown = 60;
                    DroidNet.state.polling.rebootCountdown = setInterval(() => {
                        countdown--;
                        if (countdown > 0) {
                            statusDiv.textContent = `Device is rebooting... (${countdown}s)`;
                        } else {
                            clearInterval(DroidNet.state.polling.rebootCountdown);
                            DroidNet.state.polling.rebootCountdown = null;
                            statusDiv.textContent = 'Device should be ready. Refresh the page to reconnect.';
                        }
                    }, 1000);
                } else {
                    showStatusMessage(result.error || 'Failed to reboot device', 'error', 8000);
                    statusDiv.classList.add('hidden');
                }
            } catch (error) {
                showStatusMessage('Failed to send reboot command. Device may already be rebooting.', 'error', 8000);
                statusDiv.classList.add('hidden');
            }
        },
        'Reboot',
        'confirm-btn'
    );
}

// System Update Functions
DroidNet.state.update.eventSource = null;
DroidNet.state.polling.updateStatusPoller = null;
DroidNet.state.update.logBuffer = [];

// Update console functions
function addUpdateLog(message, type = 'info') {
    const logDiv = document.getElementById('update-log');
    const timestamp = new Date().toLocaleTimeString();
    const entry = document.createElement('div');
    entry.className = `log-entry log-${type}`;
    entry.innerHTML = `<span class="log-time">[${timestamp}]</span> <span class="log-text">${escapeHtml(message)}</span>`;
    logDiv.appendChild(entry);
    logDiv.scrollTop = logDiv.scrollHeight;
    
    // Add to buffer for copying
    DroidNet.state.update.logBuffer.push(`[${timestamp}] ${message}`);
}

function clearUpdateConsole() {
    document.getElementById('update-log').innerHTML = '';
    DroidNet.state.update.logBuffer = [];
}

function copyUpdateLog() {
    const logText = DroidNet.state.update.logBuffer.join('\n');
    
    // Check if clipboard API is available (requires HTTPS or localhost)
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(logText).then(() => {
            showSuccess('Update log copied to clipboard');
        }).catch(err => {
            console.error('Failed to copy log:', err);
            fallbackCopyToClipboard(logText);
        });
    } else {
        // Fallback for HTTP contexts
        fallbackCopyToClipboard(logText);
    }
}

function fallbackCopyToClipboard(text) {
    // Create a temporary textarea element
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    textArea.style.top = '-999999px';
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    
    try {
        const successful = document.execCommand('copy');
        if (successful) {
            showSuccess('Update log copied to clipboard');
        } else {
            showStatusMessage('Failed to copy log - please select and copy manually', 'error', 8000);
        }
    } catch (err) {
        console.error('Fallback copy failed:', err);
        showStatusMessage('Failed to copy log - please select and copy manually', 'error', 8000);
    }
    
    document.body.removeChild(textArea);
}

async function uploadUpdate() {
    const fileInput = document.getElementById('update-file');
    const updateBtn = document.getElementById('update-btn');
    const statusDiv = document.getElementById('update-status');
    const progressDiv = document.getElementById('update-progress');
    const progressFill = document.getElementById('progress-fill');
    const statusText = document.getElementById('update-status-text');
    const consoleDiv = document.getElementById('update-console');
    
    if (!fileInput.files.length) {
        showStatusMessage('Please select an update file', 'error', 8000);
        return;
    }
    
    const file = fileInput.files[0];
    
    // Validate file type
    if (!file.name.endsWith('.zip')) {
        showStatusMessage('Please select a valid update package (.zip file)', 'error', 8000);
        return;
    }
    
    // Show confirmation dialog
    showConfirmDialog(
        'Install Update',
        `Are you sure you want to install the update "${file.name}"? The device will restart automatically after the update is applied.`,
        async () => {
            // Disable button and show progress and console
            updateBtn.disabled = true;
            updateBtn.textContent = 'Uploading...';
            progressDiv.classList.remove('hidden');
            consoleDiv.classList.remove('hidden');
            statusDiv.classList.add('hidden');
            
            // Clear previous logs
            clearUpdateConsole();
            addUpdateLog(`Starting update with ${file.name}`, 'info');
            
            // Create form data
            const formData = new FormData();
            formData.append('update_file', file);
            
            try {
                // Upload with progress tracking
                const xhr = new XMLHttpRequest();
                
                xhr.upload.addEventListener('progress', (event) => {
                    if (event.lengthComputable) {
                        const percentComplete = (event.loaded / event.total) * 100;
                        progressFill.style.width = percentComplete + '%';
                        statusText.textContent = `Uploading... ${Math.round(percentComplete)}%`;
                        
                        if (percentComplete === 100) {
                            addUpdateLog('Upload complete, processing update package...', 'success');
                        }
                    }
                });
                
                xhr.addEventListener('load', () => {
                    if (xhr.status === 200) {
                        const result = JSON.parse(xhr.responseText);
                        if (result.success) {
                            statusText.textContent = 'Installing update...';
                            progressFill.style.width = '100%';
                            addUpdateLog('Update package uploaded successfully', 'success');
                            
                            // Connect to update stream for real-time logs
                            connectUpdateStream();
                        } else {
                            showStatusMessage(result.error || 'Update upload failed', 'error', 8000);
                            addUpdateLog(`Upload failed: ${result.error || 'Unknown error'}`, 'error');
                            resetUpdateUI();
                        }
                    } else {
                        showStatusMessage('Upload failed: ' + xhr.statusText, 'error', 8000);
                        addUpdateLog(`Upload failed: ${xhr.statusText}`, 'error');
                        resetUpdateUI();
                    }
                });
                
                xhr.addEventListener('error', () => {
                    showStatusMessage('Upload failed: Network error', 'error', 8000);
                    addUpdateLog('Upload failed: Network error', 'error');
                    resetUpdateUI();
                });
                
                xhr.open('POST', '/api/system/update');
                xhr.send(formData);
                
            } catch (error) {
                showStatusMessage('Failed to upload update: ' + error.message, 'error', 8000);
                addUpdateLog(`Failed to upload update: ${error.message}`, 'error');
                resetUpdateUI();
            }
        },
        'Install Update',
        'confirm-btn'
    );
}

function connectUpdateStream() {
    // Close any existing connection
    if (DroidNet.state.update.eventSource) {
        DroidNet.state.update.eventSource.close();
    }
    
    addUpdateLog('Connecting to update stream...', 'info');
    
    // Connect to server-sent events stream
    DroidNet.state.update.eventSource = new EventSource('/api/system/update-stream');
    
    DroidNet.state.update.eventSource.onopen = function() {
        addUpdateLog('Connected to update stream', 'success');
    };
    
    DroidNet.state.update.eventSource.onmessage = function(event) {
        try {
            const data = JSON.parse(event.data);
            
            if (data.type === 'log') {
                addUpdateLog(data.message, data.level || 'info');
            } else if (data.type === 'progress') {
                const statusText = document.getElementById('update-status-text');
                statusText.textContent = data.message;
            } else if (data.type === 'complete') {
                handleUpdateComplete(data);
            } else if (data.type === 'error') {
                handleUpdateError(data);
            } else if (data.type === 'connected') {
                addUpdateLog(data.message || 'Stream connected', 'info');
            }
        } catch (e) {
            console.error('Failed to parse update stream message:', e);
            addUpdateLog('Received invalid update stream data', 'error');
        }
    };
    
    DroidNet.state.update.eventSource.onerror = function(error) {
        console.error('Update stream error:', error);
        
        if (DroidNet.state.update.eventSource.readyState === EventSource.CONNECTING) {
            addUpdateLog('Connecting to update stream...', 'warning');
        } else if (DroidNet.state.update.eventSource.readyState === EventSource.CLOSED) {
            // Check if this might be due to service restart
            const lastLog = document.getElementById('update-log').lastElementChild?.textContent || '';
            if (lastLog.includes('Services are restarting') || lastLog.includes('Restarting services')) {
                addUpdateLog('Services are restarting - this is normal. Checking update status...', 'info');
            } else {
                addUpdateLog('Connection to update stream lost - checking status...', 'warning');
            }
            
            // Close the event source
            if (DroidNet.state.update.eventSource) {
                DroidNet.state.update.eventSource.close();
                DroidNet.state.update.eventSource = null;
            }
            
            // Check status immediately and then periodically
            checkUpdateStatus();
            
            // Set up polling to catch completion
            if (!DroidNet.state.polling.updateStatusPoller) {
                DroidNet.state.polling.updateStatusPoller = setInterval(async () => {
                    const status = await checkUpdateStatus();
                    if (status && (status.status === 'completed' || status.status === 'failed' || status.status === 'idle')) {
                        clearInterval(DroidNet.state.polling.updateStatusPoller);
                        DroidNet.state.polling.updateStatusPoller = null;
                    }
                }, 2000);
            }
        }
    };
}

function handleUpdateComplete(data) {
    const statusDiv = document.getElementById('update-status');
    const statusText = document.getElementById('update-status-text');
    
    if (DroidNet.state.update.eventSource) {
        DroidNet.state.update.eventSource.close();
        DroidNet.state.update.eventSource = null;
    }
    
    statusText.textContent = 'Update completed successfully!';
    statusDiv.classList.remove('hidden');
    statusDiv.className = 'status-message success';
    statusDiv.textContent = `Update to version ${data.version} completed successfully!`;
    
    addUpdateLog(`✅ Update completed successfully! New version: ${data.version}`, 'success');
    addUpdateLog('The page will refresh automatically in 5 seconds...', 'info');
    
    // Reset UI after delay
    setTimeout(() => {
        resetUpdateUI();
        // Refresh to show new version
        loadSystemInfo();
    }, 10000);
}

function handleUpdateError(data) {
    const statusDiv = document.getElementById('update-status');
    const statusText = document.getElementById('update-status-text');
    
    if (DroidNet.state.update.eventSource) {
        DroidNet.state.update.eventSource.close();
        DroidNet.state.update.eventSource = null;
    }
    
    statusText.textContent = 'Update failed';
    statusDiv.classList.remove('hidden');
    statusDiv.className = 'status-message error';
    statusDiv.textContent = data.error || 'Update installation failed';
    
    addUpdateLog(`Update failed: ${data.error || 'Unknown error'}`, 'error');
    
    resetUpdateUI();
}

// Fallback status check for when streaming is not available
async function checkUpdateStatus() {
    try {
        const response = await fetch('/api/system/update-status');
        const status = await response.json();
        
        const progressDiv = document.getElementById('update-progress');
        const statusText = document.getElementById('update-status-text');
        const statusDiv = document.getElementById('update-status');
        
        if (status.status === 'processing') {
            statusText.textContent = status.progress || 'Installing update...';
            
            // Check for pending restart
            if (status.pending_restart) {
                addUpdateLog('Update complete - services are restarting...', 'info');
            } else {
                addUpdateLog(status.progress || 'Update in progress...', 'info');
            }
            
            // If not connected to stream, try to connect
            if (!DroidNet.state.update.eventSource || DroidNet.state.update.eventSource.readyState === EventSource.CLOSED) {
                connectUpdateStream();
            }
        } else if (status.status === 'completed') {
            // Clear any polling
            if (DroidNet.state.polling.updateStatusPoller) {
                clearInterval(DroidNet.state.polling.updateStatusPoller);
                DroidNet.state.polling.updateStatusPoller = null;
            }
            
            // Update succeeded
            const version = status.new_version || status.result?.version || 'unknown';
            
            // Special handling for completion marker
            if (status.from_marker) {
                addUpdateLog('✅ Update completed successfully during service restart!', 'success');
                addUpdateLog(`New version: ${version}`, 'success');
            }
            
            handleUpdateComplete({
                version: version,
                message: 'Update completed successfully'
            });
        } else if (status.status === 'failed') {
            // Clear any polling
            if (DroidNet.state.polling.updateStatusPoller) {
                clearInterval(DroidNet.state.polling.updateStatusPoller);
                DroidNet.state.polling.updateStatusPoller = null;
            }
            
            // Update failed
            handleUpdateError({
                error: status.error || status.result?.error || 'Update installation failed'
            });
        } else if (status.logs) {
            // Display any logs from the status
            status.logs.forEach(log => {
                addUpdateLog(log.message, log.level || 'info');
            });
        }
        
        return status;
    } catch (error) {
        console.error('Failed to check update status:', error);
        addUpdateLog('Failed to check update status', 'error');
        return null;
    }
}

function resetUpdateUI() {
    const updateBtn = document.getElementById('update-btn');
    const progressDiv = document.getElementById('update-progress');
    const progressFill = document.getElementById('progress-fill');
    const fileInput = document.getElementById('update-file');
    const consoleDiv = document.getElementById('update-console');
    
    updateBtn.disabled = false;
    updateBtn.textContent = 'Upload Update';
    progressDiv.classList.add('hidden');
    progressFill.style.width = '0%';
    fileInput.value = '';
    
    // Don't hide console immediately - let user see the final logs
    setTimeout(() => {
        consoleDiv.classList.add('hidden');
    }, 10000);
    
    // Close event source if active
    if (DroidNet.state.update.eventSource) {
        DroidNet.state.update.eventSource.close();
        DroidNet.state.update.eventSource = null;
    }
}

// Load current version on page load
async function loadSystemInfo() {
    try {
        const response = await fetch('/api/system/update-status');
        const status = await response.json();

        if (status.current_version && status.current_version !== 'unknown') {
            document.getElementById('current-version').textContent = 'v' + status.current_version;
        } else {
            // Fallback if no version available
            document.getElementById('current-version').textContent = 'Development';
        }
    } catch (error) {
        console.error('Failed to load system info:', error);
        document.getElementById('current-version').textContent = 'Unknown';
    }
}

// ============================================================================
// GitHub Update Functions
// ============================================================================

/**
 * Load GitHub update availability status on page load
 */
async function loadGitHubUpdateStatus() {
    try {
        const [availableResp, configResp] = await Promise.all([
            fetch('/api/system/update-available'),
            fetch('/api/system/update-config')
        ]);

        const available = await availableResp.json();
        const config = await configResp.json();

        // Update state
        DroidNet.state.update.available = available.available || false;
        DroidNet.state.update.availableVersion = available.available_version || null;
        DroidNet.state.update.currentVersion = available.current_version || null;
        DroidNet.state.update.changelog = available.changelog || [];

        // Update UI
        updateGitHubUpdateUI();

        // Update settings form if elements exist
        const autoCheckEl = document.getElementById('auto-check-updates');
        const intervalEl = document.getElementById('update-check-interval');
        if (autoCheckEl) autoCheckEl.checked = config.auto_check_enabled !== false;
        if (intervalEl) intervalEl.value = config.check_interval_hours || 24;

        // Trigger fresh update check on first page load after restart
        // Uses sessionStorage to track if we've already checked this session
        if (!sessionStorage.getItem('droidnet_startup_update_checked')) {
            sessionStorage.setItem('droidnet_startup_update_checked', 'true');
            // Delay slightly to let the page fully load, then check silently
            setTimeout(() => checkForUpdatesOnStartup(), 2000);
        }

    } catch (error) {
        console.error('Failed to load GitHub update status:', error);
    }
}

/**
 * Check for updates silently on startup (first page load after restart)
 * Only shows notification if an update is actually available
 */
async function checkForUpdatesOnStartup() {
    // Don't interfere if user is already checking
    if (DroidNet.state.update.checkInProgress) return;

    console.log('Checking for updates on startup...');

    try {
        const response = await fetch('/api/system/check-updates', {
            method: 'POST'
        });
        const result = await response.json();

        if (result.success && result.update_available) {
            // Update found - update state and UI
            DroidNet.state.update.available = true;
            DroidNet.state.update.availableVersion = result.available_version;
            DroidNet.state.update.currentVersion = result.current_version;
            DroidNet.state.update.changelog = result.changelog || [];
            updateGitHubUpdateUI();

            // Show a subtle notification that an update is available
            showSuccess(`Update available: v${result.available_version}`, 8000);
            console.log(`Update available: v${result.available_version}`);
        } else if (result.success) {
            // No update available - silently update UI without notification
            DroidNet.state.update.available = false;
            updateGitHubUpdateUI();
            console.log('No updates available');
        }
        // On error, fail silently - don't bother user on startup
    } catch (error) {
        console.log('Startup update check failed (device may be offline):', error.message);
        // Fail silently - this is a background check
    }
}

/**
 * Check for updates manually
 */
async function checkForUpdates(showNotification = true) {
    if (DroidNet.state.update.checkInProgress) return;

    DroidNet.state.update.checkInProgress = true;
    const checkBtn = document.getElementById('check-updates-btn');
    if (checkBtn) {
        checkBtn.disabled = true;
        checkBtn.innerHTML = '<span class="spinner-small"></span> Checking...';
    }

    try {
        const response = await fetch('/api/system/check-updates', {
            method: 'POST'
        });
        const result = await response.json();

        if (result.success) {
            if (result.update_available) {
                DroidNet.state.update.available = true;
                DroidNet.state.update.availableVersion = result.available_version;
                DroidNet.state.update.currentVersion = result.current_version;
                DroidNet.state.update.changelog = result.changelog || [];
                updateGitHubUpdateUI();
                if (showNotification) {
                    showSuccess(`Update available: v${result.available_version}`);
                }
            } else {
                DroidNet.state.update.available = false;
                updateGitHubUpdateUI();
                if (showNotification) {
                    showSuccess('You are running the latest version');
                }
            }
        } else {
            if (showNotification) {
                showStatusMessage(result.error || 'Failed to check for updates', 'error', 8000);
            }
        }
    } catch (error) {
        console.error('Update check failed:', error);
        if (showNotification) {
            showStatusMessage('Failed to connect to update server', 'error', 8000);
        }
    } finally {
        DroidNet.state.update.checkInProgress = false;
        if (checkBtn) {
            checkBtn.disabled = false;
            checkBtn.innerHTML = 'Check for Updates';
        }
    }
}

/**
 * Update the GitHub update UI based on current state
 */
function updateGitHubUpdateUI() {
    const notificationBadge = document.getElementById('update-notification-badge');
    const updateSection = document.getElementById('github-update-section');
    const availableInfo = document.getElementById('update-available-info');

    if (DroidNet.state.update.available) {
        // Show notification badge in header
        if (notificationBadge) {
            notificationBadge.style.display = 'inline-flex';
            notificationBadge.title = `Update available: v${DroidNet.state.update.availableVersion}`;
        }

        // Highlight update section
        if (updateSection) {
            updateSection.classList.add('update-available');
        }

        // Show update available info
        if (availableInfo) {
            const changelogHtml = DroidNet.state.update.changelog.length > 0
                ? `<details class="changelog-details">
                    <summary>What's new</summary>
                    <ul class="changelog-list">
                        ${DroidNet.state.update.changelog.map(item => `<li>${escapeHtml(item)}</li>`).join('')}
                    </ul>
                </details>`
                : '';

            availableInfo.innerHTML = `
                <div class="update-banner">
                    <div class="update-banner-content">
                        <strong>Update Available: v${DroidNet.state.update.availableVersion}</strong>
                        <p>Current version: v${DroidNet.state.update.currentVersion}</p>
                        ${changelogHtml}
                    </div>
                    <div class="update-banner-actions">
                        <button onclick="downloadAndInstallUpdate()" class="btn btn-primary" id="update-now-btn">
                            Update Now
                        </button>
                        <button onclick="dismissGitHubUpdate()" class="btn btn-secondary btn-sm">
                            Dismiss
                        </button>
                    </div>
                </div>
            `;
            availableInfo.style.display = 'block';
        }
    } else {
        // Hide notification badge
        if (notificationBadge) {
            notificationBadge.style.display = 'none';
        }

        // Remove highlight from update section
        if (updateSection) {
            updateSection.classList.remove('update-available');
        }

        // Hide update available info
        if (availableInfo) {
            availableInfo.style.display = 'none';
        }
    }
}

/**
 * Download and install update from GitHub
 */
async function downloadAndInstallUpdate() {
    const updateBtn = document.getElementById('update-now-btn');
    const progressContainer = document.getElementById('github-update-progress');
    const progressBar = document.getElementById('github-update-progress-fill');
    const statusText = document.getElementById('github-update-status');
    const consoleDiv = document.getElementById('update-console');

    // Show confirmation
    showConfirmDialog(
        'Install Update',
        `Are you sure you want to update to v${DroidNet.state.update.availableVersion}? The device will restart after the update.`,
        async () => {
            // Disable button and show progress
            if (updateBtn) updateBtn.disabled = true;
            if (progressContainer) progressContainer.style.display = 'block';
            if (consoleDiv) consoleDiv.classList.remove('hidden');

            // Clear previous logs
            clearUpdateConsole();
            addUpdateLog('Starting download from GitHub...', 'info');

            try {
                // Start download with SSE
                const eventSource = new EventSource('/api/system/download-update');

                eventSource.onmessage = async (event) => {
                    const data = JSON.parse(event.data);

                    if (data.type === 'start') {
                        addUpdateLog('Download started', 'info');
                    } else if (data.type === 'progress') {
                        if (progressBar) progressBar.style.width = `${data.percent}%`;
                        if (statusText) statusText.textContent = `Downloading: ${data.percent}%`;
                    } else if (data.type === 'complete') {
                        eventSource.close();

                        if (data.success) {
                            addUpdateLog('Download complete, verifying...', 'success');
                            if (statusText) statusText.textContent = 'Installing update...';
                            if (progressBar) progressBar.style.width = '100%';

                            // Install the downloaded package
                            await installDownloadedPackage(data.package_path);
                        } else {
                            addUpdateLog(`Download failed: ${data.error}`, 'error');
                            showStatusMessage(data.error || 'Download failed', 'error', 8000);
                            resetGitHubUpdateUI();
                        }
                    } else if (data.type === 'error') {
                        eventSource.close();
                        addUpdateLog(`Error: ${data.error}`, 'error');
                        showStatusMessage(data.error || 'Download error', 'error', 8000);
                        resetGitHubUpdateUI();
                    }
                };

                eventSource.onerror = () => {
                    eventSource.close();
                    addUpdateLog('Connection to server lost', 'error');
                    showStatusMessage('Connection to update server lost', 'error', 8000);
                    resetGitHubUpdateUI();
                };

            } catch (error) {
                console.error('Update failed:', error);
                addUpdateLog(`Update failed: ${error.message}`, 'error');
                showStatusMessage('Update failed: ' + error.message, 'error', 8000);
                resetGitHubUpdateUI();
            }
        },
        'Update Now',
        'confirm-btn'
    );
}

/**
 * Install an already-downloaded update package
 */
async function installDownloadedPackage(packagePath) {
    try {
        addUpdateLog('Installing update package...', 'info');

        const response = await fetch('/api/system/install-downloaded-update', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({package_path: packagePath})
        });

        const result = await response.json();

        if (result.success) {
            addUpdateLog('Installation started', 'success');
            // Connect to update stream for installation progress
            connectUpdateStream();
        } else {
            addUpdateLog(`Installation failed: ${result.error}`, 'error');
            showStatusMessage(result.error || 'Installation failed', 'error', 8000);
            resetGitHubUpdateUI();
        }
    } catch (error) {
        addUpdateLog(`Installation failed: ${error.message}`, 'error');
        showStatusMessage('Installation failed: ' + error.message, 'error', 8000);
        resetGitHubUpdateUI();
    }
}

/**
 * Dismiss the update notification
 */
async function dismissGitHubUpdate() {
    try {
        const response = await fetch('/api/system/dismiss-update', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({version: DroidNet.state.update.availableVersion})
        });

        const result = await response.json();

        if (result.success) {
            DroidNet.state.update.available = false;
            updateGitHubUpdateUI();
            showSuccess('Update notification dismissed');
        }
    } catch (error) {
        console.error('Failed to dismiss update:', error);
    }
}

/**
 * Reset the GitHub update UI to default state
 */
function resetGitHubUpdateUI() {
    const updateBtn = document.getElementById('update-now-btn');
    const progressContainer = document.getElementById('github-update-progress');
    const progressBar = document.getElementById('github-update-progress-fill');

    if (updateBtn) updateBtn.disabled = false;
    if (progressContainer) progressContainer.style.display = 'none';
    if (progressBar) progressBar.style.width = '0%';
}

/**
 * Save GitHub update settings
 */
async function saveUpdateSettings() {
    const autoCheck = document.getElementById('auto-check-updates')?.checked ?? true;
    const checkInterval = parseInt(document.getElementById('update-check-interval')?.value) || 24;

    try {
        const response = await fetch('/api/system/update-config', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                auto_check_enabled: autoCheck,
                check_interval_hours: checkInterval
            })
        });

        const result = await response.json();

        if (result.success) {
            showSuccess('Update settings saved');
        } else {
            showStatusMessage(result.error || 'Failed to save settings', 'error', 8000);
        }
    } catch (error) {
        showStatusMessage('Failed to save settings', 'error', 8000);
    }
}

/**
 * Scroll to update section when notification badge is clicked
 */
function scrollToUpdateSection() {
    const updateSection = document.getElementById('github-update-section');
    if (updateSection) {
        updateSection.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
}

// Utility functions
function showError(message) {
    showStatusMessage(message, 'error', 8000);
}

function showSuccess(message) {
    showStatusMessage(message, 'success', 5000);
}

// Cleanup on page unload
window.addEventListener('beforeunload', function(e) {
    // Check for unsaved changes
    if (DroidNet.state.wcb.unsavedChanges || DroidNet.state.wcb.updateInProgress) {
        e.preventDefault();
        e.returnValue = 'You have unsaved changes. Are you sure you want to leave?';
    }

    // Clean up all intervals
    if (DroidNet.state.polling.refreshInterval) {
        clearInterval(DroidNet.state.polling.refreshInterval);
    }
    if (DroidNet.state.polling.deviceDiscoveryInterval) {
        clearInterval(DroidNet.state.polling.deviceDiscoveryInterval);
    }
    if (DroidNet.state.polling.comlinkRefreshInterval) {
        clearInterval(DroidNet.state.polling.comlinkRefreshInterval);
    }
    if (DroidNet.state.polling.healthCheckInterval) {
        clearInterval(DroidNet.state.polling.healthCheckInterval);
    }
    if (DroidNet.state.polling.wcbPollingInterval) {
        clearInterval(DroidNet.state.polling.wcbPollingInterval);
    }
    if (DroidNet.state.polling.victronPollingInterval) {
        clearInterval(DroidNet.state.polling.victronPollingInterval);
    }
    if (DroidNet.state.polling.victronChartPollingInterval) {
        clearInterval(DroidNet.state.polling.victronChartPollingInterval);
    }
    if (DroidNet.state.polling.updateStatusPoller) {
        clearInterval(DroidNet.state.polling.updateStatusPoller);
    }
    if (DroidNet.state.polling.apModeCountdown) {
        clearInterval(DroidNet.state.polling.apModeCountdown);
    }
    if (DroidNet.state.polling.rebootCountdown) {
        clearInterval(DroidNet.state.polling.rebootCountdown);
    }

    // Clean up all sockets
    if (DroidNet.state.serial.socket) {
        DroidNet.state.serial.socket.close();
    }
    if (DroidNet.state.wcb.socket) {
        DroidNet.state.wcb.socket.close();
    }
    if (typeof maestroClient !== 'undefined' && maestroClient) {
        maestroClient.disconnect();
    }

    // Clean up EventSource
    if (DroidNet.state.update.eventSource) {
        DroidNet.state.update.eventSource.close();
    }

    // Clean up resize handlers
    if (resizeMouseMoveHandler) {
        document.removeEventListener('mousemove', resizeMouseMoveHandler);
    }
    if (resizeMouseUpHandler) {
        document.removeEventListener('mouseup', resizeMouseUpHandler);
    }

    // Clean up Victron charts
    if (DroidNet.state.victron.charts.voltage) {
        DroidNet.state.victron.charts.voltage.destroy();
        DroidNet.state.victron.charts.voltage = null;
    }
    if (DroidNet.state.victron.charts.current) {
        DroidNet.state.victron.charts.current.destroy();
        DroidNet.state.victron.charts.current = null;
    }
    if (DroidNet.state.victron.charts.soc) {
        DroidNet.state.victron.charts.soc.destroy();
        DroidNet.state.victron.charts.soc = null;
    }
    if (DroidNet.state.victron.expandedChart) {
        DroidNet.state.victron.expandedChart.destroy();
        DroidNet.state.victron.expandedChart = null;
    }
});

// Network Priority Management
async function updateNetworkPriority(ssid) {
    const inputId = `priority-${ssid.replace(/[^a-zA-Z0-9]/g, '_')}`;
    const priorityInput = document.getElementById(inputId);
    const priority = parseInt(priorityInput.value);
    const button = event.target;
    
    if (isNaN(priority) || priority < 1 || priority > 999) {
        showStatusMessage('Priority must be between 1 and 999', 'error', 8000);
        priorityInput.focus();
        return;
    }
    
    setButtonLoading(button, true, 'Saving');
    
    try {
        const response = await fetch('/api/wifi/priority', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ssid, priority })
        });
        
        const result = await response.json();
        if (result.success) {
            showSuccess('Priority updated');
            animateSuccess(priorityInput);
            // Don't reload immediately to show the success animation
            setTimeout(() => {
                loadWifiStatus(); // Reload to show sorted list
            }, 500);
        } else {
            showStatusMessage('Failed to update priority: ' + result.error, 'error', 8000);
        }
    } catch (error) {
        showStatusMessage('Error updating priority', 'error', 8000);
    } finally {
        setButtonLoading(button, false);
    }
}

// AP Configuration
async function loadAPConfig() {
    try {
        const response = await fetch('/api/ap/config');
        if (!response.ok) {
            throw new Error('Failed to fetch AP config');
        }
        const config = await response.json();
        
        if (config.success) {
            document.getElementById('ap-ssid').value = config.ssid || '';
            document.getElementById('ap-password').value = config.password || '';
            document.getElementById('ap-ssid').placeholder = config.ssid || 'DroidNet-AP';
            document.getElementById('ap-password').placeholder = '••••••••';
            
            // Remove mode indicator - not needed
            const modeIndicator = document.querySelector('.ap-mode-indicator');
            if (modeIndicator) {
                modeIndicator.textContent = '';
            }
        } else {
            // AP config not available when in client mode - this is expected
            if (config.error !== 'AP connection not found') {
                console.error('AP config error:', config.error);
            }
            document.getElementById('ap-ssid').placeholder = 'AP mode only';
            document.getElementById('ap-password').placeholder = 'AP mode only';
        }
    } catch (error) {
        console.error('Failed to load AP config:', error);
        document.getElementById('ap-ssid').placeholder = 'Error loading';
        document.getElementById('ap-password').placeholder = 'Error loading';
    }
}

async function updateAPSettings() {
    const ssid = document.getElementById('ap-ssid').value.trim();
    const password = document.getElementById('ap-password').value;
    const button = event.target;
    
    if (!ssid) {
        showStatusMessage('Network name cannot be empty', 'error', 8000);
        return;
    }
    
    if (password && password.length < 8) {
        showStatusMessage('Password must be at least 8 characters', 'error', 8000);
        return;
    }
    
    setButtonLoading(button, true, 'Updating');
    
    try {
        const response = await fetch('/api/ap/config', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ssid, password })
        });
        
        const result = await response.json();
        
        if (result.success) {
            showSuccess('AP settings updated. Restart device to apply changes.');
            // Animate the input fields
            animateSuccess(document.getElementById('ap-ssid'));
            animateSuccess(document.getElementById('ap-password'));
        } else {
            showStatusMessage(result.error || 'Failed to update AP settings', 'error', 8000);
        }
    } catch (error) {
        showStatusMessage('Error updating AP settings', 'error', 8000);
    } finally {
        setButtonLoading(button, false);
    }
}

function toggleAPPassword() {
    const passwordInput = document.getElementById('ap-password');
    const toggleBtn = document.getElementById('ap-password-toggle');
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        toggleBtn.textContent = 'Hide';
    } else {
        passwordInput.type = 'password';
        toggleBtn.textContent = 'Show';
    }
}

// Network Settings Management
async function loadNetworkSettings() {
    try {
        const response = await fetch('/api/network/settings');
        const data = await response.json();
        
        if (data.success && data.settings) {
            document.getElementById('connection-timeout').value = data.settings.client_connection_timeout || 60;
        } else {
            console.error('Failed to load network settings:', data.error);
            document.getElementById('connection-timeout').value = 60;
        }
    } catch (error) {
        console.error('Error loading network settings:', error);
        document.getElementById('connection-timeout').value = 60;
    }
}

async function updateNetworkSettings() {
    const timeout = parseInt(document.getElementById('connection-timeout').value);
    const button = event.target;
    const statusDiv = document.getElementById('network-settings-status');
    
    // Validate timeout value
    if (isNaN(timeout) || timeout < 10 || timeout > 300) {
        showStatusMessage('Timeout must be between 10 and 300 seconds', 'error', 8000);
        return;
    }
    
    setButtonLoading(button, true, 'Updating');
    
    try {
        const response = await fetch('/api/network/settings', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ client_connection_timeout: timeout })
        });
        
        const result = await response.json();
        
        if (result.success) {
            showSuccess('Network settings updated successfully', statusDiv);
            animateSuccess(document.getElementById('connection-timeout'));
        } else {
            showStatusMessage(result.error || 'Failed to update network settings', statusDiv, 'error', 8000);
        }
    } catch (error) {
        showStatusMessage('Error updating network settings: ' + error.message, statusDiv, 'error', 8000);
    } finally {
        setButtonLoading(button, false);
    }
}

// Board detection function
async function detectBoard() {
    console.log('detectBoard() called');
    
    // First ensure we're on the flash tab
    const flashTab = document.getElementById('flash-tab');
    if (!flashTab || !flashTab.classList.contains('active')) {
        console.log('Switching to flash tab');
        showTab('flash');
        // Wait a moment for tab to be fully shown
        await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    const devicePort = document.getElementById('device-select').value;
    
    if (!devicePort) {
        showStatusMessage('Please select a device from the dropdown first', 'error', 8000);
        // Focus on the device select dropdown
        document.getElementById('device-select').focus();
        return;
    }
    
    // Disconnect any active serial connections to avoid port conflicts
    let disconnectedConnections = [];
    
    if (DroidNet.state.serial.socket && DroidNet.state.serial.socket.readyState === WebSocket.OPEN) {
        console.log('Disconnecting serial monitor for board detection...');
        DroidNet.state.serial.socket.close();
        DroidNet.state.serial.socket = null;
        DroidNet.state.serial.isConnected = false;
        document.getElementById('serial-btn').textContent = 'Connect';
        addSerialLog('Disconnected for board detection');
        disconnectedConnections.push('Serial Monitor');
    }
    
    // Also disconnect WCB if it's using the same device
    if (DroidNet.state.wcb.socket && DroidNet.state.wcb.socket.readyState === WebSocket.OPEN) {
        const wcbDevice = document.getElementById('wcb-device-select')?.value;
        if (wcbDevice === devicePort) {
            console.log('Disconnecting WCB serial for board detection...');
            DroidNet.state.wcb.socket.close();
            DroidNet.state.wcb.socket = null;
            DroidNet.state.wcb.isConnected = false;
            updateWCBConnectionStatus(false);
            addWCBSerialLog('Disconnected for board detection');
            disconnectedConnections.push('WCB');
        }
    }
    
    // Show notification if connections were closed
    if (disconnectedConnections.length > 0) {
        showStatusMessage(`Disconnected ${disconnectedConnections.join(' and ')} to free serial port for detection`, 'info', 3000);
    }
    
    const detectBtn = document.getElementById('detect-btn');
    detectBtn.disabled = true;
    detectBtn.textContent = 'Detecting...';
    
    // Show the console section
    document.getElementById('flash-console').classList.remove('hidden');
    clearFlashConsole();
    addFlashLog('Starting board detection...', 'info');
    addFlashLog(`Checking device on port ${devicePort}`, 'info');
    
    try {
        addFlashLog('Attempting to read MCU signature...', 'info');

        const response = await fetch(`/api/detect/board?port=${encodeURIComponent(devicePort)}`);
        if (!response.ok) {
            throw new Error(`HTTP error ${response.status}`);
        }
        const result = await response.json();
        
        // Show debug output if available
        if (result.output) {
            const outputLines = result.output.split('\n');
            outputLines.forEach(line => {
                if (line.trim()) {
                    addFlashLog(line);
                }
            });
        }
        
        if (result.success) {
            if (result.type === 'arduino') {
                addFlashLog(`✓ Detected Arduino board!`, 'success');
                addFlashLog(`Board type: ${result.board}`, 'success');
                if (result.config) {
                    addFlashLog(`MCU: ${result.config.mcu || 'unknown'}`, 'info');
                    addFlashLog(`Programmer: ${result.config.programmer || 'unknown'}`, 'info');
                    addFlashLog(`Baud rate: ${result.config.baud || 'unknown'}`, 'info');
                }
                showSuccess(`Detected Arduino ${result.board}`);
                document.getElementById('board-type').value = result.board;
            } else if (result.type === 'esp32') {
                addFlashLog(`✓ Detected ESP32 chip!`, 'success');
                addFlashLog(`Chip type: ${result.chip}`, 'success');
                if (result.config) {
                    addFlashLog(`Flash size: ${result.config.flash_size || 'unknown'}`, 'info');
                    addFlashLog(`Flash mode: ${result.config.flash_mode || 'unknown'}`, 'info');
                    addFlashLog(`Baud rate: ${result.config.baud || 'unknown'}`, 'info');
                }
                showSuccess(`Detected ESP32 chip: ${result.chip}`);
                document.getElementById('board-type').value = result.chip;
            }
            addFlashLog('Detection complete!', 'success');
        } else {
            addFlashLog('✗ Could not detect board type', 'error');
            addFlashLog(`Error: ${result.message || 'Unknown error'}`, 'error');
            if (result.message && result.message.includes('avrdude')) {
                addFlashLog('Tip: Make sure the board is properly connected', 'info');
                addFlashLog('For Leonardo/Pro Micro, try pressing reset button', 'info');
            }
            showStatusMessage('Could not detect board type: ' + (result.message || 'Unknown error'), 'error', 8000);
        }
    } catch (error) {
        addFlashLog('✗ Detection failed', 'error');
        addFlashLog(`Error: ${error.message}`, 'error');
        showStatusMessage('Detection error: ' + error.message, 'error', 8000);
    } finally {
        detectBtn.disabled = false;
        detectBtn.textContent = 'Detect Board Only';
    }
}

// WCB (Wireless Communication Board) Config Functions
async function loadWCBConfig() {
    try {
        const response = await fetch('/api/wcb/config');
        if (!response.ok) {
            throw new Error(`HTTP error ${response.status}`);
        }
        const result = await response.json();

        console.log('WCB config loaded:', result);

        if (result.success) {
            const config = result.config;
            document.getElementById('wcb-enabled-checkbox').checked = config.enabled;

            // Show/hide WCB tab and always-on section based on enabled state
            const wcbTabBtn = document.getElementById('wcb-tab-btn');
            const alwaysOnSection = document.getElementById('wcb-alwayson-section');
            const disabledOverlay = document.getElementById('wcb-disabled-overlay');

            if (config.enabled) {
                wcbTabBtn.style.display = 'inline-block';
                document.getElementById('wcb-devices-section').classList.remove('hidden');
                if (alwaysOnSection) {
                    alwaysOnSection.classList.remove('hidden');
                    loadWCBAlwaysOnConfig();
                }
                if (disabledOverlay) {
                    disabledOverlay.style.display = 'none';
                }
                updateWCBDeviceList();
            } else {
                wcbTabBtn.style.display = 'none';
                document.getElementById('wcb-devices-section').classList.add('hidden');
                if (alwaysOnSection) {
                    alwaysOnSection.classList.add('hidden');
                }
                if (disabledOverlay) {
                    disabledOverlay.style.display = 'flex';
                }
            }
        }
    } catch (error) {
        console.error('Error loading WCB config:', error);
    }
}

async function toggleWCBFeature() {
    const checkbox = document.getElementById('wcb-enabled-checkbox');
    const enabled = checkbox.checked;
    const statusDiv = document.getElementById('wcb-enable-status');

    try {
        const response = await fetch('/api/wcb/config', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ enabled: enabled })
        });

        const result = await response.json();

        if (result.success) {
            // Show/hide WCB tab
            const wcbTabBtn = document.getElementById('wcb-tab-btn');
            const alwaysOnSection = document.getElementById('wcb-alwayson-section');
            const disabledOverlay = document.getElementById('wcb-disabled-overlay');

            if (enabled) {
                wcbTabBtn.style.display = 'inline-block';
                document.getElementById('wcb-devices-section').classList.remove('hidden');
                if (alwaysOnSection) {
                    alwaysOnSection.classList.remove('hidden');
                    loadWCBAlwaysOnConfig();
                }
                if (disabledOverlay) {
                    disabledOverlay.style.display = 'none';
                }
                updateWCBDeviceList();
                showSuccess('WCB feature enabled', statusDiv);
            } else {
                wcbTabBtn.style.display = 'none';
                document.getElementById('wcb-devices-section').classList.add('hidden');
                if (alwaysOnSection) {
                    alwaysOnSection.classList.add('hidden');
                }
                if (disabledOverlay) {
                    disabledOverlay.style.display = 'flex';
                }
                showSuccess('WCB feature disabled', statusDiv);
            }
        } else {
            showStatusMessage('Failed to update WCB settings: ' + result.error, statusDiv, 'error', 8000);
            checkbox.checked = !enabled; // Revert
        }
    } catch (error) {
        showStatusMessage('Error: ' + error.message, statusDiv, 'error', 8000);
        checkbox.checked = !enabled; // Revert
    }
}

async function updateWCBDeviceList() {
    try {
        // Get all serial devices
        const response = await fetch('/api/devices/serial');
        const devices = await response.json();
        
        // Get WCB config to see which devices are marked
        const configResponse = await fetch('/api/wcb/config');
        const configResult = await configResponse.json();
        const wcbDevices = configResult.success ? configResult.config.wcb_devices : [];
        
        const deviceListDiv = document.getElementById('wcb-device-list');
        
        if (!devices || devices.length === 0) {
            deviceListDiv.innerHTML = '<p>No serial devices found</p>';
            return;
        }
        
        // Build device list with checkboxes
        let html = '<div class="device-selection-list">';
        devices.forEach(device => {
            const deviceId = device.unique_id || `${device.vendor_id}:${device.product_id}`;
            const isWCB = wcbDevices.includes(deviceId);
            
            html += `
                <div class="device-selection-item">
                    <label class="checkbox-container">
                        <input type="checkbox" 
                               id="wcb-device-${deviceId}" 
                               data-device-id="${deviceId}"
                               ${isWCB ? 'checked' : ''}
                               onchange="toggleWCBDevice('${deviceId}', this.checked)">
                        <span>${device.name} (${device.port})</span>
                    </label>
                </div>
            `;
        });
        html += '</div>';
        
        deviceListDiv.innerHTML = html;
    } catch (error) {
        console.error('Error loading device list:', error);
        document.getElementById('wcb-device-list').innerHTML = 
            '<p class="error">Error loading devices</p>';
    }
}

async function toggleWCBDevice(deviceId, enabled) {
    try {
        const response = await fetch('/api/wcb/device', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                device_id: deviceId,
                enabled: enabled 
            })
        });
        
        const result = await response.json();
        
        if (!result.success) {
            showStatusMessage('Failed to update device: ' + result.error, 'error', 8000);
            // Revert checkbox
            document.getElementById(`wcb-device-${deviceId}`).checked = !enabled;
        } else {
            // Refresh WCB device dropdown if WCB tab is visible
            if (document.getElementById('wcb-tab').classList.contains('active')) {
                loadWCBDevices();
            }
        }
    } catch (error) {
        console.error('Error updating device:', error);
        showStatusMessage('Error: ' + error.message, 'error', 8000);
        // Revert checkbox
        document.getElementById(`wcb-device-${deviceId}`).checked = !enabled;
    }
}

// WCB Always-On Configuration Functions
async function loadWCBAlwaysOnConfig() {
    try {
        // Load both devices and listener status
        const [devicesResp, listenersResp, configResp] = await Promise.all([
            fetch('/api/devices/serial'),
            fetch('/api/wcb/listeners'),
            fetch('/api/wcb/alwayson/config')
        ]);

        const devices = await devicesResp.json();
        const listenersData = await listenersResp.json();
        const configData = await configResp.json();

        // Get configured always-on devices
        const alwaysOnConfig = configData.success ? configData.config : {};

        // Update listener count
        const activeCount = listenersData.success && listenersData.listeners
            ? listenersData.listeners.filter(l => l.connected).length
            : 0;
        document.getElementById('wcb-listener-count').textContent = activeCount;

        // Display devices with toggles
        const devicesContainer = document.getElementById('wcb-alwayson-devices');

        if (!devices || devices.length === 0) {
            devicesContainer.innerHTML = '<div style="padding: 20px; text-align: center; color: #999;">No serial devices found. Connect a WCB device and reload.</div>';
            return;
        }

        let html = '';
        devices.forEach(device => {
            const port = device.port || device.path;
            if (!port) return; // Skip devices without a port

            const enabled = alwaysOnConfig[port]?.enabled || false;
            const baud = alwaysOnConfig[port]?.baud || 115200;

            html += `
                <div class="wcb-alwayson-device-item ${enabled ? 'enabled' : ''}">
                    <div class="wcb-alwayson-device-info">
                        <div class="wcb-alwayson-device-name">${device.name || 'Unknown Device'}</div>
                        <div class="wcb-alwayson-device-port">${port}</div>
                    </div>
                    <div class="wcb-alwayson-device-controls">
                        <select class="wcb-alwayson-baud-select"
                                id="baud-${port.replace(/\//g, '-')}"
                                ${enabled ? '' : 'disabled'}>
                            <option value="9600" ${baud === 9600 ? 'selected' : ''}>9600</option>
                            <option value="19200" ${baud === 19200 ? 'selected' : ''}>19200</option>
                            <option value="38400" ${baud === 38400 ? 'selected' : ''}>38400</option>
                            <option value="57600" ${baud === 57600 ? 'selected' : ''}>57600</option>
                            <option value="115200" ${baud === 115200 ? 'selected' : ''}>115200</option>
                        </select>
                        <label class="wcb-alwayson-toggle">
                            <input type="checkbox"
                                   id="alwayson-${port.replace(/\//g, '-')}"
                                   data-port="${port}"
                                   ${enabled ? 'checked' : ''}
                                   onchange="toggleWCBAlwaysOn('${port}', this.checked)">
                            <span class="wcb-alwayson-slider"></span>
                        </label>
                    </div>
                </div>
            `;
        });

        devicesContainer.innerHTML = html;

    } catch (error) {
        console.error('Error loading always-on config:', error);
        showStatusMessage('Failed to load always-on configuration', 'error', 8000);
    }
}

function toggleWCBAlwaysOn(port, enabled) {
    // Update UI immediately
    const portId = port.replace(/\//g, '-');
    const deviceItem = document.getElementById(`alwayson-${portId}`)?.closest('.wcb-alwayson-device-item');
    const baudSelect = document.getElementById(`baud-${portId}`);

    if (deviceItem) {
        if (enabled) {
            deviceItem.classList.add('enabled');
            if (baudSelect) baudSelect.disabled = false;
        } else {
            deviceItem.classList.remove('enabled');
            if (baudSelect) baudSelect.disabled = true;
        }
    }
}

async function saveWCBAlwaysOnConfig() {
    const statusDiv = document.getElementById('wcb-alwayson-status');

    try {
        // Collect configuration from UI
        const config = {};
        const checkboxes = document.querySelectorAll('[id^="alwayson-"]');

        checkboxes.forEach(checkbox => {
            const port = checkbox.dataset.port;
            const portId = port.replace(/\//g, '-');
            const baudSelect = document.getElementById(`baud-${portId}`);
            const baud = baudSelect ? parseInt(baudSelect.value) : 115200;

            config[port] = {
                enabled: checkbox.checked,
                baud: baud
            };
        });

        // Save configuration
        const response = await fetch('/api/wcb/alwayson/config', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ config })
        });

        const result = await response.json();

        if (result.success) {
            showSuccess('Configuration saved. Restart device to apply changes.', statusDiv);
        } else {
            showStatusMessage('Failed to save configuration: ' + result.error, statusDiv, 'error', 8000);
        }

    } catch (error) {
        console.error('Error saving always-on config:', error);
        showStatusMessage('Error saving configuration: ' + error.message, statusDiv, 'error', 8000);
    }
}

// WCB Tab Functions
// Note: WCB state variables are now in DroidNet.state.wcb and DroidNet.state.config

// WCB Device Selection and Auto-connect
// Initialize WCB tab when shown
async function initializeWCBTab() {
    try {
        await loadWCBDevices();
        // Check if we need to auto-connect to a device (if one was previously selected)
        const selectedPort = document.getElementById('wcb-device-select').value;
        if (selectedPort) {
            onWCBDeviceSelected();
        }
        // Initialize backup section
        await initWCBBackup();
    } catch (error) {
        console.error('Failed to initialize WCB tab:', error);
        showStatusMessage('Failed to initialize WCB tab', 'error', 8000);
    }
}

// Load WCB devices and check for always-on listeners
async function loadWCBDevices() {
    const deviceSelect = document.getElementById('wcb-device-select');
    const currentValue = deviceSelect.value;

    // Show loading state while fetching
    deviceSelect.innerHTML = '<option value="">Loading devices...</option>';
    deviceSelect.disabled = true;

    try {
        // Load only WCB-marked devices and active listeners
        const [devicesResp, listenersResp] = await Promise.all([
            fetch('/api/wcb/devices'),
            fetch('/api/wcb/listeners')
        ]);

        const devicesData = await devicesResp.json();
        const listenersData = await listenersResp.json();

        // Clear and populate dropdown
        deviceSelect.innerHTML = '<option value="">Select WCB device...</option>';
        deviceSelect.disabled = false;

        // Get list of always-on ports
        const alwaysOnPorts = listenersData.success && listenersData.listeners
            ? listenersData.listeners.map(l => l.port)
            : [];

        // Add only WCB-marked devices
        if (devicesData.success && devicesData.devices && Array.isArray(devicesData.devices)) {
            devicesData.devices.forEach(device => {
                const option = document.createElement('option');
                option.value = device.port;
                option.dataset.uniqueId = device.unique_id || device.port;

                // Indicate if device has always-on listener
                const hasListener = alwaysOnPorts.includes(device.port);
                const label = hasListener ? '⚡ ' : '';
                option.textContent = `${label}${device.name || device.port}`;

                deviceSelect.appendChild(option);
            });
        }

        // Restore previous selection if it still exists
        if (currentValue) {
            const optionExists = Array.from(deviceSelect.options).some(opt => opt.value === currentValue);
            if (optionExists) {
                deviceSelect.value = currentValue;
            }
        }

        return listenersData;

    } catch (error) {
        console.error('Failed to load WCB devices:', error);
        deviceSelect.innerHTML = '<option value="">Select WCB device...</option>';
        deviceSelect.disabled = false;
        showStatusMessage('Failed to load device list', 'error', 8000);
    }
}

async function onWCBDeviceSelected() {
    const select = document.getElementById('wcb-device-select');
    const devicePort = select.value;
    const selectedOption = select.options[select.selectedIndex];
    const statusBadge = document.getElementById('wcb-connection-status');
    const statusInfo = document.getElementById('wcb-status-info');
    const statusIcon = document.getElementById('wcb-status-icon');
    const statusTitle = document.getElementById('wcb-status-title');
    const statusSubtitle = document.getElementById('wcb-status-subtitle');

    // Store selected device info for backup and other operations
    DroidNet.state.wcb.selectedPort = devicePort || null;
    DroidNet.state.wcb.selectedDeviceId = selectedOption?.dataset?.uniqueId || devicePort || null;

    if (!devicePort) {
        // No device selected
        disconnectWCBSerial();
        statusBadge.textContent = 'Select a device';
        statusBadge.className = 'wcb-status-badge disconnected';
        if (statusInfo) statusInfo.style.display = 'none';
        DroidNet.state.wcb.selectedPort = null;
        DroidNet.state.wcb.selectedDeviceId = null;
        return;
    }

    // Load preset commands for this device
    loadWCBPresets();

    try {
        // Check if device has always-on listener
        const response = await fetch('/api/wcb/listeners');
        const data = await response.json();

        let hasListener = false;
        let listenerConnected = false;

        if (data.success && data.listeners) {
            const listener = data.listeners.find(l => l.port === devicePort);
            if (listener) {
                hasListener = true;
                listenerConnected = listener.connected;
            }
        }

        // Update UI based on listener status
        if (hasListener && listenerConnected) {
            // Device has active always-on listener - tap in
            statusBadge.textContent = 'Always-On Active';
            statusBadge.className = 'wcb-status-badge always-on';

            if (statusInfo) {
                statusInfo.style.display = 'flex';
                statusIcon.textContent = '⚡';
                statusTitle.textContent = 'Always-On Monitoring Active';
                statusSubtitle.textContent = 'This device has a persistent listener. Your connection will tap into the existing stream.';
            }
        } else {
            // No always-on listener - create temporary connection
            statusBadge.textContent = 'Temporary Connection';
            statusBadge.className = 'wcb-status-badge temporary';

            if (statusInfo) {
                statusInfo.style.display = 'flex';
                statusIcon.textContent = '○';
                statusTitle.textContent = 'Temporary Monitoring';
                statusSubtitle.textContent = 'Creating a temporary connection for this session. To enable always-on monitoring, go to the Config tab.';
            }
        }

        // Show connecting state
        statusBadge.textContent = 'Connecting...';
        statusBadge.className = 'wcb-status-badge connecting';

        // Connect to the device
        await connectWCBSerial(devicePort, 115200);

    } catch (error) {
        console.error('Error checking listener status:', error);
        // Continue with connection anyway
        await connectWCBSerial(devicePort, 115200);
    }
}

// Serial Connection Management
async function connectWCBSerial(port, baud) {
    // Disconnect any existing serial monitor connection first
    if (DroidNet.state.serial.socket && DroidNet.state.serial.socket.readyState === WebSocket.OPEN) {
        console.log('Closing serial monitor connection to use WCB');
        DroidNet.state.serial.socket.close();
    }

    // Disconnect any existing WCB connection first to prevent duplicate subscriptions
    if (DroidNet.state.wcb.socket && DroidNet.state.wcb.socket.readyState === WebSocket.OPEN) {
        console.log('Closing existing WCB connection before reconnect');
        DroidNet.state.wcb.socket.close();
        DroidNet.state.wcb.socket = null;
    }

    // Reset sequence tracking for new connection
    DroidNet.state.wcb.expectedSeq = null;
    DroidNet.state.wcb.chunkBuffers = {};

    // Reset buffering state to ensure clean parsing of first backup
    DroidNet.state.wcb.configBuffer = '';
    DroidNet.state.wcb.buffering = false;
    DroidNet.state.wcb.bufferingType = null;

    // Reset autoSent flag so new device gets auto-backup
    DroidNet.state.config.autoSent = false;

    // Check if there's an always-on listener and load history
    try {
        const response = await fetch('/api/wcb/listeners');
        const data = await response.json();

        if (data.success && data.listeners) {
            const listener = data.listeners.find(l => l.port === port && l.connected);

            if (listener) {
                // Always-on listener exists - load history
                console.log('Loading serial history for always-on device...');
                try {
                    const historyResponse = await fetch(`/api/serial/history?port=${encodeURIComponent(port)}`);
                    const historyData = await historyResponse.json();

                    if (historyData.success && historyData.history && historyData.history.length > 0) {
                        addWCBSerialLog(`--- Loaded ${historyData.history.length} historical messages ---`);
                        historyData.history.forEach(entry => {
                            const isSent = entry.direction === 'sent';
                            const line = isSent ? '> ' + entry.line : entry.line;
                            addWCBSerialLog(line, isSent);
                        });
                        addWCBSerialLog('--- End of history, live output follows ---');
                    }
                } catch (error) {
                    console.error('Error loading serial history:', error);
                }
            }
        }
    } catch (error) {
        console.error('Error checking for always-on listener:', error);
    }

    const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsHost = location.hostname + ':8080';
    const wsUrl = `${protocol}//${wsHost}/api/serial/ws?port=${encodeURIComponent(port)}&baud=${encodeURIComponent(baud)}`;

    // Connection timeout in milliseconds
    const CONNECTION_TIMEOUT_MS = 10000;

    return new Promise((resolve, reject) => {
        const socket = new WebSocket(wsUrl);
        let connectionTimeout = null;
        let connected = false;

        // Set up connection timeout
        connectionTimeout = setTimeout(() => {
            if (!connected) {
                console.error('WebSocket connection timeout');
                socket.close();
                DroidNet.state.wcb.isConnected = false;
                updateWCBConnectionStatus(false);
                showStatusMessage('Connection timed out - device may be unavailable', 'error', 8000);
                document.getElementById('wcb-device-select').value = '';
                reject(new Error('WebSocket connection timeout'));
            }
        }, CONNECTION_TIMEOUT_MS);

        socket.onopen = function() {
            connected = true;
            clearTimeout(connectionTimeout);
            DroidNet.state.wcb.socket = socket;
            DroidNet.state.wcb.isConnected = true;
            updateWCBConnectionStatus(true);
            // Note: Server sends "Connected to..." message with mode suffix (always-on/temporary)

            // Auto-send ?BACKUP command only if table is empty and we haven't sent it yet
            setTimeout(() => {
                if (DroidNet.state.wcb.commandTable.length === 0 && !DroidNet.state.config.autoSent) {
                    sendBackupCommand();
                    DroidNet.state.config.autoSent = true;
                }
            }, 500);

            resolve();
        };

        socket.onmessage = function(event) {
            // Check if message is JSON (sent commands) or plain text (received data)
            let line = event.data;
            let isSent = false;

            try {
                const parsed = JSON.parse(event.data);
                if (parsed.line !== undefined) {
                    // Reassemble chunked messages first (before any other processing)
                    const msg = reassembleChunks(parsed, DroidNet.state.wcb.chunkBuffers);
                    if (!msg) {
                        // Still buffering chunks, wait for more
                        return;
                    }

                    // Sequence gap detection
                    if (!DroidNet.state.wcb.expectedSeq) {
                        DroidNet.state.wcb.expectedSeq = msg.seq;
                    }
                    if (msg.seq > DroidNet.state.wcb.expectedSeq) {
                        const missed = msg.seq - DroidNet.state.wcb.expectedSeq;
                        console.warn(`[WCB-WS] Sequence gap: expected ${DroidNet.state.wcb.expectedSeq}, got ${msg.seq} (missed ${missed} messages)`);
                        addWCBSerialLog(`⚠️ Possible data loss: ${missed} message(s) missed`, false);
                    }
                    DroidNet.state.wcb.expectedSeq = msg.seq + 1;

                    // Hash integrity validation
                    if (msg.hash && msg.len !== undefined) {
                        const receivedLen = msg.line.length;
                        const calculatedHash = CRC32(msg.line);

                        if (calculatedHash !== msg.hash || receivedLen !== msg.len) {
                            console.error(`[WCB-WS] Data corruption: seq=${msg.seq} serverLen=${msg.len} clientLen=${receivedLen} serverHash=${msg.hash} clientHash=${calculatedHash}`);
                            if (calculatedHash !== msg.hash) {
                                addWCBSerialLog(`⚠️ HASH MISMATCH: expected ${msg.hash}, got ${calculatedHash}`, false);
                            }
                            if (receivedLen !== msg.len) {
                                addWCBSerialLog(`⚠️ LENGTH MISMATCH: expected ${msg.len} chars, got ${receivedLen}`, false);
                            }
                        }
                    }

                    line = msg.line;
                    isSent = msg.direction === 'sent';
                    // Add "> " prefix for sent commands
                    if (isSent) {
                        line = '> ' + line;
                    }
                }
            } catch (e) {
                // Not JSON, treat as plain text received data
            }

            addWCBSerialLog(line, isSent);

            // Buffer messages for CONFIG or BACKUP response (only for received data)
            if (!isSent) {
                if (!DroidNet.state.wcb.configBuffer) {
                    DroidNet.state.wcb.configBuffer = '';
                }

                // Start buffering when we see the start of CONFIG or BACKUP response
                if (line.includes('?CONFIG') || line.includes('Serial Settings') || line.includes('----------- Configuration Info')) {
                    DroidNet.state.wcb.configBuffer = line + '\n';
                    DroidNet.state.wcb.buffering = true;
                    DroidNet.state.wcb.bufferingType = 'config';
                    console.log('Started buffering CONFIG response');
                } else if (line.includes('WCB Configuration Backup')) {
                    DroidNet.state.wcb.configBuffer = line + '\n';
                    DroidNet.state.wcb.buffering = true;
                    DroidNet.state.wcb.bufferingType = 'backup';
                    console.log('Started buffering BACKUP response');
                } else if (DroidNet.state.wcb.buffering) {
                    DroidNet.state.wcb.configBuffer += line + '\n';

                    // Check if we've reached the end (different markers for CONFIG vs BACKUP)
                    const isConfigEnd = line.includes('End of Configuration Info') || line.includes('--- End of Configuration Info ---');
                    const isBackupEnd = line.includes('End of Backup');

                    if ((DroidNet.state.wcb.bufferingType === 'config' && isConfigEnd) ||
                        (DroidNet.state.wcb.bufferingType === 'backup' && isBackupEnd)) {
                        DroidNet.state.wcb.buffering = false;
                        console.log('Full ' + DroidNet.state.wcb.bufferingType.toUpperCase() + ' Response:', DroidNet.state.wcb.configBuffer);
                        parseConfigResponse(DroidNet.state.wcb.configBuffer);
                        DroidNet.state.wcb.configBuffer = '';
                        DroidNet.state.wcb.bufferingType = null;
                    }
                }
            }
        };

        socket.onclose = function() {
            clearTimeout(connectionTimeout);
            // Only update state if this socket is still the active socket
            // (prevents race condition when closing old socket before reconnect)
            if (DroidNet.state.wcb.socket === socket || DroidNet.state.wcb.socket === null) {
                DroidNet.state.wcb.isConnected = false;
                updateWCBConnectionStatus(false);
                addWCBSerialLog('Connection closed');
            }
        };

        socket.onerror = function(error) {
            clearTimeout(connectionTimeout);
            connected = false;
            // Only update state if this socket is still the active socket
            // (prevents race condition when closing old socket before reconnect)
            if (DroidNet.state.wcb.socket === socket || DroidNet.state.wcb.socket === null) {
                showStatusMessage('WCB connection error', 'error', 8000);
                DroidNet.state.wcb.isConnected = false;
                updateWCBConnectionStatus(false);
                // Revert dropdown
                document.getElementById('wcb-device-select').value = '';
            }
            reject(error);
        };
    });
}

function disconnectWCBSerial() {
    if (DroidNet.state.wcb.socket) {
        DroidNet.state.wcb.socket.close();
        DroidNet.state.wcb.socket = null;
    }
    DroidNet.state.wcb.isConnected = false;
    updateWCBConnectionStatus(false);
}

async function updateWCBConnectionStatus(connected) {
    const status = document.getElementById('wcb-connection-status');
    const statusInfo = document.getElementById('wcb-status-info');
    const disconnectBtn = document.getElementById('wcb-disconnect-btn');

    if (connected) {
        // Check if this is an always-on or temporary connection
        const devicePort = document.getElementById('wcb-device-select').value;

        try {
            const response = await fetch('/api/wcb/listeners');
            const data = await response.json();
            const hasListener = data.success && data.listeners &&
                data.listeners.some(l => l.port === devicePort && l.connected);

            if (hasListener) {
                status.textContent = 'Always-On Active';
                status.className = 'wcb-status-badge always-on';
                if (statusInfo) statusInfo.style.display = 'flex';
                // Hide disconnect button for always-on connections
                if (disconnectBtn) disconnectBtn.style.display = 'none';
            } else {
                status.textContent = 'Connected (Temporary)';
                status.className = 'wcb-status-badge temporary';
                if (statusInfo) statusInfo.style.display = 'flex';
                // Show disconnect button for temporary connections
                if (disconnectBtn) disconnectBtn.style.display = 'inline-block';
            }
        } catch (error) {
            console.error('Error checking listener status:', error);
            status.textContent = 'Connected';
            status.className = 'wcb-status-badge connected';
            // Show disconnect button for generic connected state
            if (disconnectBtn) disconnectBtn.style.display = 'inline-block';
        }
    } else {
        status.textContent = 'Disconnected';
        status.className = 'wcb-status-badge disconnected';
        if (statusInfo) statusInfo.style.display = 'none';
        // Hide disconnect button when not connected
        if (disconnectBtn) disconnectBtn.style.display = 'none';
    }

    // Update backup button state
    updateBackupNowButton();
}

function addWCBSerialLog(message, isSent = false) {
    const output = document.getElementById('wcb-serial-output');
    const logEntry = document.createElement('div');
    logEntry.className = isSent ? 'serial-log-entry serial-log-sent' : 'serial-log-entry';
    logEntry.textContent = message;
    output.appendChild(logEntry);

    // Auto-scroll to bottom if enabled
    const autoScroll = document.getElementById('wcb-auto-scroll');
    if (!autoScroll || autoScroll.checked) {
        output.scrollTop = output.scrollHeight;
    }

    // Limit log entries
    while (output.children.length > 500) {
        output.removeChild(output.firstChild);
    }
}

function sendWCBSerial() {
    const input = document.getElementById('wcb-serial-command');
    const command = input.value.trim();
    
    if (command && DroidNet.state.wcb.isConnected) {
        sendWCBCommand(command);
        
        // Add to command history
        if (DroidNet.state.wcb.commandHistory.length === 0 || DroidNet.state.wcb.commandHistory[DroidNet.state.wcb.commandHistory.length - 1] !== command) {
            DroidNet.state.wcb.commandHistory.push(command);
            // Limit history to 50 commands
            if (DroidNet.state.wcb.commandHistory.length > 50) {
                DroidNet.state.wcb.commandHistory.shift();
            }
        }
        
        // Reset history position
        DroidNet.state.wcb.historyPosition = -1;
        DroidNet.state.wcb.tempCommand = '';
        
        input.value = '';
    }
}

function navigateWCBHistory(direction) {
    const input = document.getElementById('wcb-serial-command');
    
    if (direction === 'up') {
        // Save current input if starting to navigate
        if (DroidNet.state.wcb.historyPosition === -1 && input.value.trim()) {
            DroidNet.state.wcb.tempCommand = input.value;
        }
        
        // Move up in history
        if (DroidNet.state.wcb.historyPosition < DroidNet.state.wcb.commandHistory.length - 1) {
            DroidNet.state.wcb.historyPosition++;
            const historyIndex = DroidNet.state.wcb.commandHistory.length - 1 - DroidNet.state.wcb.historyPosition;
            input.value = DroidNet.state.wcb.commandHistory[historyIndex];
        }
    } else if (direction === 'down') {
        // Move down in history
        if (DroidNet.state.wcb.historyPosition > -1) {
            DroidNet.state.wcb.historyPosition--;
            
            if (DroidNet.state.wcb.historyPosition === -1) {
                // Restore temporary command
                input.value = DroidNet.state.wcb.tempCommand;
            } else {
                const historyIndex = DroidNet.state.wcb.commandHistory.length - 1 - DroidNet.state.wcb.historyPosition;
                input.value = DroidNet.state.wcb.commandHistory[historyIndex];
            }
        }
    }
    
    // Move cursor to end of input
    input.setSelectionRange(input.value.length, input.value.length);
}

/**
 * Calculate CRC32 checksum matching WCB firmware (IEEE 802.3 polynomial)
 * Used to verify commands aren't corrupted during transmission.
 * @param {string} str - String to calculate checksum for
 * @returns {string} 8-character uppercase hex checksum
 */
function calculateCRC32(str) {
    const polynomial = 0xEDB88320;
    let crc = 0xFFFFFFFF;

    for (let i = 0; i < str.length; i++) {
        crc ^= str.charCodeAt(i);
        for (let j = 0; j < 8; j++) {
            crc = (crc & 1) ? ((crc >>> 1) ^ polynomial) : (crc >>> 1);
        }
    }

    return ((crc ^ 0xFFFFFFFF) >>> 0).toString(16).toUpperCase().padStart(8, '0');
}

/**
 * Send WCB command with optional CRC32 verification.
 * When verify=true, appends ^?CHK<checksum> to protect against transmission corruption.
 * The WCB will abort and NOT execute the command if checksum fails.
 * @param {string} command - Command to send
 * @param {boolean} verify - If true, append ^?CHK<crc32> for verification
 * @returns {boolean} True if command was sent
 */
function sendWCBCommand(command, verify = false) {
    // Add checksum verification if requested and not already present
    // Use '^?CHK' pattern to avoid false matches with command data containing '?CHK'
    if (verify && !command.includes('^?CHK')) {
        const checksum = calculateCRC32(command);
        command = command + '^?CHK' + checksum;
        console.log('Sending verified command:', command);
    }

    if (DroidNet.state.wcb.socket && DroidNet.state.wcb.socket.readyState === WebSocket.OPEN) {
        DroidNet.state.wcb.socket.send(command);
        // Don't add to log here - it will appear when broadcast by server
        return true;
    } else {
        console.error('WCB WebSocket not ready - state:', DroidNet.state.wcb.socket ? DroidNet.state.wcb.socket.readyState : 'null');
        return false;
    }
}

// Disconnect WCB
function disconnectWCB() {
    if (DroidNet.state.wcb.socket) {
        DroidNet.state.wcb.socket.close();
        DroidNet.state.wcb.isConnected = false;
        updateWCBConnectionStatus(false);
        
        // Reset device selector
        const selector = document.getElementById('wcb-device-select');
        if (selector) {
            selector.value = '';
        }
        
        addWCBSerialLog('Disconnected');
    }
}

// Reconnect WCB
function reconnectWCB() {
    const selector = document.getElementById('wcb-device-select');
    if (selector && selector.value) {
        onWCBDeviceSelected();
    } else {
        showStatusMessage('Please select a WCB device first', 'error', 8000);
    }
}

// Copy WCB log to clipboard
function copyWCBLog() {
    const output = document.getElementById('wcb-serial-output');
    if (output) {
        // Get all log entries
        const logEntries = Array.from(output.querySelectorAll('.serial-log-entry'))
            .map(entry => entry.textContent)
            .join('\n');

        copyToClipboard(logEntries, event.target);
    }
}

// Clear WCB log
function clearWCBLog() {
    const output = document.getElementById('wcb-serial-output');
    if (output) {
        output.innerHTML = '';
    }
}

// Helper functions for comment handling
function hasComments(value) {
    return value && value.includes('***');
}

// Format value for contenteditable display with color coding
function formatValueForEditable(value) {
    if (!value) return '';
    
    // Escape HTML first
    value = escapeHtml(value);
    
    // Apply color coding to comments
    const lines = value.split('\n');
    const formattedLines = lines.map(line => {
        // Check if line contains comment
        const commentIndex = line.indexOf('***');
        if (commentIndex !== -1) {
            const beforeComment = line.substring(0, commentIndex);
            const comment = line.substring(commentIndex);
            return beforeComment + `<span class="comment-highlight">${comment}</span>`;
        }
        return line;
    });
    
    return formattedLines.join('<br>');
}

// Debounce timers for formatting
const formatDebounceTimers = new Map();

// Handle input in contenteditable
function handleValueInputEditable(index, element) {
    // Update character count immediately
    const textContent = element.innerText || element.textContent || '';
    const charCountElement = element.parentNode.querySelector('.char-count');
    if (charCountElement) {
        const count = textContent.length;
        charCountElement.textContent = `${count}`;
        if (count > 500) {
            charCountElement.style.color = '#e74c3c';
        } else if (count > 250) {
            charCountElement.style.color = '#f39c12';
        } else {
            charCountElement.style.color = '#666';
        }
    }
    
    // Clear existing timer for this element
    if (formatDebounceTimers.has(index)) {
        clearTimeout(formatDebounceTimers.get(index));
    }
    
    // Set new debounce timer for formatting
    const timer = setTimeout(() => {
        applyFormattingToEditable(element, textContent);
        formatDebounceTimers.delete(index);
    }, 300); // 300ms delay
    
    formatDebounceTimers.set(index, timer);
}

// Apply formatting with improved cursor restoration
function applyFormattingToEditable(element, textContent) {
    // Get cursor position before formatting
    const cursorPos = getCursorPosition(element);
    
    // Apply formatting
    const formatted = formatValueForEditable(textContent);
    if (element.innerHTML !== formatted) {
        element.innerHTML = formatted;
        
        // Restore cursor position
        setCursorPosition(element, cursorPos);
    }
}

// Get cursor position relative to text content
function getCursorPosition(element) {
    const selection = window.getSelection();
    if (selection.rangeCount === 0) return 0;
    
    const range = selection.getRangeAt(0);
    const preCaretRange = range.cloneRange();
    preCaretRange.selectNodeContents(element);
    preCaretRange.setEnd(range.endContainer, range.endOffset);
    
    // Get text content up to cursor
    const tempDiv = document.createElement('div');
    tempDiv.appendChild(preCaretRange.cloneContents());
    return tempDiv.textContent.length;
}

// Set cursor position based on text offset
function setCursorPosition(element, offset) {
    const textNodes = getTextNodes(element);
    let currentOffset = 0;
    
    for (const node of textNodes) {
        const nodeLength = node.textContent.length;
        if (currentOffset + nodeLength >= offset) {
            const range = document.createRange();
            range.setStart(node, Math.min(offset - currentOffset, nodeLength));
            range.collapse(true);
            
            const selection = window.getSelection();
            selection.removeAllRanges();
            selection.addRange(range);
            return;
        }
        currentOffset += nodeLength;
    }
    
    // If we couldn't find the position, put cursor at end
    const range = document.createRange();
    range.selectNodeContents(element);
    range.collapse(false);
    
    const selection = window.getSelection();
    selection.removeAllRanges();
    selection.addRange(range);
}

// Get all text nodes in element
function getTextNodes(element) {
    const textNodes = [];
    const walker = document.createTreeWalker(
        element,
        NodeFilter.SHOW_TEXT,
        null,
        false
    );
    
    let node;
    while (node = walker.nextNode()) {
        textNodes.push(node);
    }
    return textNodes;
}

// Handle keydown in contenteditable
function handleEditableKeydown(event, index, element) {
    // Handle Enter key
    if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault();
        
        // Insert newline using modern API
        const selection = window.getSelection();
        const range = selection.getRangeAt(0);
        
        // Create a text node with newline
        const newlineNode = document.createTextNode('\n');
        
        // Insert the newline at cursor position
        range.deleteContents();
        range.insertNode(newlineNode);
        
        // Move cursor after the newline
        range.setStartAfter(newlineNode);
        range.collapse(true);
        selection.removeAllRanges();
        selection.addRange(range);
        
        // Trigger input event for character count update
        element.dispatchEvent(new Event('input', { bubbles: true }));
    }
    
    // Max length validation removed - no character limit
}

// Capture original value on focus
function captureOriginalValue(index, element) {
    // Store the display text to compare against later
    element.setAttribute('data-original-value', element.innerText || element.textContent || '');
}

// Update command when contenteditable loses focus
function updateCommandFromEditable(index, element) {
    // Clear any pending formatting timers
    if (formatDebounceTimers.has(index)) {
        clearTimeout(formatDebounceTimers.get(index));
        formatDebounceTimers.delete(index);
        
        // Apply formatting immediately on blur
        const textContent = element.innerText || element.textContent || '';
        applyFormattingToEditable(element, textContent);
    }
    
    const value = element.innerText || element.textContent || '';
    const originalValue = element.getAttribute('data-original-value') || '';
    
    // Only update if the display text actually changed
    if (originalValue !== value) {
        updateCommand(index, 'value', value);
    }
}

function formatValueWithComments(value) {
    if (!value) return '';
    
    // For display: convert ^ to newlines and format inline comments
    const displayValue = value.replace(/\^/g, '\n');
    const lines = displayValue.split('\n');
    let formatted = '';
    
    lines.forEach((line, index) => {
        // Check if line contains inline comment (***comment)
        const commentIndex = line.indexOf('***');
        if (commentIndex !== -1) {
            // Split into command and comment parts
            const commandPart = line.substring(0, commentIndex).trim();
            const commentPart = line.substring(commentIndex);
            
            if (commandPart) {
                // Command with inline comment
                formatted += `${escapeHtml(commandPart)} <span class="command-comment">${escapeHtml(commentPart)}</span>`;
            } else {
                // Just a comment line
                formatted += `<span class="command-comment">${escapeHtml(commentPart)}</span>`;
            }
        } else {
            // Regular command line
            formatted += escapeHtml(line);
        }
        
        if (index < lines.length - 1) {
            formatted += '\n';
        }
    });
    
    return formatted;
}

// Removed old handleValueInput - now using handleValueInputEditable

// BACKUP Command Handling (BACKUP includes all CONFIG data plus additional settings)
// Note: retryCount is now in DroidNet.state.config.retryCount

function sendBackupCommand() {
    if (!DroidNet.state.wcb.isConnected) {
        showStatusMessage('Not connected to WCB device', 'error', 8000);
        return;
    }

    DroidNet.state.config.retryCount = 0;
    sendWCBCommand('?BACKUP');

    // Set up retry logic
    setTimeout(() => {
        const output = document.getElementById('wcb-serial-output').textContent;
        if (output.includes('ESP-NOW message sent successfully!') && !output.includes('WCB Configuration Backup')) {
            if (DroidNet.state.config.retryCount < 1) {
                DroidNet.state.config.retryCount++;
                sendWCBCommand('?BACKUP');
            }
        }
    }, 1000);
}

// Legacy CONFIG command (kept for backwards compatibility)
function sendConfigCommand() {
    if (!DroidNet.state.wcb.isConnected) {
        showStatusMessage('Not connected to WCB device', 'error', 8000);
        return;
    }
    sendWCBCommand('?CONFIG');
}

function sendDONCommand() {
    if (!DroidNet.state.wcb.isConnected) {
        showStatusMessage('Not connected to WCB device', 'error', 8000);
        return;
    }
    sendWCBCommand('?DON');
}

function sendDOFFCommand() {
    if (!DroidNet.state.wcb.isConnected) {
        showStatusMessage('Not connected to WCB device', 'error', 8000);
        return;
    }
    sendWCBCommand('?DOFF');
}

function sendDIAGCommand() {
    if (!DroidNet.state.wcb.isConnected) {
        showStatusMessage('Not connected to WCB device', 'error', 8000);
        return;
    }
    sendWCBCommand('?CDIAG');
}

// ========== WCB Configuration Backup ==========

// Backup state
let backupCurrentPage = 1;
let backupTotalPages = 1;
let backupConfig = { enabled: false, backup_interval_hours: 1, max_backups: 50 };
let currentRestoreFilename = null;

/**
 * Initialize WCB backup section
 */
async function initWCBBackup() {
    await loadBackupConfig();
    await loadBackupList();
}

/**
 * Load backup configuration
 */
async function loadBackupConfig() {
    try {
        const response = await fetch('/api/wcb/backup/config');
        const data = await response.json();
        if (data.success) {
            backupConfig = data.config;
            updateBackupAutoStatus();
        }
    } catch (error) {
        console.error('Error loading backup config:', error);
    }
}

/**
 * Update auto backup status badge
 */
function updateBackupAutoStatus() {
    const badge = document.getElementById('backup-auto-status');
    if (badge) {
        if (backupConfig.enabled) {
            badge.textContent = `Auto: ${backupConfig.backup_interval_hours}h`;
            badge.className = 'badge badge-success';
        } else {
            badge.textContent = 'Auto: Off';
            badge.className = 'badge badge-secondary';
        }
    }
}

/**
 * Load backup list for current device
 */
async function loadBackupList(page = 1) {
    const deviceId = DroidNet.state.wcb.selectedDeviceId;
    backupCurrentPage = page;

    try {
        let url = `/api/wcb/backup/list?page=${page}`;
        if (deviceId) {
            url += `&device_id=${encodeURIComponent(deviceId)}`;
        }

        const response = await fetch(url);
        const data = await response.json();

        if (data.success) {
            backupTotalPages = data.total_pages || 1;
            renderBackupList(data.backups || []);
            updateBackupPagination();
        } else {
            showBackupStatus(data.error || 'Failed to load backups', 'error');
        }
    } catch (error) {
        console.error('Error loading backup list:', error);
        showBackupStatus('Failed to load backups', 'error');
    }
}

/**
 * Delete a backup file
 */
async function deleteBackup(filename) {
    if (!confirm('Are you sure you want to delete this backup? This cannot be undone.')) {
        return;
    }

    try {
        const response = await fetch(`/api/wcb/backup/${encodeURIComponent(filename)}`, {
            method: 'DELETE'
        });
        const data = await response.json();

        if (data.success) {
            showBackupStatus('Backup deleted successfully', 'success');
            loadBackupList(backupCurrentPage);
        } else {
            showBackupStatus(data.error || 'Failed to delete backup', 'error');
        }
    } catch (error) {
        console.error('Error deleting backup:', error);
        showBackupStatus('Failed to delete backup', 'error');
    }
}

/**
 * Render backup list in table
 */
function renderBackupList(backups) {
    const emptyState = document.getElementById('backup-empty-state');
    const container = document.getElementById('backup-list-container');
    const tbody = document.getElementById('backup-table-body');

    if (backups.length === 0) {
        if (emptyState) emptyState.style.display = 'block';
        if (container) container.style.display = 'none';
        return;
    }

    if (emptyState) emptyState.style.display = 'none';
    if (container) container.style.display = 'block';

    if (!tbody) return;

    tbody.innerHTML = backups.map(backup => {
        const date = new Date(backup.timestamp * 1000);
        const dateStr = date.toLocaleString();
        const isError = backup.status === 'error';

        if (isError) {
            return `
                <tr class="backup-row backup-row--error">
                    <td>${dateStr}</td>
                    <td>-</td>
                    <td>-</td>
                    <td class="text-danger">ERROR</td>
                    <td class="text-danger">${escapeHtml(backup.error || 'Unknown error')}</td>
                    <td>
                        <button onclick="triggerManualBackup()" class="btn btn-xs btn-secondary">Retry</button>
                        <button onclick="deleteBackup('${backup.backup_file || ''}')" class="btn btn-xs btn-danger" ${!backup.backup_file ? 'disabled' : ''}>Remove</button>
                    </td>
                </tr>
            `;
        }

        return `
            <tr class="backup-row">
                <td>${dateStr}</td>
                <td class="monospace">${backup.wcb_number || '-'}</td>
                <td class="monospace">${backup.mac_octets || '-'}</td>
                <td class="monospace">${backup.checksum || '-'}</td>
                <td>${escapeHtml(backup.change_summary) || '—'}</td>
                <td>
                    <button onclick="openRestoreModal('${backup.backup_file}')" class="btn btn-xs btn-primary">Restore</button>
                    <button onclick="openBackupDetails('${backup.backup_file}')" class="btn btn-xs btn-secondary">Details</button>
                    <button onclick="deleteBackup('${backup.backup_file}')" class="btn btn-xs btn-danger">Remove</button>
                </td>
            </tr>
        `;
    }).join('');
}

/**
 * Update backup pagination controls
 */
function updateBackupPagination() {
    const prevBtn = document.getElementById('backup-prev-btn');
    const nextBtn = document.getElementById('backup-next-btn');
    const pageInfo = document.getElementById('backup-page-info');

    if (prevBtn) prevBtn.disabled = backupCurrentPage <= 1;
    if (nextBtn) nextBtn.disabled = backupCurrentPage >= backupTotalPages;
    if (pageInfo) pageInfo.textContent = `Page ${backupCurrentPage} of ${backupTotalPages}`;
}

/**
 * Load specific backup page
 */
function loadBackupPage(page) {
    if (page < 1 || page > backupTotalPages) return;
    loadBackupList(page);
}

/**
 * Show backup status message
 */
function showBackupStatus(message, type = 'info') {
    const status = document.getElementById('backup-status');
    if (status) {
        status.textContent = message;
        status.className = `status-message status-${type}`;
        status.classList.remove('hidden');
        setTimeout(() => status.classList.add('hidden'), 5000);
    }
}

/**
 * Trigger manual backup
 */
async function triggerManualBackup() {
    const port = DroidNet.state.wcb.selectedPort;
    const deviceId = DroidNet.state.wcb.selectedDeviceId;

    if (!port || !deviceId) {
        showStatusMessage('Please select a WCB device first', 'warning');
        return;
    }

    const btn = document.getElementById('backup-now-btn');
    if (btn) {
        btn.disabled = true;
        btn.textContent = 'Backing up...';
    }

    try {
        const response = await fetch('/api/wcb/backup/trigger', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ port, device_id: deviceId })
        });

        const data = await response.json();

        if (data.success) {
            showStatusMessage(data.message || 'Backup triggered', 'success');
            // Reload backup list after a short delay to allow backup to complete
            setTimeout(() => loadBackupList(), 3000);
        } else {
            showStatusMessage(data.error || 'Backup failed', 'error');
        }
    } catch (error) {
        console.error('Error triggering backup:', error);
        showStatusMessage('Backup failed', 'error');
    } finally {
        if (btn) {
            btn.disabled = !DroidNet.state.wcb.isConnected;
            btn.textContent = 'Backup Now';
        }
    }
}

/**
 * Open backup settings modal
 */
function openBackupSettings() {
    document.getElementById('backup-enabled-checkbox').checked = backupConfig.enabled;
    document.getElementById('backup-interval-input').value = backupConfig.backup_interval_hours;
    document.getElementById('backup-retention-input').value = backupConfig.max_backups;
    document.getElementById('backup-save-all-checkbox').checked = backupConfig.save_all_backups || false;
    document.getElementById('backup-settings-modal').style.display = 'flex';
}

/**
 * Close backup settings modal
 */
function closeBackupSettings() {
    document.getElementById('backup-settings-modal').style.display = 'none';
}

/**
 * Save backup settings
 */
async function saveBackupSettings() {
    const config = {
        enabled: document.getElementById('backup-enabled-checkbox').checked,
        backup_interval_hours: parseFloat(document.getElementById('backup-interval-input').value),
        max_backups: parseInt(document.getElementById('backup-retention-input').value),
        save_all_backups: document.getElementById('backup-save-all-checkbox').checked
    };

    try {
        const response = await fetch('/api/wcb/backup/config', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(config)
        });

        const data = await response.json();

        if (data.success) {
            backupConfig = config;
            updateBackupAutoStatus();
            closeBackupSettings();
            showStatusMessage('Backup settings saved', 'success');
        } else {
            showStatusMessage(data.error || 'Failed to save settings', 'error');
        }
    } catch (error) {
        console.error('Error saving backup settings:', error);
        showStatusMessage('Failed to save settings', 'error');
    }
}

/**
 * Open backup details modal
 */
async function openBackupDetails(filename) {
    try {
        const response = await fetch(`/api/wcb/backup/content?filename=${encodeURIComponent(filename)}`);
        const data = await response.json();

        if (!data.success) {
            showStatusMessage(data.error || 'Failed to load backup details', 'error');
            return;
        }

        const backup = data.backup;

        // Populate modal
        const date = new Date(backup.timestamp * 1000);
        document.getElementById('backup-detail-timestamp').textContent = date.toLocaleString();
        document.getElementById('backup-detail-checksum').textContent = backup.checksum || '-';
        document.getElementById('backup-detail-device').textContent = backup.device_id || '-';

        // Render changes
        const changesContent = document.getElementById('backup-changes-content');
        const changes = backup.changes_from_previous || {};

        let changesHtml = '';
        if (changes.commands_added && changes.commands_added.length > 0) {
            changesHtml += '<h5>Commands Added</h5><ul class="change-list change-list--added">';
            changes.commands_added.forEach(cmd => {
                changesHtml += `<li><code>${escapeHtml(cmd.key)}</code> &rarr; <code>${escapeHtml(cmd.value)}</code></li>`;
            });
            changesHtml += '</ul>';
        }
        if (changes.commands_removed && changes.commands_removed.length > 0) {
            changesHtml += '<h5>Commands Removed</h5><ul class="change-list change-list--removed">';
            changes.commands_removed.forEach(cmd => {
                changesHtml += `<li><code>${escapeHtml(cmd.key)}</code> &rarr; <code>${escapeHtml(cmd.value)}</code></li>`;
            });
            changesHtml += '</ul>';
        }
        if (changes.config_changes && changes.config_changes.length > 0) {
            changesHtml += '<h5>Settings Changed</h5><ul class="change-list change-list--modified">';
            changes.config_changes.forEach(change => {
                changesHtml += `<li><strong>${escapeHtml(change.setting)}</strong>: ${escapeHtml(change.old)} &rarr; ${escapeHtml(change.new)}</li>`;
            });
            changesHtml += '</ul>';
        }

        // Hide the changes section entirely if no changes to show
        const changesSection = document.getElementById('backup-changes-section');
        if (!changesHtml) {
            changesSection.style.display = 'none';
        } else {
            changesSection.style.display = 'block';
            changesContent.innerHTML = changesHtml;
        }

        // Render config summary
        const configSummary = document.getElementById('backup-config-summary');
        const parsed = backup.parsed_config || {};
        let configHtml = '<div class="config-summary-grid">';

        if (parsed.hw_version) configHtml += `<div class="config-item"><span class="label">Hardware Version</span><span class="value">${escapeHtml(parsed.hw_version)}</span></div>`;
        if (parsed.wcb_number) configHtml += `<div class="config-item"><span class="label">WCB Number</span><span class="value">${escapeHtml(parsed.wcb_number)}</span></div>`;
        if (parsed.wcb_quantity) configHtml += `<div class="config-item"><span class="label">WCB Quantity</span><span class="value">${escapeHtml(parsed.wcb_quantity)}</span></div>`;

        // Stored commands count
        const cmdCount = (parsed.stored_commands || []).length;
        configHtml += `<div class="config-item"><span class="label">Stored Commands</span><span class="value">${cmdCount}</span></div>`;

        configHtml += '</div>';
        configSummary.innerHTML = configHtml;

        // Populate raw backup data for copy/paste
        const rawBackupContent = document.getElementById('backup-raw-content');
        rawBackupContent.textContent = backup.raw_backup || 'No raw backup data available';

        document.getElementById('backup-details-modal').style.display = 'flex';
    } catch (error) {
        console.error('Error loading backup details:', error);
        showStatusMessage('Failed to load backup details', 'error');
    }
}

/**
 * Copy raw backup data to clipboard
 */
function copyRawBackup() {
    const rawContent = document.getElementById('backup-raw-content').textContent;
    if (rawContent && rawContent !== 'No raw backup data available') {
        navigator.clipboard.writeText(rawContent).then(() => {
            showStatusMessage('Raw backup copied to clipboard', 'success', 3000);
        }).catch(err => {
            console.error('Failed to copy:', err);
            showStatusMessage('Failed to copy to clipboard', 'error');
        });
    }
}

/**
 * Close backup details modal
 */
function closeBackupDetails() {
    document.getElementById('backup-details-modal').style.display = 'none';
}

/**
 * Confirm and delete all backup history
 */
function confirmDeleteBackupHistory() {
    const confirmed = confirm(
        'WARNING: This will permanently delete ALL backup history.\n\n' +
        'This action cannot be undone. Are you sure you want to continue?'
    );

    if (confirmed) {
        deleteBackupHistory();
    }
}

/**
 * Delete all backup history
 */
async function deleteBackupHistory() {
    try {
        const response = await fetch('/api/wcb/backup/clear', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        });

        const data = await response.json();

        if (data.success) {
            showStatusMessage('Backup history cleared', 'success');
            loadBackupList(); // Refresh the backup list
        } else {
            showStatusMessage(data.error || 'Failed to clear backup history', 'error');
        }
    } catch (error) {
        console.error('Error clearing backup history:', error);
        showStatusMessage('Failed to clear backup history', 'error');
    }
}

/**
 * Open restore confirmation modal
 */
function openRestoreModal(filename) {
    currentRestoreFilename = filename;
    document.getElementById('restore-preview-section').style.display = 'none';
    document.querySelector('input[name="restore-mode"][value="configured"]').checked = true;
    document.getElementById('backup-restore-modal').style.display = 'flex';
}

/**
 * Close restore modal
 */
function closeRestoreModal() {
    currentRestoreFilename = null;
    document.getElementById('backup-restore-modal').style.display = 'none';
}

/**
 * Toggle restore preview
 */
async function toggleRestorePreview() {
    const previewSection = document.getElementById('restore-preview-section');
    const previewCommands = document.getElementById('restore-preview-commands');

    if (previewSection.style.display === 'none') {
        const mode = document.querySelector('input[name="restore-mode"]:checked').value;

        try {
            const response = await fetch(`/api/wcb/backup/restore?filename=${encodeURIComponent(currentRestoreFilename)}&mode=${mode}`);
            const data = await response.json();

            if (data.success) {
                previewCommands.textContent = data.commands || 'No commands';
                previewSection.style.display = 'block';
            } else {
                showStatusMessage(data.error || 'Failed to load preview', 'error');
            }
        } catch (error) {
            console.error('Error loading preview:', error);
            showStatusMessage('Failed to load preview', 'error');
        }
    } else {
        previewSection.style.display = 'none';
    }
}

// Guard to prevent multiple restore operations
let restoreInProgress = false;

/**
 * Confirm and execute restore
 */
async function confirmRestore() {
    // Prevent multiple clicks
    if (restoreInProgress) {
        console.log('Restore already in progress, ignoring duplicate click');
        return;
    }

    const port = DroidNet.state.wcb.selectedPort;
    const mode = document.querySelector('input[name="restore-mode"]:checked').value;

    if (!port) {
        showStatusMessage('Please select a WCB device first', 'warning');
        return;
    }

    if (!currentRestoreFilename) {
        showStatusMessage('No backup selected', 'error');
        return;
    }

    // Set guard and update UI
    restoreInProgress = true;
    const restoreBtn = document.querySelector('#backup-restore-modal .btn-danger');
    const originalText = restoreBtn ? restoreBtn.textContent : 'Restore';
    if (restoreBtn) {
        restoreBtn.disabled = true;
        restoreBtn.textContent = 'Restoring...';
    }

    try {
        showStatusMessage('Sending restore commands...', 'info');

        const response = await fetch('/api/wcb/backup/restore', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                port,
                filename: currentRestoreFilename,
                mode
            })
        });

        const data = await response.json();

        if (data.success) {
            showStatusMessage(data.message || 'Restore commands sent - watch Live Output', 'success');
            closeRestoreModal();
            // Scroll to Live Output section so user can watch the restore
            const liveOutput = document.getElementById('wcb-serial-output');
            if (liveOutput) {
                liveOutput.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        } else {
            showStatusMessage(data.error || 'Restore failed', 'error');
        }
    } catch (error) {
        console.error('Error restoring backup:', error);
        showStatusMessage('Restore failed', 'error');
    } finally {
        // Reset guard and UI
        restoreInProgress = false;
        if (restoreBtn) {
            restoreBtn.disabled = false;
            restoreBtn.textContent = originalText;
        }
    }
}

/**
 * Update backup now button state based on connection
 */
function updateBackupNowButton() {
    const btn = document.getElementById('backup-now-btn');
    if (btn) {
        btn.disabled = !DroidNet.state.wcb.isConnected;
    }
}

// ========== WCB Preset Commands ==========

// Current preset commands state
DroidNet.state.wcb.presets = [];
DroidNet.state.wcb.presetsDeviceId = null;
DroidNet.state.wcb.presetsIsDefault = true;

/**
 * Load preset commands for the current WCB device
 */
async function loadWCBPresets() {
    const deviceId = DroidNet.state.wcb.selectedDeviceId;
    try {
        const url = deviceId
            ? `/api/wcb/preset-commands?device_id=${encodeURIComponent(deviceId)}`
            : '/api/wcb/preset-commands';
        const response = await fetch(url);
        const data = await response.json();

        if (data.success !== false) {
            DroidNet.state.wcb.presets = data.presets || [];
            DroidNet.state.wcb.presetsDeviceId = data.device_id;
            DroidNet.state.wcb.presetsIsDefault = data.is_default;
            renderPresetButtons();
        }
    } catch (error) {
        console.error('Error loading WCB presets:', error);
        // Fall back to defaults (BACKUP first as it includes all CONFIG data plus more)
        DroidNet.state.wcb.presets = [
            {name: 'BACKUP', command: '?BACKUP'},
            {name: 'CONFIG', command: '?CONFIG'},
            {name: 'DON', command: '?DON'},
            {name: 'DOFF', command: '?DOFF'},
            {name: 'DIAG', command: '?CDIAG'}
        ];
        renderPresetButtons();
    }
}

/**
 * Render preset command buttons
 */
function renderPresetButtons() {
    const container = document.getElementById('wcb-preset-buttons');
    const editBtn = document.getElementById('wcb-preset-edit-btn');
    if (!container) return;

    const hasPresets = DroidNet.state.wcb.presets && DroidNet.state.wcb.presets.length > 0;

    container.innerHTML = hasPresets ? DroidNet.state.wcb.presets.map((preset, idx) =>
        `<button onclick="sendPresetCommand(${idx})" class="btn btn-sm btn-secondary">${escapeHtml(preset.name)}</button>`
    ).join('') : '';

    // Show/hide edit button based on whether we have presets (device selected)
    if (editBtn) {
        editBtn.style.display = hasPresets ? '' : 'none';
    }
}

/**
 * Send a preset command by index
 */
function sendPresetCommand(index) {
    const preset = DroidNet.state.wcb.presets[index];
    if (!preset) return;

    if (!DroidNet.state.wcb.isConnected) {
        showStatusMessage('Not connected to WCB device', 'error', 8000);
        return;
    }

    // Special handling for BACKUP and CONFIG commands (with retry logic)
    if (preset.command === '?BACKUP') {
        DroidNet.state.config.retryCount = 0;
        sendWCBCommand('?BACKUP');
        setTimeout(() => {
            const output = document.getElementById('wcb-serial-output').textContent;
            if (output.includes('ESP-NOW message sent successfully!') && !output.includes('WCB Configuration Backup')) {
                if (DroidNet.state.config.retryCount < 1) {
                    DroidNet.state.config.retryCount++;
                    sendWCBCommand('?BACKUP');
                }
            }
        }, 1000);
    } else if (preset.command === '?CONFIG') {
        DroidNet.state.config.retryCount = 0;
        sendWCBCommand('?CONFIG');
        setTimeout(() => {
            const output = document.getElementById('wcb-serial-output').textContent;
            if (output.includes('ESP-NOW message sent successfully!') && !output.includes('Configuration Info')) {
                if (DroidNet.state.config.retryCount < 1) {
                    DroidNet.state.config.retryCount++;
                    sendWCBCommand('?CONFIG');
                }
            }
        }, 1000);
    } else {
        // Use CRC32 verification for custom presets to detect transmission errors
        // This is safe for both read and write commands
        sendWCBCommand(preset.command, true);
    }
}

/**
 * Open the preset editor modal
 */
function openPresetEditor() {
    const modal = document.getElementById('preset-editor-modal');
    if (!modal) return;

    renderPresetEditorList();
    modal.style.display = 'flex';
}

/**
 * Close the preset editor modal
 */
function closePresetEditor() {
    const modal = document.getElementById('preset-editor-modal');
    if (modal) modal.style.display = 'none';
}

/**
 * Render the preset editor list
 */
function renderPresetEditorList() {
    const container = document.getElementById('preset-editor-list');
    if (!container) return;

    const presets = DroidNet.state.wcb.presets;
    container.innerHTML = presets.map((preset, idx) => `
        <div class="preset-editor-item" data-index="${idx}">
            <input type="text" class="form-control form-control-sm preset-name"
                   value="${escapeHtml(preset.name)}" placeholder="Name" maxlength="20">
            <input type="text" class="form-control form-control-sm preset-command"
                   value="${escapeHtml(preset.command)}" placeholder="Command" maxlength="100">
            <button class="btn-icon btn-icon--danger" onclick="removePresetItem(${idx})" title="Remove">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="18" y1="6" x2="6" y2="18"></line>
                    <line x1="6" y1="6" x2="18" y2="18"></line>
                </svg>
            </button>
        </div>
    `).join('');
}

/**
 * Add a new preset item to the editor
 */
function addPresetItem() {
    DroidNet.state.wcb.presets.push({name: '', command: ''});
    renderPresetEditorList();
    // Focus the new name input
    const items = document.querySelectorAll('.preset-editor-item');
    if (items.length > 0) {
        const lastItem = items[items.length - 1];
        const nameInput = lastItem.querySelector('.preset-name');
        if (nameInput) nameInput.focus();
    }
}

/**
 * Remove a preset item from the editor
 */
function removePresetItem(index) {
    DroidNet.state.wcb.presets.splice(index, 1);
    renderPresetEditorList();
}

/**
 * Collect preset values from the editor form
 */
function collectPresetsFromEditor() {
    const items = document.querySelectorAll('.preset-editor-item');
    const presets = [];
    items.forEach(item => {
        const name = item.querySelector('.preset-name').value.trim();
        const command = item.querySelector('.preset-command').value.trim();
        if (name && command) {
            presets.push({name, command});
        }
    });
    return presets;
}

/**
 * Save presets to the backend
 */
async function savePresets() {
    const deviceId = DroidNet.state.wcb.selectedDeviceId;
    if (!deviceId) {
        showStatusMessage('Please select a WCB device first', 'error');
        return;
    }

    const presets = collectPresetsFromEditor();
    if (presets.length === 0) {
        showStatusMessage('Add at least one preset command', 'error');
        return;
    }

    try {
        const response = await fetch('/api/wcb/preset-commands', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({device_id: deviceId, presets})
        });
        const data = await response.json();

        if (data.success) {
            DroidNet.state.wcb.presets = data.presets;
            DroidNet.state.wcb.presetsIsDefault = false;
            renderPresetButtons();
            closePresetEditor();
            showStatusMessage('Presets saved', 'success');
        } else {
            showStatusMessage(data.error || 'Failed to save presets', 'error');
        }
    } catch (error) {
        console.error('Error saving presets:', error);
        showStatusMessage('Failed to save presets', 'error');
    }
}

/**
 * Reset presets to defaults
 */
async function resetPresetsToDefault() {
    const deviceId = DroidNet.state.wcb.selectedDeviceId;
    if (!deviceId) {
        showStatusMessage('Please select a WCB device first', 'error');
        return;
    }

    try {
        const response = await fetch('/api/wcb/preset-commands/reset', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({device_id: deviceId})
        });
        const data = await response.json();

        if (data.success) {
            DroidNet.state.wcb.presets = data.presets;
            DroidNet.state.wcb.presetsIsDefault = true;
            renderPresetEditorList();
            renderPresetButtons();
            showStatusMessage('Presets reset to defaults', 'success');
        } else {
            showStatusMessage(data.error || 'Failed to reset presets', 'error');
        }
    } catch (error) {
        console.error('Error resetting presets:', error);
        showStatusMessage('Failed to reset presets', 'error');
    }
}

// Command Table Management
function parseConfigResponse(response) {
    try {
        console.log('Parsing response, length:', response.length);

        // Check if this is a ?BACKUP response by looking for checksum marker and backup header
        // The ?CHK marker is the definitive indicator of a backup with checksum protection
        const hasChecksum = /\?CHK[A-Fa-f0-9]{8}/.test(response);
        const hasBackupHeader = response.includes('WCB Configuration Backup') || response.includes('End of Backup');
        const isBackupResponse = hasChecksum && hasBackupHeader;

        if (isBackupResponse) {
            console.log('Detected BACKUP response format (checksum protected)');
            parseBackupResponse(response);
            return;
        }

        console.log('Detected CONFIG response format');

        // Extract stored commands section - try multiple possible markers
        const startMarkers = ['--- Stored Commands ---', 'Stored Commands:', 'Commands:'];
        const endMarkers = ['--- End of Stored Commands ---', '---', 'End of Commands'];

        let startIdx = -1;
        let endIdx = -1;
        let startMarker = '';

        // Find start marker
        for (const marker of startMarkers) {
            startIdx = response.indexOf(marker);
            if (startIdx !== -1) {
                startMarker = marker;
                break;
            }
        }

        // Find end marker
        if (startIdx !== -1) {
            for (const marker of endMarkers) {
                endIdx = response.indexOf(marker, startIdx + startMarker.length);
                if (endIdx !== -1) {
                    break;
                }
            }
        }

        // Check for "No stored commands" message
        if (response.includes('No stored commands')) {
            console.log('No stored commands found');
            DroidNet.state.wcb.commandTable = [];
            DroidNet.state.wcb.unsavedChanges = false;
            populateCommandTable();

            // Show a message in the table
            const tbody = document.getElementById('command-table-body');
            if (tbody && tbody.children.length === 0) {
                const row = document.createElement('tr');
                row.innerHTML = '<td colspan="3" style="text-align: center; color: #666;">No stored commands. Click "Add Command" to create one.</td>';
                tbody.appendChild(row);
            }
            return;
        }

        // Debug: Log the response to see what format commands are in
        console.log('Full CONFIG response for parsing:', response);

        // Look for "--- Stored Commands ---" section
        if (response.includes('--- Stored Commands ---')) {
            const startIdx = response.indexOf('--- Stored Commands ---');
            const endIdx = response.indexOf('--- End of Stored Commands ---');
            if (startIdx !== -1 && endIdx !== -1) {
                const commandSection = response.substring(startIdx + '--- Stored Commands ---'.length, endIdx);
                console.log('Command section found:', commandSection);
                parseCommandSection(commandSection);
                return;
            }
        }

        if (startIdx === -1) {
            console.warn('CONFIG response does not contain expected markers.');
            // Try to find commands in a different format
            const commandLines = response.split('\n').filter(line =>
                line.includes('Key:') && line.includes('->') && line.includes('Value:')
            );

            if (commandLines.length > 0) {
                console.log('Found command lines:', commandLines);
                parseCommandSection(commandLines.join('\n'));
            } else {
                console.log('No commands found in response');
                DroidNet.state.wcb.commandTable = [];
                populateCommandTable();
            }
            return;
        }

        const commandsSection = response.substring(startIdx + startMarker.length, endIdx !== -1 ? endIdx : response.length);
        parseCommandSection(commandsSection);

    } catch (error) {
        // If parsing fails, do nothing
        console.error('Response parse error:', error);
    }
}

/**
 * Show error message in the Stored Commands table
 * @param {string} message - Error message to display
 */
function showStoredCommandsError(message) {
    const tbody = document.getElementById('command-table-body');
    if (tbody) {
        tbody.innerHTML = `<tr><td colspan="3" class="text-danger" style="text-align: center;">${escapeHtml(message)}</td></tr>`;
    }
}

/**
 * Parse ?BACKUP response format.
 * Commands are listed one per line before "*** === For Configured Boards".
 * This avoids complexity of parsing concatenated restore lines with embedded ^ and ?CHK.
 */
function parseBackupResponse(response) {
    console.log('Parsing BACKUP response');

    // BACKUP format has commands listed one per line BEFORE the section markers:
    //   *** WCB Configuration Backup
    //   *** Copy and paste these commands to restore
    //   *** ========================================
    //   ?HW24
    //   ?CSalarm,<CA0010>^*** Play Death Star...
    //   ?CSangrysound,<SM0>^*** HCR Mild Angry^
    //   ...
    //   *** === For Configured Boards (Current Delimiter: '^')
    //   [concatenated restore line - we skip this]
    //   *** Checksum: ?CHKxxxxxxxx
    //
    // We parse the individual lines (each ?CS on its own line) which avoids
    // all complexity of splitting concatenated commands or handling embedded ?CHK.

    // Find the section marker that ends the individual command lines
    const sectionMarker = '*** === For Configured Boards';
    const sectionIdx = response.indexOf(sectionMarker);

    if (sectionIdx === -1) {
        console.warn('Could not find section marker "*** === For Configured Boards" in BACKUP response');
        // Fall back to parsing all lines if marker not found
    }

    // Extract the portion before the section marker (individual command lines)
    const commandSection = sectionIdx !== -1 ? response.substring(0, sectionIdx) : response;

    // Parse each line - look for lines starting with ?CS
    const commands = [];
    const lines = commandSection.split('\n');

    for (const line of lines) {
        const trimmed = line.trim();
        if (trimmed.startsWith('?CS')) {
            // Parse: ?CSkey,value (value may contain ^ characters, that's fine)
            const cmdPart = trimmed.substring(3); // Remove '?CS'
            const commaIdx = cmdPart.indexOf(',');
            if (commaIdx !== -1) {
                const key = cmdPart.substring(0, commaIdx);
                const value = cmdPart.substring(commaIdx + 1);
                commands.push({ key, value, modified: false });
            }
        }
    }

    console.log(`Parsed ${commands.length} stored commands from validated backup`);

    // 7. Sort and update table
    commands.sort((a, b) => a.key.toLowerCase().localeCompare(b.key.toLowerCase()));
    DroidNet.state.wcb.commandTable = commands;
    DroidNet.state.wcb.unsavedChanges = false;
    populateCommandTable();

    // Show message if no commands found
    if (commands.length === 0) {
        const tbody = document.getElementById('command-table-body');
        if (tbody && tbody.children.length === 0) {
            const row = document.createElement('tr');
            row.innerHTML = '<td colspan="3" style="text-align: center; color: #666;">No stored commands. Click "ADD" to create one.</td>';
            tbody.appendChild(row);
        }
    }

    // Refresh backup list - server saves backups when it sees backup data
    setTimeout(() => loadBackupList(), 3000);
}

function parseCommandSection(commandsSection) {
    const commands = [];
    
    console.log('Parsing command section:', commandsSection);
    
    // Parse each command line - try multiple formats
    const lines = commandsSection.trim().split('\n');
    console.log('Lines to parse:', lines);
    
    for (const line of lines) {
        console.log('Parsing line:', line);
        
        // Format 1: Key: 'X' -> Value: 'Y'
        let match = line.match(/Key:\s*'([^']+)'\s*->\s*Value:\s*'([^']*)'/);
        if (!match) {
            // Format 2: Key: 'X' -> Value: 'Y' (without $ at end)
            match = line.match(/Key:\s*'([^']+)'\s*->\s*Value:\s*'([^']*)'*/);
        }
        if (!match) {
            // Format 3: X -> Y
            match = line.match(/^\s*([A-Za-z0-9]+)\s*->\s*(.*)$/);
        }
        if (!match) {
            // Format 4: X: Y
            match = line.match(/^\s*([A-Za-z0-9]+):\s*(.*)$/);
        }
        
        if (match) {
            let value = match[2] ? match[2].trim() : '';
            
            // Fix any formatting issues in stored values
            // Replace space before *** with ^***
            if (value.includes(' ***')) {
                value = value.replace(/\s+\*\*\*/g, '^***');
                console.log(`Fixed formatting for key '${match[1].trim()}': ${value}`);
            }
            
            commands.push({
                key: match[1].trim(),
                value: value,
                modified: false
            });
        }
    }
    
    console.log('Parsed commands:', commands);
    
    // Sort commands alphabetically by key
    commands.sort((a, b) => {
        return a.key.toLowerCase().localeCompare(b.key.toLowerCase());
    });
    
    console.log('Sorted commands:', commands);
    
    // Update table
    DroidNet.state.wcb.commandTable = commands;
    DroidNet.state.wcb.unsavedChanges = false;
    populateCommandTable();
}

// Table Population
function populateCommandTable() {
    const tbody = document.getElementById('command-table-body');
    tbody.innerHTML = '';
    
    if (DroidNet.state.wcb.commandTable.length === 0) {
        // Show empty state message
        const row = document.createElement('tr');
        row.innerHTML = '<td colspan="3" style="text-align: center; color: #666;">No stored commands. Click "ADD" to create one.</td>';
        tbody.appendChild(row);
    } else {
        DroidNet.state.wcb.commandTable.forEach((cmd, index) => {
            const row = createCommandRow(cmd, index);
            tbody.appendChild(row);
        });
    }
}

function createCommandRow(cmd, index) {
    const row = document.createElement('tr');
    if (cmd.modified) {
        row.classList.add('unsaved-row');
    }
    
    // Apply delimiter parsing for display
    // The WCB format uses:
    // - ^*** for inline comments (displays on same line as command)
    // - ^^*** for comments on their own line
    // - ^ as a general delimiter between different items
    
    let displayValue = cmd.value;
    
    // Split by ^ to process each segment
    const segments = displayValue.split('^');
    const displayLines = [];
    let currentLine = '';
    
    for (let i = 0; i < segments.length; i++) {
        const segment = segments[i];
        
        if (segment.startsWith('***')) {
            // This is a comment
            if (currentLine) {
                // Add to current line as inline comment
                currentLine += ' ' + segment;
            } else {
                // Standalone comment (after ^^)
                displayLines.push(segment);
            }
        } else if (segment === '') {
            // Empty segment means we had ^^
            // Push current line and prepare for standalone comment
            if (currentLine) {
                displayLines.push(currentLine);
                currentLine = '';
            }
        } else {
            // Regular command
            if (currentLine) {
                // Push previous line and start new one
                displayLines.push(currentLine);
            }
            currentLine = segment;
        }
    }
    
    // Don't forget last line
    if (currentLine) {
        displayLines.push(currentLine);
    }
    
    displayValue = displayLines.join('\n');
    
    row.innerHTML = `
        <td>
            <div class="key-input-wrapper">
                <input type="text" class="key-input" value="${cmd.key}" 
                       maxlength="15" pattern="[A-Za-z0-9]+" 
                       data-index="${index}" 
                       oninput="handleKeyInput(${index}, this)"
                       onchange="updateCommand(${index}, 'key', this.value)">
                <small class="key-char-count">${cmd.key.length}/15</small>
            </div>
        </td>
        <td>
            <div class="value-input-wrapper">
                <div class="value-input ${hasComments(cmd.value) ? 'value-with-comments' : ''}" 
                     contenteditable="true"
                     data-index="${index}" 
                     data-placeholder="Enter command value..."
                     data-original-value="${(cmd.value || '').replace(/"/g, '&quot;')}"
                     onfocus="captureOriginalValue(${index}, this)"
                     oninput="handleValueInputEditable(${index}, this)"
                     onblur="updateCommandFromEditable(${index}, this)"
                     onkeydown="handleEditableKeydown(event, ${index}, this)">${formatValueForEditable(displayValue)}</div>
                <small class="char-count">${cmd.value.length}</small>
            </div>
        </td>
        <td class="action-buttons">
            <button onclick="testCommand(${index})" class="btn btn-small">TEST</button>
            <button onclick="updateCommand(${index})" class="btn btn-small btn-primary">UPDATE</button>
            <button onclick="removeCommand(${index})" class="btn btn-small btn-danger">REMOVE</button>
        </td>
    `;
    
    return row;
}

// Command Operations
async function updateCommand(index, field, value) {
    if (field) {
        // Update specific field
        if (field === 'key') {
            // Validate key format
            if (!/^[A-Za-z0-9]+$/.test(value)) {
                showStatusMessage('Key must contain only letters and numbers', 'error', 8000);
                return;
            }
            DroidNet.state.wcb.commandTable[index].key = value;
            DroidNet.state.wcb.commandTable[index].modified = true;
            DroidNet.state.wcb.unsavedChanges = true;
            // Update row class without repopulating
            const tbody = document.getElementById('command-table-body');
            const rows = tbody.getElementsByTagName('tr');
            if (rows[index]) {
                rows[index].classList.add('unsaved-row');
            }
            return; // Exit early to avoid the generic handler below
        } else if (field === 'value') {
            // Handle special comment formatting:
            // - Comments on same line: COMMAND ***COMMENT → COMMAND^***COMMENT
            // - Comments on new line: COMMAND\n***COMMENT → COMMAND^^***COMMENT
            // - Regular newlines: COMMAND\nCOMMAND2 → COMMAND^COMMAND2
            
            // Split into lines for processing
            const lines = value.split('\n');
            const processedLines = [];
            
            for (let i = 0; i < lines.length; i++) {
                const line = lines[i];
                
                // Process all lines the same way - replace any space before ***
                let processed = line;
                
                // Replace any occurrence of space(s) followed by ***
                if (line.includes('***')) {
                    processed = line.replace(/\s+\*\*\*/g, '^***');
                }
                
                if (i > 0) {
                    // This line comes after a newline
                    if (processed.trim().startsWith('***')) {
                        // Comment on new line - needs ^^ (additional ^ prefix)
                        processedLines.push('^' + processed);
                    } else {
                        // Regular command on new line
                        processedLines.push(processed);
                    }
                } else {
                    // First line
                    processedLines.push(processed);
                }
            }
            
            // Join with ^ delimiter
            value = processedLines.join('^');
            
            // Only mark as modified if the value actually changed
            if (DroidNet.state.wcb.commandTable[index].value !== value) {
                DroidNet.state.wcb.commandTable[index].value = value;
                DroidNet.state.wcb.commandTable[index].modified = true;
                DroidNet.state.wcb.unsavedChanges = true;
                // Don't repopulate the table immediately - just update the row's class
                const tbody = document.getElementById('command-table-body');
                const rows = tbody.getElementsByTagName('tr');
                if (rows[index]) {
                    rows[index].classList.add('unsaved-row');
                }
            }
        }
    } else {
        // UPDATE button clicked - send to device
        if (!DroidNet.state.wcb.isConnected) {
            showStatusMessage('Not connected to WCB device', 'error', 8000);
            return;
        }
        
        const cmd = DroidNet.state.wcb.commandTable[index];
        
        // Validate key and value
        if (!cmd.key || !cmd.value) {
            showStatusMessage('Key and value cannot be empty', 'error', 8000);
            return;
        }
        
        // Always ensure proper formatting before sending
        // Replace any space before *** with ^***
        let processedValue = cmd.value;
        if (processedValue.includes(' ***')) {
            processedValue = processedValue.replace(/\s+\*\*\*/g, '^***');
            console.log('Fixed formatting in value:', processedValue);
        }
        
        const command = `?CS${cmd.key},${processedValue}`;
        console.log('Sending UPDATE command:', command);
        console.log('Key:', cmd.key);
        console.log('Value being sent:', processedValue);

        // Send with CRC32 verification to detect transmission errors
        // The ?CHK checksum is verified and stripped by WCB firmware before storing
        if (!sendWCBCommand(command, true)) {
            showStatusMessage('Failed to send command - check connection', 'error', 8000);
            return;
        }
        
        // Mark as saved immediately
        DroidNet.state.wcb.commandTable[index].modified = false;
        
        // Update visual state without repopulating table
        const tbody = document.getElementById('command-table-body');
        const rows = tbody.getElementsByTagName('tr');
        if (rows[index]) {
            rows[index].classList.remove('unsaved-row');
        }
    }
}

function testCommand(index) {
    if (!DroidNet.state.wcb.isConnected) {
        showStatusMessage('Please connect to a WCB device first', 'error', 8000);
        return;
    }
    
    const cmd = DroidNet.state.wcb.commandTable[index];
    
    // For test command, we need to parse the command the same way as WCB does
    // Split by delimiter and filter out comments (lines starting with ***)
    const segments = cmd.value.split('^');
    const nonCommentSegments = segments.filter(segment => {
        const trimmed = segment.trim();
        return trimmed && !trimmed.startsWith('***');
    });
    
    // Send each non-comment segment as a separate command
    nonCommentSegments.forEach((segment, i) => {
        if (segment.trim()) {
            // Add a small delay between commands to avoid overwhelming the device
            setTimeout(() => {
                sendWCBCommand(segment.trim());
            }, i * 50);
        }
    });
    
    // Auto-scroll serial monitor
    const output = document.getElementById('wcb-serial-output');
    output.scrollTop = output.scrollHeight;
}

function removeCommand(index) {
    if (!DroidNet.state.wcb.isConnected) {
        showStatusMessage('Please connect to a WCB device first', 'error', 8000);
        return;
    }
    
    const cmd = DroidNet.state.wcb.commandTable[index];
    
    // Confirm deletion
    if (!confirm(`Are you sure you want to remove command "${cmd.key}"?`)) {
        return;
    }
    
    // Send delete command to WCB with CRC32 verification
    const command = `?CE${cmd.key}`;
    sendWCBCommand(command, true);
    
    // Remove from local table
    DroidNet.state.wcb.commandTable.splice(index, 1);
    DroidNet.state.wcb.unsavedChanges = false; // Deletion is immediate, no unsaved state
    populateCommandTable();
    
    // Show success message
    showSuccess(`Command "${cmd.key}" removed`);
    
    // Reload commands after a short delay to confirm deletion
    setTimeout(() => {
        sendWCBCommand('?BACKUP');
    }, 1000);
}

function addNewCommand() {
    DroidNet.state.wcb.commandTable.push({
        key: '',
        value: '',
        modified: true
    });
    DroidNet.state.wcb.unsavedChanges = true;
    populateCommandTable();
    
    // Focus on new key input
    setTimeout(() => {
        const inputs = document.querySelectorAll('.key-input');
        inputs[inputs.length - 1].focus();
    }, 100);
}

// UPDATE ALL Implementation
async function updateAllCommands() {
    if (!DroidNet.state.wcb.isConnected) {
        showStatusMessage('Not connected to WCB device', 'error', 8000);
        return;
    }
    
    if (DroidNet.state.wcb.updateInProgress) {
        return;
    }
    
    DroidNet.state.wcb.updateInProgress = true;
    disableWCBControls(true);
    
    // Mark all rows as red
    DroidNet.state.wcb.commandTable.forEach(cmd => cmd.modified = true);
    populateCommandTable();
    
    const delay = parseInt(document.getElementById('update-delay-slider').value);
    
    try {
        for (let i = 0; i < DroidNet.state.wcb.commandTable.length; i++) {
            // Check if still connected
            if (!DroidNet.state.wcb.isConnected) {
                // Device disconnected - keep remaining rows red
                break;
            }
            
            const cmd = DroidNet.state.wcb.commandTable[i];
            if (!cmd.key || !cmd.value) continue;

            const command = `?CS${cmd.key},${cmd.value}`;
            const sent = sendWCBCommand(command, true);  // Use CRC32 verification

            if (sent) {
                // Mark as saved only if command was actually sent
                DroidNet.state.wcb.commandTable[i].modified = false;
            } else {
                // Command failed to send - keep row red, log warning
                console.warn(`Failed to send command for key: ${cmd.key}`);
            }
            populateCommandTable();
            
            // Wait for delay
            if (i < DroidNet.state.wcb.commandTable.length - 1) {
                await new Promise(resolve => setTimeout(resolve, delay));
            }
        }
    } catch (error) {
        console.error('UPDATE ALL error:', error);
    } finally {
        DroidNet.state.wcb.updateInProgress = false;
        // Only clear unsaved changes if all rows were sent
        if (!DroidNet.state.wcb.commandTable.some(cmd => cmd.modified)) {
            DroidNet.state.wcb.unsavedChanges = false;
        }
        disableWCBControls(false);
    }
}

// Clear all commands with confirmation
async function clearAllCommands() {
    // Create confirmation message
    const message = `⚠️ WARNING: Clear All Commands?\n\n` +
                   `This will permanently delete ALL stored commands from the WCB device.\n\n` +
                   `This action cannot be undone!\n\n` +
                   `💡 TIP: Export your commands first to save a backup.\n\n` +
                   `Are you sure you want to clear all commands?`;
    
    if (confirm(message)) {
        // Double confirmation for safety
        if (confirm('Final confirmation: Delete ALL commands from the device?')) {
            // Check if connected to WCB
            if (!DroidNet.state.wcb.isConnected) {
                showStatusMessage('Not connected to WCB device. Please connect first.', 'error', 8000);
                return;
            }
            
            try {
                // Send clear all command to WCB device with CRC32 verification
                const clearCommand = '?CCLEAR';  // Clear All Stored Commands
                sendWCBCommand(clearCommand, true);
                
                // Wait a bit for the device to process
                await new Promise(resolve => setTimeout(resolve, 500));
                
                // Clear the local command table
                DroidNet.state.wcb.commandTable = [];
                DroidNet.state.wcb.unsavedChanges = false;
                
                // Update the display
                populateCommandTable();
                
                // Show success message
                const statusElement = document.getElementById('import-export-status');
                if (statusElement) {
                    statusElement.textContent = 'All commands cleared from device successfully';
                    statusElement.classList.remove('hidden', 'error');
                    statusElement.classList.add('success');
                    setTimeout(() => {
                        statusElement.classList.add('hidden');
                    }, 3000);
                }
            } catch (error) {
                showStatusMessage('Failed to clear commands: ' + error.message, 'error', 8000);
            }
        }
    }
}

// Import/Export Functions
function exportCommands() {
    const exportData = DroidNet.state.wcb.commandTable.map(cmd => ({
        key: cmd.key,
        value: cmd.value
    }));
    
    const json = JSON.stringify(exportData, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `wcb-commands-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

async function importCommands(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    try {
        const text = await file.text();
        const importData = JSON.parse(text);
        
        // Validate format
        if (!Array.isArray(importData)) {
            throw new Error('Invalid file format');
        }
        
        // Replace all commands
        DroidNet.state.wcb.commandTable = importData.map(cmd => ({
            key: cmd.key || '',
            value: cmd.value || '',
            modified: true
        }));
        
        DroidNet.state.wcb.unsavedChanges = true;
        populateCommandTable();
        
        showSuccess('Commands imported successfully');
    } catch (error) {
        showStatusMessage('Failed to import file: ' + error.message, 'error', 8000);
    }
    
    // Clear file input
    event.target.value = '';
}

// UI Helper Functions
function updateDelayValue(value) {
    document.getElementById('update-delay-value').textContent = value + 'ms';
}

function updateDelimiterParsing() {
    DroidNet.state.config.delimiterParsing = document.getElementById('delimiter-parsing').checked;
    populateCommandTable();
}

function disableWCBControls(disabled) {
    document.getElementById('update-all-btn').disabled = disabled;
    document.querySelectorAll('.command-table button').forEach(btn => {
        if (btn.id !== 'update-all-btn') {
            btn.disabled = disabled;
        }
    });
    document.querySelectorAll('.command-table input, .command-table textarea').forEach(input => {
        input.disabled = disabled;
    });
}

// Navigation Guards
// (beforeunload handler consolidated above at line 2496)

// Tab switching guard
const originalShowTab = window.showTab;
window.showTab = function(tabName) {
    if (tabName !== 'wcb' && (DroidNet.state.wcb.unsavedChanges || DroidNet.state.wcb.updateInProgress)) {
        if (!confirm('You have unsaved changes. Continue?')) {
            return;
        }
    }
    
    // Load WCB devices when tab is shown
    if (tabName === 'wcb') {
        loadWCBDevices();
    }
    
    originalShowTab(tabName);
};

// Command Table Filtering
function filterCommandTable() {
    const keyFilter = document.getElementById('key-filter').value.toLowerCase();
    const valueFilter = document.getElementById('value-filter').value.toLowerCase();
    
    // Show/hide clear buttons
    document.getElementById('key-filter-clear').style.display = keyFilter ? 'flex' : 'none';
    document.getElementById('value-filter-clear').style.display = valueFilter ? 'flex' : 'none';
    
    const tbody = document.getElementById('command-table-body');
    const rows = tbody.getElementsByTagName('tr');
    let visibleCount = 0;
    let totalCount = rows.length;
    
    // Handle empty table case
    if (totalCount === 1 && rows[0].querySelector('td[colspan]')) {
        // This is the "No stored commands" message
        return;
    }
    
    for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const keyInput = row.querySelector('.key-input');
        const valueElement = row.querySelector('.value-input[contenteditable]');
        
        if (!keyInput || !valueElement) continue;
        
        const keyText = keyInput.value.toLowerCase();
        const valueText = (valueElement.innerText || valueElement.textContent || '').toLowerCase();
        
        const keyMatch = !keyFilter || keyText.includes(keyFilter);
        const valueMatch = !valueFilter || valueText.includes(valueFilter);
        
        if (keyMatch && valueMatch) {
            row.classList.remove('filtered-out');
            visibleCount++;
        } else {
            row.classList.add('filtered-out');
        }
    }
    
    // Update results display
    const resultsDiv = document.getElementById('filter-results');
    if (keyFilter || valueFilter) {
        resultsDiv.textContent = `Showing ${visibleCount} of ${totalCount} commands`;
        resultsDiv.classList.add('active');
    } else {
        resultsDiv.classList.remove('active');
    }
}

// Clear specific filter
function clearFilter(column) {
    const filterId = column + '-filter';
    const filterInput = document.getElementById(filterId);
    filterInput.value = '';
    filterInput.focus();
    filterCommandTable();
}

// Handle key input for character counter
function handleKeyInput(index, element) {
    const value = element.value;
    const charCountElement = element.parentNode.querySelector('.key-char-count');
    if (charCountElement) {
        charCountElement.textContent = `${value.length}/15`;
        
        // Change color based on length
        if (value.length >= 15) {
            charCountElement.style.color = '#e74c3c';
        } else if (value.length >= 12) {
            charCountElement.style.color = '#f39c12';
        } else {
            charCountElement.style.color = '#666';
        }
    }
}

// Template Management Functions
// Note: Template state variables are now in DroidNet.state.templates

async function loadTemplates() {
    try {
        const response = await fetch('/api/templates');
        const result = await response.json();
        
        if (result.success) {
            DroidNet.state.templates.list = result.templates || [];
            displayTemplates();
        } else {
            console.error('Failed to load templates:', result.error);
            DroidNet.state.templates.list = [];
            displayTemplates();
        }
    } catch (error) {
        console.error('Error loading templates:', error);
        DroidNet.state.templates.list = [];
        displayTemplates();
    }
}

function displayTemplates(filterCategory = 'all') {
    const templatesList = document.getElementById('templates-list');
    
    // Filter templates by category
    let filteredTemplates = DroidNet.state.templates.list;
    if (filterCategory !== 'all') {
        filteredTemplates = DroidNet.state.templates.list.filter(t => t.category === filterCategory);
    }
    
    if (filteredTemplates.length === 0) {
        templatesList.innerHTML = '<div class="template-item">No templates found. Click "Add New Template" to create one.</div>';
        return;
    }
    
    templatesList.innerHTML = filteredTemplates.map(template => `
        <div class="template-item" onclick="selectTemplate('${template.id}')" data-template-id="${template.id}">
            <div class="template-header">
                <span class="template-name">${escapeHtml(template.name)}</span>
                <span class="template-category ${template.category}">${template.category}</span>
            </div>
            <div class="template-command">${escapeHtml(template.command)}</div>
            ${template.description ? `<div class="template-description">${escapeHtml(template.description)}</div>` : ''}
            <div class="template-actions">
                <button onclick="editTemplate('${template.id}'); event.stopPropagation();" class="btn btn-secondary">Edit</button>
                <button onclick="sendTemplateQuick('${template.id}'); event.stopPropagation();" class="btn btn-primary">Send</button>
            </div>
        </div>
    `).join('');
}

function filterTemplatesByCategory() {
    const category = document.getElementById('template-category').value;
    displayTemplates(category);
}

function selectTemplate(templateId) {
    // Remove previous selection
    document.querySelectorAll('.template-item').forEach(item => {
        item.classList.remove('selected');
    });
    
    // Add selection to clicked template
    const templateElement = document.querySelector(`[data-template-id="${templateId}"]`);
    if (templateElement) {
        templateElement.classList.add('selected');
    }
    
    // Find template data
    DroidNet.state.templates.selected = DroidNet.state.templates.list.find(t => t.id === templateId);
    
    if (DroidNet.state.templates.selected) {
        // Update quick send section
        document.getElementById('selected-template').textContent = 
            `${DroidNet.state.templates.selected.name}: ${DroidNet.state.templates.selected.command}`;
        document.getElementById('send-template-btn').disabled = false;
        document.getElementById('test-template-btn').disabled = false;
    }
}

function addNewTemplate() {
    DroidNet.state.templates.editingId = null;
    document.getElementById('editor-title').textContent = 'New Template';
    document.getElementById('template-name').value = '';
    document.getElementById('template-command').value = '';
    document.getElementById('template-description').value = '';
    document.getElementById('template-cat').value = 'custom';
    document.getElementById('template-params').value = '';
    document.getElementById('template-target').value = '';
    document.getElementById('delete-template-btn').style.display = 'none';
    document.getElementById('template-editor').classList.remove('hidden');
    document.getElementById('template-editor').scrollIntoView({ behavior: 'smooth' });
}

function editTemplate(templateId) {
    const template = DroidNet.state.templates.list.find(t => t.id === templateId);
    if (!template) return;
    
    DroidNet.state.templates.editingId = templateId;
    document.getElementById('editor-title').textContent = 'Edit Template';
    document.getElementById('template-name').value = template.name || '';
    document.getElementById('template-command').value = template.command || '';
    document.getElementById('template-description').value = template.description || '';
    document.getElementById('template-cat').value = template.category || 'custom';
    document.getElementById('template-params').value = template.parameters ? template.parameters.join(', ') : '';
    document.getElementById('template-target').value = template.targetDevice || '';
    document.getElementById('delete-template-btn').style.display = 'inline-block';
    document.getElementById('template-editor').classList.remove('hidden');
    document.getElementById('template-editor').scrollIntoView({ behavior: 'smooth' });
}

async function saveTemplate() {
    const name = document.getElementById('template-name').value.trim();
    const command = document.getElementById('template-command').value.trim();
    const description = document.getElementById('template-description').value.trim();
    const category = document.getElementById('template-cat').value;
    const paramsStr = document.getElementById('template-params').value.trim();
    const targetDevice = document.getElementById('template-target').value;
    
    if (!name || !command) {
        showStatusMessage('Template name and command are required', 'error', 8000);
        return;
    }
    
    const parameters = paramsStr ? paramsStr.split(',').map(p => p.trim()).filter(p => p) : [];
    
    const template = {
        name,
        command,
        description,
        category,
        parameters,
        targetDevice: targetDevice || null
    };
    
    if (DroidNet.state.templates.editingId) {
        template.id = DroidNet.state.templates.editingId;
    }
    
    try {
        const response = await fetch('/api/templates', {
            method: DroidNet.state.templates.editingId ? 'PUT' : 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(template)
        });
        
        const result = await response.json();
        const statusDiv = document.getElementById('template-editor-status');
        
        statusDiv.classList.remove('hidden');
        if (result.success) {
            statusDiv.className = 'status-message success';
            statusDiv.textContent = DroidNet.state.templates.editingId ? 'Template updated successfully' : 'Template created successfully';
            
            // Reload templates
            await loadTemplates();
            
            // Hide editor after short delay
            setTimeout(() => {
                cancelTemplateEdit();
            }, 1500);
        } else {
            statusDiv.className = 'status-message error';
            statusDiv.textContent = result.error || 'Failed to save template';
        }
        
        setTimeout(() => {
            statusDiv.classList.add('hidden');
        }, 5000);
    } catch (error) {
        showStatusMessage('Error saving template: ' + error.message, 'error', 8000);
    }
}

function cancelTemplateEdit() {
    document.getElementById('template-editor').classList.add('hidden');
    DroidNet.state.templates.editingId = null;
}

async function deleteTemplate() {
    if (!DroidNet.state.templates.editingId) return;
    
    const template = DroidNet.state.templates.list.find(t => t.id === DroidNet.state.templates.editingId);
    if (!template) return;
    
    if (!confirm(`Delete template "${template.name}"?`)) {
        return;
    }
    
    try {
        const response = await fetch(`/api/templates/${DroidNet.state.templates.editingId}`, {
            method: 'DELETE'
        });
        
        const result = await response.json();
        
        if (result.success) {
            showSuccess('Template deleted successfully');
            await loadTemplates();
            cancelTemplateEdit();
        } else {
            showStatusMessage('Failed to delete template: ' + result.error, 'error', 8000);
        }
    } catch (error) {
        showStatusMessage('Error deleting template: ' + error.message, 'error', 8000);
    }
}

async function loadTemplateDevices() {
    try {
        // Load serial devices for template target and quick send
        const [devicesResponse, namesResponse] = await Promise.all([
            fetch('/api/devices/serial'),
            fetch('/api/devices/names')
        ]);
        
        const devices = await devicesResponse.json();
        const customNames = await namesResponse.json();
        
        // Update template target device dropdown
        const targetSelect = document.getElementById('template-target');
        targetSelect.innerHTML = '<option value="">Any Device</option>';
        
        // Update quick send device dropdown
        const sendSelect = document.getElementById('send-device');
        sendSelect.innerHTML = '<option value="">Select device...</option>';
        
        devices.forEach(device => {
            const displayName = DroidNet.utils.getDeviceDisplayName(device, customNames);
            
            const option1 = document.createElement('option');
            option1.value = device.port;
            option1.textContent = `${displayName} (${device.port})`;
            targetSelect.appendChild(option1);
            
            const option2 = document.createElement('option');
            option2.value = device.port;
            option2.textContent = `${displayName} (${device.port})`;
            sendSelect.appendChild(option2);
        });
    } catch (error) {
        console.error('Failed to load devices for templates:', error);
    }
}

async function sendSelectedTemplate() {
    if (!DroidNet.state.templates.selected) {
        showStatusMessage('No template selected', 'error', 8000);
        return;
    }

    const devicePort = document.getElementById('send-device').value;
    if (!devicePort) {
        showStatusMessage('Please select a device', 'error', 8000);
        return;
    }

    try {
        await sendTemplateCommand(DroidNet.state.templates.selected.command, devicePort);
    } catch (error) {
        console.error('Failed to send template:', error);
        showStatusMessage('Failed to send template command', 'error', 8000);
    }
}

async function testSelectedTemplate() {
    if (!DroidNet.state.templates.selected) {
        showStatusMessage('No template selected', 'error', 8000);
        return;
    }
    
    // Switch to serial monitor tab
    showTab('serial');
    
    // Wait for tab to load
    setTimeout(() => {
        // Set the command in serial input
        document.getElementById('serial-command').value = DroidNet.state.templates.selected.command;
        
        // Show notification
        showSuccess('Template command copied to Serial Monitor. Select a device and click Send.');
    }, 100);
}

async function sendTemplateQuick(templateId) {
    const template = DroidNet.state.templates.list.find(t => t.id === templateId);
    if (!template) return;

    try {
        // Check if template has a target device specified
        if (template.targetDevice) {
            await sendTemplateCommand(template.command, template.targetDevice);
        } else {
            // Select the template and scroll to quick send
            selectTemplate(templateId);
            document.querySelector('.quick-send-section').scrollIntoView({ behavior: 'smooth' });
            showSuccess('Template selected. Choose a device and click Send Command.');
        }
    } catch (error) {
        console.error('Failed to send template:', error);
        showStatusMessage('Failed to send template command', 'error', 8000);
    }
}

async function sendTemplateCommand(command, devicePort) {
    const statusDiv = document.getElementById('quick-send-status');
    
    try {
        const response = await fetch('/api/templates/send', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ command, device_port: devicePort })
        });
        
        const result = await response.json();
        
        statusDiv.classList.remove('hidden');
        if (result.success) {
            statusDiv.className = 'status-message success';
            statusDiv.textContent = `Command sent successfully to ${devicePort}`;
        } else {
            statusDiv.className = 'status-message error';
            statusDiv.textContent = result.error || 'Failed to send command';
        }
        
        setTimeout(() => {
            statusDiv.classList.add('hidden');
        }, 5000);
    } catch (error) {
        showStatusMessage('Error sending command: ' + error.message, 'error', 8000);
    }
}

async function exportTemplates() {
    try {
        const dataStr = JSON.stringify(DroidNet.state.templates.list, null, 2);
        const dataBlob = new Blob([dataStr], { type: 'application/json' });
        const url = URL.createObjectURL(dataBlob);

        const link = document.createElement('a');
        link.href = url;
        link.download = `droidnet-templates-${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);

        showSuccess('Templates exported successfully');
    } catch (error) {
        showStatusMessage('Error exporting templates: ' + error.message, 'error', 8000);
    }
}

async function importTemplates(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const statusDiv = document.getElementById('import-export-status');
    
    try {
        const text = await file.text();
        const importedTemplates = JSON.parse(text);
        
        if (!Array.isArray(importedTemplates)) {
            throw new Error('Invalid template file format');
        }
        
        const response = await fetch('/api/templates/import', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ templates: importedTemplates })
        });
        
        const result = await response.json();
        
        statusDiv.classList.remove('hidden');
        if (result.success) {
            statusDiv.className = 'status-message success';
            statusDiv.textContent = `Imported ${result.count} templates successfully`;
            await loadTemplates();
        } else {
            statusDiv.className = 'status-message error';
            statusDiv.textContent = result.error || 'Failed to import templates';
        }
        
        setTimeout(() => {
            statusDiv.classList.add('hidden');
        }, 5000);
    } catch (error) {
        statusDiv.classList.remove('hidden');
        statusDiv.className = 'status-message error';
        statusDiv.textContent = 'Error importing templates: ' + error.message;
        
        setTimeout(() => {
            statusDiv.classList.add('hidden');
        }, 5000);
    }
    
    // Clear the file input
    event.target.value = '';
}

// Make functions globally accessible for onclick handlers
window.showTab = showTab;
window.refreshDevices = refreshDevices;
window.scanNetworks = scanNetworks;
window.connectWifi = connectWifi;
window.cancelWifi = cancelWifi;
window.flashFirmware = flashFirmware;
window.toggleSerial = toggleSerial;
window.clearSerial = clearSerial;
window.copySerial = copySerial;
window.sendSerial = sendSerial;
window.handleFirmwareSelect = handleFirmwareSelect;
window.copyFlashLog = copyFlashLog;
window.updateDeviceName = updateDeviceName;
window.resetDeviceName = resetDeviceName;
window.rebootDevice = rebootDevice;
window.uploadUpdate = uploadUpdate;
window.copyUpdateLog = copyUpdateLog;
window.clearUpdateConsole = clearUpdateConsole;
window.checkForUpdates = checkForUpdates;
window.downloadAndInstallUpdate = downloadAndInstallUpdate;
window.dismissGitHubUpdate = dismissGitHubUpdate;
window.saveUpdateSettings = saveUpdateSettings;
window.scrollToUpdateSection = scrollToUpdateSection;
window.editDeviceName = editDeviceName;
window.connectToSaved = connectToSaved;
window.forgetNetwork = forgetNetwork;
window.switchToAPMode = switchToAPMode;
window.toggleVirtualHere = toggleVirtualHere;
window.clearFlashConsole = clearFlashConsole;
window.updateNetworkPriority = updateNetworkPriority;
window.updateAPSettings = updateAPSettings;
window.toggleAPPassword = toggleAPPassword;
window.detectBoard = detectBoard;
window.toggleWCBFeature = toggleWCBFeature;
window.copyWCBLog = copyWCBLog;
window.clearWCBLog = clearWCBLog;
window.disconnectWCB = disconnectWCB;
window.reconnectWCB = reconnectWCB;
window.sendWCBSerial = sendWCBSerial;
window.sendWCBCommand = sendWCBCommand;
window.onWCBDeviceSelected = onWCBDeviceSelected;
window.sendConfigCommand = sendConfigCommand;
window.sendDONCommand = sendDONCommand;
window.sendDOFFCommand = sendDOFFCommand;
window.sendDIAGCommand = sendDIAGCommand;
window.sendPresetCommand = sendPresetCommand;
window.openPresetEditor = openPresetEditor;
window.closePresetEditor = closePresetEditor;
window.addPresetItem = addPresetItem;
window.removePresetItem = removePresetItem;
window.savePresets = savePresets;
window.resetPresetsToDefault = resetPresetsToDefault;
window.addNewCommand = addNewCommand;
window.updateAllCommands = updateAllCommands;
window.exportCommands = exportCommands;
window.importCommands = importCommands;
window.updateDelayValue = updateDelayValue;
window.updateDelimiterParsing = updateDelimiterParsing;
window.filterCommandTable = filterCommandTable;
window.clearFilter = clearFilter;
window.clearAllCommands = clearAllCommands;
window.handleValueInputEditable = handleValueInputEditable;
window.handleEditableKeydown = handleEditableKeydown;
window.captureOriginalValue = captureOriginalValue;
window.updateCommandFromEditable = updateCommandFromEditable;
window.handleKeyInput = handleKeyInput;
window.navigateSerialHistory = navigateSerialHistory;
window.navigateWCBHistory = navigateWCBHistory;

// Comlink Functions
async function toggleComlinkFeature() {
    const checkbox = document.getElementById('comlink-enabled-checkbox');
    const enabled = checkbox.checked;
    const statusDiv = document.getElementById('comlink-enable-status');
    
    try {
        const response = await fetch('/api/comlink/config', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ enabled: enabled })
        });
        
        const result = await response.json();
        
        if (result.success) {
            // Show/hide Comlink tab
            const comlinkTabBtn = document.getElementById('comlink-tab-btn');
            const comlinkSettings = document.getElementById('comlink-settings-section');
            const disabledOverlay = document.getElementById('comlink-disabled-overlay');

            if (enabled) {
                comlinkTabBtn.style.display = 'inline-block';
                comlinkSettings.classList.remove('hidden');
                if (disabledOverlay) {
                    disabledOverlay.style.display = 'none';
                }
                showSuccess('Comlink feature enabled', statusDiv);
                // Load settings and populate USB devices
                loadComlinkSettings();
            } else {
                comlinkTabBtn.style.display = 'none';
                comlinkSettings.classList.add('hidden');
                if (disabledOverlay) {
                    disabledOverlay.style.display = 'flex';
                }
                showSuccess('Comlink feature disabled', statusDiv);
            }
        } else {
            showStatusMessage('Failed to update Comlink settings: ' + result.error, statusDiv, 'error', 8000);
            checkbox.checked = !enabled; // Revert
        }
    } catch (error) {
        showStatusMessage('Error: ' + error.message, statusDiv, 'error', 8000);
        checkbox.checked = !enabled; // Revert
    }
}

async function loadComlinkSettings() {
    try {
        const response = await fetch('/api/comlink/config');
        const result = await response.json();

        if (result.success) {
            const config = result.config;
            const disabledOverlay = document.getElementById('comlink-disabled-overlay');

            // Set checkbox state
            document.getElementById('comlink-enabled-checkbox').checked = config.enabled;

            // Show/hide settings, tab, and overlay
            if (config.enabled) {
                document.getElementById('comlink-tab-btn').style.display = 'inline-block';
                document.getElementById('comlink-settings-section').classList.remove('hidden');
                if (disabledOverlay) {
                    disabledOverlay.style.display = 'none';
                }
            } else {
                document.getElementById('comlink-tab-btn').style.display = 'none';
                document.getElementById('comlink-settings-section').classList.add('hidden');
                if (disabledOverlay) {
                    disabledOverlay.style.display = 'flex';
                }
            }

            // Set form values
            document.getElementById('comlink-default-target').value = config.default_target || 'usb';
            document.getElementById('comlink-gpio-pin').value = config.default_gpio_pin || '27';
            document.getElementById('comlink-baud-rate').value = config.default_baud_rate || '115200';
            document.getElementById('comlink-add-cr').checked = config.add_cr_termination !== false;

            // Show/hide target-specific settings
            updateComlinkTarget();

            // Populate USB devices
            await updateComlinkUSBDevices();

            // Set USB port if saved
            if (config.default_usb_port) {
                document.getElementById('comlink-usb-port').value = config.default_usb_port;
            }
        }
    } catch (error) {
        console.error('Error loading Comlink settings:', error);
    }
}

async function updateComlinkUSBDevices() {
    try {
        const response = await fetch('/api/devices/serial');
        const devices = await response.json();
        
        const select = document.getElementById('comlink-usb-port');
        // Clear existing options except the first
        while (select.options.length > 1) {
            select.remove(1);
        }
        
        // Store devices data for later use
        select.devicesData = devices;
        
        // Add device options
        devices.forEach(device => {
            const option = document.createElement('option');
            option.value = device.unique_id;  // Use unique ID as value
            option.dataset.port = device.port; // Store port for display
            
            // Show more helpful info: port, name, and ID type
            let displayText = `${device.port} - ${device.name}`;
            if (device.id_type === 'serial') {
                displayText += ` (S/N: ${device.serial_number})`;
            } else if (device.id_type === 'usb_port') {
                displayText += ` (USB Port)`;
            }
            option.textContent = displayText;
            
            select.appendChild(option);
        });
    } catch (error) {
        console.error('Error loading USB devices:', error);
    }
}

function updateComlinkTarget() {
    const target = document.getElementById('comlink-default-target').value;
    const usbSettings = document.getElementById('comlink-usb-settings');
    const gpioSettings = document.getElementById('comlink-gpio-settings');
    
    if (target === 'usb') {
        usbSettings.classList.remove('hidden');
        gpioSettings.classList.add('hidden');
    } else {
        usbSettings.classList.add('hidden');
        gpioSettings.classList.remove('hidden');
    }
}

async function saveComlinkSettings() {
    const statusDiv = document.getElementById('comlink-enable-status');
    
    try {
        const select = document.getElementById('comlink-usb-port');
        const selectedUniqueId = select.value;
        
        const config = {
            enabled: document.getElementById('comlink-enabled-checkbox').checked,
            default_target: document.getElementById('comlink-default-target').value,
            default_gpio_pin: parseInt(document.getElementById('comlink-gpio-pin').value),
            default_baud_rate: parseInt(document.getElementById('comlink-baud-rate').value),
            add_cr_termination: document.getElementById('comlink-add-cr').checked
        };
        
        // If USB device is selected, save device info
        if (selectedUniqueId && select.devicesData) {
            const selectedDevice = select.devicesData.find(d => d.unique_id === selectedUniqueId);
            if (selectedDevice) {
                config.default_usb_device = {
                    unique_id: selectedDevice.unique_id,
                    name: selectedDevice.name,
                    last_known_port: selectedDevice.port
                };
            }
        } else {
            config.default_usb_device = null;
        }
        
        // Validate USB port selection if target is USB
        if (config.enabled && config.default_target === 'usb' && !config.default_usb_device) {
            showStatusMessage('Please select a USB device from the dropdown', 'error', 8000);
            return;
        }
        
        const response = await fetch('/api/comlink/config', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(config)
        });
        
        const result = await response.json();
        
        if (result.success) {
            showSuccess('Comlink settings saved successfully', statusDiv);
        } else {
            showStatusMessage('Failed to save settings: ' + result.error, statusDiv, 'error', 8000);
        }
    } catch (error) {
        showStatusMessage('Error: ' + error.message, statusDiv, 'error', 8000);
    }
}

// Comlink tab functions
async function loadComlinkStatus() {
    try {
        const response = await fetch('/api/comlink/status');
        const result = await response.json();
        
        if (result.success) {
            const status = result.status;
            
            // Update status display
            document.getElementById('comlink-service-status').textContent = 
                status.service_running ? 'Running' : 'Stopped';
            document.getElementById('comlink-service-status').className = 
                'status-value ' + (status.service_running ? 'status-active' : 'status-inactive');
            
            document.getElementById('comlink-device-name').textContent = status.device_name;
            document.getElementById('comlink-ip-address').textContent = status.ip_address || 'Not connected';
            document.getElementById('comlink-commands-received').textContent = status.commands_received || '0';
            
            // Update active devices - removed (section not fully functional)
            // updateComlinkDeviceList(status.active_devices || []);
        }
    } catch (error) {
        console.error('Error loading Comlink status:', error);
    }
}

// Removed - Active devices section was not fully functional
// function updateComlinkDeviceList(devices) {
//     const deviceList = document.getElementById('comlink-device-list');
//     
//     if (devices.length === 0) {
//         deviceList.innerHTML = '<div class="device-item">No active devices</div>';
//     } else {
//         deviceList.innerHTML = devices.map(device => `
//             <div class="device-item">
//                 <span class="device-name">${device.name}</span>
//                 <span class="device-info">${device.ip} - Last seen: ${formatTimestamp(device.last_seen)}</span>
//             </div>
//         `).join('');
//     }
// }

async function refreshComlinkHistory() {
    await loadComlinkHistory();
}

async function loadComlinkHistory() {
    try {
        const filter = document.getElementById('comlink-history-filter').value;
        const response = await fetch(`/api/comlink/history?filter=${filter}`);
        const result = await response.json();
        
        if (result.success) {
            const tbody = document.getElementById('comlink-history-body');
            
            if (result.history.length === 0) {
                tbody.innerHTML = '<tr><td colspan="5">No command history</td></tr>';
            } else {
                tbody.innerHTML = result.history.map(entry => `
                    <tr>
                        <td>${formatTimestamp(entry.timestamp)}</td>
                        <td>${entry.source}</td>
                        <td class="command-cell">${escapeHtml(entry.command)}</td>
                        <td>${entry.target}</td>
                        <td class="${entry.status === 'success' ? 'status-success' : 'status-error'}">${entry.status}</td>
                    </tr>
                `).join('');
            }
            
            // Update statistics
            updateComlinkStatistics(result.statistics);
        }
    } catch (error) {
        console.error('Error loading Comlink history:', error);
    }
}

function updateComlinkStatistics(stats) {
    document.getElementById('comlink-total-commands').textContent = stats.total_commands || '0';
    document.getElementById('comlink-commands-today').textContent = stats.commands_today || '0';
    document.getElementById('comlink-last-command-time').textContent = 
        stats.last_command_time ? formatTimestamp(stats.last_command_time) : 'Never';
    document.getElementById('comlink-unique-commands').textContent = stats.unique_commands || '0';
    
    // Update top commands
    const topCommandsDiv = document.getElementById('comlink-top-commands');
    if (stats.top_commands && stats.top_commands.length > 0) {
        topCommandsDiv.innerHTML = stats.top_commands.map(cmd => `
            <div class="command-item">
                <span class="command-text">${escapeHtml(cmd.command)}</span>
                <span class="command-count">${cmd.count} times</span>
            </div>
        `).join('');
    } else {
        topCommandsDiv.innerHTML = '<div class="command-item">No data available</div>';
    }
}

function filterComlinkHistory() {
    loadComlinkHistory();
}

async function clearComlinkHistory() {
    if (confirm('Are you sure you want to clear all command history? This cannot be undone.')) {
        try {
            const response = await fetch('/api/comlink/history', {
                method: 'DELETE'
            });
            
            const result = await response.json();
            
            if (result.success) {
                showSuccess('Command history cleared');
                await loadComlinkHistory();
            } else {
                showStatusMessage('Failed to clear history: ' + result.error, 'error', 8000);
            }
        } catch (error) {
            showStatusMessage('Error: ' + error.message, 'error', 8000);
        }
    }
}


// Format timestamp helper
function formatTimestamp(timestamp) {
    if (!timestamp) return 'Never';
    
    // Convert Unix timestamp (seconds) to milliseconds for JavaScript Date
    const date = new Date(timestamp * 1000);
    const now = new Date();
    const diffMs = now - date;
    const diffSecs = Math.floor(diffMs / 1000);
    
    if (diffSecs < 60) {
        return `${diffSecs}s ago`;
    } else if (diffSecs < 3600) {
        return `${Math.floor(diffSecs / 60)}m ago`;
    } else if (diffSecs < 86400) {
        return `${Math.floor(diffSecs / 3600)}h ago`;
    } else {
        return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
    }
}

// Export Comlink functions
window.toggleComlinkFeature = toggleComlinkFeature;
window.updateComlinkTarget = updateComlinkTarget;
window.saveComlinkSettings = saveComlinkSettings;
window.refreshComlinkHistory = refreshComlinkHistory;
window.filterComlinkHistory = filterComlinkHistory;
window.clearComlinkHistory = clearComlinkHistory;

async function loadComlinkConfig() {
    try {
        const response = await fetch('/api/comlink/config');
        const result = await response.json();
        
        if (result.success) {
            const config = result.config;
            
            // Update UI with config values
            document.getElementById('comlink-enabled-checkbox').checked = config.enabled;
            document.getElementById('comlink-default-target').value = config.default_target;
            document.getElementById('comlink-gpio-pin').value = config.default_gpio_pin;
            document.getElementById('comlink-baud-rate').value = config.default_baud_rate;
            document.getElementById('comlink-add-cr').checked = config.add_cr_termination !== false;
            
            // Load USB devices after config is loaded
            await updateComlinkUSBDevices();
            
            // Set the selected USB device if configured
            if (config.default_usb_device && config.default_usb_device.unique_id) {
                const usbSelect = document.getElementById('comlink-usb-port');
                if (usbSelect) {
                    usbSelect.value = config.default_usb_device.unique_id;
                }
            }
            
            // Update visibility of settings
            updateComlinkTargetSettings();
        }
    } catch (error) {
        console.error('Error loading Comlink config:', error);
    }
}

// Update visibility of Comlink target settings based on selected type
function updateComlinkTargetSettings() {
    // Reuse existing updateComlinkTarget function
    if (typeof updateComlinkTarget === 'function') {
        updateComlinkTarget();
    }
}



// Comlink auto-refresh
DroidNet.state.polling.comlinkRefreshInterval = null;

function startComlinkAutoRefresh() {
    // Stop any existing interval
    stopComlinkAutoRefresh();
    
    // Refresh every 2 seconds
    DroidNet.state.polling.comlinkRefreshInterval = setInterval(() => {
        loadComlinkStatus();  // This updates active devices and stats
        loadComlinkHistory(); // This updates the command history
    }, 2000);
}

function stopComlinkAutoRefresh() {
    if (DroidNet.state.polling.comlinkRefreshInterval) {
        clearInterval(DroidNet.state.polling.comlinkRefreshInterval);
        DroidNet.state.polling.comlinkRefreshInterval = null;
    }
}

// Maestro Config Functions
async function loadMaestroConfig() {
    try {
        const response = await fetch('/api/maestro/config');
        const result = await response.json();

        if (result.success) {
            const config = result.config;
            const disabledOverlay = document.getElementById('maestro-disabled-overlay');

            // Set checkbox state
            document.getElementById('maestro-enabled-checkbox').checked = config.enabled;

            // Show/hide Maestro tab based on enabled state
            const maestroTabBtn = document.getElementById('maestro-tab-btn');
            if (config.enabled) {
                maestroTabBtn.style.display = 'inline-block';
                if (disabledOverlay) {
                    disabledOverlay.style.display = 'none';
                }
                // Initialize Maestro interface
                if (typeof initMaestro === 'function') {
                    initMaestro();
                }
            } else {
                maestroTabBtn.style.display = 'none';
                if (disabledOverlay) {
                    disabledOverlay.style.display = 'flex';
                }
            }
        }
    } catch (error) {
        console.error('Error loading Maestro config:', error);
    }
}

async function toggleMaestroFeature() {
    const checkbox = document.getElementById('maestro-enabled-checkbox');
    const enabled = checkbox.checked;
    const statusDiv = document.getElementById('maestro-enable-status');

    try {
        const response = await fetch('/api/maestro/config', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ enabled: enabled })
        });

        const result = await response.json();

        if (result.success) {
            // Show/hide Maestro tab
            const maestroTabBtn = document.getElementById('maestro-tab-btn');
            const disabledOverlay = document.getElementById('maestro-disabled-overlay');

            if (enabled) {
                maestroTabBtn.style.display = 'inline-block';
                if (disabledOverlay) {
                    disabledOverlay.style.display = 'none';
                }
                showSuccess('Maestro feature enabled', statusDiv);
                // Initialize Maestro if function exists
                if (typeof initMaestro === 'function') {
                    initMaestro();
                }
            } else {
                maestroTabBtn.style.display = 'none';
                if (disabledOverlay) {
                    disabledOverlay.style.display = 'flex';
                }
                showSuccess('Maestro feature disabled', statusDiv);
            }
        } else {
            showStatusMessage(result.error || 'Failed to update Maestro settings', statusDiv, 'error', 8000);
            checkbox.checked = !enabled; // Revert checkbox
        }
    } catch (error) {
        console.error('Error toggling Maestro feature:', error);
        showStatusMessage('Failed to update Maestro settings', 'error', 8000);
        checkbox.checked = !enabled; // Revert checkbox
    }
}

async function loadVictronFeatureConfig() {
    try {
        const response = await fetch('/api/victron/feature-config');
        const result = await response.json();

        if (result.success) {
            const config = result.config;
            const disabledOverlay = document.getElementById('victron-disabled-overlay');

            // Set checkbox state
            document.getElementById('victron-enabled-checkbox').checked = config.enabled;

            // Show/hide Victron tab based on enabled state
            const victronTabBtn = document.getElementById('victron-tab-btn');
            if (config.enabled) {
                victronTabBtn.style.display = 'inline-block';
                if (disabledOverlay) {
                    disabledOverlay.style.display = 'none';
                }
            } else {
                victronTabBtn.style.display = 'none';
                if (disabledOverlay) {
                    disabledOverlay.style.display = 'flex';
                }
            }
        }
    } catch (error) {
        console.error('Error loading Victron feature config:', error);
    }
}

async function toggleVictronFeature() {
    const checkbox = document.getElementById('victron-enabled-checkbox');
    const enabled = checkbox.checked;
    const statusDiv = document.getElementById('victron-enable-status');

    try {
        const response = await fetch('/api/victron/feature-config', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ enabled: enabled })
        });

        const result = await response.json();

        if (result.success) {
            // Show/hide Victron tab
            const victronTabBtn = document.getElementById('victron-tab-btn');
            const disabledOverlay = document.getElementById('victron-disabled-overlay');

            if (enabled) {
                victronTabBtn.style.display = 'inline-block';
                if (disabledOverlay) {
                    disabledOverlay.style.display = 'none';
                }
                showSuccess('Victron feature enabled', statusDiv);
            } else {
                victronTabBtn.style.display = 'none';
                if (disabledOverlay) {
                    disabledOverlay.style.display = 'flex';
                }
                showSuccess('Victron feature disabled', statusDiv);
            }
        } else {
            showStatusMessage(result.error || 'Failed to update Victron settings', statusDiv, 'error', 8000);
            checkbox.checked = !enabled; // Revert checkbox
        }
    } catch (error) {
        console.error('Error toggling Victron feature:', error);
        showStatusMessage('Failed to update Victron settings', statusDiv, 'error', 8000);
        checkbox.checked = !enabled; // Revert checkbox
    }
}

// Resize Handle Functionality
function initializeResizeHandles() {
    // Remove old handlers first to prevent memory leaks
    if (resizeMouseMoveHandler) {
        document.removeEventListener('mousemove', resizeMouseMoveHandler);
    }
    if (resizeMouseUpHandler) {
        document.removeEventListener('mouseup', resizeMouseUpHandler);
    }

    const handles = document.querySelectorAll('.resize-handle');

    // Shared state for resize operation
    let isResizing = false;
    let startY = 0;
    let startHeight = 0;
    let targetElement = null;
    let activeHandle = null;

    // Define the mousedown handler that will be reused
    const mousedownHandler = (e) => {
        isResizing = true;
        startY = e.clientY;
        const targetId = e.currentTarget.getAttribute('data-target');
        targetElement = document.getElementById(targetId);
        startHeight = targetElement.offsetHeight;
        activeHandle = e.currentTarget;

        // Prevent text selection during drag
        document.body.style.userSelect = 'none';
        document.body.style.cursor = 'ns-resize';

        // Add active class for visual feedback
        e.currentTarget.classList.add('active');
    };

    // Define new handlers
    resizeMouseMoveHandler = (e) => {
        if (!isResizing || !targetElement) return;

        const deltaY = e.clientY - startY;
        const newHeight = startHeight + deltaY;

        // Set min/max heights based on target
        const minHeight = 100;
        const maxHeight = targetElement.id === 'wcb-serial-output' ? 400 : 500;

        if (newHeight >= minHeight && newHeight <= maxHeight) {
            targetElement.style.height = newHeight + 'px';

            // Save preference to localStorage
            localStorage.setItem(`${targetElement.id}-height`, newHeight);
        }
    };

    resizeMouseUpHandler = () => {
        if (isResizing) {
            isResizing = false;
            document.body.style.userSelect = '';
            document.body.style.cursor = '';
            if (activeHandle) {
                activeHandle.classList.remove('active');
                activeHandle = null;
            }
        }
    };

    // Add new handlers to document
    document.addEventListener('mousemove', resizeMouseMoveHandler);
    document.addEventListener('mouseup', resizeMouseUpHandler);

    // Remove old mousedown listeners and add new ones
    handles.forEach(handle => {
        // Remove any existing mousedown listeners by replacing the element with a clone
        // This is necessary because we can't track anonymous function references
        const newHandle = handle.cloneNode(true);
        handle.parentNode.replaceChild(newHandle, handle);

        // Add the mousedown listener to the new (clean) element
        newHandle.addEventListener('mousedown', mousedownHandler);
    });
    
    // Restore saved heights
    const serialOutput = document.getElementById('serial-output');
    const wcbSerialOutput = document.getElementById('wcb-serial-output');
    
    if (serialOutput) {
        const savedHeight = localStorage.getItem('serial-output-height');
        if (savedHeight) {
            serialOutput.style.height = savedHeight + 'px';
        }
    }
    
    if (wcbSerialOutput) {
        const savedHeight = localStorage.getItem('wcb-serial-output-height');
        if (savedHeight) {
            wcbSerialOutput.style.height = savedHeight + 'px';
        }
    }
}

// Initialize resize handles when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeResizeHandles);
} else {
    initializeResizeHandles();
}

// Fallback Mode Functions
async function makePermanentAP() {
    if (!confirm('Make AP mode permanent? The device will stay in AP mode on future boots.')) {
        return;
    }
    
    try {
        const response = await fetch('/api/wifi/make-permanent-ap', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        
        const result = await response.json();
        
        if (result.success) {
            showMessage(result.message);
            // Hide the fallback notice
            document.getElementById('fallback-notice').style.display = 'none';
            // Update status
            updateSystemStatus();
        } else {
            showMessage(result.error || 'Failed to make AP mode permanent', 'error');
        }
    } catch (error) {
        console.error('Error making AP permanent:', error);
        showMessage('Failed to make AP mode permanent', 'error');
    }
}

async function retryClient() {
    if (!confirm('Retry WiFi connection? The device will restart and attempt to connect to saved networks.')) {
        return;
    }
    
    try {
        const response = await fetch('/api/wifi/retry-client', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        
        const result = await response.json();
        
        if (result.success) {
            showMessage(result.message);
            // Device will restart - show a longer message
            showMessage('Device is restarting. You may need to reconnect in a few moments.', 'info');
        } else {
            showMessage(result.error || 'Failed to retry client mode', 'error');
        }
    } catch (error) {
        console.error('Error retrying client mode:', error);
        showMessage('Failed to retry client mode', 'error');
    }
}

// ============================================================================
// Display Video Management Functions
// ============================================================================

DroidNet.state.display.status = null;

async function loadDisplayStatus() {
    try {
        const response = await fetch('/api/display/status');
        const data = await response.json();

        if (data.success) {
            DroidNet.state.display.status = data;

            // Update status display
            const supportedEl = document.getElementById('display-supported');
            if (supportedEl) {
                supportedEl.textContent = data.supported ? 'Supported' : 'Not Supported';
                supportedEl.className = `status-value ${data.supported ? 'connected' : 'disconnected'}`;
            }

            const modelEl = document.getElementById('display-pi-model');
            if (modelEl) {
                modelEl.textContent = data.pi_model || 'Unknown';
            }

            const playerEl = document.getElementById('display-player-status');
            if (playerEl) {
                const hasPlayer = data.players && data.players.any;
                playerEl.textContent = hasPlayer ? 'Available' : 'Not Available';
                playerEl.className = `status-value ${hasPlayer ? 'connected' : 'disconnected'}`;
            }

            const hdmiEl = document.getElementById('display-hdmi-power');
            if (hdmiEl) {
                hdmiEl.textContent = data.hdmi_power || 'Unknown';
            }

            const countEl = document.getElementById('display-video-count');
            if (countEl) {
                countEl.textContent = data.video_count || 0;
            }

            // Show tab if supported
            if (data.supported) {
                const tabBtn = document.getElementById('display-tab-btn');
                if (tabBtn) {
                    tabBtn.style.display = 'inline-block';
                }
            }

            // Load video library
            await refreshDisplayVideos();
        }
    } catch (error) {
        console.error('Error loading display status:', error);
    }
}

async function refreshDisplayVideos() {
    try {
        const response = await fetch('/api/display/status');
        const data = await response.json();

        if (data.success) {
            const library = document.getElementById('display-video-library');
            if (!library) return;

            if (!data.videos || data.videos.length === 0) {
                library.innerHTML = '<div class="video-item">No videos uploaded yet</div>';
                return;
            }

            library.innerHTML = data.videos.map(video => {
                const sizeMB = (video.size / (1024 * 1024)).toFixed(2);
                const date = new Date(video.modified * 1000).toLocaleString();
                return `
                    <div class="video-item">
                        <div class="video-info">
                            <div class="video-name">${video.name}</div>
                            <div class="video-meta">
                                <span>${sizeMB} MB</span>
                                <span>${date}</span>
                            </div>
                        </div>
                        <div class="video-actions">
                            <button onclick="playDisplayVideo('${video.name}')" class="btn btn-primary btn-small">Play</button>
                            <button onclick="pauseDisplayVideo()" class="btn btn-secondary btn-small">Pause</button>
                            <button onclick="stopDisplayVideo()" class="btn btn-warning btn-small">Stop</button>
                            <button onclick="deleteDisplayVideo('${video.name}')" class="btn btn-danger btn-small">Delete</button>
                        </div>
                    </div>
                `;
            }).join('');
        }
    } catch (error) {
        console.error('Error refreshing videos:', error);
        showMessage('Failed to load videos', 'error');
    }
}

async function uploadDisplayVideo() {
    const fileInput = document.getElementById('display-video-file');
    const file = fileInput.files[0];

    if (!file) {
        showMessage('Please select a video file', 'error');
        return;
    }

    // Check if feature is supported
    if (!DroidNet.state.display.status || !DroidNet.state.display.status.supported) {
        showMessage('Display feature not supported on this Pi model', 'error');
        return;
    }

    // Show progress
    const progressSection = document.getElementById('display-upload-progress');
    const progressFill = document.getElementById('display-progress-fill');
    const statusText = document.getElementById('display-upload-status-text');
    const uploadBtn = document.getElementById('display-upload-btn');

    if (progressSection) progressSection.classList.remove('hidden');
    if (uploadBtn) uploadBtn.disabled = true;

    try {
        // Create form data
        const formData = new FormData();
        formData.append('video_file', file);

        // Upload with progress tracking
        const xhr = new XMLHttpRequest();

        xhr.upload.addEventListener('progress', (e) => {
            if (e.lengthComputable) {
                const percent = (e.loaded / e.total) * 100;
                if (progressFill) {
                    progressFill.style.width = percent + '%';
                }
                if (statusText) {
                    statusText.textContent = `Uploading... ${percent.toFixed(0)}%`;
                }
            }
        });

        xhr.addEventListener('load', async () => {
            if (progressSection) progressSection.classList.add('hidden');
            if (uploadBtn) uploadBtn.disabled = false;

            if (xhr.status === 200) {
                const result = JSON.parse(xhr.responseText);
                if (result.success) {
                    showMessage(result.message, 'success');
                    fileInput.value = '';
                    await refreshDisplayVideos();
                } else {
                    showMessage(result.error || 'Upload failed', 'error');
                }
            } else {
                showMessage('Upload failed', 'error');
            }
        });

        xhr.addEventListener('error', () => {
            if (progressSection) progressSection.classList.add('hidden');
            if (uploadBtn) uploadBtn.disabled = false;
            showMessage('Upload failed', 'error');
        });

        xhr.open('POST', '/api/display/upload');
        xhr.send(formData);

    } catch (error) {
        console.error('Error uploading video:', error);
        showMessage('Upload failed', 'error');
        if (progressSection) progressSection.classList.add('hidden');
        if (uploadBtn) uploadBtn.disabled = false;
    }
}

async function playDisplayVideo(videoName) {
    try {
        const response = await fetch('/api/display/play', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ video: videoName })
        });

        const result = await response.json();

        if (result.success) {
            showMessage(result.message, 'success');
        } else {
            showMessage(result.error || 'Playback failed', 'error');
        }
    } catch (error) {
        console.error('Error playing video:', error);
        showMessage('Playback failed', 'error');
    }
}

async function pauseDisplayVideo() {
    try {
        const response = await fetch('/api/display/pause', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        const result = await response.json();

        if (result.success) {
            showMessage('Video paused', 'success');
        } else {
            showMessage(result.error || 'Pause failed', 'error');
        }
    } catch (error) {
        console.error('Error pausing video:', error);
        showMessage('Pause failed', 'error');
    }
}

async function resumeDisplayVideo() {
    try {
        const response = await fetch('/api/display/resume', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        const result = await response.json();

        if (result.success) {
            showMessage('Video resumed', 'success');
        } else {
            showMessage(result.error || 'Resume failed', 'error');
        }
    } catch (error) {
        console.error('Error resuming video:', error);
        showMessage('Resume failed', 'error');
    }
}

async function stopDisplayVideo() {
    try {
        const response = await fetch('/api/display/stop', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        const result = await response.json();

        if (result.success) {
            showMessage('Video stopped', 'success');
        } else {
            showMessage(result.error || 'Stop failed', 'error');
        }
    } catch (error) {
        console.error('Error stopping video:', error);
        showMessage('Stop failed', 'error');
    }
}

async function deleteDisplayVideo(videoName) {
    if (!confirm(`Delete video "${videoName}"?`)) {
        return;
    }

    try {
        const response = await fetch(`/api/display/video/${encodeURIComponent(videoName)}`, {
            method: 'DELETE'
        });

        const result = await response.json();

        if (result.success) {
            showMessage(result.message, 'success');
            await refreshDisplayVideos();
        } else {
            showMessage(result.error || 'Delete failed', 'error');
        }
    } catch (error) {
        console.error('Error deleting video:', error);
        showMessage('Delete failed', 'error');
    }
}

async function runDisplayDiagnostics() {
    const output = document.getElementById('display-diagnostics-output');
    const text = document.getElementById('display-diagnostics-text');

    if (!output || !text) return;

    output.classList.remove('hidden');
    text.textContent = 'Running diagnostics...';

    try {
        const response = await fetch('/api/display/diagnostics');
        const data = await response.json();

        if (data.success) {
            text.textContent = JSON.stringify(data.diagnostics, null, 2);
        } else {
            text.textContent = `Error: ${data.error}`;
        }
    } catch (error) {
        console.error('Error running diagnostics:', error);
        text.textContent = `Error: ${error.message}`;
    }
}

function clearDisplayDiagnostics() {
    const output = document.getElementById('display-diagnostics-output');
    const text = document.getElementById('display-diagnostics-text');

    if (output) output.classList.add('hidden');
    if (text) text.textContent = '';
}

// Initialize Display tab when it's shown
function initDisplayTab() {
    if (DroidNet.state.display.status === null) {
        loadDisplayStatus();
    }
    if (DroidNet.state.display.imageStatus === null) {
        loadImageStatus();
    }
}

// ============================================
// Image Display Functions
// ============================================

DroidNet.state.display.imageStatus = null;

async function loadImageStatus() {
    try {
        const response = await fetch('/api/display/images/status');
        const data = await response.json();

        if (data.success) {
            DroidNet.state.display.imageStatus = data;

            // Update image count
            const countEl = document.getElementById('image-count');
            if (countEl) countEl.textContent = data.image_count || 0;

            // Update current image
            const currentEl = document.getElementById('current-image');
            if (currentEl) {
                currentEl.textContent = data.current_image || 'None';
                if (data.current_image) {
                    currentEl.classList.add('status-active');
                } else {
                    currentEl.classList.remove('status-active');
                }
            }

            // Refresh image library
            refreshDisplayImages();
        }
    } catch (error) {
        console.error('Error loading image status:', error);
    }
}

async function refreshDisplayImages() {
    const library = document.getElementById('display-image-library');
    if (!library) return;

    try {
        const response = await fetch('/api/display/images/status');
        const data = await response.json();

        if (data.success && data.images) {
            if (data.images.length === 0) {
                library.innerHTML = '<div class="image-item">No images uploaded yet</div>';
            } else {
                library.innerHTML = data.images.map(image => `
                    <div class="image-item">
                        <div class="image-info">
                            <div class="image-name">${escapeHtml(image.name)}</div>
                            <div class="image-meta">
                                ${DroidNet.utils.formatBytes(image.size)} •
                                ${new Date(image.modified * 1000).toLocaleDateString()}
                            </div>
                        </div>
                        <div class="image-actions">
                            <button onclick="showDisplayImage('${escapeHtml(image.name)}')" class="btn btn-primary btn-sm">Show</button>
                            <button onclick="hideDisplayImage()" class="btn btn-secondary btn-sm">Hide</button>
                            <button onclick="deleteDisplayImage('${escapeHtml(image.name)}')" class="btn btn-danger btn-sm">Delete</button>
                        </div>
                    </div>
                `).join('');
            }
        } else {
            library.innerHTML = '<div class="image-item error">Failed to load images</div>';
        }
    } catch (error) {
        console.error('Error refreshing images:', error);
        library.innerHTML = '<div class="image-item error">Error loading images</div>';
    }
}

async function uploadDisplayImage() {
    const fileInput = document.getElementById('display-image-file');
    const uploadBtn = document.getElementById('display-image-upload-btn');
    const statusDiv = document.getElementById('display-image-upload-status');
    const progressDiv = document.getElementById('display-image-upload-progress');
    const progressFill = document.getElementById('display-image-progress-fill');
    const statusText = document.getElementById('display-image-upload-status-text');

    if (!fileInput.files || fileInput.files.length === 0) {
        showStatus(statusDiv, 'Please select an image file first', 'error');
        return;
    }

    const file = fileInput.files[0];
    const formData = new FormData();
    formData.append('image_file', file);

    try {
        // Disable upload button and show progress
        if (uploadBtn) uploadBtn.disabled = true;
        if (statusDiv) statusDiv.classList.add('hidden');
        if (progressDiv) progressDiv.classList.remove('hidden');
        if (progressFill) progressFill.style.width = '0%';
        if (statusText) statusText.textContent = 'Uploading...';

        // Create XMLHttpRequest for progress tracking
        const xhr = new XMLHttpRequest();

        xhr.upload.addEventListener('progress', (e) => {
            if (e.lengthComputable) {
                const percentComplete = (e.loaded / e.total) * 100;
                if (progressFill) progressFill.style.width = percentComplete + '%';
                if (statusText) statusText.textContent = `Uploading... ${Math.round(percentComplete)}%`;
            }
        });

        const uploadPromise = new Promise((resolve, reject) => {
            xhr.addEventListener('load', () => {
                if (xhr.status >= 200 && xhr.status < 300) {
                    resolve(JSON.parse(xhr.responseText));
                } else {
                    reject(new Error('Upload failed'));
                }
            });
            xhr.addEventListener('error', () => reject(new Error('Upload failed')));
            xhr.open('POST', '/api/display/images/upload');
            xhr.send(formData);
        });

        const data = await uploadPromise;

        if (data.success) {
            showStatus(statusDiv, data.message || 'Image uploaded successfully!', 'success');
            fileInput.value = '';
            refreshDisplayImages();
            loadImageStatus();
        } else {
            showStatus(statusDiv, data.error || 'Upload failed', 'error');
        }
    } catch (error) {
        console.error('Upload error:', error);
        showStatus(statusDiv, 'Upload failed: ' + error.message, 'error');
    } finally {
        if (uploadBtn) uploadBtn.disabled = false;
        if (progressDiv) progressDiv.classList.add('hidden');
    }
}

async function showDisplayImage(imageName) {
    try {
        const response = await fetch('/api/display/images/show', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ image: imageName })
        });

        const data = await response.json();

        if (data.success) {
            console.log('Image displayed:', imageName);
            loadImageStatus();
        } else {
            showStatusMessage('Failed to display image: ' + (data.error || 'Unknown error'), 'error');
        }
    } catch (error) {
        console.error('Error showing image:', error);
        showStatusMessage('Error displaying image: ' + error.message, 'error');
    }
}

async function hideDisplayImage() {
    try {
        const response = await fetch('/api/display/images/hide', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        });

        const data = await response.json();

        if (data.success) {
            console.log('Image hidden');
            loadImageStatus();
        } else {
            showStatusMessage('Failed to hide image: ' + (data.error || 'Unknown error'), 'error');
        }
    } catch (error) {
        console.error('Error hiding image:', error);
        showStatusMessage('Error hiding image: ' + error.message, 'error');
    }
}

async function deleteDisplayImage(imageName) {
    if (!confirm(`Are you sure you want to delete "${imageName}"?`)) {
        return;
    }

    try {
        const response = await fetch(`/api/display/images/${encodeURIComponent(imageName)}`, {
            method: 'DELETE'
        });

        const data = await response.json();

        if (data.success) {
            console.log('Image deleted:', imageName);
            refreshDisplayImages();
            loadImageStatus();
        } else {
            showStatusMessage('Failed to delete image: ' + (data.error || 'Unknown error'), 'error');
        }
    } catch (error) {
        console.error('Error deleting image:', error);
        showStatusMessage('Error deleting image: ' + error.message, 'error');
    }
}

async function runImageDiagnostics() {
    const output = document.getElementById('display-diagnostics-output');
    const text = document.getElementById('display-diagnostics-text');

    if (!output || !text) return;

    try {
        text.textContent = 'Running image diagnostics...\n';
        output.classList.remove('hidden');

        const response = await fetch('/api/display/images/diagnostics');
        const data = await response.json();

        if (data.success) {
            const diag = data.diagnostics;
            let output_text = '=== Image Display Diagnostics ===\n\n';

            output_text += `Pi Model: ${diag.pi_model || 'unknown'}\n`;
            output_text += `Supported: ${diag.supported ? 'Yes' : 'No'}\n`;
            output_text += `ffmpeg Available: ${diag.ffmpeg_available ? 'Yes' : 'No'}\n`;
            output_text += `vcgencmd Available: ${diag.vcgencmd_available ? 'Yes' : 'No'}\n`;
            output_text += `HDMI Available: ${diag.hdmi_available ? 'Yes' : 'No'}\n`;
            output_text += `HDMI Status: ${diag.hdmi_status || 'unknown'}\n\n`;

            output_text += `Image Directory: ${diag.image_dir || 'unknown'}\n`;
            output_text += `Directory Exists: ${diag.image_dir_exists ? 'Yes' : 'No'}\n`;
            output_text += `Directory Writable: ${diag.image_dir_writable ? 'Yes' : 'No'}\n`;
            output_text += `Disk Space Free: ${diag.disk_space_free_mb ? Math.round(diag.disk_space_free_mb) + ' MB' : 'unknown'}\n\n`;

            output_text += `Image Display Script Exists: ${diag.image_display_script_exists ? 'Yes' : 'No'}\n`;
            output_text += `Image Display Script Executable: ${diag.image_display_script_executable ? 'Yes' : 'No'}\n`;
            output_text += `Image Control Script Exists: ${diag.image_control_script_exists ? 'Yes' : 'No'}\n`;
            output_text += `Image Control Script Executable: ${diag.image_control_script_executable ? 'Yes' : 'No'}\n\n`;

            if (diag.recent_log_entries && diag.recent_log_entries.length > 0) {
                output_text += '=== Recent Log Entries ===\n';
                output_text += diag.recent_log_entries.join('');
            }

            text.textContent = output_text;
        } else {
            text.textContent = 'Error: ' + (data.error || 'Unknown error');
        }
    } catch (error) {
        console.error('Diagnostics error:', error);
        text.textContent = 'Error running diagnostics: ' + error.message;
    }
}

// Helper function for status messages
function showStatus(element, message, type) {
    if (!element) return;
    element.textContent = message;
    element.className = 'status-message ' + type;
    element.classList.remove('hidden');
    setTimeout(() => element.classList.add('hidden'), 5000);
}

// ============================================
// Phase 4: Serial Architecture UI Features
// ============================================

// Health Widget and Status Monitoring
DroidNet.state.polling.healthCheckInterval = null;
DroidNet.state.polling.wcbPollingInterval = null;
DroidNet.state.ui.eventLogMaxItems = 100;

// Hardware-adaptive intervals for WCB/health polling
const WCB_POLL_INTERVALS = {
    'pi_zero_w': 15000,  // 15 seconds
    'pi_zero_2': 10000,  // 10 seconds
    'pi_3': 5000,        // 5 seconds
    'pi_4': 5000,        // 5 seconds
    'unknown': 10000     // Safe default
};

function getWCBPollInterval() {
    const model = DroidNet.state.hardware.piModel || 'unknown';
    return WCB_POLL_INTERVALS[model] || WCB_POLL_INTERVALS['unknown'];
}

function initPhase4UI() {
    // Wait for pi_model detection before starting pollers
    // Use polling to check for pi_model, with max wait of 5 seconds
    let attempts = 0;
    const maxAttempts = 25;  // 25 * 200ms = 5 seconds max wait

    function startPollers() {
        // Start health monitoring
        startHealthMonitoring();

        // Load WCB listener status
        loadWCBListenerStatus();

        // Set up periodic updates - hardware-adaptive
        const wcbInterval = getWCBPollInterval();
        console.log('WCB: Starting polling at ' + wcbInterval + 'ms interval (pi_model: ' + (DroidNet.state.hardware.piModel || 'unknown') + ')');
        DroidNet.state.polling.wcbPollingInterval = setInterval(loadWCBListenerStatus, wcbInterval);
    }

    function waitForPiModel() {
        attempts++;
        if (DroidNet.state.hardware.piModel) {
            console.log('Pi model ready after ' + (attempts * 200) + 'ms, starting pollers');
            startPollers();
        } else if (attempts >= maxAttempts) {
            console.log('Pi model detection timeout, starting with defaults');
            startPollers();
        } else {
            setTimeout(waitForPiModel, 200);
        }
    }

    // Start waiting for pi_model
    setTimeout(waitForPiModel, 200);
}

function startHealthMonitoring() {
    updateHealthStatus();
    // Health check interval: 2x the WCB interval (less critical)
    const healthInterval = getWCBPollInterval() * 2;
    console.log('Health: Starting polling at ' + healthInterval + 'ms interval');
    DroidNet.state.polling.healthCheckInterval = setInterval(updateHealthStatus, healthInterval);
}

async function updateHealthStatus() {
    // Get elements first - they may not exist on non-dashboard tabs
    const healthStatus = document.getElementById('health-status');
    const healthText = document.getElementById('health-text');

    // Skip update if elements don't exist (not on dashboard tab)
    if (!healthStatus || !healthText) {
        return;
    }

    try {
        // Check WCB listeners
        const listenersResp = await fetch('/api/wcb/listeners');
        if (!listenersResp.ok) {
            throw new Error(`HTTP error ${listenersResp.status}`);
        }
        const listenersData = await listenersResp.json();

        const activeListeners = listenersData.listeners?.filter(l => l.connected).length || 0;
        const totalListeners = listenersData.listeners?.length || 0;

        if (listenersData.success) {
            if (activeListeners === totalListeners && totalListeners > 0) {
                healthStatus.className = 'health-status ok';
                healthStatus.textContent = '⚡';
                healthText.textContent = 'System OK (' + activeListeners + '/' + totalListeners + ')';
            } else if (activeListeners > 0) {
                healthStatus.className = 'health-status warning';
                healthStatus.textContent = '⚠';
                healthText.textContent = activeListeners + '/' + totalListeners + ' Active';
            } else {
                healthStatus.className = 'health-status';
                healthStatus.textContent = '○';
                healthText.textContent = 'No listeners';
            }
        }

        // Update health details panel
        updatePortStatusList(listenersData.listeners || []);
        updateWCBListenerStatusInPanel(listenersData.listeners || []);

    } catch (error) {
        console.error('Health check failed:', error);
        healthStatus.className = 'health-status error';
        healthStatus.textContent = '⚠';
        healthText.textContent = 'Check Failed';
    }
}

function toggleHealthDetails() {
    const panel = document.getElementById('health-details');
    if (panel.style.display === 'none' || !panel.style.display) {
        panel.style.display = 'block';
        updateHealthStatus(); // Refresh on open
    } else {
        panel.style.display = 'none';
    }
}

// Close health panel when clicking outside
document.addEventListener('click', (e) => {
    const widget = document.getElementById('health-widget');
    const panel = document.getElementById('health-details');
    if (widget && panel && !widget.contains(e.target) && !panel.contains(e.target)) {
        panel.style.display = 'none';
    }
});

function updatePortStatusList(listeners) {
    const container = document.getElementById('port-status-list');
    if (!container) return;

    if (listeners.length === 0) {
        container.innerHTML = '<div class="status-item">No active ports</div>';
        return;
    }

    container.innerHTML = listeners.map(listener => '<div class="status-item ' + (listener.connected ? 'connected' : 'disconnected') + '"><div><div class="port-name">' + listener.port + '</div><div class="port-details">' + listener.baud + ' baud • ' + DroidNet.utils.formatBytes(listener.bytes_received) + ' received</div></div><span class="status-indicator">' + (listener.connected ? 'Connected' : 'Disconnected') + '</span></div>').join('');
}

function updateWCBListenerStatusInPanel(listeners) {
    const container = document.getElementById('wcb-listener-status');
    if (!container) return;

    if (listeners.length === 0) {
        container.innerHTML = '<div class="status-item">No active listeners</div>';
        return;
    }

    container.innerHTML = listeners.map(listener => '<div class="status-item ' + (listener.connected ? 'connected' : 'disconnected') + '"><div><div class="port-name">' + listener.port + '</div><div class="port-details">Uptime: ' + DroidNet.utils.formatUptime(listener.uptime_seconds) + '</div></div><span class="status-indicator">' + (listener.connected ? 'Active' : 'Inactive') + '</span></div>').join('');
}

// WCB Listener Status Grid
async function loadWCBListenerStatus() {
    try {
        const response = await fetch('/api/wcb/listeners');
        const data = await response.json();

        if (data.success && data.listeners) {
            displayWCBListeners(data.listeners);
        }
    } catch (error) {
        console.error('Failed to load WCB listener status:', error);
        addEventLog('error', 'Failed to load listener status');
    }
}

function displayWCBListeners(listeners) {
    const container = document.getElementById('wcb-listeners-grid');
    if (!container) return;

    if (listeners.length === 0) {
        container.innerHTML = '<div class="listener-card"><div class="listener-info">No WCB listeners configured. Listeners will appear here when started.</div></div>';
        return;
    }

    container.innerHTML = listeners.map(listener => '<div class="listener-card ' + (listener.connected ? 'active' : 'error') + '"><div class="listener-header"><span class="listener-port">' + listener.port + '</span><span class="listener-badge ' + (listener.connected ? 'active' : 'inactive') + '">' + (listener.connected ? 'Active' : 'Inactive') + '</span></div><div class="listener-stats"><div class="listener-stat"><strong>' + listener.baud + '</strong>Baud Rate</div><div class="listener-stat"><strong>' + DroidNet.utils.formatUptime(listener.uptime_seconds) + '</strong>Uptime</div><div class="listener-stat"><strong>' + DroidNet.utils.formatBytes(listener.bytes_sent) + '</strong>Sent</div><div class="listener-stat"><strong>' + DroidNet.utils.formatBytes(listener.bytes_received) + '</strong>Received</div></div><div class="listener-actions">' + (listener.connected ? '<button class="btn-stop" onclick="stopWCBListener(\'' + listener.port + '\')">Stop</button>' : '<button class="btn-start" onclick="startWCBListener(\'' + listener.port + '\', ' + listener.baud + ')">Start</button>') + '</div></div>').join('');
}

async function stopWCBListener(port) {
    try {
        const response = await fetch('/api/wcb/listener/stop', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ port })
        });

        const data = await response.json();
        if (data.success) {
            addEventLog('success', 'Stopped listener on ' + port);
            loadWCBListenerStatus();
        } else {
            addEventLog('error', 'Failed to stop ' + port + ': ' + data.message);
        }
    } catch (error) {
        addEventLog('error', 'Error stopping ' + port + ': ' + error.message);
    }
}

async function startWCBListener(port, baud) {
    try {
        const response = await fetch('/api/wcb/listener/start', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ port, baud })
        });

        const data = await response.json();
        if (data.success) {
            addEventLog('success', 'Started listener on ' + port);
            loadWCBListenerStatus();
        } else {
            addEventLog('error', 'Failed to start ' + port + ': ' + data.message);
        }
    } catch (error) {
        addEventLog('error', 'Error starting ' + port + ': ' + error.message);
    }
}

// WCB Event Log
function addEventLog(type, message) {
    const log = document.getElementById('wcb-event-log');
    if (!log) return;

    const timestamp = new Date().toLocaleTimeString();
    const item = document.createElement('div');
    item.className = 'event-item ' + type;
    item.innerHTML = '<span class="timestamp">' + timestamp + '</span><span class="event-type">[' + type.toUpperCase() + ']</span>' + message;

    log.appendChild(item);

    // Limit log size
    while (log.children.length > DroidNet.state.ui.eventLogMaxItems) {
        log.removeChild(log.firstChild);
    }

    // Auto-scroll if enabled
    const autoScroll = document.getElementById('auto-scroll-events');
    if (autoScroll && autoScroll.checked) {
        log.scrollTop = log.scrollHeight;
    }
}

function clearEventLog() {
    const log = document.getElementById('wcb-event-log');
    if (log) {
        log.innerHTML = '<div class="event-item info">Event log cleared</div>';
    }
}

// Initialize Phase 4 UI when page loads
document.addEventListener('DOMContentLoaded', function() {
    initPhase4UI();
    console.log('Phase 4 UI initialized');
});

console.log('Phase 4 Serial Architecture UI loaded');
// Add Listener Dialog Functions
async function showAddListenerDialog() {
    const dialog = document.getElementById('add-listener-dialog');
    const overlay = document.getElementById('add-listener-overlay');
    
    if (!dialog || !overlay) return;
    
    // Load available devices
    await loadAvailableWCBDevices();
    
    dialog.classList.add('active');
    overlay.classList.add('active');
}

function hideAddListenerDialog() {
    const dialog = document.getElementById('add-listener-dialog');
    const overlay = document.getElementById('add-listener-overlay');
    
    if (dialog) dialog.classList.remove('active');
    if (overlay) overlay.classList.remove('active');
}

async function loadAvailableWCBDevices() {
    try {
        const response = await fetch('/api/devices');
        const data = await response.json();

        const portSelect = document.getElementById('new-listener-port');
        if (!portSelect) return;

        // Filter for serial devices (those with serial_port property)
        // API returns array directly, not {devices: [...]}
        const serialDevices = data.filter(d => d.serial_port !== null);

        if (serialDevices.length === 0) {
            portSelect.innerHTML = '<option value="">No serial devices found</option>';
            return;
        }

        portSelect.innerHTML = '<option value="">Select a device...</option>' +
            serialDevices.map(device => {
                const label = device.name || device.type;
                return '<option value="' + device.serial_port + '">' +
                       device.serial_port + ' (' + label + ')</option>';
            }).join('');
            
    } catch (error) {
        console.error('Failed to load devices:', error);
        const portSelect = document.getElementById('new-listener-port');
        if (portSelect) {
            portSelect.innerHTML = '<option value="">Error loading devices</option>';
        }
    }
}

async function addNewListener() {
    const portSelect = document.getElementById('new-listener-port');
    const baudSelect = document.getElementById('new-listener-baud');
    
    if (!portSelect || !baudSelect) return;
    
    const port = portSelect.value;
    const baud = parseInt(baudSelect.value);
    
    if (!port) {
        addEventLog('error', 'Please select a device');
        return;
    }
    
    hideAddListenerDialog();
    addEventLog('info', 'Starting listener on ' + port + ' at ' + baud + ' baud...');
    
    try {
        const response = await fetch('/api/wcb/listener/start', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ port: port, baud: baud })
        });
        
        const data = await response.json();
        if (data.success) {
            addEventLog('success', 'Listener started on ' + port);
            loadWCBListenerStatus();
        } else {
            addEventLog('error', 'Failed to start listener: ' + data.message);
        }
    } catch (error) {
        addEventLog('error', 'Error starting listener: ' + error.message);
    }
}

// Close dialog when clicking overlay
document.addEventListener('click', function(e) {
    const overlay = document.getElementById('add-listener-overlay');
    if (overlay && e.target === overlay) {
        hideAddListenerDialog();
    }
});

console.log('Add Listener dialog functions loaded');

// ============================================================================
// VICTRON SMART SHUNT BLE MONITORING
// ============================================================================

// Global state
DroidNet.state.victron.charts = {};
DroidNet.state.polling.victronPollingInterval = null;
DroidNet.state.polling.victronChartPollingInterval = null;
DroidNet.state.victron.chartRange = 3600; // Default: 1 hour

// Hardware-adaptive polling intervals for Victron
const VICTRON_POLL_INTERVALS = {
    'pi_zero_w': { telemetry: 10000, charts: 60000 },  // 10s telemetry, 60s charts
    'pi_zero_2': { telemetry: 5000, charts: 30000 },   // 5s telemetry, 30s charts
    'pi_3': { telemetry: 3000, charts: 15000 },        // 3s telemetry, 15s charts
    'pi_4': { telemetry: 2000, charts: 10000 },        // 2s telemetry, 10s charts
    'unknown': { telemetry: 5000, charts: 30000 }      // Safe defaults
};

function getVictronIntervals() {
    const model = DroidNet.state.hardware.piModel || 'unknown';
    return VICTRON_POLL_INTERVALS[model] || VICTRON_POLL_INTERVALS['unknown'];
}

/**
 * Initialize Victron tab on page load
 */
async function initVictron() {
    await loadVictronConfig();
}

/**
 * Load Victron configuration and update UI
 */
async function loadVictronConfig() {
    try {
        const response = await fetch('/api/victron/config');
        const data = await response.json();

        const monitoringBtn = document.getElementById('victron-monitoring-btn');
        const deleteBtn = document.getElementById('victron-delete-btn');
        const chartsSection = document.getElementById('victron-charts-section');

        if (data.success && data.config.device) {
            // Device is configured
            document.getElementById('victron-config-display').innerHTML = `
                <div class="config-info">
                    <p><strong>Device:</strong> ${data.config.device.name}</p>
                    <p><strong>MAC:</strong> ${data.config.device.mac}</p>
                    <p><strong>History Retention:</strong> ${data.config.history_retention_seconds / 3600} hours</p>
                </div>
            `;
            document.getElementById('victron-configure-btn').textContent = 'Edit Configuration';

            // Show control buttons when configured
            monitoringBtn.style.display = 'inline-block';
            deleteBtn.style.display = 'inline-block';

            // Check if monitoring is active
            const statusResponse = await fetch('/api/victron/status');
            const statusData = await statusResponse.json();

            if (statusData.success && statusData.status.monitoring) {
                // Monitoring is active
                monitoringBtn.textContent = 'Stop Monitoring';
                monitoringBtn.classList.remove('btn-primary');
                monitoringBtn.classList.add('btn-secondary');

                // Show telemetry and charts sections
                document.getElementById('victron-telemetry-section').style.display = 'block';
                chartsSection.style.display = 'block';
                initVictronCharts();
                startVictronPolling();
            } else {
                // Monitoring is stopped
                monitoringBtn.textContent = 'Start Monitoring';
                monitoringBtn.classList.remove('btn-secondary');
                monitoringBtn.classList.add('btn-primary');

                // Hide telemetry and charts sections
                document.getElementById('victron-telemetry-section').style.display = 'none';
                chartsSection.style.display = 'none';
                stopVictronPolling();
            }
        } else {
            // No device configured
            document.getElementById('victron-config-display').innerHTML = `
                <div class="config-info">
                    <p>No Victron device configured yet.</p>
                    <p>Click "Configure Device" to get started.</p>
                </div>
            `;
            document.getElementById('victron-configure-btn').textContent = 'Configure Device';

            // Hide control buttons when not configured
            monitoringBtn.style.display = 'none';
            deleteBtn.style.display = 'none';

            // Hide telemetry and charts sections
            document.getElementById('victron-telemetry-section').style.display = 'none';
            chartsSection.style.display = 'none';
        }
    } catch (error) {
        console.error('Failed to load Victron config:', error);
        document.getElementById('victron-config-display').innerHTML = `
            <div class="error">Failed to load configuration: ${error.message}</div>
        `;
    }
}

/**
 * Show configuration form, preloading existing config if available
 */
async function showVictronConfigForm() {
    // Try to preload existing configuration
    try {
        const response = await fetch('/api/victron/config');
        const data = await response.json();

        if (data.success && data.config.device) {
            // Populate form with existing values
            document.getElementById('victron-mac').value = data.config.device.mac || '';
            document.getElementById('victron-key').value = data.config.device.encryption_key || '';
            document.getElementById('victron-name').value = data.config.device.name || 'Smart Shunt';
            document.getElementById('victron-retention').value = (data.config.history_retention_seconds / 3600) || 1;
        }
    } catch (error) {
        console.error('Failed to preload Victron config:', error);
        // Continue showing form even if preload fails
    }

    document.getElementById('victron-config-form').style.display = 'block';
    document.getElementById('victron-configure-btn').style.display = 'none';
}

/**
 * Cancel configuration form
 */
function cancelVictronConfig() {
    document.getElementById('victron-config-form').style.display = 'none';
    document.getElementById('victron-configure-btn').style.display = 'block';
}

/**
 * Save Victron configuration
 */
async function saveVictronConfig() {
    let mac = document.getElementById('victron-mac').value.trim();
    const key = document.getElementById('victron-key').value.trim();
    const name = document.getElementById('victron-name').value.trim() || 'Smart Shunt';
    const retention = parseInt(document.getElementById('victron-retention').value) || 1;

    // Validate inputs
    if (!mac || !key) {
        showStatusMessage('Please enter both MAC address and encryption key', 'error');
        return;
    }

    // Normalize MAC address format - accept both with and without colons
    // Remove any existing separators and convert to uppercase
    const cleanMac = mac.replace(/[:-]/g, '').toUpperCase();

    // Validate MAC is exactly 12 hex characters
    const macHexRegex = /^[0-9A-F]{12}$/;
    if (!macHexRegex.test(cleanMac)) {
        showStatusMessage('Invalid MAC address. Enter 12 hex characters (e.g., AABBCCDDEEFF or AA:BB:CC:DD:EE:FF)', 'error');
        return;
    }

    // Convert to colon-separated format for backend
    mac = cleanMac.match(/.{2}/g).join(':');

    // Validate key length
    if (key.length !== 32) {
        showStatusMessage('Encryption key must be exactly 32 hexadecimal characters', 'error');
        return;
    }

    try {
        // Save device configuration
        const deviceResponse = await fetch('/api/victron/device', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ mac, encryption_key: key, name, enabled: true })
        });

        const deviceData = await deviceResponse.json();
        if (!deviceData.success) {
            throw new Error(deviceData.error || 'Failed to save device');
        }

        // Save settings (retention)
        const configResponse = await fetch('/api/victron/config', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                history_retention_seconds: retention * 3600,
                auto_start: true
            })
        });

        const configData = await configResponse.json();
        if (!configData.success) {
            console.warn('Failed to save settings:', configData.error);
        }

        // Start monitoring
        const startResponse = await fetch('/api/victron/start', { method: 'POST' });
        const startData = await startResponse.json();

        if (!startData.success) {
            throw new Error(startData.error || 'Failed to start monitoring');
        }

        // Hide form, show telemetry
        cancelVictronConfig();
        await loadVictronConfig();
        showStatusMessage('Victron monitoring started successfully!', 'success');

    } catch (error) {
        console.error('Failed to save Victron config:', error);
        showStatusMessage('Error: ' + error.message, 'error');
    }
}

/**
 * Stop Victron monitoring
 */
async function stopVictronMonitoring() {
    try {
        const response = await fetch('/api/victron/stop', { method: 'POST' });
        const data = await response.json();

        if (data.success) {
            stopVictronPolling();
            document.getElementById('victron-telemetry-section').style.display = 'none';
            document.getElementById('victron-charts-section').style.display = 'none';
            await loadVictronConfig();
        } else {
            throw new Error(data.error || 'Failed to stop monitoring');
        }
    } catch (error) {
        console.error('Failed to stop monitoring:', error);
        showStatusMessage('Error: ' + error.message, 'error');
    }
}

/**
 * Toggle Victron monitoring on/off
 */
async function toggleVictronMonitoring() {
    try {
        // Check current monitoring state
        const statusResponse = await fetch('/api/victron/status');
        const statusData = await statusResponse.json();

        if (statusData.success && statusData.status.monitoring) {
            // Currently monitoring - stop it
            await stopVictronMonitoring();
        } else {
            // Not monitoring - start it
            const startResponse = await fetch('/api/victron/start', { method: 'POST' });
            const startData = await startResponse.json();

            if (!startData.success) {
                throw new Error(startData.error || 'Failed to start monitoring');
            }

            await loadVictronConfig();
        }
    } catch (error) {
        console.error('Failed to toggle monitoring:', error);
        showStatusMessage('Error: ' + error.message, 'error');
    }
}

/**
 * Delete Victron device
 */
async function deleteVictronDevice() {
    if (!confirm('Delete Victron device configuration? This will stop monitoring and clear all data.')) return;

    try {
        const response = await fetch('/api/victron/device', { method: 'DELETE' });
        const data = await response.json();

        if (data.success) {
            stopVictronPolling();
            document.getElementById('victron-telemetry-section').style.display = 'none';
            document.getElementById('victron-charts-section').style.display = 'none';
            await loadVictronConfig();
        } else {
            throw new Error(data.error || 'Failed to delete device');
        }
    } catch (error) {
        console.error('Failed to delete device:', error);
        showStatusMessage('Error: ' + error.message, 'error');
    }
}

/**
 * Start polling for telemetry updates
 * Intervals are hardware-adaptive based on Pi model
 */
function startVictronPolling() {
    if (DroidNet.state.polling.victronPollingInterval) return; // Already polling

    const intervals = getVictronIntervals();
    const model = DroidNet.state.hardware.piModel || 'unknown';
    console.log('Victron: Starting polling (telemetry: ' + intervals.telemetry + 'ms, charts: ' + intervals.charts + 'ms, pi_model: ' + model + ')');

    // Telemetry polling - hardware-adaptive
    DroidNet.state.polling.victronPollingInterval = setInterval(async () => {
        await updateVictronTelemetry();
    }, intervals.telemetry);

    // Chart polling - hardware-adaptive (history fetch is expensive, ~90KB)
    DroidNet.state.polling.victronChartPollingInterval = setInterval(async () => {
        await updateVictronCharts();
    }, intervals.charts);

    // Initial update
    updateVictronTelemetry();
    updateVictronCharts();
}

/**
 * Stop polling for telemetry updates
 */
function stopVictronPolling() {
    if (DroidNet.state.polling.victronPollingInterval) {
        clearInterval(DroidNet.state.polling.victronPollingInterval);
        DroidNet.state.polling.victronPollingInterval = null;
    }
    if (DroidNet.state.polling.victronChartPollingInterval) {
        clearInterval(DroidNet.state.polling.victronChartPollingInterval);
        DroidNet.state.polling.victronChartPollingInterval = null;
    }

    // Clean up Chart.js instances to prevent memory leaks
    if (DroidNet.state.victron.charts.voltage) {
        DroidNet.state.victron.charts.voltage.destroy();
        DroidNet.state.victron.charts.voltage = null;
    }
    if (DroidNet.state.victron.charts.current) {
        DroidNet.state.victron.charts.current.destroy();
        DroidNet.state.victron.charts.current = null;
    }
    if (DroidNet.state.victron.charts.soc) {
        DroidNet.state.victron.charts.soc.destroy();
        DroidNet.state.victron.charts.soc = null;
    }
}

/**
 * Update real-time telemetry display
 */
async function updateVictronTelemetry() {
    try {
        // Fetch both telemetry and status for recovery info
        const [telemetryResponse, statusResponse] = await Promise.all([
            fetch('/api/victron/telemetry'),
            fetch('/api/victron/status')
        ]);
        const data = await telemetryResponse.json();
        const status = await statusResponse.json();

        const reconnectBtn = document.getElementById('victron-reconnect-btn');
        const restartBtBtn = document.getElementById('victron-restart-bt-btn');
        const viewLogsBtn = document.getElementById('victron-view-logs-btn');
        const statusIcon = document.getElementById('victron-status-icon');
        const statusText = document.getElementById('victron-status-text');

        // Check recovery status and Bluetooth status
        const recovery = status.status?.recovery || status.recovery || {};
        const bluetooth = status.status?.bluetooth || {};
        const btAvailable = bluetooth.available !== false;

        // Detect Bluetooth state changes and show toasts
        if (!btAvailable && DroidNet.state.victron.lastBluetoothState !== false) {
            if (!DroidNet.state.victron.bluetoothUnavailableNotified) {
                showToast('Bluetooth hardware unavailable - monitoring paused', 'error', 10000);
                DroidNet.state.victron.bluetoothUnavailableNotified = true;
            }
        } else if (btAvailable && DroidNet.state.victron.lastBluetoothState === false) {
            showToast('Bluetooth hardware recovered', 'success', 5000);
            DroidNet.state.victron.bluetoothUnavailableNotified = false;
        }
        DroidNet.state.victron.lastBluetoothState = btAvailable;

        if (data.success && data.telemetry) {
            const t = data.telemetry;

            // Update values (always show last known data)
            document.getElementById('victron-voltage').textContent = t.voltage.toFixed(2);
            document.getElementById('victron-current').textContent = t.current.toFixed(2);
            document.getElementById('victron-power').textContent = t.power.toFixed(1);
            document.getElementById('victron-soc').textContent = t.soc.toFixed(1);
            document.getElementById('victron-consumed').textContent = t.consumed_ah.toFixed(2);
            document.getElementById('victron-time').textContent = t.time_remaining || '--';

            // Check if Bluetooth is unavailable even though we have cached telemetry
            if (!btAvailable) {
                // Bluetooth hardware unavailable - show error state despite cached data
                statusIcon.className = 'victron-dot bluetooth-error';
                statusText.textContent = 'Bluetooth Unavailable';
                statusText.className = 'badge badge-danger';
                if (reconnectBtn) reconnectBtn.style.display = 'none';
                if (restartBtBtn) restartBtBtn.style.display = 'inline-block';
                if (viewLogsBtn) viewLogsBtn.style.display = 'inline-block';
                // Show error in header
                updateHeaderSoC(null, true);
            } else {
                // Update status (using new inline dot classes)
                statusIcon.className = 'victron-dot connected';
                statusText.textContent = 'Connected';
                statusText.className = 'badge badge-success';
                if (reconnectBtn) reconnectBtn.style.display = 'none';
                if (restartBtBtn) restartBtBtn.style.display = 'none';
                if (viewLogsBtn) viewLogsBtn.style.display = 'none';

            // Update RSSI
            const rssi = t.rssi;
            let rssiClass = 'rssi-poor';
            if (rssi > -60) rssiClass = 'rssi-excellent';
            else if (rssi > -75) rssiClass = 'rssi-good';
            else if (rssi > -85) rssiClass = 'rssi-fair';

            document.getElementById('victron-rssi').innerHTML = `<span class="${rssiClass}">${rssi} dBm</span>`;

            // Update timestamp
            const lastUpdate = new Date(t.timestamp * 1000);
            document.getElementById('victron-last-update').textContent = lastUpdate.toLocaleTimeString();

            // Update header SoC display
            updateHeaderSoC(t.soc);
            }

        } else {
            // No telemetry available - check why
            if (!btAvailable) {
                // Bluetooth hardware unavailable
                statusIcon.className = 'victron-dot bluetooth-error';
                statusText.textContent = 'Bluetooth Unavailable';
                statusText.className = 'badge badge-danger';
                if (reconnectBtn) reconnectBtn.style.display = 'none';
                if (restartBtBtn) restartBtBtn.style.display = 'inline-block';
                if (viewLogsBtn) viewLogsBtn.style.display = 'inline-block';
                // Show error in header
                updateHeaderSoC(null, true);
            } else if (recovery.is_recovering) {
                statusIcon.className = 'victron-dot recovering';
                statusText.textContent = `Recovering (${recovery.attempts}/${recovery.max_attempts})`;
                statusText.className = 'badge badge-warning';
                if (reconnectBtn) reconnectBtn.style.display = 'none';
                if (restartBtBtn) restartBtBtn.style.display = 'none';
                if (viewLogsBtn) viewLogsBtn.style.display = 'none';
                // Hide header SoC during recovery
                const headerSoc = document.getElementById('header-victron-soc');
                if (headerSoc) headerSoc.style.display = 'none';
            } else if (recovery.needs_manual) {
                statusIcon.className = 'victron-dot disconnected';
                statusText.textContent = 'Connection Failed';
                statusText.className = 'badge badge-danger';
                if (reconnectBtn) reconnectBtn.style.display = 'inline-block';
                if (restartBtBtn) restartBtBtn.style.display = 'inline-block';
                if (viewLogsBtn) viewLogsBtn.style.display = 'inline-block';
                // Hide header SoC when failed
                const headerSoc = document.getElementById('header-victron-soc');
                if (headerSoc) headerSoc.style.display = 'none';
            } else {
                statusIcon.className = 'victron-dot disconnected';
                statusText.textContent = data.error || 'No data';
                statusText.className = 'badge badge-secondary';
                // Show reconnect if disconnected for a while
                const timeSinceData = status.status?.time_since_data || status.time_since_data;
                if (reconnectBtn) {
                    reconnectBtn.style.display = (timeSinceData && timeSinceData > 60) ? 'inline-block' : 'none';
                }
                if (restartBtBtn) restartBtBtn.style.display = 'none';
                if (viewLogsBtn) viewLogsBtn.style.display = 'none';
                // Hide header SoC when no data
                const headerSoc = document.getElementById('header-victron-soc');
                if (headerSoc) headerSoc.style.display = 'none';
            }
        }
    } catch (error) {
        console.error('Failed to update telemetry:', error);
        document.getElementById('victron-status-icon').className = 'victron-dot disconnected';
        document.getElementById('victron-status-text').textContent = 'Error';
        document.getElementById('victron-status-text').className = 'badge badge-danger';
    }
}

/**
 * Manually trigger BLE reconnection
 */
async function victronReconnect() {
    const reconnectBtn = document.getElementById('victron-reconnect-btn');
    const statusText = document.getElementById('victron-status-text');

    if (reconnectBtn) {
        reconnectBtn.disabled = true;
        reconnectBtn.textContent = 'Reconnecting...';
    }

    try {
        const response = await fetch('/api/victron/reconnect', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        });
        const result = await response.json();

        if (result.success) {
            if (statusText) {
                statusText.textContent = 'Reconnecting...';
                statusText.className = 'badge badge-warning';
            }
            showToast('Reconnection initiated', 'success');
        } else {
            showToast(result.error || 'Reconnect failed', 'error');
        }
    } catch (error) {
        console.error('Reconnect failed:', error);
        showToast('Reconnect failed: ' + error.message, 'error');
    } finally {
        if (reconnectBtn) {
            reconnectBtn.disabled = false;
            reconnectBtn.textContent = 'Reconnect';
        }
    }
}

/**
 * Update header SoC display with color-coded status
 * @param {number|null} soc - State of charge percentage, or null if unavailable
 * @param {boolean} isError - If true, show error indicator instead of hiding
 */
function updateHeaderSoC(soc, isError = false) {
    const headerSoc = document.getElementById('header-victron-soc');
    const socValue = document.getElementById('header-soc-value');

    if (!headerSoc || !socValue) return;

    // Handle error state
    if (isError) {
        headerSoc.style.display = 'flex';
        socValue.textContent = '!';
        headerSoc.classList.remove('soc-critical', 'soc-low');
        headerSoc.classList.add('soc-error');
        headerSoc.title = 'Bluetooth unavailable';
        return;
    }

    // Handle null/undefined SoC
    if (soc === null || soc === undefined) {
        headerSoc.style.display = 'none';
        return;
    }

    // Show the SoC display
    headerSoc.style.display = 'flex';
    headerSoc.title = '';

    // Update value
    socValue.textContent = Math.round(soc);

    // Update color class based on SoC level
    headerSoc.classList.remove('soc-critical', 'soc-low', 'soc-error');
    if (soc < 20) {
        headerSoc.classList.add('soc-critical');
    } else if (soc < 40) {
        headerSoc.classList.add('soc-low');
    }
}

/**
 * Manually restart Bluetooth service
 */
async function victronRestartBluetooth() {
    const restartBtBtn = document.getElementById('victron-restart-bt-btn');
    const statusText = document.getElementById('victron-status-text');

    if (restartBtBtn) {
        restartBtBtn.disabled = true;
        restartBtBtn.textContent = 'Restarting...';
    }

    try {
        const response = await fetch('/api/victron/restart-bluetooth', { method: 'POST' });
        const data = await response.json();

        if (data.success) {
            showToast('Bluetooth service restarted - waiting for recovery...', 'success');
            if (statusText) {
                statusText.textContent = 'Recovering...';
                statusText.className = 'badge badge-warning';
            }
            // Reset notification state to allow new toast if still fails
            DroidNet.state.victron.bluetoothUnavailableNotified = false;
            DroidNet.state.victron.lastBluetoothState = true;
        } else {
            showToast(data.error || 'Failed to restart Bluetooth', 'error');
        }
    } catch (error) {
        console.error('Bluetooth restart failed:', error);
        showToast('Failed to restart Bluetooth: ' + error.message, 'error');
    } finally {
        if (restartBtBtn) {
            restartBtBtn.disabled = false;
            restartBtBtn.textContent = 'Restart Bluetooth';
        }
    }
}

/**
 * Open Victron logs modal
 */
async function openVictronLogsModal() {
    const modal = document.getElementById('victron-logs-modal');
    const logsContent = document.getElementById('victron-logs-content');

    if (!modal || !logsContent) return;

    logsContent.innerHTML = '<div class="loading">Loading logs...</div>';
    modal.style.display = 'flex';

    try {
        const response = await fetch('/api/victron/logs');
        const data = await response.json();

        if (data.success && data.logs && data.logs.length > 0) {
            const logsHtml = data.logs.map(line => {
                // Color-code log levels
                let className = 'log-line';
                if (line.includes('ERROR')) className += ' log-error';
                else if (line.includes('WARNING')) className += ' log-warning';
                else if (line.includes('INFO')) className += ' log-info';
                return `<div class="${className}">${escapeHtml(line)}</div>`;
            }).join('');
            logsContent.innerHTML = `<div class="logs-container">${logsHtml}</div>`;
        } else {
            logsContent.innerHTML = '<div class="no-logs">No Victron/Bluetooth logs found</div>';
        }
    } catch (error) {
        console.error('Failed to load logs:', error);
        logsContent.innerHTML = `<div class="error">Failed to load logs: ${error.message}</div>`;
    }
}

/**
 * Close Victron logs modal
 */
function closeVictronLogsModal() {
    const modal = document.getElementById('victron-logs-modal');
    if (modal) modal.style.display = 'none';
}

/**
 * Escape HTML to prevent XSS in log display
 */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

/**
 * Initialize Chart.js charts
 */
function initVictronCharts() {
    if (DroidNet.state.victron.charts.voltage) return; // Already initialized

    const chartOptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: { display: false }
        },
        scales: {
            x: {
                type: 'time',
                time: { unit: 'minute' },
                title: { display: true, text: 'Time' }
            },
            y: {
                beginAtZero: false
            }
        }
    };

    // Voltage chart
    const voltageCtx = document.getElementById('victron-voltage-chart').getContext('2d');
    DroidNet.state.victron.charts.voltage = new Chart(voltageCtx, {
        type: 'line',
        data: {
            datasets: [{
                label: 'Voltage (V)',
                data: [],
                borderColor: '#00ff00',
                backgroundColor: 'rgba(0, 255, 0, 0.1)',
                tension: 0.1
            }]
        },
        options: { ...chartOptions, scales: { ...chartOptions.scales, y: { ...chartOptions.scales.y, title: { display: true, text: 'Voltage (V)' } } } }
    });

    // Current chart
    const currentCtx = document.getElementById('victron-current-chart').getContext('2d');
    DroidNet.state.victron.charts.current = new Chart(currentCtx, {
        type: 'line',
        data: {
            datasets: [{
                label: 'Current (A)',
                data: [],
                borderColor: '#00aaff',
                backgroundColor: 'rgba(0, 170, 255, 0.1)',
                tension: 0.1
            }]
        },
        options: { ...chartOptions, scales: { ...chartOptions.scales, y: { ...chartOptions.scales.y, title: { display: true, text: 'Current (A)' } } } }
    });

    // SOC chart
    const socCtx = document.getElementById('victron-soc-chart').getContext('2d');
    DroidNet.state.victron.charts.soc = new Chart(socCtx, {
        type: 'line',
        data: {
            datasets: [{
                label: 'State of Charge (%)',
                data: [],
                borderColor: '#ffaa00',
                backgroundColor: 'rgba(255, 170, 0, 0.1)',
                tension: 0.1
            }]
        },
        options: { ...chartOptions, scales: { ...chartOptions.scales, y: { ...chartOptions.scales.y, title: { display: true, text: 'SOC (%)' }, min: 0, max: 100 } } }
    });
}

/**
 * Update charts with historical data
 */
async function updateVictronCharts() {
    if (!DroidNet.state.victron.charts.voltage) return; // Charts not initialized

    try {
        const response = await fetch(`/api/victron/history?seconds=${DroidNet.state.victron.chartRange}`);
        const data = await response.json();

        if (data.success && data.history.length > 0) {
            // Convert history to chart data
            const voltageData = data.history.map(t => ({ x: new Date(t.timestamp * 1000), y: t.voltage }));
            const currentData = data.history.map(t => ({ x: new Date(t.timestamp * 1000), y: t.current }));
            const socData = data.history.map(t => ({ x: new Date(t.timestamp * 1000), y: t.soc }));

            // Update charts
            DroidNet.state.victron.charts.voltage.data.datasets[0].data = voltageData;
            DroidNet.state.victron.charts.voltage.update('none');

            DroidNet.state.victron.charts.current.data.datasets[0].data = currentData;
            DroidNet.state.victron.charts.current.update('none');

            DroidNet.state.victron.charts.soc.data.datasets[0].data = socData;
            DroidNet.state.victron.charts.soc.update('none');
        }
    } catch (error) {
        console.error('Failed to update charts:', error);
    }
}

/**
 * Set chart time range
 */
function setVictronChartRange(seconds) {
    DroidNet.state.victron.chartRange = seconds;

    // Update active button
    document.querySelectorAll('.chart-controls .btn').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.classList.add('active');

    // Update charts immediately
    updateVictronCharts();
}

// Store expanded Victron chart for modal
DroidNet.state.victron.expandedChart = null;

/**
 * Open expanded chart modal for Victron data
 * @param {string} chartType - 'voltage', 'current', or 'soc'
 * @param {string} title - Chart title
 */
async function openVictronChartModal(chartType, title) {
    const modal = document.getElementById('chart-modal');
    const titleEl = document.getElementById('chart-modal-title');
    const canvas = document.getElementById('expanded-chart');

    if (!modal || !canvas) return;

    // Set title
    if (titleEl) titleEl.textContent = title + ' History';

    // Destroy existing chart
    if (DroidNet.state.victron.expandedChart) {
        DroidNet.state.victron.expandedChart.destroy();
        DroidNet.state.victron.expandedChart = null;
    }

    // Fetch current history data
    try {
        const response = await fetch(`/api/victron/history?seconds=${DroidNet.state.victron.chartRange}`);
        const data = await response.json();

        if (!data.success || !data.history || data.history.length === 0) {
            console.warn('No Victron history data available');
            return;
        }

        // Map chart type to data field and color
        const chartConfig = {
            voltage: {
                field: 'voltage',
                color: '#10b981',
                unit: 'V',
                yMin: null,
                yMax: null
            },
            current: {
                field: 'current',
                color: '#3b82f6',
                unit: 'A',
                yMin: null,
                yMax: null
            },
            soc: {
                field: 'soc',
                color: '#f59e0b',
                unit: '%',
                yMin: 0,
                yMax: 100
            }
        };

        const config = chartConfig[chartType];
        if (!config) return;

        // Prepare data
        const chartData = data.history.map(t => ({
            x: new Date(t.timestamp * 1000),
            y: t[config.field]
        }));

        // Show modal first so we can measure container size
        modal.style.display = 'flex';

        // Use requestAnimationFrame to ensure CSS has been applied
        requestAnimationFrame(() => {
            // Destroy any existing chart on this canvas (safety check)
            if (DroidNet.state.victron.expandedChart) {
                DroidNet.state.victron.expandedChart.destroy();
                DroidNet.state.victron.expandedChart = null;
            }

            // Get modal body dimensions for responsive sizing
            const modalBody = modal.querySelector('.modal-body');
            const containerWidth = modalBody ? Math.max(modalBody.clientWidth - 48, 600) : 800;
            const containerHeight = Math.min(window.innerHeight * 0.6, 450);

            // Set canvas dimensions
            canvas.width = containerWidth;
            canvas.height = containerHeight;

            // Create expanded chart
            const ctx = canvas.getContext('2d');
            DroidNet.state.victron.expandedChart = new Chart(ctx, {
            type: 'line',
            data: {
                datasets: [{
                    label: title,
                    data: chartData,
                    borderColor: config.color,
                    backgroundColor: config.color + '30',
                    fill: true,
                    tension: 0.3,
                    pointRadius: 3,
                    pointHoverRadius: 6,
                    borderWidth: 2.5
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        enabled: true,
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleFont: { size: 14 },
                        bodyFont: { size: 14 },
                        padding: 12,
                        callbacks: {
                            label: function(context) {
                                return context.parsed.y.toFixed(2) + ' ' + config.unit;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        type: 'time',
                        display: true,
                        title: {
                            display: true,
                            text: 'Time',
                            color: '#9ca3af',
                            font: { size: 14 }
                        },
                        ticks: {
                            color: '#9ca3af',
                            font: { size: 12 },
                            maxTicksLimit: 8
                        },
                        grid: {
                            color: 'rgba(156, 163, 175, 0.2)'
                        }
                    },
                    y: {
                        display: true,
                        min: config.yMin,
                        max: config.yMax,
                        title: {
                            display: true,
                            text: config.unit,
                            color: '#9ca3af',
                            font: { size: 14 }
                        },
                        ticks: {
                            color: '#9ca3af',
                            font: { size: 12 }
                        },
                        grid: {
                            color: 'rgba(156, 163, 175, 0.2)'
                        }
                    }
                }
            }
        });
        });

    } catch (error) {
        console.error('Failed to load Victron chart data:', error);
    }
}

// Initialize Victron on page load
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('victron-tab')) {
        initVictron();
    }
});

console.log('Victron Smart Shunt functions loaded');

// ============================================================================
// Droid Tab - Multi-Device Management
// ============================================================================

/**
 * Show error message in Droid tab (replaces alert())
 * @param {string} message - Error message to display
 */
function showDroidError(message) {
    const errorContainer = document.getElementById('droid-error-container');
    if (errorContainer) {
        const errorDiv = document.createElement('div');
        errorDiv.className = 'alert alert-error';
        errorDiv.role = 'alert';
        errorDiv.textContent = message;
        errorContainer.innerHTML = '';
        errorContainer.appendChild(errorDiv);
        setTimeout(() => errorDiv.remove(), 8000);
    } else {
        // Fallback to console if container not available
        console.error('Droid Error:', message);
    }
}

/**
 * Initialize Droid tab with event delegation
 */
function setupDroidEventDelegation() {
    // Event delegation for device list (with guard to prevent duplicate listeners)
    const deviceList = document.getElementById('droid-device-list');
    if (deviceList && !deviceList._droidDelegationSetup) {
        deviceList._droidDelegationSetup = true;
        deviceList.addEventListener('click', (e) => {
            // Handle remove button
            const removeBtn = e.target.closest('.droid-remove-btn');
            if (removeBtn) {
                removeDroidDevice(removeBtn.dataset.hostname);
                return;
            }
            // Handle inline update button
            const updateBtn = e.target.closest('.droid-update-device-btn');
            if (updateBtn) {
                DroidUpdateManager.updateDevice(updateBtn.dataset.hostname, updateBtn.dataset.ip);
            }
        });
    }

    // Event delegation for flash targets (with guard to prevent duplicate listeners)
    const flashSection = document.getElementById('droid-flash-section');
    if (flashSection && !flashSection._droidDelegationSetup) {
        flashSection._droidDelegationSetup = true;
        flashSection.addEventListener('change', (e) => {
            const checkbox = e.target.closest('.droid-flash-target-check');
            if (checkbox) {
                // Support both new grouped layout (.droid-flash-location) and legacy (.droid-flash-target)
                const target = checkbox.closest('.droid-flash-location') || checkbox.closest('.droid-flash-target');
                if (target) {
                    const selectedClass = target.classList.contains('droid-flash-location')
                        ? 'droid-flash-location--selected'
                        : 'droid-flash-target--selected';
                    target.classList.toggle(selectedClass, checkbox.checked);
                }
                updateDroidFlashButtonState();
            }
        });
    }

    // Event delegation for flash progress retry buttons (with guard to prevent duplicate listeners)
    const progressEl = document.getElementById('droid-flash-progress');
    if (progressEl && !progressEl._droidDelegationSetup) {
        progressEl._droidDelegationSetup = true;
        progressEl.addEventListener('click', (e) => {
            const retryBtn = e.target.closest('.droid-flash-retry-btn');
            if (retryBtn) {
                const hostname = retryBtn.dataset.hostname;
                const ip = retryBtn.dataset.ip;
                const port = retryBtn.dataset.port;
                retryDroidFlash(hostname, ip, port);
            }
        });
    }
}

/**
 * Update the state of the update button based on selections
 */
function updateDroidUpdateButtonState() {
    const btn = document.getElementById('droid-update-btn');
    const checked = document.querySelectorAll('.droid-update-check:checked');
    if (btn) {
        btn.disabled = checked.length === 0;
    }
}

/**
 * Update the state of the flash button based on selections
 */
function updateDroidFlashButtonState() {
    const btn = document.getElementById('droid-flash-btn');
    const checked = document.querySelectorAll('.droid-flash-target-check:checked');
    if (btn) {
        btn.disabled = checked.length === 0 || !DroidNet.state.droid.selectedFirmwareData;
    }
}

/**
 * Refresh the list of DroidNet devices
 */
async function refreshDroidDevices() {
    const refreshBtn = document.getElementById('droid-refresh-btn');
    const listEl = document.getElementById('droid-device-list');
    const countEl = document.getElementById('droid-device-count');

    if (refreshBtn) {
        setButtonLoading(refreshBtn, true, 'Scanning...');
    }

    try {
        const response = await fetch('/api/droid/devices');
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        const data = await response.json();

        if (data.success && data.devices) {
            DroidNet.state.droid.devices = data.devices;
            renderDroidDeviceList(data.devices);
            if (countEl) {
                const onlineCount = data.devices.filter(d => d.online).length;
                countEl.textContent = `${onlineCount} online`;
            }
        } else {
            listEl.innerHTML = '<p class="text-muted">Could not discover devices.</p>';
        }
    } catch (error) {
        console.error('Error refreshing droid devices:', error);
        listEl.innerHTML = '<p class="text-error">Error scanning for devices.</p>';
    } finally {
        if (refreshBtn) {
            setButtonLoading(refreshBtn, false);
        }
    }
}

/**
 * Format uptime in a human-readable way
 * @param {number} seconds - Uptime in seconds
 * @returns {string} Formatted uptime
 */
function formatUptime(seconds) {
    if (!seconds || seconds < 0) return '--';
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const mins = Math.floor((seconds % 3600) / 60);

    if (days > 0) return `${days}d ${hours}h`;
    if (hours > 0) return `${hours}h ${mins}m`;
    return `${mins}m`;
}

/**
 * Get CPU bar color class based on usage percentage
 * @param {number} cpu - CPU percentage
 * @returns {string} CSS class
 */
function getCpuBarClass(cpu) {
    if (cpu >= 80) return 'droid-cpu-bar-fill--danger';
    if (cpu >= 50) return 'droid-cpu-bar-fill--warning';
    return '';
}

/**
 * Format version string for display
 * - Strips -dirty suffix
 * - Handles git hash format (shows as git-XXXXXXX)
 * @param {string} version - Raw version string
 * @returns {string} Formatted version for display
 */
function formatVersion(version) {
    if (!version) return '--';
    // Strip -dirty suffix for cleaner display
    let clean = version.replace(/-dirty$/, '');
    // If it starts with git-, it's already formatted
    if (clean.startsWith('git-')) {
        return clean.substring(0, 11);  // git- plus 7 chars
    }
    // If it's a raw hex hash (exactly 7 or 40 chars - short or full git hash), format as git hash
    if (/^[0-9a-f]{7}$/i.test(clean) || /^[0-9a-f]{40}$/i.test(clean)) {
        return 'git-' + clean.substring(0, 7);
    }
    // Otherwise it's a semantic version - add v prefix if not present
    if (!clean.startsWith('v')) {
        return 'v' + clean;
    }
    return clean;
}

/**
 * Manages update operations with real-time progress feedback
 */
const DroidUpdateManager = {
    // Track active updates: hostname -> { eventSource, status, progress, startTime, retries }
    activeUpdates: new Map(),

    // Bulk update state
    bulk: {
        active: false,
        total: 0,
        completed: 0,
        failed: 0,
        devices: new Set()
    },

    // Configuration
    config: {
        maxRetries: 3,
        maxRebootRetries: 10,
        retryDelayMs: 2000,
        sseTimeoutMs: 60000,
        staggerDelayMs: 500,
        maxUpdateDurationMs: 10 * 60 * 1000  // 10 minutes max
    },

    /**
     * Start update for a single device
     */
    async updateDevice(hostname, ip) {
        if (this.activeUpdates.has(hostname)) {
            console.warn(`Update already in progress for ${hostname}`);
            return;
        }

        // Disable update button immediately to prevent double-clicks
        const updateBtn = document.querySelector(`.droid-update-device-btn[data-hostname="${hostname}"]`);
        if (updateBtn) {
            updateBtn.disabled = true;
        }

        // Initialize tracking state
        this.activeUpdates.set(hostname, {
            eventSource: null,
            status: 'starting',
            progress: 'Starting update...',
            percent: 0,
            startTime: Date.now(),
            retries: 0,
            ip: ip
        });

        // Update UI immediately
        this.updateDeviceUI(hostname, 'starting', 'Starting update...', 5);
        this.showProgressRow(hostname, true);

        try {
            // Trigger update via batch API (works for single device too)
            const response = await fetch('/api/droid/updates/batch', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ devices: [{ hostname, ip }] })
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }

            const data = await response.json();
            if (!data.success) {
                throw new Error(data.error || 'Failed to start update');
            }

            // Start polling for progress (SSE may not be available cross-origin)
            this.pollProgress(hostname, ip);

        } catch (error) {
            console.error(`Failed to start update for ${hostname}:`, error);
            this.handleError(hostname, `Failed to start: ${error.message}`);
        }
    },

    /**
     * Update all devices with available updates
     */
    async updateAll() {
        const devicesWithUpdates = DroidNet.state.droid.devices.filter(
            d => d.update_available && d.online
        );

        if (devicesWithUpdates.length === 0) {
            showNotification('No updates available', 'info');
            return;
        }

        // Initialize bulk state
        this.bulk = {
            active: true,
            total: devicesWithUpdates.length,
            completed: 0,
            failed: 0,
            devices: new Set(devicesWithUpdates.map(d => d.hostname))
        };

        // Show aggregate progress
        this.updateAggregateUI();
        document.getElementById('droid-aggregate-progress')?.classList.add('active');

        // Hide the Update All button, disable Check for Updates
        const updateAllBtn = document.getElementById('droid-update-all-btn');
        const checkBtn = document.getElementById('droid-check-updates-btn');
        if (updateAllBtn) updateAllBtn.style.display = 'none';
        if (checkBtn) checkBtn.disabled = true;

        // Start updates with staggered timing to avoid network congestion
        for (let i = 0; i < devicesWithUpdates.length; i++) {
            const device = devicesWithUpdates[i];
            setTimeout(() => {
                this.updateDevice(device.hostname, device.ip);
            }, i * this.config.staggerDelayMs);
        }
    },

    /**
     * Check the network manager's batch status for errors
     * Returns the error message if the device failed, null otherwise
     */
    async checkBatchError(hostname) {
        try {
            const response = await fetch('/api/droid/updates/status', {
                signal: AbortSignal.timeout(5000)
            });
            if (!response.ok) return null;
            const data = await response.json();
            const deviceStatus = data.devices?.[hostname];
            if (deviceStatus?.status === 'failed' && deviceStatus?.error) {
                return deviceStatus.error;
            }
        } catch (e) {
            // Ignore batch status check errors
        }
        return null;
    },

    /**
     * Poll for update progress (fallback when SSE not available)
     */
    async pollProgress(hostname, ip) {
        const state = this.activeUpdates.get(hostname);
        if (!state) return;

        // Check for max duration timeout
        if (Date.now() - state.startTime > this.config.maxUpdateDurationMs) {
            this.handleError(hostname, 'Update timed out after 10 minutes');
            return;
        }

        // First check if the batch operation failed for this device
        // (happens when the device doesn't support the endpoint or connection failed)
        if (state.retries === 0 || state.status === 'starting') {
            const batchError = await this.checkBatchError(hostname);
            if (batchError) {
                this.handleError(hostname, batchError);
                return;
            }
        }

        try {
            const response = await fetch(`http://${ip}/api/system/update-status`, {
                signal: AbortSignal.timeout(10000)
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }

            const data = await response.json();

            // Update state and UI
            const status = data.status || 'unknown';
            const progress = data.progress || data.result?.version || status;
            const percent = this.statusToPercent(status);

            state.status = status;
            state.progress = progress;
            state.percent = percent;

            this.updateDeviceUI(hostname, status, progress, percent);

            // Handle terminal states
            if (status === 'completed' || status === 'complete') {
                const version = data.new_version || data.result?.version || data.current_version;
                this.handleComplete(hostname, version);
            } else if (status === 'failed' || status === 'error') {
                this.handleError(hostname, data.error || progress);
            } else if (status === 'idle' && state.retries < this.config.maxRetries) {
                // Device shows idle - check batch status for errors
                const batchError = await this.checkBatchError(hostname);
                if (batchError) {
                    this.handleError(hostname, batchError);
                    return;
                }
                // Device might have rebooted, retry
                state.retries++;
                setTimeout(() => this.pollProgress(hostname, ip), this.config.retryDelayMs);
            } else {
                // Continue polling
                setTimeout(() => this.pollProgress(hostname, ip), 2000);
            }

        } catch (error) {
            // Connection error - check batch status first for any trigger errors
            const batchError = await this.checkBatchError(hostname);
            if (batchError) {
                this.handleError(hostname, batchError);
                return;
            }

            // Device might be rebooting
            if (state.status === 'restarting' || state.progress?.includes('Restart')) {
                this.updateDeviceUI(hostname, 'restarting', 'Device rebooting...', 90);
                state.retries++;
                if (state.retries < this.config.maxRebootRetries) {
                    setTimeout(() => this.pollProgress(hostname, ip), 3000);
                } else {
                    this.handleError(hostname, 'Device did not come back online');
                }
            } else if (state.retries < this.config.maxRetries) {
                state.retries++;
                this.updateDeviceUI(hostname, 'retrying', `Connection lost. Retry ${state.retries}/${this.config.maxRetries}...`, state.percent);
                setTimeout(() => this.pollProgress(hostname, ip), this.config.retryDelayMs);
            } else {
                this.handleError(hostname, `Connection lost after ${this.config.maxRetries} retries`);
            }
        }
    },

    /**
     * Map status string to percentage
     */
    statusToPercent(status) {
        const map = {
            'starting': 5,
            'idle': 10,
            'uploading': 20,
            'processing': 40,
            'extracting': 50,
            'applying': 70,
            'restarting': 90,
            'completed': 100,
            'complete': 100,
            'error': 100,
            'failed': 100
        };
        return map[status] || 50;
    },

    /**
     * Handle successful update completion
     */
    handleComplete(hostname, newVersion) {
        const state = this.activeUpdates.get(hostname);
        if (state?.eventSource) {
            state.eventSource.close();
        }

        // Update UI to show success
        this.updateDeviceUI(hostname, 'complete', `Updated to v${newVersion || '?'}`, 100);

        // Update device row state
        const row = document.querySelector(`.droid-device-row[data-hostname="${hostname}"]`);
        if (row) {
            row.classList.remove('droid-device-row--updating');
            row.classList.add('droid-device-row--update-success');

            // Update version in the row
            const versionEl = row.querySelector('.droid-version');
            if (versionEl && newVersion) {
                versionEl.textContent = `v${newVersion}`;
            }

            // Remove update button, add checkmark
            const versionCol = row.querySelector('.droid-col-version');
            const updateBtn = versionCol?.querySelector('.droid-update-device-btn');
            if (updateBtn) {
                updateBtn.remove();
                const checkmark = document.createElement('span');
                checkmark.className = 'droid-version-status droid-version-status--current';
                checkmark.setAttribute('title', 'Up to date');
                checkmark.innerHTML = '&#10004;';
                versionCol.insertBefore(checkmark, versionCol.firstChild);
            }
        }

        // Hide progress row after delay
        setTimeout(() => {
            this.showProgressRow(hostname, false);
            row?.classList.remove('droid-device-row--update-success');
        }, 3000);

        // Clean up and update bulk progress
        this.activeUpdates.delete(hostname);
        if (this.bulk.active && this.bulk.devices.has(hostname)) {
            this.bulk.completed++;
            this.updateAggregateUI();
            this.checkBulkComplete();
        }

        // Update device state
        const device = DroidNet.state.droid.devices.find(d => d.hostname === hostname);
        if (device) {
            device.update_available = false;
            if (newVersion) device.version = newVersion;
        }
    },

    /**
     * Handle update error
     */
    handleError(hostname, errorMessage) {
        const state = this.activeUpdates.get(hostname);
        if (state?.eventSource) {
            state.eventSource.close();
        }

        // Update UI to show error
        this.updateDeviceUI(hostname, 'error', errorMessage, 100);

        // Update device row state
        const row = document.querySelector(`.droid-device-row[data-hostname="${hostname}"]`);
        if (row) {
            row.classList.remove('droid-device-row--updating');
            row.classList.add('droid-device-row--update-failed');
        }

        // Show retry button (use data attributes to avoid XSS)
        const progressRow = document.getElementById(`droid-progress-${hostname}`);
        const actionsEl = progressRow?.querySelector('.droid-progress-actions');
        if (actionsEl) {
            const safeHostname = escapeHtml(hostname);
            const safeIp = escapeHtml(state?.ip || '');
            actionsEl.innerHTML = `
                <button class="btn btn-xs btn-warning droid-retry-btn"
                        data-hostname="${safeHostname}" data-ip="${safeIp}">
                    Retry
                </button>
            `;
            // Add click handler directly to avoid XSS
            const retryBtn = actionsEl.querySelector('.droid-retry-btn');
            if (retryBtn) {
                retryBtn.addEventListener('click', () => {
                    DroidUpdateManager.retry(hostname, state?.ip || '');
                });
            }
        }

        // Clean up and update bulk progress
        this.activeUpdates.delete(hostname);
        if (this.bulk.active && this.bulk.devices.has(hostname)) {
            this.bulk.failed++;
            this.updateAggregateUI();
            this.checkBulkComplete();
        }
    },

    /**
     * Retry a failed update
     */
    retry(hostname, ip) {
        const row = document.querySelector(`.droid-device-row[data-hostname="${hostname}"]`);
        if (row) {
            row.classList.remove('droid-device-row--update-failed');
        }
        this.updateDevice(hostname, ip);
    },

    /**
     * Cancel all active updates
     */
    cancelAll() {
        for (const [hostname, state] of this.activeUpdates) {
            if (state.eventSource) {
                state.eventSource.close();
            }
            this.showProgressRow(hostname, false);
            const row = document.querySelector(`.droid-device-row[data-hostname="${hostname}"]`);
            if (row) {
                row.classList.remove('droid-device-row--updating', 'droid-device-row--update-failed');
            }
        }

        this.activeUpdates.clear();
        this.bulk.active = false;

        // Hide aggregate progress
        document.getElementById('droid-aggregate-progress')?.classList.remove('active');

        // Re-enable buttons
        const checkBtn = document.getElementById('droid-check-updates-btn');
        if (checkBtn) checkBtn.disabled = false;

        // Show Update All if there are still updates
        const hasUpdates = DroidNet.state.droid.devices.some(d => d.update_available && d.online);
        const updateAllBtn = document.getElementById('droid-update-all-btn');
        if (updateAllBtn) {
            updateAllBtn.style.display = hasUpdates ? 'inline-block' : 'none';
        }
    },

    /**
     * Check if bulk update is complete
     */
    checkBulkComplete() {
        const finished = this.bulk.completed + this.bulk.failed;
        if (finished >= this.bulk.total) {
            setTimeout(() => {
                // Hide aggregate progress
                document.getElementById('droid-aggregate-progress')?.classList.remove('active');

                // Re-enable check button
                const checkBtn = document.getElementById('droid-check-updates-btn');
                if (checkBtn) checkBtn.disabled = false;

                // Show summary notification
                if (this.bulk.failed === 0) {
                    showNotification(`All ${this.bulk.completed} devices updated successfully`, 'success');
                } else if (this.bulk.completed === 0) {
                    showNotification(`Update failed for all ${this.bulk.failed} devices`, 'error');
                } else {
                    showNotification(
                        `${this.bulk.completed} updated, ${this.bulk.failed} failed`,
                        'warning'
                    );
                }

                this.bulk.active = false;
            }, 1500);
        }
    },

    /**
     * Update the progress UI for a specific device
     */
    updateDeviceUI(hostname, status, message, percent) {
        const progressRow = document.getElementById(`droid-progress-${hostname}`);
        if (!progressRow) return;

        const progressFill = progressRow.querySelector('.droid-progress-bar-fill');
        const progressStatus = progressRow.querySelector('.droid-progress-status');

        if (progressFill) {
            progressFill.style.width = `${percent}%`;
            progressFill.classList.remove('droid-progress-bar-fill--complete', 'droid-progress-bar-fill--error', 'droid-progress-bar-fill--indeterminate');

            if (status === 'complete' || status === 'completed') {
                progressFill.classList.add('droid-progress-bar-fill--complete');
            } else if (status === 'error' || status === 'failed') {
                progressFill.classList.add('droid-progress-bar-fill--error');
            } else if (status === 'restarting' || status === 'retrying') {
                progressFill.classList.add('droid-progress-bar-fill--indeterminate');
            }
        }

        if (progressStatus) {
            progressStatus.textContent = message;
            progressStatus.classList.toggle('droid-progress-status--error', status === 'error' || status === 'failed');
        }

        // Clear actions area unless there's an error
        if (status !== 'error' && status !== 'failed') {
            const actionsEl = progressRow.querySelector('.droid-progress-actions');
            if (actionsEl) actionsEl.innerHTML = '';
        }
    },

    /**
     * Show/hide progress row for a device
     */
    showProgressRow(hostname, show) {
        const row = document.querySelector(`.droid-device-row[data-hostname="${hostname}"]`);
        let progressRow = document.getElementById(`droid-progress-${hostname}`);

        if (show) {
            // Add updating class to main row
            if (row) {
                row.classList.add('droid-device-row--updating');
            }

            // Create progress row if it doesn't exist
            if (!progressRow && row) {
                progressRow = document.createElement('div');
                progressRow.id = `droid-progress-${hostname}`;
                progressRow.className = 'droid-update-progress-row active';
                progressRow.innerHTML = `
                    <div class="droid-progress-bar-container">
                        <div class="droid-progress-bar-track">
                            <div class="droid-progress-bar-fill"></div>
                        </div>
                    </div>
                    <span class="droid-progress-status">Preparing...</span>
                    <div class="droid-progress-actions"></div>
                `;
                row.insertAdjacentElement('afterend', progressRow);
            } else if (progressRow) {
                progressRow.classList.add('active');
            }
        } else {
            // Hide and remove progress row after transition
            if (progressRow) {
                progressRow.classList.remove('active');
                // Remove from DOM after CSS transition completes
                setTimeout(() => {
                    progressRow.remove();
                }, 300);
            }
            if (row) {
                row.classList.remove('droid-device-row--updating');
            }
        }
    },

    /**
     * Update aggregate progress UI
     */
    updateAggregateUI() {
        const completed = this.bulk.completed + this.bulk.failed;
        const percent = this.bulk.total > 0 ? Math.round((completed / this.bulk.total) * 100) : 0;

        const completedEl = document.getElementById('droid-update-completed');
        const totalEl = document.getElementById('droid-update-total');
        const fillEl = document.getElementById('droid-aggregate-progress-fill');

        if (completedEl) completedEl.textContent = completed;
        if (totalEl) totalEl.textContent = this.bulk.total;
        if (fillEl) fillEl.style.width = `${percent}%`;
    }
};

// Make it globally available
window.DroidUpdateManager = DroidUpdateManager;

/**
 * Render the device list with grid-based layout for alignment
 * @param {Array} devices - Array of device objects
 */
function renderDroidDeviceList(devices) {
    const listEl = document.getElementById('droid-device-list');
    if (!listEl) return;

    if (!devices || devices.length === 0) {
        listEl.innerHTML = '<p class="text-muted">No DroidNet devices found on this network.</p>';
        return;
    }

    // Header row for alignment
    const headerHtml = `
        <div class="droid-device-header-row">
            <span class="droid-col-device">Device</span>
            <span class="droid-col-version">Version</span>
            <span class="droid-col-cpu">CPU</span>
            <span class="droid-col-uptime">Uptime</span>
            <span class="droid-col-usb">USB</span>
            <span class="droid-col-features">Features</span>
            <span class="droid-col-actions"></span>
        </div>
    `;

    const devicesHtml = devices.map(device => {
        const statusClass = device.online ? 'droid-device-status--online' : 'droid-device-status--offline';
        const onlineClass = device.online ? 'droid-device-card--online' : 'droid-device-card--offline';
        const currentClass = device.is_current ? 'droid-device-card--current' : '';
        const cardClass = `droid-device-row ${onlineClass} ${currentClass}`.trim();

        const modeClass = device.network_mode === 'ap' ? 'droid-mode-badge--ap' : 'droid-mode-badge--client';
        const modeText = device.network_mode === 'ap' ? 'AP' : 'Client';

        // Escape user-controllable data to prevent XSS
        const safeHostname = escapeHtml(device.hostname || '');
        const safeVersion = escapeHtml(device.version || '');
        const displayVersion = formatVersion(safeVersion);

        const lastSeen = device.last_seen ? formatRelativeTime(device.last_seen) : '';

        // USB device count - prefer usb_count field, fallback to usb_devices array length
        const usbCount = device.usb_count ?? (device.usb_devices || []).length;

        // CPU and uptime (from extended info if available)
        const cpu = device.cpu_usage || 0;
        const uptime = device.uptime || 0;
        const cpuBarClass = getCpuBarClass(cpu);

        // Services (from extended info if available)
        const services = device.services || {};
        const servicesBadges = [];
        if (services.comlink) {
            servicesBadges.push('<span class="droid-service-badge droid-service-badge--comlink">Comlink</span>');
        }
        if (services.virtualhere) {
            servicesBadges.push('<span class="droid-service-badge droid-service-badge--virtualhere">VH</span>');
        }
        if (services.maestro) {
            servicesBadges.push('<span class="droid-service-badge droid-service-badge--maestro">Maestro</span>');
        }
        if (services.wcb) {
            servicesBadges.push('<span class="droid-service-badge droid-service-badge--wcb">WCB</span>');
        }
        if (services.victron) {
            servicesBadges.push('<span class="droid-service-badge droid-service-badge--victron">Victron</span>');
        }

        if (device.online) {
            return `
                <div class="${cardClass}" data-hostname="${safeHostname}">
                    <div class="droid-col-device">
                        <div class="droid-device-status ${statusClass}"></div>
                        <span class="droid-device-hostname">${safeHostname}</span>
                        ${device.is_current ? '<span class="droid-current-badge">This</span>' : ''}
                        <span class="droid-mode-badge ${modeClass}">${modeText}</span>
                    </div>
                    <div class="droid-col-version">
                        ${device.update_available === false ?
                            '<span class="droid-version-status droid-version-status--current" title="Up to date" aria-label="Up to date">&#10004;</span>' :
                            device.update_available === true ?
                            `<button class="droid-update-device-btn" data-hostname="${safeHostname}" data-ip="${escapeHtml(device.ip || '')}" title="Update available" aria-label="Update ${safeHostname}">&#8593;</button>` :
                            ''}
                        <span class="droid-version">${displayVersion}</span>
                    </div>
                    <div class="droid-col-cpu">
                        <div class="droid-cpu-bar">
                            <div class="droid-cpu-bar-track">
                                <div class="droid-cpu-bar-fill ${cpuBarClass}" style="width: ${cpu}%"></div>
                            </div>
                            <span class="droid-cpu-value">${cpu}%</span>
                        </div>
                    </div>
                    <div class="droid-col-uptime">
                        <span class="droid-metric-value">${formatUptime(uptime)}</span>
                    </div>
                    <div class="droid-col-usb">
                        <span class="droid-metric-value">${usbCount}</span>
                    </div>
                    <div class="droid-col-features">
                        ${servicesBadges.length > 0 ? servicesBadges.join('') : '<span class="text-muted">--</span>'}
                    </div>
                    <div class="droid-col-actions">
                    </div>
                </div>
            `;
        } else {
            // Offline device - simplified row
            return `
                <div class="${cardClass}" data-hostname="${safeHostname}">
                    <div class="droid-col-device">
                        <div class="droid-device-status ${statusClass}"></div>
                        <span class="droid-device-hostname">${safeHostname}</span>
                    </div>
                    <div class="droid-col-version">
                        <span class="droid-version droid-version--offline">${displayVersion}</span>
                    </div>
                    <div class="droid-col-offline-info" style="grid-column: span 4;">
                        ${lastSeen ? `<span class="droid-last-seen">Last seen ${lastSeen}</span>` : '<span class="text-muted">Never connected</span>'}
                    </div>
                    <div class="droid-col-actions">
                        <button class="btn btn-sm btn-icon droid-remove-btn" data-hostname="${safeHostname}" title="Remove from list">
                            &#128465;
                        </button>
                    </div>
                </div>
            `;
        }
    }).join('');

    listEl.innerHTML = headerHtml + devicesHtml;
    // Event listeners handled by event delegation in initDroidTab()

    // Show/hide Update All button based on whether any online devices have updates available
    const updateAllBtn = document.getElementById('droid-update-all-btn');
    if (updateAllBtn) {
        const hasUpdates = devices.some(d => d.online && d.update_available === true);
        updateAllBtn.style.display = hasUpdates ? 'inline-block' : 'none';
    }
}

/**
 * Format a timestamp as relative time (e.g., "5 minutes ago")
 * @param {string} isoTimestamp - ISO timestamp string
 * @returns {string} Relative time string
 */
function formatRelativeTime(isoTimestamp) {
    const date = new Date(isoTimestamp);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    return `${diffDays}d ago`;
}

/**
 * Remove an offline device from the known devices list
 * @param {string} hostname - Device hostname to remove
 */
async function removeDroidDevice(hostname) {
    if (!confirm(`Remove ${hostname} from known devices?`)) return;

    try {
        const response = await fetch(`/api/droid/devices/${encodeURIComponent(hostname)}`, {
            method: 'DELETE'
        });
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        const data = await response.json();

        if (data.success) {
            refreshDroidDevices();
        } else {
            showDroidError('Failed to remove device');
        }
    } catch (error) {
        console.error('Error removing device:', error);
        showDroidError('Error removing device');
    }
}

/**
 * Check for updates across all devices (uses independent endpoint)
 */
async function checkDroidUpdates() {
    const btn = document.getElementById('droid-check-updates-btn');
    const sectionEl = document.getElementById('droid-updates-section');
    if (btn) setButtonLoading(btn, true, 'Checking...');

    try {
        // Fetch updates summary independently (doesn't require Devices pane)
        const response = await fetch('/api/droid/updates/summary');
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const data = await response.json();

        if (data.success && Array.isArray(data.devices)) {
            renderDroidUpdatesSection(data.devices);
        } else {
            if (sectionEl) sectionEl.innerHTML = '<p class="text-danger">Failed to fetch update status.</p>';
        }
    } catch (error) {
        console.error('Error checking updates:', error);
        if (sectionEl) sectionEl.innerHTML = '<p class="text-danger">Error checking for updates.</p>';
    } finally {
        if (btn) setButtonLoading(btn, false);
    }
}

/**
 * Render the updates section with provided device data
 * @param {Array} devices - Array of device objects (optional, falls back to state)
 */
function renderDroidUpdatesSection(devices = null) {
    const sectionEl = document.getElementById('droid-updates-section');
    const updateBtn = document.getElementById('droid-update-btn');
    if (!sectionEl) return;

    // Use provided devices or fall back to state
    const deviceList = devices || DroidNet.state.droid.devices.filter(d => d.online);

    if (deviceList.length === 0) {
        sectionEl.innerHTML = '<p class="text-muted">No online devices found. Click "Check All" to scan.</p>';
        if (updateBtn) updateBtn.disabled = true;
        return;
    }

    // Count devices with updates available
    const updatesAvailable = deviceList.filter(d => d.update_available).length;

    // Build header summary
    const headerHtml = updatesAvailable > 0 ? `
        <div class="droid-updates-header">
            <div class="droid-updates-summary">
                <strong>${updatesAvailable}</strong> device${updatesAvailable !== 1 ? 's' : ''} with updates available
            </div>
        </div>
    ` : `
        <div class="droid-updates-header">
            <div class="droid-updates-summary">All ${deviceList.length} devices are up to date</div>
        </div>
    `;

    // Build device list
    const devicesHtml = deviceList.map(device => {
        const hasUpdate = device.update_available;

        // Escape user-controllable data
        const safeHostname = escapeHtml(device.hostname || '');
        const safeIp = escapeHtml(device.ip || '');
        const safeVersion = escapeHtml(device.version || 'unknown');

        return `
            <div class="droid-update-row">
                <input type="checkbox" class="droid-update-check" data-hostname="${safeHostname}"
                    data-ip="${safeIp}" ${hasUpdate ? 'checked' : ''}>
                <div class="droid-update-device-info">
                    <span class="droid-update-device-name">${safeHostname}</span>
                    <span class="droid-update-device-version">v${safeVersion}</span>
                </div>
                <div class="droid-update-status">
                    ${hasUpdate ? `
                        <span class="droid-update-status-icon droid-update-status-icon--pending">&#8593;</span>
                        <span class="text-warning">Update available</span>
                    ` : `
                        <span class="droid-update-status-icon droid-update-status-icon--complete">&#10004;</span>
                        <span class="text-success">Up to date</span>
                    `}
                </div>
            </div>
        `;
    }).join('');

    sectionEl.innerHTML = headerHtml + `<div class="droid-update-list">${devicesHtml}</div>`;
    // Event listeners handled by event delegation in initDroidTab()

    updateDroidUpdateButtonState();
}

/**
 * Update the state of the update button based on checkbox selection
 */
function updateDroidUpdateButtonState() {
    const updateBtn = document.getElementById('droid-update-btn');
    if (!updateBtn) return;

    const checkedBoxes = document.querySelectorAll('.droid-update-check:checked');
    updateBtn.disabled = checkedBoxes.length === 0;
}

/**
 * Start batch update for selected devices
 */
async function startDroidBatchUpdate() {
    const checkedBoxes = document.querySelectorAll('.droid-update-check:checked');
    if (checkedBoxes.length === 0) return;

    const devices = Array.from(checkedBoxes).map(cb => ({
        hostname: cb.dataset.hostname,
        ip: cb.dataset.ip
    }));

    const btn = document.getElementById('droid-update-btn');
    if (btn) setButtonLoading(btn, true, 'Starting...');

    try {
        const response = await fetch('/api/droid/updates/batch', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ devices })
        });
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        const data = await response.json();

        if (data.success) {
            DroidNet.state.droid.updateInProgress = true;
            DroidNet.state.droid.updatePollingId = null;
            pollDroidUpdateProgress();
        } else {
            showDroidError('Failed to start batch update: ' + (data.error || 'Unknown error'));
        }
    } catch (error) {
        console.error('Error starting batch update:', error);
        showDroidError('Error starting batch update');
    } finally {
        if (btn) setButtonLoading(btn, false);
    }
}

/**
 * Poll for batch update progress
 */
async function pollDroidUpdateProgress() {
    if (!DroidNet.state.droid.updateInProgress) return;

    // Clear any existing timeout to prevent stacking
    if (DroidNet.state.droid.updatePollingId) {
        clearTimeout(DroidNet.state.droid.updatePollingId);
        DroidNet.state.droid.updatePollingId = null;
    }

    try {
        const response = await fetch('/api/droid/updates/status');
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        const data = await response.json();

        if (data.devices) {
            renderDroidUpdateProgress(data);

            // Check if all complete
            const allComplete = Object.values(data.devices).every(
                d => d.status === 'complete' || d.status === 'failed' || d.status === 'timeout'
            );

            if (!allComplete) {
                DroidNet.state.droid.updatePollingId = setTimeout(pollDroidUpdateProgress, 2000);
            } else {
                DroidNet.state.droid.updateInProgress = false;
                DroidNet.state.droid.updatePollingId = null;
                // Refresh device list after updates complete
                setTimeout(refreshDroidDevices, 3000);
            }
        }
    } catch (error) {
        console.error('Error polling update progress:', error);
        DroidNet.state.droid.updateInProgress = false;
        DroidNet.state.droid.updatePollingId = null;
    }
}

/**
 * Render update progress
 * @param {Object} data - Batch update status data
 */
function renderDroidUpdateProgress(data) {
    const sectionEl = document.getElementById('droid-updates-section');
    if (!sectionEl) return;

    // Guard against null/undefined devices object
    if (!data.devices || typeof data.devices !== 'object') {
        sectionEl.innerHTML = '<p class="text-danger">Invalid update progress data.</p>';
        return;
    }

    sectionEl.innerHTML = Object.entries(data.devices).map(([hostname, status]) => {
        const progressClass = status.status === 'complete' ? 'droid-progress-fill--success' :
            (status.status === 'failed' ? 'droid-progress-fill--error' : '');
        const statusIcon = status.status === 'complete' ? '&#10004;' :
            (status.status === 'failed' ? '&#10008;' :
                (status.status === 'in_progress' ? '&#8987;' : '&#9679;'));

        // Escape user-controllable data
        const safeHostname = escapeHtml(hostname || '');
        const safeStatus = escapeHtml(status.status || '');
        // Bound progress to 0-100 range
        const progress = Math.max(0, Math.min(100, parseInt(status.progress, 10) || 0));

        return `
            <div class="droid-update-row">
                <span>${statusIcon}</span>
                <span class="droid-device-hostname">${safeHostname}</span>
                <div class="droid-progress">
                    <div class="droid-progress-fill ${progressClass}" style="width: ${progress}%"></div>
                </div>
                <span>${safeStatus}</span>
            </div>
        `;
    }).join('');
}

/**
 * Check for updates and update device rows inline
 * Shows/hides "Update All" button based on results
 */
async function checkDroidUpdatesInline() {
    const btn = document.getElementById('droid-check-updates-btn');
    const updateAllBtn = document.getElementById('droid-update-all-btn');
    if (btn) setButtonLoading(btn, true, 'Checking...');

    try {
        // Fetch updates summary
        const response = await fetch('/api/droid/updates/summary');
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const data = await response.json();

        if (data.success && Array.isArray(data.devices)) {
            // Update the device state with new update info
            const deviceMap = {};
            data.devices.forEach(d => {
                deviceMap[d.hostname] = d.update_available;
            });

            // Update the state
            DroidNet.state.droid.devices.forEach(device => {
                if (deviceMap.hasOwnProperty(device.hostname)) {
                    device.update_available = deviceMap[device.hostname];
                }
            });

            // Re-render device list with updated info
            renderDroidDeviceList(DroidNet.state.droid.devices);

            // Show/hide Update All button based on whether any updates are available
            const hasUpdates = data.devices.some(d => d.update_available);
            if (updateAllBtn) {
                updateAllBtn.style.display = hasUpdates ? 'inline-block' : 'none';
            }
        } else {
            // API returned error or invalid data
            showDroidError('Failed to check for updates: ' + (data.error || 'Invalid response'));
        }
    } catch (error) {
        console.error('Error checking updates:', error);
        showDroidError('Error checking for updates');
    } finally {
        if (btn) setButtonLoading(btn, false);
    }
}

/**
 * Update all devices that have updates available
 */
async function updateAllDroidDevices() {
    const devicesWithUpdates = DroidNet.state.droid.devices.filter(d => d.update_available && d.online);
    if (devicesWithUpdates.length === 0) return;

    const devices = devicesWithUpdates.map(d => ({
        hostname: d.hostname,
        ip: d.ip
    }));

    const btn = document.getElementById('droid-update-all-btn');
    if (btn) setButtonLoading(btn, true, 'Starting...');

    try {
        const response = await fetch('/api/droid/updates/batch', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ devices })
        });
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        const data = await response.json();

        if (data.success) {
            DroidNet.state.droid.updateInProgress = true;
            DroidNet.state.droid.updatePollingId = null;
            pollDroidUpdateProgressInline();
        } else {
            showDroidError('Failed to start batch update: ' + (data.error || 'Unknown error'));
        }
    } catch (error) {
        console.error('Error starting batch update:', error);
        showDroidError('Error starting batch update');
    } finally {
        if (btn) setButtonLoading(btn, false);
    }
}

/**
 * Update a single device from inline button
 * @param {string} hostname - Device hostname
 * @param {string} ip - Device IP address
 */
async function updateSingleDroidDevice(hostname, ip) {
    if (!hostname || !ip) return;

    // Find and disable the button to prevent double-clicks
    const btn = document.querySelector(`.droid-update-device-btn[data-hostname="${hostname}"]`);
    if (btn) {
        btn.disabled = true;
        btn.textContent = '...';
    }

    const devices = [{ hostname, ip }];

    try {
        const response = await fetch('/api/droid/updates/batch', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ devices })
        });
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        const data = await response.json();

        if (data.success) {
            DroidNet.state.droid.updateInProgress = true;
            DroidNet.state.droid.updatePollingId = null;
            pollDroidUpdateProgressInline();
        } else {
            showDroidError('Failed to start update: ' + (data.error || 'Unknown error'));
            // Re-enable button on failure
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = '&#8593;';
            }
        }
    } catch (error) {
        console.error('Error starting update:', error);
        showDroidError('Error starting update for ' + hostname);
        // Re-enable button on error
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = '&#8593;';
        }
    }
}

/**
 * Poll for update progress and update device rows inline
 */
async function pollDroidUpdateProgressInline() {
    if (!DroidNet.state.droid.updateInProgress) return;

    // Clear any existing timeout
    if (DroidNet.state.droid.updatePollingId) {
        clearTimeout(DroidNet.state.droid.updatePollingId);
        DroidNet.state.droid.updatePollingId = null;
    }

    try {
        const response = await fetch('/api/droid/updates/status');
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        const data = await response.json();

        if (data.devices) {
            // Check if all complete
            const allComplete = Object.values(data.devices).every(
                d => d.status === 'complete' || d.status === 'failed' || d.status === 'timeout'
            );

            if (!allComplete) {
                DroidNet.state.droid.updatePollingId = setTimeout(pollDroidUpdateProgressInline, 2000);
            } else {
                DroidNet.state.droid.updateInProgress = false;
                DroidNet.state.droid.updatePollingId = null;
                // Hide Update All button
                const updateAllBtn = document.getElementById('droid-update-all-btn');
                if (updateAllBtn) updateAllBtn.style.display = 'none';
                // Refresh device list after updates complete
                setTimeout(refreshDroidDevices, 3000);
            }
        }
    } catch (error) {
        console.error('Error polling update progress:', error);
        DroidNet.state.droid.updateInProgress = false;
        DroidNet.state.droid.updatePollingId = null;
    }
}

/**
 * Handle firmware file selection for multi-device flash
 * @param {HTMLInputElement} input - File input element
 */
async function handleDroidFirmwareSelect(input) {
    const file = input.files[0];
    const infoEl = document.getElementById('droid-firmware-info');
    const targetsEl = document.getElementById('droid-flash-targets');
    const actionsEl = document.getElementById('droid-flash-actions');

    if (!file) {
        if (infoEl) infoEl.textContent = '';
        if (targetsEl) targetsEl.style.display = 'none';
        if (actionsEl) actionsEl.style.display = 'none';
        return;
    }

    if (infoEl) infoEl.textContent = `${file.name} (${(file.size / 1024).toFixed(1)} KB)`;

    // Read file data
    const reader = new FileReader();
    reader.onload = async function(e) {
        try {
            DroidNet.state.droid.selectedFirmware = file;
            DroidNet.state.droid.selectedFirmwareData = e.target.result;

            // Detect board type from file
            const boardType = detectBoardTypeFromFile(file.name, e.target.result);

            if (!boardType) {
                if (infoEl) infoEl.textContent = `${file.name} - Unknown firmware type`;
                if (targetsEl) targetsEl.style.display = 'none';
                if (actionsEl) actionsEl.style.display = 'none';
                showDroidError('Could not detect firmware type from file');
                return;
            }

            // Show compatible targets
            renderDroidFlashTargets(boardType);
        } catch (error) {
            console.error('Error processing firmware file:', error);
            if (infoEl) infoEl.textContent = 'Error reading file';
            showDroidError('Error processing firmware file');
        }
    };
    reader.onerror = function() {
        console.error('FileReader error:', reader.error);
        if (infoEl) infoEl.textContent = 'Error reading file';
        showDroidError('Error reading firmware file');
    };
    reader.readAsArrayBuffer(file);
}

/**
 * Detect board type from filename and file content
 * @param {string} filename - Firmware filename
 * @param {ArrayBuffer} data - File data
 * @returns {string|null} Detected board type or null if unknown
 */
function detectBoardTypeFromFile(filename, data) {
    if (!data || data.byteLength === 0) {
        console.warn('Empty firmware file');
        return null;
    }

    // Check file extension
    if (filename.endsWith('.hex')) {
        return 'arduino';
    }

    // Check ESP32 magic byte (must be .bin file)
    if (filename.endsWith('.bin')) {
        const view = new Uint8Array(data);
        if (view[0] === 0xE9) {
            return 'esp32';
        }
    }

    // Check for Intel HEX format (starts with ':')
    const view = new Uint8Array(data);
    if (view[0] === 0x3A) {
        return 'arduino';
    }

    // Unknown file type - return null instead of guessing
    console.warn('Could not detect board type for file:', filename);
    return null;
}

/**
 * Check if a USB device is compatible with a given board type for flashing
 * @param {Object} usb - USB device object with type, vendor_id, name
 * @param {string} boardType - Target board type (esp32, arduino)
 * @returns {boolean} Whether the device is compatible
 */
function isFlashCompatible(usb, boardType) {
    // Silicon Labs CP210x (vendor 10c4) is commonly used for ESP32 boards like WCB
    const isSiliconLabs = usb.vendor_id === '10c4' ||
        (usb.name && usb.name.toLowerCase().includes('cp210'));

    // FTDI (vendor 0403) can be used for both ESP32 and Arduino
    const isFTDI = usb.vendor_id === '0403' ||
        (usb.name && usb.name.toLowerCase().includes('ftdi'));

    // CH340/CH341 (vendor 1a86) - common for Arduino clones and some ESP32 boards
    const isCH340 = usb.vendor_id === '1a86' ||
        (usb.name && usb.name.toLowerCase().includes('ch34'));

    // Native Arduino (vendor 2341)
    const isNativeArduino = usb.vendor_id === '2341' ||
        (usb.name && usb.name.toLowerCase().includes('arduino'));

    // Check if this is a known programmable device (has a recognized serial adapter)
    const hasKnownSerialAdapter = isSiliconLabs || isFTDI || isCH340 || isNativeArduino;

    if (boardType === 'esp32') {
        // ESP32 can be flashed via: CP210x, FTDI, CH340, or devices already typed as esp32
        // Do NOT include 'unknown' type - that would match USB hubs and other non-flashable devices
        return usb.type === 'esp32' ||
            isSiliconLabs ||
            isFTDI ||
            isCH340 ||
            // Arduino type with serial bridge chip can flash ESP32
            (usb.type === 'arduino' && hasKnownSerialAdapter);
    } else if (boardType === 'arduino') {
        // Arduino can be flashed via: native Arduino, FTDI, CH340
        // Do NOT include 'unknown' type - that would match USB hubs and other non-flashable devices
        return usb.type === 'arduino' ||
            isNativeArduino ||
            isFTDI ||
            isCH340;
    }

    return false;
}

/**
 * Get device name for grouping - uses raw USB device name without normalization
 * @param {Object} usb - USB device object
 * @returns {string} Device name for grouping
 */
function getDeviceGroupName(usb) {
    // Return the raw device name as reported by the system
    return usb.name || usb.port || 'Unknown Device';
}

/**
 * Get the board type badge for a device group
 * @param {Object} usb - USB device object
 * @param {string} boardType - Target board type being flashed
 * @returns {string} Badge text (ESP32, Arduino, Serial)
 */
function getDeviceTypeBadge(usb, boardType) {
    const name = (usb.name || '').toLowerCase();

    if (name.includes('cp210') || usb.vendor_id === '10c4') {
        return 'ESP32';  // CP210x is primarily used for ESP32
    }
    if (usb.type === 'esp32') {
        return 'ESP32';
    }
    if (usb.type === 'arduino' || name.includes('mega') || name.includes('uno')) {
        return 'Arduino';
    }

    return boardType === 'esp32' ? 'ESP32' : 'Arduino';
}

/**
 * Render flash targets based on compatible devices
 * Groups devices by name and only shows devices appearing on multiple Pis
 * @param {string} boardType - Detected board type
 */
function renderDroidFlashTargets(boardType) {
    const targetsEl = document.getElementById('droid-flash-targets');
    const actionsEl = document.getElementById('droid-flash-actions');
    const flashBtn = document.getElementById('droid-flash-btn');

    if (!targetsEl) return;

    const devices = DroidNet.state.droid.devices.filter(d => d.online);

    // Find compatible USB devices across all devices
    const allTargets = [];
    devices.forEach(device => {
        (device.usb_devices || []).forEach(usb => {
            const compatible = isFlashCompatible(usb, boardType);
            if (compatible) {
                allTargets.push({
                    hostname: device.hostname,
                    ip: device.ip,
                    port: usb.port,
                    name: usb.name || usb.port,
                    type: usb.type,
                    vendor_id: usb.vendor_id || '',
                    groupName: getDeviceGroupName(usb),
                    typeBadge: getDeviceTypeBadge(usb, boardType)
                });
            }
        });
    });

    // Group targets by device name
    const groups = {};
    allTargets.forEach(target => {
        const key = target.groupName;
        if (!groups[key]) {
            groups[key] = {
                name: key,
                typeBadge: target.typeBadge,
                locations: []
            };
        }
        groups[key].locations.push(target);
    });

    // Filter based on showSingleDevices setting
    const showSingle = DroidNet.state.droid.showSingleDevices ?? true;
    const displayGroups = showSingle
        ? Object.values(groups)
        : Object.values(groups).filter(g => g.locations.length > 1);

    if (displayGroups.length === 0) {
        targetsEl.innerHTML = `
            <div class="droid-flash-empty">
                <div class="droid-flash-empty-icon">&#128268;</div>
                <div class="droid-flash-empty-text">
                    ${allTargets.length === 0
                        ? 'No compatible USB devices found for this firmware type.'
                        : 'No matching devices found.'}
                </div>
            </div>
        `;
        targetsEl.style.display = 'block';
        if (actionsEl) actionsEl.style.display = 'none';
        return;
    }

    // Render grouped flash targets
    targetsEl.innerHTML = `<div class="droid-flash-groups">
        ${displayGroups.map(group => {
            const safeGroupName = escapeHtml(group.name);
            return `
                <div class="droid-flash-group">
                    <div class="droid-flash-group-header">
                        <div class="droid-flash-group-title">
                            <span class="droid-flash-group-name">${safeGroupName}</span>
                            <span class="droid-flash-group-type">${escapeHtml(group.typeBadge)}</span>
                        </div>
                        <span class="droid-flash-group-count">${group.locations.length} devices</span>
                    </div>
                    <div class="droid-flash-locations">
                        ${group.locations.map(loc => {
                            const safeHostname = escapeHtml(loc.hostname || '');
                            const safeIp = escapeHtml(loc.ip || '');
                            const safePort = escapeHtml(loc.port || '');
                            return `
                                <label class="droid-flash-location">
                                    <input type="checkbox" class="droid-flash-target-check"
                                        data-hostname="${safeHostname}"
                                        data-ip="${safeIp}"
                                        data-port="${safePort}">
                                    <div class="droid-flash-location-info">
                                        <span class="droid-flash-location-host">${safeHostname}</span>
                                        <span class="droid-flash-location-port">${safePort}</span>
                                    </div>
                                </label>
                            `;
                        }).join('')}
                    </div>
                </div>
            `;
        }).join('')}
    </div>`;

    targetsEl.style.display = 'block';
    if (actionsEl) actionsEl.style.display = 'block';
    // Event listeners handled by event delegation in initDroidTab()

    if (flashBtn) flashBtn.disabled = true;
}

/**
 * Start multi-device firmware flash
 */
async function startDroidMultiFlash() {
    const selected = document.querySelectorAll('.droid-flash-target-check:checked');
    if (selected.length === 0) return;

    if (!DroidNet.state.droid.selectedFirmwareData) {
        alert('No firmware file selected');
        return;
    }

    const targets = Array.from(selected).map(cb => ({
        hostname: cb.dataset.hostname,
        ip: cb.dataset.ip,
        port: cb.dataset.port
    }));

    const flashBtn = document.getElementById('droid-flash-btn');
    if (flashBtn) setButtonLoading(flashBtn, true, 'Flashing...');

    try {
        // Create form data with firmware and targets
        const formData = new FormData();
        formData.append('firmware_file', DroidNet.state.droid.selectedFirmware);
        formData.append('targets', JSON.stringify(targets));

        const response = await fetch('/api/droid/flash/start', {
            method: 'POST',
            body: formData
        });
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        const data = await response.json();

        if (data.success) {
            DroidNet.state.droid.flashInProgress = true;
            DroidNet.state.droid.flashPollingId = null;

            // Record start time for each target
            targets.forEach(t => {
                const key = `${t.hostname}:${t.port}`;
                DroidNet.state.droid.flashStartTimes[key] = Date.now();
            });

            // Show progress section immediately
            const progressEl = document.getElementById('droid-flash-progress');
            if (progressEl) {
                progressEl.style.display = 'block';
                renderDroidFlashProgress({
                    devices: Object.fromEntries(
                        targets.map(t => [`${t.hostname}:${t.port}`, {
                            hostname: t.hostname,
                            port: t.port,
                            status: 'in_progress'
                        }])
                    )
                });
            }

            pollDroidFlashProgress();
        } else {
            showDroidError('Failed to start flash: ' + (data.error || 'Unknown error'));
        }
    } catch (error) {
        console.error('Error starting multi-flash:', error);
        showDroidError('Error starting flash');
    } finally {
        if (flashBtn) setButtonLoading(flashBtn, false);
    }
}

/**
 * Poll for flash progress
 */
async function pollDroidFlashProgress() {
    if (!DroidNet.state.droid.flashInProgress) return;

    // Clear any existing timeout to prevent stacking
    if (DroidNet.state.droid.flashPollingId) {
        clearTimeout(DroidNet.state.droid.flashPollingId);
        DroidNet.state.droid.flashPollingId = null;
    }

    try {
        const response = await fetch('/api/droid/flash/status');
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        const data = await response.json();

        if (data.devices) {
            renderDroidFlashProgress(data);

            // Check if all complete
            const allComplete = Object.values(data.devices).every(
                d => d.status === 'complete' || d.status === 'failed'
            );

            if (!allComplete) {
                DroidNet.state.droid.flashPollingId = setTimeout(pollDroidFlashProgress, 2000);
            } else {
                DroidNet.state.droid.flashInProgress = false;
                DroidNet.state.droid.flashPollingId = null;
                // Clear start times on completion
                DroidNet.state.droid.flashStartTimes = {};
            }
        }
    } catch (error) {
        console.error('Error polling flash progress:', error);
        DroidNet.state.droid.flashInProgress = false;
        DroidNet.state.droid.flashPollingId = null;
    }
}

/**
 * Render flash progress with animated indicators and elapsed time
 * @param {Object} data - Batch flash status data
 */
function renderDroidFlashProgress(data) {
    const progressEl = document.getElementById('droid-flash-progress');
    if (!progressEl) return;

    if (!data.devices || typeof data.devices !== 'object') {
        progressEl.innerHTML = '<p class="text-danger">Invalid flash progress data.</p>';
        progressEl.style.display = 'block';
        return;
    }

    const devices = Object.entries(data.devices);
    const stats = {
        total: devices.length,
        complete: devices.filter(([, d]) => d.status === 'complete').length,
        failed: devices.filter(([, d]) => d.status === 'failed').length,
        inProgress: devices.filter(([, d]) => d.status === 'in_progress' || d.status === 'pending').length
    };

    progressEl.style.display = 'block';
    progressEl.innerHTML = `
        <div class="droid-flash-progress-container">
            <!-- Aggregate Progress -->
            <div class="droid-flash-aggregate">
                <div class="droid-flash-aggregate-header">
                    <span class="droid-flash-aggregate-title">
                        ${stats.inProgress > 0 ? 'Flashing' : 'Flash Complete'}
                    </span>
                    <span class="droid-flash-aggregate-stats">
                        ${stats.complete}/${stats.total} complete
                        ${stats.failed > 0 ? `, ${stats.failed} failed` : ''}
                    </span>
                </div>
                <div class="droid-flash-aggregate-bar">
                    <div class="droid-flash-aggregate-fill ${stats.inProgress > 0 ? 'droid-flash-progress-animated' : ''}"
                         style="width: ${Math.round((stats.complete / stats.total) * 100)}%"></div>
                </div>
            </div>

            <!-- Per-Device Progress -->
            <div class="droid-flash-device-list">
                ${devices.map(([key, status]) => {
                    const startTime = DroidNet.state.droid.flashStartTimes[key];
                    const elapsed = startTime ? Math.floor((Date.now() - startTime) / 1000) : 0;
                    const elapsedStr = elapsed > 0 ? `${elapsed}s` : '--';

                    const isActive = status.status === 'in_progress' || status.status === 'pending';
                    const isComplete = status.status === 'complete';
                    const isFailed = status.status === 'failed';

                    const statusIcon = isComplete ? '&#10004;' : (isFailed ? '&#10008;' : '');
                    const statusClass = isComplete ? 'complete' : (isFailed ? 'failed' : 'active');

                    return `
                        <div class="droid-flash-device-item droid-flash-device-item--${statusClass}">
                            <div class="droid-flash-device-row">
                                <div class="droid-flash-device-info">
                                    ${statusIcon ? `<span class="droid-flash-device-icon">${statusIcon}</span>` : ''}
                                    <span class="droid-flash-device-name">${escapeHtml(status.hostname || '')}</span>
                                    <span class="droid-flash-device-port">${escapeHtml(status.port || '')}</span>
                                </div>
                                <div class="droid-flash-device-status">
                                    <span class="droid-flash-device-elapsed">${elapsedStr}</span>
                                </div>
                            </div>
                            ${isActive ? `
                                <div class="droid-flash-device-bar">
                                    <div class="droid-flash-device-bar-fill droid-flash-progress-animated"></div>
                                </div>
                                <div class="droid-flash-device-phase">Flashing...</div>
                            ` : ''}
                            ${isFailed ? `
                                <div class="droid-flash-device-error">
                                    <span class="droid-flash-error-text">${escapeHtml(status.error || 'Flash failed')}</span>
                                    <button class="btn btn-xs btn-warning droid-flash-retry-btn"
                                            data-hostname="${escapeHtml(status.hostname || '')}"
                                            data-ip="${escapeHtml(status.ip || '')}"
                                            data-port="${escapeHtml(status.port || '')}">
                                        Retry
                                    </button>
                                </div>
                            ` : ''}
                        </div>
                    `;
                }).join('')}
            </div>
        </div>
    `;
    // Note: Retry button click handlers use event delegation via setupDroidEventDelegation()
}

/**
 * Retry a failed flash for a single device
 */
async function retryDroidFlash(hostname, ip, port) {
    if (!DroidNet.state.droid.selectedFirmwareData) {
        showDroidError('No firmware file selected for retry');
        return;
    }

    const target = { hostname, ip, port };
    const key = `${hostname}:${port}`;

    // Record new start time
    DroidNet.state.droid.flashStartTimes[key] = Date.now();

    try {
        const formData = new FormData();
        formData.append('firmware_file', DroidNet.state.droid.selectedFirmware);
        formData.append('targets', JSON.stringify([target]));

        const response = await fetch('/api/droid/flash/start', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }

        const data = await response.json();
        if (!data.success) {
            showDroidError('Retry failed: ' + (data.error || 'Unknown error'));
        } else {
            // Resume polling if not already active
            if (!DroidNet.state.droid.flashInProgress) {
                DroidNet.state.droid.flashInProgress = true;
                pollDroidFlashProgress();
            }
        }
    } catch (error) {
        showDroidError('Retry error: ' + error.message);
    }
}

// Expose to window
window.retryDroidFlash = retryDroidFlash;

/**
 * Initialize Droid tab when it becomes visible
 */
function initDroidTab() {
    setupDroidEventDelegation();
    refreshDroidDevices();
}

// Expose functions to window for onclick handlers
window.refreshDroidDevices = refreshDroidDevices;
window.removeDroidDevice = removeDroidDevice;
window.checkDroidUpdates = checkDroidUpdates;
window.startDroidBatchUpdate = startDroidBatchUpdate;
window.handleDroidFirmwareSelect = handleDroidFirmwareSelect;
window.startDroidMultiFlash = startDroidMultiFlash;
window.checkDroidUpdatesInline = checkDroidUpdatesInline;
window.updateAllDroidDevices = updateAllDroidDevices;
window.updateSingleDroidDevice = updateSingleDroidDevice;
window.pollDroidUpdateProgressInline = pollDroidUpdateProgressInline;

console.log('Droid tab functions loaded');

// ============================================================================
// Theme Management (Light/Dark Mode)
// ============================================================================

/**
 * Initialize theme from localStorage on page load
 */
function initTheme() {
    const savedTheme = localStorage.getItem('droidnet-theme');
    const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;

    // Use saved theme, or fall back to system preference
    const isDarkMode = savedTheme === 'dark' || (savedTheme === null && prefersDark);

    if (isDarkMode) {
        document.body.classList.add('dark-mode');
    }

    // Update toggle checkbox if it exists
    const themeToggle = document.getElementById('theme-toggle');
    if (themeToggle) {
        themeToggle.checked = isDarkMode;
    }

    // Update theme icon
    updateThemeIcon(isDarkMode);
}

/**
 * Toggle between light and dark theme
 * @param {boolean} isDark - Whether to enable dark mode
 */
function toggleTheme(isDark) {
    if (isDark) {
        document.body.classList.add('dark-mode');
        localStorage.setItem('droidnet-theme', 'dark');
    } else {
        document.body.classList.remove('dark-mode');
        localStorage.setItem('droidnet-theme', 'light');
    }

    updateThemeIcon(isDark);
    console.log('Theme changed to:', isDark ? 'dark' : 'light');
}

/**
 * Update theme icon in the modal
 * @param {boolean} isDark - Whether dark mode is active
 */
function updateThemeIcon(isDark) {
    const themeIcon = document.getElementById('theme-icon');
    if (themeIcon) {
        themeIcon.innerHTML = isDark ? '&#9790;' : '&#9788;'; // Moon or Sun
    }
}

// Expose toggleTheme to window for onclick handler
window.toggleTheme = toggleTheme;

// Initialize theme as early as possible (before DOMContentLoaded for flash prevention)
(function() {
    const savedTheme = localStorage.getItem('droidnet-theme');
    if (savedTheme === 'dark') {
        document.body.classList.add('dark-mode');
    }
})();

// Full theme init after DOM is ready (updates checkbox and icon)
document.addEventListener('DOMContentLoaded', initTheme);

console.log('Theme management functions loaded');
