"""
DroidNet Constants Module
Consolidates magic numbers and configuration values used throughout the codebase
"""

from pathlib import Path

# =============================================================================
# Baud Rate Constants
# =============================================================================

BAUD_RATE_STANDARD = 115200
BAUD_RATE_MAESTRO = 9600
BAUD_RATE_MARCDUINO = 9600


# =============================================================================
# Timeout Constants
# =============================================================================

TIMEOUT_DEVICE_INACTIVE_SECONDS = 300  # 5 minutes
TIMEOUT_HISTORY_HOUR_SECONDS = 3600
TIMEOUT_HISTORY_DAY_SECONDS = 86400
TIMEOUT_SERIAL_DEFAULT = 0.1
TIMEOUT_COMMAND_DEFAULT = 30


# =============================================================================
# Path Constants
# =============================================================================

PROJECT_ROOT = Path("/opt/droidnet")
CONFIG_DIR = PROJECT_ROOT / "config"
DATA_DIR = PROJECT_ROOT / "data"
SCRIPTS_DIR = PROJECT_ROOT / "scripts"
WEB_DIR = PROJECT_ROOT / "web"
BIN_DIR = PROJECT_ROOT / "bin"
LOG_DIR = Path("/var/log/droidnet")
RUNTIME_DIR = Path("/var/lib/droidnet")


# =============================================================================
# Network/WiFi Path Constants
# =============================================================================

# Runtime state files
NETWORK_STATE_FILE = RUNTIME_DIR / "network-state"
DROIDNET_MODE_FILE = RUNTIME_DIR / "droidnet-mode"
DROIDNET_MODE_FILE_BOOT = Path("/boot/firmware/droidnet-mode")
FALLBACK_FLAG_FILE = RUNTIME_DIR / "is-fallback"

# System config files
HOSTAPD_CONF_SYSTEM = Path("/etc/hostapd/hostapd.conf")
NETWORKMANAGER_CONNECTIONS_DIR = Path("/etc/NetworkManager/system-connections")

# DroidNet config files
WIFI_CONFIG_FILE = CONFIG_DIR / "wifi-config.json"
NETWORK_SETTINGS_FILE = CONFIG_DIR / "network-settings.json"
HOSTAPD_TEMPLATE_FILE = CONFIG_DIR / "hostapd.conf"

# Scripts
SWITCH_NETWORK_MODE_SCRIPT = SCRIPTS_DIR / "switch-network-mode.sh"
DETECT_VHUSBD_SCRIPT = BIN_DIR / "detect-vhusbd.sh"
VHUSBD_BINARY = BIN_DIR / "vhusbd"


# =============================================================================
# Update/Upgrade Path Constants
# =============================================================================

UPDATE_LOG_FILE = LOG_DIR / "update.log"
UPDATE_STATUS_FILE = RUNTIME_DIR / "update-status.json"
LAST_UPDATE_COMPLETED_FILE = RUNTIME_DIR / "last-update-completed.json"
UPDATE_EXECUTOR_SCRIPT = SCRIPTS_DIR / "update_executor.py"


# =============================================================================
# Firmware/AVR Constants
# =============================================================================

AVRDUDE_CONFIG_PATH = Path("/etc/avrdude.conf")
FLASH_LOG_FILE = LOG_DIR / "flash.log"


# =============================================================================
# Cache Constants
# =============================================================================

CACHE_DEVICE_PORT_TIMEOUT_SECONDS = 5
CACHE_DEVICE_LIST_TIMEOUT_SECONDS = 2
