#!/usr/bin/env python3
"""
DroidNet Update Downloader

Downloads and verifies update packages from GitHub releases.
Provides progress callbacks for UI integration.
"""

import hashlib
import json
import logging
import ssl
import sys
import urllib.request
from pathlib import Path
from typing import Any, Callable, Optional

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from config.constants import RUNTIME_DIR

# Configuration
DOWNLOAD_DIR = Path("/tmp/droidnet-updates")
UPDATE_AVAILABLE_FILE = RUNTIME_DIR / "update-available.json"
CHUNK_SIZE = 8192

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("update_downloader")

# Type alias for progress callback
ProgressCallback = Callable[[int, int], None]


class UpdateDownloader:
    """Downloads and verifies update packages from GitHub."""

    def __init__(self) -> None:
        DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)

    def get_update_info(self) -> Optional[dict[str, Any]]:
        """Get current update available info."""
        try:
            if UPDATE_AVAILABLE_FILE.exists():
                with open(UPDATE_AVAILABLE_FILE) as f:
                    return json.load(f)
        except Exception as e:
            logger.error(f"Failed to read update info: {e}")
        return None

    def download_with_progress(
        self,
        url: str,
        dest_path: Path,
        progress_callback: Optional[ProgressCallback] = None,
    ) -> bool:
        """Download file with optional progress callback.

        Args:
            url: URL to download from
            dest_path: Local path to save file
            progress_callback: Optional function(downloaded, total) called during download

        Returns:
            True if download succeeded
        """
        try:
            ctx = ssl.create_default_context()
            request = urllib.request.Request(
                url, headers={"User-Agent": "DroidNet-Updater/1.0"}
            )

            logger.info(f"Downloading from: {url}")

            with urllib.request.urlopen(
                request, context=ctx, timeout=300
            ) as response:
                total_size = int(response.headers.get("content-length", 0))
                downloaded = 0

                logger.info(f"Total size: {total_size / 1024 / 1024:.1f} MB")

                with open(dest_path, "wb") as f:
                    while True:
                        chunk = response.read(CHUNK_SIZE)
                        if not chunk:
                            break
                        f.write(chunk)
                        downloaded += len(chunk)

                        if progress_callback and total_size:
                            progress_callback(downloaded, total_size)

            logger.info(f"Download complete: {dest_path}")
            return True

        except Exception as e:
            logger.error(f"Download failed: {e}")
            # Clean up partial download
            if dest_path.exists():
                dest_path.unlink()
            return False

    def verify_checksum(self, file_path: Path, expected_sha256: str) -> bool:
        """Verify SHA256 checksum of downloaded file.

        Args:
            file_path: Path to file to verify
            expected_sha256: Expected SHA256 hash (hex string)

        Returns:
            True if checksum matches
        """
        try:
            sha256_hash = hashlib.sha256()
            with open(file_path, "rb") as f:
                for chunk in iter(lambda: f.read(CHUNK_SIZE), b""):
                    sha256_hash.update(chunk)

            actual = sha256_hash.hexdigest()
            if actual.lower() == expected_sha256.lower():
                logger.info("Checksum verification passed")
                return True
            else:
                logger.error(
                    f"Checksum mismatch: expected {expected_sha256}, got {actual}"
                )
                return False

        except Exception as e:
            logger.error(f"Checksum verification failed: {e}")
            return False

    def download_update(
        self, progress_callback: Optional[ProgressCallback] = None
    ) -> Optional[Path]:
        """Download the available update.

        Args:
            progress_callback: Optional function(downloaded, total) for progress

        Returns:
            Path to downloaded package, or None on failure
        """
        info = self.get_update_info()
        if not info or not info.get("available"):
            logger.error("No update available to download")
            return None

        url = info.get("download_url")
        checksum = info.get("checksum_sha256")
        version = info.get("available_version")

        if not url:
            logger.error("Missing download URL in update info")
            return None

        if not checksum:
            logger.error("Missing checksum in update info - refusing to download")
            return None

        # Download to temp location
        filename = f"droidnet-update-{version}.zip"
        dest_path = DOWNLOAD_DIR / filename

        # Remove existing file if present
        if dest_path.exists():
            logger.info(f"Removing existing download: {dest_path}")
            dest_path.unlink()

        logger.info(f"Downloading update v{version}")

        if not self.download_with_progress(url, dest_path, progress_callback):
            return None

        # Verify checksum
        logger.info("Verifying checksum...")
        if not self.verify_checksum(dest_path, checksum):
            logger.error("Checksum verification failed - deleting corrupted file")
            dest_path.unlink()
            return None

        logger.info(f"Update downloaded and verified: {dest_path}")
        return dest_path

    def download_update_forced(
        self, progress_callback: Optional[ProgressCallback] = None
    ) -> Optional[Path]:
        """Force download the latest update, bypassing version check.

        Fetches release info directly from GitHub and downloads regardless
        of current version. Useful for reinstalling or testing.

        Args:
            progress_callback: Optional function(downloaded, total) for progress

        Returns:
            Path to downloaded package, or None on failure
        """
        try:
            # Fetch releases.json directly
            import ssl
            import urllib.request

            releases_url = "https://raw.githubusercontent.com/travisccook/DroidNetSignalBooster-releases/main/releases.json"
            ctx = ssl.create_default_context()
            request = urllib.request.Request(
                releases_url, headers={"User-Agent": "DroidNet-Updater/1.0"}
            )

            logger.info("Fetching latest release info for forced download...")

            with urllib.request.urlopen(request, context=ctx, timeout=30) as response:
                releases = json.load(response)

            # Get major version from local file
            major_version = "1"
            major_version_file = Path(__file__).parent.parent / "MAJOR_VERSION"
            if major_version_file.exists():
                major_version = major_version_file.read_text().strip()

            latest_info = releases.get("latest", {}).get(major_version)
            if not latest_info:
                logger.error(f"No release found for major version {major_version}")
                return None

            url = latest_info.get("download_url")
            checksum = latest_info.get("checksum_sha256")
            version = latest_info.get("version")

            if not url or not checksum:
                logger.error("Missing download URL or checksum in release info")
                return None

            # Download to temp location
            filename = f"droidnet-update-{version}.zip"
            dest_path = DOWNLOAD_DIR / filename

            # Remove existing file if present
            if dest_path.exists():
                logger.info(f"Removing existing download: {dest_path}")
                dest_path.unlink()

            logger.info(f"Force downloading update v{version}")

            if not self.download_with_progress(url, dest_path, progress_callback):
                return None

            # Verify checksum
            logger.info("Verifying checksum...")
            if not self.verify_checksum(dest_path, checksum):
                logger.error("Checksum verification failed - deleting corrupted file")
                dest_path.unlink()
                return None

            logger.info(f"Update downloaded and verified: {dest_path}")
            return dest_path

        except Exception as e:
            logger.error(f"Forced download failed: {e}")
            return None

    def cleanup_downloads(self) -> None:
        """Remove all downloaded update packages."""
        try:
            for file in DOWNLOAD_DIR.glob("droidnet-update-*.zip"):
                file.unlink()
                logger.info(f"Cleaned up: {file}")
        except Exception as e:
            logger.error(f"Cleanup failed: {e}")


def main() -> None:
    """Run update download."""
    import argparse

    parser = argparse.ArgumentParser(description="DroidNet Update Downloader")
    parser.add_argument(
        "--cleanup", action="store_true", help="Remove downloaded packages"
    )
    parser.add_argument(
        "--verbose", "-v", action="store_true", help="Enable verbose logging"
    )
    args = parser.parse_args()

    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    downloader = UpdateDownloader()

    if args.cleanup:
        downloader.cleanup_downloads()
        print("Cleanup complete")
        sys.exit(0)

    def progress(downloaded: int, total: int) -> None:
        percent = (downloaded / total) * 100
        mb_downloaded = downloaded / 1024 / 1024
        mb_total = total / 1024 / 1024
        print(
            f"\rDownloading: {percent:.1f}% ({mb_downloaded:.1f}/{mb_total:.1f} MB)",
            end="",
            flush=True,
        )

    result = downloader.download_update(progress_callback=progress)
    print()  # New line after progress

    if result:
        print(f"Downloaded to: {result}")
        sys.exit(0)
    else:
        print("Download failed")
        sys.exit(1)


if __name__ == "__main__":
    main()
