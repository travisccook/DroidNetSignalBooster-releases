#!/bin/bash
# Video Player Script for DroidNet Display Feature
# Manages HDMI display power and video playback with proper resource constraints

set -e

# Configuration
VIDEO_DIR="/opt/droidnet/videos"
LOG_FILE="/var/log/droidnet/video-player.log"
PID_FILE="/var/run/droidnet-video.pid"
SUPPORTED_MODELS="Pi Zero 2|Pi 3|Pi 4"

# Logging function
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

# Error logging function
log_error() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ERROR: $1" | tee -a "$LOG_FILE" >&2
}

# Check if Pi model is supported
check_pi_model() {
    if ! grep -qE "$SUPPORTED_MODELS" /proc/cpuinfo; then
        log_error "Unsupported Pi model. Display feature requires Pi Zero 2W, Pi 3, or Pi 4."
        exit 1
    fi
}

# Control HDMI display power
hdmi_power() {
    local state=$1  # 0=off, 1=on

    if command -v vcgencmd &> /dev/null; then
        vcgencmd display_power $state &>> "$LOG_FILE"
        log "HDMI power set to: $state"
    else
        log "vcgencmd not available, HDMI power control unavailable"
    fi
}

# Cleanup function called on exit
cleanup() {
    log "Cleanup: turning off HDMI and removing PID file"
    hdmi_power 0 2>/dev/null || true
    rm -f "$PID_FILE"
}

# Check if video file exists
check_video() {
    local video_path=$1

    if [[ ! -f "$video_path" ]]; then
        log_error "Video file not found: $video_path"
        return 1
    fi

    return 0
}

# Play video with hardware acceleration and priority constraints
play_video() {
    local video_path=$1

    # Check video exists
    if ! check_video "$video_path"; then
        return 1
    fi

    log "Starting playback: $video_path"

    # Turn on HDMI
    hdmi_power 1
    sleep 1  # Give display time to initialize

    # Get framebuffer resolution
    local fb_resolution=$(cat /sys/class/graphics/fb0/virtual_size 2>/dev/null || echo "720,576")
    local fb_width=$(echo "$fb_resolution" | cut -d',' -f1)
    local fb_height=$(echo "$fb_resolution" | cut -d',' -f2)

    log "Framebuffer resolution: ${fb_width}x${fb_height}"

    # Setup cleanup trap
    trap cleanup EXIT INT TERM

    # Use ffmpeg to play video directly to framebuffer
    if ! command -v ffmpeg &> /dev/null; then
        log_error "ffmpeg not found (required for video playback)"
        hdmi_power 0
        return 1
    fi

    log "Using ffmpeg for playback"
    # ffmpeg with:
    # - Real-time playback (-re) to respect frame rate
    # - Scale to fit screen height, crop width to fit
    # - Fast bilinear scaling for better performance
    # - Direct framebuffer output (no X11 needed)
    # - Lower priority
    nice -n 10 ionice -c 2 -n 7 ffmpeg \
        -re \
        -i "$video_path" \
        -vf "scale=-1:${fb_height},crop=${fb_width}:${fb_height}" \
        -sws_flags fast_bilinear \
        -pix_fmt bgra \
        -f fbdev /dev/fb0 \
        &>> "$LOG_FILE" 2>&1 &

    # Save PID for control
    local player_pid=$!
    echo "$player_pid" > "$PID_FILE"
    log "Started ffmpeg (PID: $player_pid)"

    # Wait for playback to complete
    wait "$player_pid"
    local exit_code=$?

    if [[ $exit_code -eq 0 ]]; then
        log "Playback completed successfully"
    else
        log_error "Playback failed with exit code: $exit_code"
    fi

    # Turn off HDMI
    sleep 0.5
    hdmi_power 0

    # Cleanup
    rm -f "$PID_FILE"

    return $exit_code
}

# Main function
main() {
    local video_name=$1

    if [[ -z "$video_name" ]]; then
        log_error "No video name provided"
        echo "Usage: $0 <video_name>"
        exit 1
    fi

    # Check Pi model support
    check_pi_model

    # Construct full path
    local video_path="${VIDEO_DIR}/${video_name}"

    # Add common extensions if no extension provided
    if [[ ! "$video_name" =~ \. ]]; then
        if [[ -f "${video_path}.mp4" ]]; then
            video_path="${video_path}.mp4"
        elif [[ -f "${video_path}.mkv" ]]; then
            video_path="${video_path}.mkv"
        elif [[ -f "${video_path}.avi" ]]; then
            video_path="${video_path}.avi"
        fi
    fi

    # Play the video
    play_video "$video_path"

    exit $?
}

# Run main function
main "$@"