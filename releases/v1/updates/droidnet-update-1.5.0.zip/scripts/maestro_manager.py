#!/usr/bin/env python3
"""
Maestro Device Manager
Manages multiple Maestro controllers with automatic detection
Singleton pattern for centralized device management
"""

import logging
import json
import os
import sys
import glob
import re
from typing import Dict, Optional, List
from dataclasses import dataclass
import threading

# Setup Python paths
sys.path.insert(0, "/opt/droidnet")
from utils.import_helper import setup_paths
from utils.config_helpers import load_json_config, save_json_config

from config.constants import BAUD_RATE_MAESTRO, CONFIG_DIR
from maestro_controller import MaestroController
from maestro_configurator import MaestroConfigurator
from maestro_listener import MaestroListener

logger = logging.getLogger(__name__)


@dataclass
class MaestroDevice:
    """Represents a connected Maestro device."""

    port: str
    serial_number: Optional[str]
    model_info: Dict
    controller: MaestroController
    configurator: Optional[MaestroConfigurator]
    listener: Optional[MaestroListener]


class MaestroManager:
    """
    Singleton manager for all Maestro devices.

    Provides:
    - Automatic device detection
    - Unified control interface
    - State aggregation for all devices
    - Configuration persistence
    """

    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return

        self.devices: Dict[str, MaestroDevice] = {}
        self.config_path = str(CONFIG_DIR / "maestro-config.json")
        self._device_lock = threading.Lock()  # Thread safety for device operations
        self._initialized = True

        # Load saved configuration
        self.load_config()

        logger.info("MaestroManager initialized")

    def detect_devices(self) -> List[Dict]:
        """
        Detect all connected Maestro devices.

        Returns:
            List of device info dictionaries with port, model, serial_number, etc.
        """
        detected = []

        # Use USB configurator to find all Maestro devices
        usb_devices = MaestroConfigurator.list_devices()

        # Match USB devices to serial ports
        # Maestro creates /dev/ttyACM* devices
        acm_ports = sorted(glob.glob("/dev/ttyACM*"))

        for usb_dev in usb_devices:
            # Find matching serial port
            # For now, we'll use simple matching based on discovery order
            # In production, would use USB bus/address to match to /sys/devices
            port = None
            if acm_ports:
                # Simple heuristic: match in order of discovery
                port = acm_ports.pop(0)

            detected.append(
                {
                    "serial_number": usb_dev["serial_number"],
                    "model": usb_dev["model"],
                    "channels": usb_dev["channels"],
                    "is_mini": usb_dev["is_mini"],
                    "port": port,
                    "product_id": usb_dev["product_id"],
                }
            )

        logger.info(f"Detected {len(detected)} Maestro device(s)")
        return detected

    def add_device(
        self,
        port: str,
        serial_number: Optional[str] = None,
        start_listener: bool = True,
        baud: int = BAUD_RATE_MAESTRO,
    ) -> bool:
        """
        Add and connect to a Maestro device.

        Args:
            port: Serial port path
            serial_number: USB serial number for configuration
            start_listener: Whether to start the position listener
            baud: Baud rate (default 9600 for Maestro)

        Returns:
            True if device added successfully
        """
        # Validate port path for security
        if not re.match(r"^/dev/(ttyACM|ttyUSB|maestro_)\d*", port):
            logger.error(f"Invalid port path: {port}")
            return False

        # Check if device already exists (with lock)
        with self._device_lock:
            if port in self.devices:
                logger.warning(f"Device already exists on {port}")
                return True

        # Create controller (outside lock - slow I/O operation)
        controller = MaestroController(port, baud=baud)
        if not controller.connect():
            logger.error(f"Failed to connect to Maestro on {port}")
            return False

        # Create configurator if serial number provided
        configurator = None
        model_info = None

        if serial_number:
            configurator = MaestroConfigurator(serial_number)
            if configurator.connect():
                model_info = configurator.model_info
            else:
                logger.warning(
                    f"Failed to connect USB configurator for {serial_number}"
                )
                configurator = None

        # If no model info from USB, try to detect from available devices
        if not model_info:
            detected = MaestroConfigurator.list_devices()
            if detected:
                # Use first detected device as fallback
                model_info = {
                    "name": detected[0]["model"],
                    "channels": detected[0]["channels"],
                    "mini": detected[0]["is_mini"],
                }
            else:
                # Default to Micro 6 if unknown
                model_info = {"name": "Unknown Maestro", "channels": 6, "mini": False}

        # Set controller's max_channels from detected model
        controller.max_channels = model_info.get("channels", 6)

        # Create listener (note: must be started via async start() method)
        listener = None
        if start_listener:
            listener = MaestroListener(controller, model_info)
            # Listener must be started in async context via listener.start()

        # Store device (with lock)
        with self._device_lock:
            self.devices[port] = MaestroDevice(
                port=port,
                serial_number=serial_number,
                model_info=model_info,
                controller=controller,
                configurator=configurator,
                listener=listener,
            )

        logger.info(f"Added Maestro device on {port}: {model_info['name']}")

        # Save configuration
        self.save_config()

        return True

    def remove_device(self, port: str):
        """
        Remove and disconnect a device.

        Args:
            port: Serial port path
        """
        with self._device_lock:
            if port not in self.devices:
                logger.warning(f"Device not found on {port}")
                return

            device = self.devices[port]

            # Note: Listener stop should be called in async context before this
            if device.configurator:
                device.configurator.disconnect()

            device.controller.disconnect()

            del self.devices[port]

        logger.info(f"Removed Maestro device on {port}")

        # Save configuration
        self.save_config()

    def has_device(self, port: str) -> bool:
        """
        Check if a device exists.

        Args:
            port: Serial port path

        Returns:
            True if device exists
        """
        with self._device_lock:
            return port in self.devices

    def get_device(self, port: str) -> Optional[MaestroDevice]:
        """
        Get device by port.

        Args:
            port: Serial port path

        Returns:
            MaestroDevice or None
        """
        with self._device_lock:
            return self.devices.get(port)

    def get_listener(self, port: str) -> Optional[MaestroListener]:
        """
        Get listener for a device.

        Args:
            port: Serial port path

        Returns:
            MaestroListener or None
        """
        with self._device_lock:
            device = self.devices.get(port)
            return device.listener if device else None

    def list_devices(self) -> List[Dict]:
        """
        List all managed devices.

        Returns:
            List of device info dictionaries
        """
        with self._device_lock:
            devices = []
            for port, device in self.devices.items():
                devices.append(
                    {
                        "port": port,
                        "serial_number": device.serial_number,
                        "model": device.model_info["name"],
                        "channels": device.model_info["channels"],
                        "is_mini": device.model_info.get("mini", False),
                        "has_listener": device.listener is not None,
                        "connected": device.controller.is_connected(),
                    }
                )
            return devices

    # ─────────────────────────────────────────────────────────────────
    # Unified Control Interface
    # ─────────────────────────────────────────────────────────────────

    def set_target(self, port: str, channel: int, target: int) -> bool:
        """
        Set servo target on a device.

        Args:
            port: Serial port path
            channel: Channel number
            target: Target in quarter-microseconds

        Returns:
            True if successful
        """
        device = self.devices.get(port)
        if not device:
            logger.error(f"Device not found on {port}")
            return False

        result = device.controller.set_target(channel, target)

        # Update listener state if present
        if device.listener and result:
            device.listener.update_target(channel, target)

        return result

    def set_speed(self, port: str, channel: int, speed: int) -> bool:
        """
        Set servo speed on a device.

        Args:
            port: Serial port path
            channel: Channel number
            speed: Speed limit

        Returns:
            True if successful
        """
        device = self.devices.get(port)
        if not device:
            logger.error(f"Device not found on {port}")
            return False

        result = device.controller.set_speed(channel, speed)

        # Update listener state if present
        if device.listener and result:
            device.listener.update_speed(channel, speed)

        return result

    def set_acceleration(self, port: str, channel: int, acceleration: int) -> bool:
        """
        Set servo acceleration on a device.

        Args:
            port: Serial port path
            channel: Channel number
            acceleration: Acceleration limit

        Returns:
            True if successful
        """
        device = self.devices.get(port)
        if not device:
            logger.error(f"Device not found on {port}")
            return False

        result = device.controller.set_acceleration(channel, acceleration)

        # Update listener state if present
        if device.listener and result:
            device.listener.update_acceleration(channel, acceleration)

        return result

    def go_home(self, port: str) -> bool:
        """
        Send all servos to home position.

        Args:
            port: Serial port path

        Returns:
            True if successful
        """
        device = self.devices.get(port)
        if not device:
            logger.error(f"Device not found on {port}")
            return False

        result = device.controller.go_home()

        # Read back positions and update listener state
        # This ensures UI reflects actual servo positions after go_home
        if result and device.listener:
            num_channels = device.model_info.get("channels", 0)
            for channel in range(num_channels):
                position = device.controller.get_position(channel)
                if position is not None:
                    device.listener.update_target(channel, position)

        return result

    def stop_script(self, port: str) -> bool:
        """
        Stop running script.

        Args:
            port: Serial port path

        Returns:
            True if successful
        """
        device = self.devices.get(port)
        if not device:
            logger.error(f"Device not found on {port}")
            return False
        return device.controller.stop_script()

    def restart_script(self, port: str) -> bool:
        """
        Restart script from beginning.

        Args:
            port: Serial port path

        Returns:
            True if successful
        """
        device = self.devices.get(port)
        if not device:
            logger.error(f"Device not found on {port}")
            return False
        return device.controller.restart_script()

    def run_subroutine(self, port: str, subroutine: int) -> bool:
        """
        Run a script subroutine.

        Args:
            port: Serial port path
            subroutine: Subroutine number

        Returns:
            True if successful
        """
        device = self.devices.get(port)
        if not device:
            logger.error(f"Device not found on {port}")
            return False
        return device.controller.restart_script_at_subroutine(subroutine)

    def get_state(self, port: str) -> Optional[Dict]:
        """
        Get complete device state.

        Args:
            port: Serial port path

        Returns:
            State dictionary or None
        """
        device = self.devices.get(port)
        if not device:
            logger.error(f"Device not found on {port}")
            return None

        if device.listener:
            return device.listener.get_state()

        # Fallback: query positions directly
        state = {
            "port": port,
            "model": device.model_info["name"],
            "channels": device.model_info["channels"],
            "connected": device.controller.is_connected(),
            "servos": {},
        }

        for ch in range(device.model_info["channels"]):
            pos = device.controller.get_position(ch)
            state["servos"][ch] = {
                "position": pos,
                "position_us": pos / 4.0 if pos else None,
            }

        return state

    def get_all_states(self) -> Dict[str, Dict]:
        """
        Get states for all devices.

        Returns:
            Dictionary mapping port to state dictionary
        """
        return {port: self.get_state(port) for port in self.devices}

    # ─────────────────────────────────────────────────────────────────
    # Configuration Persistence
    # ─────────────────────────────────────────────────────────────────

    def load_config(self) -> None:
        """Load configuration from file."""
        config = load_json_config(self.config_path, defaults={})

        if not config:
            logger.info("No saved Maestro configuration found")
            return

        try:
            # Auto-connect devices if configured
            for device_config in config.get("devices", []):
                port = device_config.get("port")
                if port and device_config.get("auto_connect", False):
                    logger.info(f"Auto-connecting to {port}")
                    self.add_device(
                        port=port,
                        serial_number=device_config.get("serial_number"),
                        start_listener=device_config.get("start_listener", True),
                        baud=device_config.get("baud", BAUD_RATE_MAESTRO),
                    )

            logger.info("Loaded Maestro configuration")

        except (ValueError, KeyError) as e:
            logger.error(f"Invalid data in Maestro configuration: {e}")

    def save_config(self) -> None:
        """Save configuration to file."""
        config = {"devices": []}

        for port, device in self.devices.items():
            config["devices"].append(
                {
                    "port": port,
                    "serial_number": device.serial_number,
                    "model": device.model_info["name"],
                    "channels": device.model_info["channels"],
                    "auto_connect": True,
                    "start_listener": device.listener is not None,
                    "baud": device.controller.baud,
                }
            )

        if save_json_config(self.config_path, config):
            logger.info("Saved Maestro configuration")
        else:
            logger.error("Failed to save Maestro configuration")


# Singleton accessor
def get_maestro_manager() -> MaestroManager:
    """
    Get the singleton MaestroManager instance.

    Returns:
        MaestroManager singleton
    """
    return MaestroManager()
