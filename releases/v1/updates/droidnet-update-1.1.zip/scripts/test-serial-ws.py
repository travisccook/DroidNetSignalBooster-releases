#!/usr/bin/env python3
"""Test WebSocket serial connection to diagnose hanging issue"""

import asyncio
import websockets
import sys


async def test_serial_connection(host, port="/dev/ttyUSB0", baud=115200):
    uri = f"ws://{host}:8080/api/serial/ws?port={port}&baud={baud}"
    print(f"Connecting to: {uri}")

    try:
        async with websockets.connect(uri, ping_timeout=5) as websocket:
            print("WebSocket connected successfully")

            # Wait for initial connection message
            message = await asyncio.wait_for(websocket.recv(), timeout=5)
            print(f"Received: {message}")

            # Send a test command
            await websocket.send("test")
            print("Sent test message")

            # Try to receive a few messages
            for i in range(3):
                try:
                    message = await asyncio.wait_for(websocket.recv(), timeout=2)
                    print(f"Received: {message}")
                except asyncio.TimeoutError:
                    print(f"Timeout waiting for message {i+1}")

            await websocket.close()
            print("Connection closed successfully")

    except asyncio.TimeoutError:
        print("ERROR: Connection timed out")
    except Exception as e:
        print(f"ERROR: {type(e).__name__}: {e}")


if __name__ == "__main__":
    host = sys.argv[1] if len(sys.argv) > 1 else "droidnet.local"
    asyncio.run(test_serial_connection(host))
