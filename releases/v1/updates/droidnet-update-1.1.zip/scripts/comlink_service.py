#!/usr/bin/env python3
"""
DroidNet Comlink Service
Handles UDP communication with Comlink mobile app for remote serial command execution
"""

import os
import sys
import json
import socket
import threading
import time
import logging
import subprocess
import serial
from typing import Dict, List, Optional, Any

# Setup Python paths
sys.path.insert(0, "/opt/droidnet")
from utils.import_helper import setup_paths
from utils.config_helpers import load_json_config, save_json_config

# Import USB manager for device identification
try:
    from usb_manager import USBManager
except ImportError:
    USBManager = None

# Import constants
from config.constants import (
    CACHE_DEVICE_PORT_TIMEOUT_SECONDS,
    TIMEOUT_DEVICE_INACTIVE_SECONDS,
    CONFIG_DIR,
    DATA_DIR,
    LOG_DIR,
)

# Configuration
CONFIG_PATH = str(CONFIG_DIR / "comlink_config.json")
HISTORY_FILE = str(DATA_DIR / "comlink_history.json")
DEVICES_FILE = str(DATA_DIR / "comlink_devices.json")
VICTRON_TELEMETRY_FILE = str(DATA_DIR / "victron_telemetry.json")
LOG_FILE = str(LOG_DIR / "comlink.log")

# Default ports
DEFAULT_COMMAND_PORT = 8080
DEFAULT_DISCOVERY_PORT = 8081

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[logging.FileHandler(LOG_FILE), logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger(__name__)


class ComlinkService:
    def __init__(self):
        self.config = self.load_config()
        self.running = False
        self.command_socket = None
        self.discovery_socket = None
        self.command_count = 0
        self.active_devices = {}
        self.port_cache = {}  # Cache for device port lookups
        self.last_port_check = {}  # Track last port check time
        self._mac_address = None  # Cache MAC address

        # Ensure data directory exists
        os.makedirs(str(DATA_DIR), exist_ok=True)

    def load_config(self) -> Dict[str, Any]:
        """Load configuration from file"""
        default_config = {
            "enabled": True,
            "command_port": DEFAULT_COMMAND_PORT,
            "discovery_port": DEFAULT_DISCOVERY_PORT,
            "default_target": "usb",
            "default_usb_device": None,  # Stores device unique ID
            "default_gpio_pin": 27,
            "default_baud_rate": 115200,
            "history_size": 1000,
            "discovery_interval": 5,
            "command_timeout": 100,
            "add_cr_termination": True,
        }

        config = load_json_config(CONFIG_PATH, defaults=default_config)

        if config.get("default_usb_device"):
            device = config["default_usb_device"]
            logger.info(f"Loaded device config: {device}")

        return config

    def save_config(self) -> None:
        """Save current configuration to file"""
        if save_json_config(CONFIG_PATH, self.config):
            logger.info("Configuration saved successfully")
        else:
            logger.error("Failed to save configuration")

    def start(self):
        """Start the Comlink service"""
        self.running = True
        logger.info("Starting Comlink service")

        # Start command listener thread
        command_thread = threading.Thread(target=self.command_listener)
        command_thread.daemon = True
        command_thread.start()

        # Start discovery broadcaster thread
        discovery_thread = threading.Thread(target=self.discovery_broadcaster)
        discovery_thread.daemon = True
        discovery_thread.start()

        # Start device cleanup thread
        cleanup_thread = threading.Thread(target=self.device_cleanup)
        cleanup_thread.daemon = True
        cleanup_thread.start()

        logger.info(
            f"Comlink service started - Command port: {self.config['command_port']}, "
            f"Discovery port: {self.config['discovery_port']}"
        )

        # Keep the main thread alive
        try:
            while self.running:
                time.sleep(1)
        except KeyboardInterrupt:
            self.stop()

    def stop(self):
        """Stop the Comlink service"""
        logger.info("Stopping Comlink service")
        self.running = False

        # Close sockets
        if self.command_socket:
            self.command_socket.close()
        if self.discovery_socket:
            self.discovery_socket.close()

        logger.info("Comlink service stopped")

    def command_listener(self):
        """Listen for incoming commands on UDP port"""
        try:
            self.command_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.command_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.command_socket.bind(("", self.config["command_port"]))
            self.command_socket.settimeout(
                1.0
            )  # 1 second timeout for checking self.running

            logger.info(
                f"Command listener started on port {self.config['command_port']}"
            )

            while self.running:
                try:
                    data, addr = self.command_socket.recvfrom(4096)

                    # Process command in separate thread
                    thread = threading.Thread(
                        target=self.process_command, args=(data, addr)
                    )
                    thread.daemon = True
                    thread.start()

                except socket.timeout:
                    continue
                except (socket.error, OSError, ConnectionError) as e:
                    if self.running:
                        logger.error(f"Error in command listener: {e}")

        except (socket.error, OSError, ConnectionError) as e:
            logger.error(f"Failed to start command listener: {e}")

    def process_command(self, data, addr):
        """Process incoming command"""
        try:
            # Parse JSON command
            command_data = json.loads(data.decode("utf-8"))
            logger.info(f"Received command from {addr}: {command_data}")

            # Update device info (always track devices, even if command is not for us)
            device_id = command_data.get("device_id", str(addr))
            source = command_data.get("source", "unknown")
            self.update_device_info(device_id, addr[0], source)

            # Check if command is for this booster
            target_booster = command_data.get("target_booster")
            if target_booster:
                # Get this device's MAC address
                mac_address = self.get_mac_address()
                hostname = socket.gethostname()

                # Check if target matches our MAC or hostname
                if target_booster not in [mac_address, hostname]:
                    logger.info(
                        f"Command not for this booster (target: {target_booster}, "
                        f"our MAC: {mac_address}, hostname: {hostname})"
                    )
                    # Send NAK response
                    response = {
                        "status": "ignored",
                        "message": "Command for different booster",
                        "timestamp": time.time(),
                    }
                    self.send_response(addr, response)
                    return

            # Process the command
            command_type = command_data.get("command")
            logger.info(f"Processing command type: {command_type}")

            if command_type == "serial_send":
                logger.info("Calling handle_serial_command...")
                result = self.handle_serial_command(command_data)
                logger.info(f"handle_serial_command returned: {result}")
            elif command_data.get("command") == "keep_alive":
                result = self.handle_keep_alive(command_data)
            else:
                result = {
                    "status": "error",
                    "message": f"Unknown command: {command_data.get('command')}",
                    "timestamp": time.time(),
                }

            # Send response
            self.send_response(addr, result)

            # Log command to history
            self.log_command(command_data, addr[0], result["status"])

        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON from {addr}: {e}")
            response = {
                "status": "error",
                "message": "Invalid JSON format",
                "timestamp": time.time(),
            }
            self.send_response(addr, response)
        except (ValueError, OSError, ConnectionError) as e:
            logger.error(f"Error processing command from {addr}: {e}")
            response = {"status": "error", "message": str(e), "timestamp": time.time()}
            self.send_response(addr, response)

    def get_current_port_for_device(self, device_config):
        """Find the current port for a device by its unique ID with caching"""
        if not USBManager or not device_config:
            return None

        try:
            unique_id = device_config.get("unique_id")
            if not unique_id:
                return None

            # Check cache first
            cache_timeout = CACHE_DEVICE_PORT_TIMEOUT_SECONDS
            now = time.time()
            if unique_id in self.port_cache and unique_id in self.last_port_check:
                if now - self.last_port_check[unique_id] < cache_timeout:
                    cached_port = self.port_cache[unique_id]
                    logger.debug(
                        f"Using cached port {cached_port} for device {unique_id}"
                    )
                    return cached_port

            # Not in cache or cache expired, look up the device
            usb_manager = USBManager()
            devices = usb_manager.get_usb_devices()

            for device in devices:
                if device.unique_id == unique_id:
                    port = device.get_serial_port()
                    if port:
                        logger.info(f"Found device {unique_id} at port {port}")

                        # Update cache
                        self.port_cache[unique_id] = port
                        self.last_port_check[unique_id] = now

                        # Check if port changed from saved config
                        saved_port = device_config.get("last_known_port")
                        if saved_port != port:
                            logger.info(
                                f"Port changed from {saved_port} to {port}, updating config"
                            )
                            # Update the device config
                            device_config["last_known_port"] = port
                            # Update in main config
                            if (
                                self.config.get("default_usb_device")
                                and self.config["default_usb_device"].get("unique_id")
                                == unique_id
                            ):
                                self.config["default_usb_device"][
                                    "last_known_port"
                                ] = port
                                self.save_config()

                        return port

            logger.warning(f"Device {unique_id} not found on any port")
            # Clear cache for this device
            self.port_cache.pop(unique_id, None)
            self.last_port_check.pop(unique_id, None)
            return None

        except (OSError, ValueError) as e:
            logger.error(f"Error finding device port: {e}")
            return None

    def handle_serial_command(self, command_data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle serial send command"""
        logger.info(f"Entering handle_serial_command with data: {command_data}")
        try:
            payload = command_data.get("payload", "")
            logger.debug(f"Extracted payload: {repr(payload)}")
            if not payload:
                return {
                    "status": "error",
                    "message": "No payload specified",
                    "timestamp": time.time(),
                }

            # Determine target
            target = command_data.get("target") or self.config["default_target"]
            logger.info(f"Target device type: {target}")

            # Add CR termination if configured
            if self.config["add_cr_termination"] and not payload.endswith("\r"):
                payload += "\r"
                logger.debug(f"Added CR termination, payload now: {repr(payload)}")

            # Send to appropriate output
            if target == "usb":
                logger.info("Entering USB serial send path")
                port = None

                # Check if we have a device configured with unique ID
                if self.config.get("default_usb_device"):
                    logger.info(
                        f"USB device configured: {self.config['default_usb_device']}"
                    )
                    logger.info(
                        "Attempting to find current port for configured device..."
                    )
                    port = self.get_current_port_for_device(
                        self.config["default_usb_device"]
                    )
                    if port:
                        logger.info(
                            f"Successfully resolved port {port} for device "
                            f"{self.config['default_usb_device']['unique_id']}"
                        )
                    else:
                        device_id = self.config["default_usb_device"]["unique_id"]
                        logger.error(
                            f"Failed to find port for configured device {device_id}"
                        )
                        return {
                            "status": "error",
                            "message": (
                                f"Configured USB device ({device_id}) not found. "
                                "Please check the device is connected or "
                                "reconfigure in the Config tab."
                            ),
                            "timestamp": time.time(),
                        }
                else:
                    logger.error("No USB device configured in comlink_config.json")
                    logger.info(f"Current config: {self.config}")
                    return {
                        "status": "error",
                        "message": (
                            "No USB device configured. Please select a USB device "
                            "in the Config tab under Comlink settings."
                        ),
                        "timestamp": time.time(),
                    }

                # Send via web API for coordinated access
                logger.info(f"Sending command via web API to port {port}")
                success = self.send_via_web_api(port, payload)
                logger.info(f"Web API send returned: {success}")
            else:
                # Send via GPIO
                gpio_pin = (
                    command_data.get("gpio_pin") or self.config["default_gpio_pin"]
                )
                success = self.send_gpio_serial(gpio_pin, payload)

            self.command_count += 1

            return {
                "status": "success" if success else "error",
                "message": "Command sent successfully"
                if success
                else "Failed to send command",
                "timestamp": time.time(),
            }

        except (serial.SerialException, OSError, ValueError) as e:
            logger.error(f"Error handling serial command: {e}", exc_info=True)
            return {"status": "error", "message": str(e), "timestamp": time.time()}

    def send_via_web_api(self, port: str, data: str) -> bool:
        """Send data via web server API for coordinated serial access"""
        try:
            import requests

            # Prepare the API request
            api_url = "http://localhost/api/comlink/send"
            payload = {
                "target": "usb",
                "port": port,
                "payload": data,
                "source": "comlink_service",
            }

            # Send request with timeout
            response = requests.post(api_url, json=payload, timeout=5)

            if response.status_code == 200:
                result = response.json()
                if result.get("success"):
                    baud = result.get("baud_rate", "unknown")
                    logger.info(f"Successfully sent via web API at {baud} baud")
                    return True
                else:
                    error = result.get("error", "Unknown error")
                    logger.error(f"Web API returned error: {error}")
                    return False
            else:
                logger.error(f"Web API returned status {response.status_code}")
                return False

        except requests.exceptions.ConnectionError:
            logger.error(
                "Could not connect to web server - falling back to direct serial"
            )
            # Fallback to direct serial access if web server is down
            return self.send_usb_serial_direct(port, data)
        except (requests.RequestException, OSError) as e:
            logger.error(f"Error sending via web API: {e}", exc_info=True)
            return False

    def send_usb_serial_direct(self, port: str, data: str) -> bool:
        """Direct serial send as fallback when web API unavailable"""
        logger.warning("Using direct serial access as fallback")
        try:
            # Validate port
            if not port or not os.path.exists(port):
                logger.error(f"Invalid port: {port}")
                return False

            # Use saved baud rate if available
            device_config_file = str(CONFIG_DIR / "device-serial-config.json")
            baud_rate = self.config.get("default_baud_rate", 115200)

            if os.path.exists(device_config_file):
                try:
                    with open(device_config_file, "r") as f:
                        device_config = json.load(f)
                        # Try to find saved baud rate for this port
                        for device_id, info in device_config.get("devices", {}).items():
                            if info.get("port") == port:
                                baud_rate = info.get("last_successful_baud", baud_rate)
                                logger.info(
                                    f"Using saved baud rate {baud_rate} for {port}"
                                )
                                break
                except Exception as e:
                    logger.warning(f"Could not load device config: {e}")

            # Send with appropriate baud rate
            with serial.Serial(port, baud_rate, timeout=1) as ser:
                ser.write(data.encode("utf-8"))
                ser.flush()
                logger.info(
                    f"Sent directly to {port} at {baud_rate} baud: {repr(data)}"
                )

            return True

        except (serial.SerialException, OSError, IOError) as e:
            logger.error(f"Error in direct serial send to {port}: {e}", exc_info=True)
            return False

    def send_gpio_serial(self, gpio_pin: int, data: str) -> bool:
        """Send data via GPIO software serial"""
        try:
            # Import our GPIO serial module
            from gpio_serial import send_gpio_serial

            # Send data
            success = send_gpio_serial(gpio_pin, data, self.config["default_baud_rate"])

            if success:
                logger.info(f"Sent to GPIO {gpio_pin}: {repr(data)}")

            return success

        except ImportError as e:
            logger.error(f"GPIO serial module not available: {e}")
            return False
        except (OSError, ValueError) as e:
            logger.error(f"Error sending to GPIO serial {gpio_pin}: {e}")
            return False

    def handle_keep_alive(self, command_data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle keep-alive command"""
        # Just acknowledge the keep-alive
        # The device tracking is already handled in process_command
        return {
            "status": "success",
            "message": "Keep-alive received",
            "timestamp": time.time(),
        }

    def send_response(self, addr, response_data):
        """Send response back to client"""
        try:
            response = json.dumps(response_data).encode("utf-8")
            self.command_socket.sendto(response, addr)
        except (socket.error, OSError) as e:
            logger.error(f"Error sending response to {addr}: {e}")

    def get_broadcast_address(self):
        """Get the broadcast address for the active network interface"""
        try:
            # First check if we're in AP mode
            if os.path.exists("/var/lib/droidnet/network-state"):
                with open("/var/lib/droidnet/network-state", "r") as f:
                    network_state = f.read().strip()
                if network_state == "ap_active":
                    # In AP mode, use the specific broadcast address
                    return "192.168.4.255"

            # For client mode or fallback, try to get broadcast from ip command
            result = subprocess.run(
                ["ip", "-o", "-4", "addr", "show", "wlan0"],
                capture_output=True,
                text=True,
            )
            if result.returncode == 0 and result.stdout:
                # Extract broadcast address from output
                # Format: 3: wlan0 inet 192.168.4.1/24 brd 192.168.4.255 scope ...
                parts = result.stdout.split()
                for i, part in enumerate(parts):
                    if part == "brd" and i + 1 < len(parts):
                        return parts[i + 1]

            # Default fallback
            return "<broadcast>"
        except (subprocess.CalledProcessError, OSError, IOError) as e:
            logger.warning(f"Could not determine broadcast address: {e}")
            return "<broadcast>"

    def discovery_broadcaster(self):
        """Broadcast discovery messages with optional Victron telemetry"""
        network_errors = 0
        max_network_errors = 5

        try:
            self.discovery_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.discovery_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.discovery_socket.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

            logger.info(
                f"Discovery broadcaster started on port {self.config['discovery_port']}"
            )

            while self.running:
                try:
                    # Get device info
                    hostname = socket.gethostname()
                    ip_address = self.get_ip_address()
                    mac_address = self.get_mac_address()

                    # Build base announcement message
                    # Format: DROIDNET_ANNOUNCE:{host}:{ip}:{mac}:{platform}:{caps}
                    announcement = (
                        f"DROIDNET_ANNOUNCE:{hostname}:{ip_address}:"
                        f"{mac_address}:RaspberryPi:serial,gpio"
                    )

                    # Append Victron telemetry if available
                    # Format: ...:{json_telemetry}
                    # Example: ...:{"V":12.8,"I":-2.5,"SOC":85.0,"AH":12.3,"TTG":180}
                    victron_data = self.get_victron_telemetry()
                    if victron_data:
                        # Compact JSON (no spaces) for efficient UDP transmission
                        telemetry_json = json.dumps(victron_data, separators=(",", ":"))
                        announcement = f"{announcement}:{telemetry_json}"

                    # Get the appropriate broadcast address
                    broadcast_addr = self.get_broadcast_address()

                    # Broadcast to the network
                    self.discovery_socket.sendto(
                        announcement.encode("utf-8"),
                        (broadcast_addr, self.config["discovery_port"]),
                    )

                    logger.debug(
                        f"Broadcast discovery to {broadcast_addr}: {announcement}"
                    )
                    network_errors = 0  # Reset error counter on success

                except OSError as e:
                    if e.errno == 101:  # Network unreachable
                        network_errors += 1
                        if network_errors > max_network_errors:
                            # Log once and back off
                            logger.error(
                                "Network unreachable for broadcasts, backing off... "
                                f"(broadcast: {broadcast_addr})"
                            )
                            time.sleep(30)
                            network_errors = 0
                    else:
                        if self.running:
                            logger.error(f"Error broadcasting discovery: {e}")
                except (socket.error, OSError, ConnectionError) as e:
                    if self.running:
                        logger.error(f"Error broadcasting discovery: {e}")

                # Wait for next broadcast interval
                time.sleep(self.config["discovery_interval"])

        except (socket.error, OSError) as e:
            logger.error(f"Failed to start discovery broadcaster: {e}")

    def update_device_info(self, device_id, ip_address, source="unknown"):
        """Update active device information"""
        self.active_devices[device_id] = {
            "id": device_id,
            "ip": ip_address,
            "source": source,
            "last_seen": time.time(),
            "name": f"{source} ({device_id[:8]}...)"
            if len(device_id) > 8
            else f"{source} ({device_id})",
        }

        # Save to file
        try:
            with open(DEVICES_FILE, "w") as f:
                json.dump({"devices": list(self.active_devices.values())}, f, indent=2)
        except (OSError, IOError, json.JSONEncodeError) as e:
            logger.error(f"Error saving device info: {e}")

    def device_cleanup(self):
        """Remove inactive devices"""
        while self.running:
            try:
                current_time = time.time()
                inactive_devices = []

                # Find devices not seen in last 5 minutes
                for device_id, info in self.active_devices.items():
                    if current_time - info["last_seen"] > TIMEOUT_DEVICE_INACTIVE_SECONDS:
                        inactive_devices.append(device_id)

                # Remove inactive devices
                for device_id in inactive_devices:
                    del self.active_devices[device_id]
                    logger.info(f"Removed inactive device: {device_id}")

                # Save updated list if changes were made
                if inactive_devices:
                    try:
                        with open(DEVICES_FILE, "w") as f:
                            json.dump(
                                {"devices": list(self.active_devices.values())},
                                f,
                                indent=2,
                            )
                    except (OSError, IOError, json.JSONEncodeError) as e:
                        logger.error(f"Error saving device info: {e}")

            except (ValueError, OSError) as e:
                logger.error(f"Error in device cleanup: {e}")

            # Check every 10 seconds
            time.sleep(10)

    def log_command(self, command_data, source_ip, status):
        """Log command to history file"""
        try:
            # Load existing history
            if os.path.exists(HISTORY_FILE):
                with open(HISTORY_FILE, "r") as f:
                    history = json.load(f)
            else:
                history = {"commands": []}

            # Clean payload of control characters for JSON serialization
            raw_payload = command_data.get("payload", "")
            # Replace control characters with their escape sequences
            clean_payload = (
                raw_payload.replace("\r", "\\r")
                .replace("\n", "\\n")
                .replace("\t", "\\t")
                .replace("\b", "\\b")
                .replace("\f", "\\f")
            )

            # Remove any other non-printable characters
            clean_payload = "".join(
                c if ord(c) >= 32 or c in "\r\n\t" else f"\\x{ord(c):02x}"
                for c in clean_payload
            )

            # Add new command
            history["commands"].append(
                {
                    "timestamp": time.time(),
                    "command": clean_payload.rstrip("\\r\\n"),
                    "source": f"{command_data.get('source', 'unknown')} ({source_ip})",
                    "target": command_data.get("target", self.config["default_target"]),
                    "status": status,
                }
            )

            # Keep only last N commands
            max_history = self.config["history_size"]
            if len(history["commands"]) > max_history:
                history["commands"] = history["commands"][-max_history:]

            # Save updated history
            with open(HISTORY_FILE, "w") as f:
                json.dump(history, f, indent=2)

        except (OSError, IOError, json.JSONDecodeError, json.JSONEncodeError) as e:
            logger.error(f"Error logging command: {e}")

    def get_serial_ports(self) -> List[str]:
        """Get list of available serial ports"""
        try:
            # List all ttyUSB and ttyACM devices
            import glob

            ports = glob.glob("/dev/ttyUSB*") + glob.glob("/dev/ttyACM*")
            return sorted(ports)
        except (OSError, ValueError) as e:
            logger.error(f"Error getting serial ports: {e}")
            return []

    def get_ip_address(self) -> str:
        """Get device IP address"""
        try:
            # Try to get IP from hostname
            hostname = socket.gethostname()
            ip = socket.gethostbyname(hostname + ".local")
            return ip
        except (socket.error, OSError):
            try:
                # Fallback: get from network interface
                result = subprocess.run(
                    ["hostname", "-I"], capture_output=True, text=True
                )
                ips = result.stdout.strip().split()
                return ips[0] if ips else "Unknown"
            except (subprocess.CalledProcessError, OSError):
                return "Unknown"

    def get_mac_address(self) -> str:
        """Get device MAC address from network interface (cached)"""
        # Return cached MAC if available
        if self._mac_address:
            return self._mac_address

        try:
            # Try wlan0 first (primary wireless interface)
            interfaces = ["wlan0", "eth0"]

            for interface in interfaces:
                mac_file = f"/sys/class/net/{interface}/address"
                if os.path.exists(mac_file):
                    with open(mac_file, "r") as f:
                        mac = f.read().strip()
                        if mac and mac != "00:00:00:00:00:00":
                            self._mac_address = mac.upper()
                            logger.info(
                                f"MAC address cached from {interface}: "
                                f"{self._mac_address}"
                            )
                            return self._mac_address

            # If no valid MAC found, cache and return Unknown
            self._mac_address = "Unknown"
            logger.warning("No valid MAC address found on any interface")
            return self._mac_address
        except (OSError, IOError) as e:
            logger.error(f"Error reading MAC address: {e}")
            self._mac_address = "Unknown"
            return self._mac_address

    def get_victron_telemetry(self) -> Optional[Dict[str, Any]]:
        """
        Load latest Victron telemetry from storage file.

        Returns:
            Dict with telemetry data or None if unavailable.
            Keys: V (voltage), I (current), SOC (state of charge %),
                  AH (consumed Ah), TTG (time to go in minutes)
        """
        try:
            if not os.path.exists(VICTRON_TELEMETRY_FILE):
                return None

            with open(VICTRON_TELEMETRY_FILE, "r") as f:
                snapshot = json.load(f)

            latest = snapshot.get("latest")
            if not latest:
                return None

            # Check if telemetry is stale (older than 60 seconds)
            timestamp = latest.get("timestamp", 0)
            if time.time() - timestamp > 60:
                logger.debug("Victron telemetry is stale, not including in discovery")
                return None

            # Extract fields with abbreviated keys for compact UDP transmission
            # V=Voltage, I=Current, SOC=State of Charge, AH=Consumed Ah, TTG=TTG
            telemetry = {
                "V": round(latest.get("voltage", 0), 2),
                "I": round(latest.get("current", 0), 2),
                "SOC": round(latest.get("soc", 0), 1),
                "AH": round(latest.get("consumed_ah", 0), 2),
                "TTG": latest.get("time_remaining"),  # Can be None
            }

            return telemetry

        except json.JSONDecodeError as e:
            logger.warning(f"Invalid JSON in Victron telemetry file: {e}")
            return None
        except (OSError, IOError, ValueError) as e:
            logger.error(f"Error loading Victron telemetry: {e}")
            return None


def main():
    """Main entry point"""
    # Ensure log directory exists
    os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)

    # Create and start service
    service = ComlinkService()

    try:
        service.start()
    except (OSError, KeyboardInterrupt) as e:
        logger.error(f"Service error: {e}")
        service.stop()
        sys.exit(1)


if __name__ == "__main__":
    main()
