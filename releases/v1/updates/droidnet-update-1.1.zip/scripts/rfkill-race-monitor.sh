#!/bin/bash
# RFKill Race Condition Monitor for debugging
# This script monitors rfkill state changes during mode transitions

LOG_FILE="/var/log/droidnet/rfkill-race-monitor.log"
mkdir -p /var/log/droidnet

echo "[$(date '+%Y-%m-%d %H:%M:%S')] RFKill race monitor started" > "$LOG_FILE"

# Monitor for 30 seconds
end_time=$(($(date +%s) + 30))

while [ $(date +%s) -lt $end_time ]; do
    echo "[$(date '+%Y-%m-%d %H:%M:%S.%N')] === RFKill State ===" >> "$LOG_FILE"
    rfkill list all >> "$LOG_FILE" 2>&1
    
    # Check if any process is accessing rfkill
    if lsof /dev/rfkill 2>/dev/null | grep -v "^COMMAND"; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S.%N')] Processes accessing /dev/rfkill:" >> "$LOG_FILE"
        lsof /dev/rfkill 2>/dev/null >> "$LOG_FILE"
    fi
    
    # Check for state file changes
    if [ -f /var/lib/systemd/rfkill/platform-soc:firmware:wifi.state ]; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S.%N')] systemd rfkill state: $(cat /var/lib/systemd/rfkill/platform-soc:firmware:wifi.state 2>/dev/null)" >> "$LOG_FILE"
    fi
    
    sleep 0.5
done

echo "[$(date '+%Y-%m-%d %H:%M:%S')] RFKill race monitor stopped" >> "$LOG_FILE"