#!/usr/bin/env python3
"""
Marcduino Serial Communication via Software Serial
Uses pigpio for reliable bit-banged serial on GPIO pins
"""

import time
import logging
import string
from typing import Optional

from config.constants import BAUD_RATE_MARCDUINO

try:
    import pigpio
except ImportError:
    print("Error: pigpio module not found. Install with: pip3 install pigpio")
    print("Also ensure pigpiod daemon is running: sudo systemctl start pigpiod")
    import sys

    sys.exit(1)


class MarcduinoController:
    """
    Marcduino serial controller using software serial via pigpio
    Sends commands to droid body for panels, sounds, and effects
    """

    def __init__(self, gpio_pin: int = 17, baud: int = BAUD_RATE_MARCDUINO):
        """
        Initialize Marcduino controller

        Args:
            gpio_pin: GPIO pin number for TX (default 17)
            baud: Baud rate (default 9600)
        """
        self.logger = logging.getLogger(__name__)
        self.gpio_pin = gpio_pin
        self.baud = baud
        self.pi = None
        self.connected = False

        # Command validation
        self.max_command_length = 255
        self.allowed_chars = set(string.printable)

        # Connect to pigpio daemon
        self._connect()

    def _connect(self) -> bool:
        """Connect to pigpio daemon"""
        try:
            self.pi = pigpio.pi()

            if self.pi is None or not self.pi.connected:
                self.logger.error("Failed to connect to pigpiod daemon")
                self.logger.info(
                    "Ensure pigpiod is running: sudo systemctl start pigpiod"
                )
                return False

            # Set GPIO pin as output
            self.pi.set_mode(self.gpio_pin, pigpio.OUTPUT)

            # Set initial state high (idle for UART)
            self.pi.write(self.gpio_pin, 1)

            self.connected = True
            self.logger.info(
                f"Connected to pigpiod, using GPIO{self.gpio_pin} for Marcduino TX"
            )
            return True

        except Exception as e:
            self.logger.error(f"Error connecting to pigpiod: {e}")
            self.connected = False
            return False

    def validate_command(self, command: str) -> str:
        """
        Validate and sanitize serial command

        Args:
            command: Command string to validate

        Returns:
            Sanitized command string
        """
        # Filter non-printable characters
        filtered = "".join(c for c in command if c in self.allowed_chars)

        # Limit length
        filtered = filtered[: self.max_command_length]

        # Ensure carriage return terminator
        if not filtered.endswith("\r"):
            filtered += "\r"

        return filtered

    def send_command(self, command: str) -> bool:
        """
        Send Marcduino command via software serial

        Args:
            command: Command string (will add \r if not present)

        Returns:
            True if sent successfully
        """
        if not self.connected or not self.pi:
            self.logger.error("Not connected to pigpiod")
            return False

        try:
            # Validate and sanitize command
            command = self.validate_command(command)

            self.logger.debug(f"Sending Marcduino command: {repr(command)}")

            # Clear any previous waveforms
            self.pi.wave_clear()

            # Add serial data to waveform
            self.pi.wave_add_serial(self.gpio_pin, self.baud, command.encode("ascii"))

            # Create waveform
            wave_id = self.pi.wave_create()

            if wave_id < 0:
                self.logger.error(f"Failed to create waveform: {wave_id}")
                return False

            # Send waveform
            self.pi.wave_send_once(wave_id)

            # Wait for transmission to complete
            while self.pi.wave_tx_busy():
                time.sleep(0.001)

            # Clean up waveform
            self.pi.wave_delete(wave_id)

            self.logger.info(f"Sent command: {repr(command.rstrip())}")
            return True

        except Exception as e:
            self.logger.error(f"Error sending command: {e}")
            return False

    def send_panel_sequence(self, sequence: int) -> bool:
        """
        Send panel sequence command

        Args:
            sequence: Sequence number (1-11)
                1 = Random Happy
                2 = Random Angry
                3 = Random Scared
                4 = Random Sad
                5 = Random Wave
                6 = Scream (all panels)
                7 = Marching Ants
                8 = Faint/Short Circuit
                9 = Leia Message
                10 = Disco Dance
                11 = Imperial March

        Returns:
            True if sent successfully
        """
        if 1 <= sequence <= 11:
            return self.send_command(f"%T{sequence}")
        else:
            self.logger.error(f"Invalid panel sequence: {sequence}")
            return False

    def send_sound(self, category: int) -> bool:
        """
        Send sound command to HCR Vocalizer

        Args:
            category: Sound category number
                1 = Extreme scared
                2 = More scared
                3 = Scared
                4 = Kinda scared
                5 = Whistle
                6 = Scream
                7 = Alarm
                8 = Happy
                9 = More happy
                10 = Extremely happy
                11 = S2-S5 (varies)
                12 = S2-S5 (varies)
                13 = Yes/Affirmative
                14 = No/Negative

        Returns:
            True if sent successfully
        """
        return self.send_command(f"<SC{category}>")

    def send_volume(self, volume: int) -> bool:
        """
        Set HCR Vocalizer volume

        Args:
            volume: Volume level (0-100)

        Returns:
            True if sent successfully
        """
        volume = max(0, min(100, volume))
        return self.send_command(f"<PVV{volume:03d}>")

    def send_psi_pattern(
        self, front_pattern: Optional[int] = None, rear_pattern: Optional[int] = None
    ) -> bool:
        """
        Set PSI (Processor State Indicator) patterns

        Args:
            front_pattern: Front PSI pattern (0-99, None to skip)
            rear_pattern: Rear PSI pattern (0-99, None to skip)

        Returns:
            True if all commands sent successfully
        """
        success = True

        if front_pattern is not None:
            front_pattern = max(0, min(99, front_pattern))
            if not self.send_command(f"%4T{front_pattern:02d}"):
                success = False

        if rear_pattern is not None:
            rear_pattern = max(0, min(99, rear_pattern))
            if not self.send_command(f"%5T{rear_pattern:02d}"):
                success = False

        return success

    def send_holo_command(self, holo: str, color: int, duration: int) -> bool:
        """
        Send holo projector command

        Args:
            holo: Holo type ('A'=all, 'F'=front, 'R'=rear, 'T'=top)
            color: Color code (0-9999)
            duration: Duration in seconds (0-9)

        Returns:
            True if sent successfully
        """
        if holo not in ["A", "F", "R", "T"]:
            self.logger.error(f"Invalid holo type: {holo}")
            return False

        color = max(0, min(9999, color))
        duration = max(0, min(9, duration))

        if holo == "A":
            # All holos use different format
            return self.send_command(f"%{holo}{color:04d}|{duration}")
        else:
            # Individual holos
            return self.send_command(f"%{holo}{color:04d}")

    def close(self) -> None:
        """Close pigpio connection"""
        if self.pi:
            try:
                # Ensure pin is high (idle)
                self.pi.write(self.gpio_pin, 1)
                self.pi.stop()
                self.logger.info("Closed pigpio connection")
            except Exception as e:
                self.logger.error(f"Error closing pigpio: {e}")

        self.connected = False

    def __del__(self):
        """Cleanup on deletion"""
        self.close()


# Test/Debug functionality
if __name__ == "__main__":
    import sys

    # Set up logging
    logging.basicConfig(
        level=logging.DEBUG,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    # Create controller
    controller = MarcduinoController()

    if not controller.connected:
        print("Failed to connect to pigpiod")
        print("Ensure pigpiod is running: sudo systemctl start pigpiod")
        sys.exit(1)

    print("Marcduino controller ready")
    print("Commands:")
    print("  p1-11  - Panel sequences (e.g., p6 for scream)")
    print("  s1-14  - Sound categories (e.g., s13 for yes)")
    print("  v0-100 - Set volume (e.g., v75)")
    print("  raw    - Send raw command (e.g., raw %T1)")
    print("  q      - Quit")

    try:
        while True:
            cmd = input("> ").strip().lower()

            if cmd == "q":
                break
            elif cmd.startswith("p"):
                try:
                    seq = int(cmd[1:])
                    controller.send_panel_sequence(seq)
                    print(f"Sent panel sequence {seq}")
                except ValueError:
                    print("Invalid sequence number")
            elif cmd.startswith("s"):
                try:
                    cat = int(cmd[1:])
                    controller.send_sound(cat)
                    print(f"Sent sound category {cat}")
                except ValueError:
                    print("Invalid sound category")
            elif cmd.startswith("v"):
                try:
                    vol = int(cmd[1:])
                    controller.send_volume(vol)
                    print(f"Set volume to {vol}")
                except ValueError:
                    print("Invalid volume")
            elif cmd.startswith("raw "):
                raw_cmd = cmd[4:]
                controller.send_command(raw_cmd)
                print(f"Sent raw command: {raw_cmd}")
            else:
                print("Unknown command")

    except KeyboardInterrupt:
        print("\nShutting down...")
    finally:
        controller.close()
