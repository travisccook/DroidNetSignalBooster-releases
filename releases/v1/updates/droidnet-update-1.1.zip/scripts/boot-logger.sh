#!/bin/bash
# DroidNet Boot Logger - Emergency logging mechanism
# Writes directly to boot partition for persistence across reboots

LOG="/boot/firmware/boot-sequence.log"
MARKER_DIR="/boot/firmware/boot-markers"
LOOP_COUNT=0

# Detach from parent process to avoid being killed
if [ "$1" != "detached" ]; then
    # Use nohup to detach from terminal and ignore hangup signals
    nohup "$0" detached </dev/null >/dev/null 2>&1 &
    exit 0
fi

# Ensure we're not killed when parent dies
trap '' HUP TERM

# Create marker directory if it doesn't exist
mkdir -p "$MARKER_DIR" 2>/dev/null || true

# Initial startup message
echo "[$(date '+%Y-%m-%d %H:%M:%S')] Boot logger started from: $0" >> "$LOG"
echo "[$(date '+%Y-%m-%d %H:%M:%S')] Boot logger PID: $$" >> "$LOG"
echo "[$(date '+%Y-%m-%d %H:%M:%S')] Parent process: $(ps -p $PPID -o comm= 2>/dev/null || echo 'unknown')" >> "$LOG"
echo "[$(date '+%Y-%m-%d %H:%M:%S')] Running detached: yes" >> "$LOG"

# Create marker file for boot logger start
touch "$MARKER_DIR/boot-logger-started-$(date +%s)"

# Main logging loop
while true; do
    TIMESTAMP="[$(date '+%Y-%m-%d %H:%M:%S')]"
    
    # Heartbeat with loop counter
    echo "$TIMESTAMP HEARTBEAT #$LOOP_COUNT" >> "$LOG"
    
    # System state summary
    echo "$TIMESTAMP System uptime: $(uptime -p 2>/dev/null || uptime)" >> "$LOG"
    echo "$TIMESTAMP Active services: $(systemctl list-units --type=service --state=active --no-legend 2>/dev/null | wc -l)" >> "$LOG"
    echo "$TIMESTAMP Failed services: $(systemctl list-units --type=service --state=failed --no-legend 2>/dev/null | wc -l)" >> "$LOG"
    
    # DroidNet service status - more detailed
    echo "$TIMESTAMP === DroidNet Service Status ===" >> "$LOG"
    
    # Check each service individually for better detail
    DROIDNET_SERVICES=(
        "droidnet-wifi-setup"
        "droidnet-led"
        "droidnet-web"
        "droidnet-monitor"
        "droidnet-virtualhere"
        "droidnet-firstboot"
        "NetworkManager"
        "ssh"  # Fix-Plan-34: Add SSH status check
    )
    
    for service in "${DROIDNET_SERVICES[@]}"; do
        if systemctl list-unit-files | grep -q "^${service}.service"; then
            STATUS=$(systemctl is-active "${service}.service" 2>/dev/null || echo "unknown")
            ENABLED=$(systemctl is-enabled "${service}.service" 2>/dev/null || echo "unknown")
            echo "$TIMESTAMP ${service}: $STATUS (enabled: $ENABLED)" >> "$LOG"
            
            # If service is failed, capture journal logs
            if [ "$STATUS" = "failed" ]; then
                echo "$TIMESTAMP === Journal for failed service: ${service} ===" >> "$LOG"
                journalctl -u "${service}.service" -n 50 --no-pager 2>&1 >> "$LOG" || echo "$TIMESTAMP   Unable to get journal for ${service}" >> "$LOG"
            fi
        else
            echo "$TIMESTAMP ${service}: not installed" >> "$LOG"
        fi
    done
    
    # Special check for AP configuration
    echo "$TIMESTAMP === AP Configuration Check ===" >> "$LOG"
    if ip addr show wlan0 2>/dev/null | grep -q "192.168.4.1"; then
        echo "$TIMESTAMP AP IP configured: YES (192.168.4.1)" >> "$LOG"
    else
        echo "$TIMESTAMP AP IP configured: NO" >> "$LOG"
        echo "$TIMESTAMP wlan0 addresses: $(ip addr show wlan0 2>/dev/null | grep inet | awk '{print $2}' | tr '\n' ' ')" >> "$LOG"
    fi
    
    # Check for stage markers
    echo "$TIMESTAMP === Boot Stage Markers ===" >> "$LOG"
    if [ -d "$MARKER_DIR" ]; then
        ls -la "$MARKER_DIR/" 2>/dev/null | tail -n +2 >> "$LOG"
    fi
    
    # Memory and disk usage
    echo "$TIMESTAMP Memory: $(free -h | grep Mem | awk '{print "Total:", $2, "Used:", $3, "Free:", $4}')" >> "$LOG"
    echo "$TIMESTAMP Boot partition: $(df -h /boot/firmware | tail -1 | awk '{print "Used:", $3, "of", $2, "("$5" full)"}')" >> "$LOG"
    
    # Network interface status
    echo "$TIMESTAMP Network interfaces:" >> "$LOG"
    ip -br addr show 2>/dev/null | grep -E "^(lo|eth0|wlan0)" >> "$LOG"
    
    # Network Services Status (Fix-Plan-2)
    echo "$TIMESTAMP === Network Services Status ===" >> "$LOG"
    for service in NetworkManager dhcpcd dhcpcd5 hostapd dnsmasq; do
        if systemctl list-unit-files | grep -q "^${service}.service"; then
            status=$(systemctl is-active "$service" 2>/dev/null || echo "unknown")
            enabled=$(systemctl is-enabled "$service" 2>/dev/null || echo "unknown")
            echo "$TIMESTAMP $service: $status (enabled: $enabled)" >> "$LOG"
        fi
    done
    
    # WiFi rfkill state
    echo "$TIMESTAMP WiFi rfkill state:" >> "$LOG"
    if command -v rfkill >/dev/null 2>&1; then
        rfkill list wifi 2>&1 | head -20 >> "$LOG" || echo "$TIMESTAMP   rfkill command failed" >> "$LOG"
    else
        echo "$TIMESTAMP   rfkill not found" >> "$LOG"
    fi
    
    # Check if key processes are running
    echo "$TIMESTAMP Key processes:" >> "$LOG"
    for proc in systemd NetworkManager python3; do
        if pgrep -x "$proc" >/dev/null 2>&1; then
            echo "$TIMESTAMP   $proc: running (PID: $(pgrep -x "$proc" | head -1))" >> "$LOG"
        else
            echo "$TIMESTAMP   $proc: not running" >> "$LOG"
        fi
    done
    
    # Every 5 loops, do a more detailed check
    if [ $((LOOP_COUNT % 5)) -eq 0 ] && [ $LOOP_COUNT -gt 0 ]; then
        echo "$TIMESTAMP === Detailed Service Check ===" >> "$LOG"
        systemctl status droidnet-*.service --no-pager 2>&1 | head -100 >> "$LOG"
        
        # Check NetworkManager status specifically
        echo "$TIMESTAMP === NetworkManager Status ===" >> "$LOG"
        systemctl status NetworkManager --no-pager 2>&1 | head -20 >> "$LOG"
        echo "$TIMESTAMP === NetworkManager Journal (last 20 lines) ===" >> "$LOG"
        journalctl -u NetworkManager -n 20 --no-pager 2>&1 >> "$LOG" || true
        
        # Check AP connection status
        echo "$TIMESTAMP === NetworkManager Connections ===" >> "$LOG"
        nmcli con show 2>&1 >> "$LOG" || true
        nmcli con show --active 2>&1 >> "$LOG" || true
        nmcli device status 2>&1 >> "$LOG" || true
        
        # Also check systemd-analyze if available
        if command -v systemd-analyze >/dev/null 2>&1; then
            echo "$TIMESTAMP === Boot Analysis ===" >> "$LOG"
            systemd-analyze time 2>&1 >> "$LOG"
            echo "$TIMESTAMP Top 10 slowest services:" >> "$LOG"
            systemd-analyze blame 2>&1 | head -10 >> "$LOG"
        fi
    fi
    
    echo "$TIMESTAMP === End of heartbeat ===" >> "$LOG"
    echo "" >> "$LOG"
    
    # Increment loop counter
    LOOP_COUNT=$((LOOP_COUNT + 1))
    
    # More frequent logging during early boot (first 10 loops = 5 minutes)
    if [ $LOOP_COUNT -lt 10 ]; then
        # Sleep for 10 seconds during critical boot phase
        sleep 10
    else
        # Sleep for 30 seconds after boot stabilizes
        sleep 30
    fi
done