#!/usr/bin/env python3
"""
DroidNet Signal Booster - USB Device Manager
Manages USB devices and VirtualHere integration
"""

import os
import re
import subprocess
import json
from typing import List, Dict, Optional, Any


class USBDevice:
    """Represents a USB device"""

    def __init__(
        self,
        bus: str,
        device: str,
        vendor_id: str,
        product_id: str,
        vendor_name: str = "",
        product_name: str = "",
        serial_number: str = "",
        usb_port_path: str = "",
    ):
        self.bus = bus
        self.device = device
        self.vendor_id = vendor_id
        self.product_id = product_id
        self.vendor_name = vendor_name
        self.product_name = product_name
        self.serial_number = serial_number
        self.port_path = f"/dev/bus/usb/{bus}/{device}"
        self.usb_port_path = usb_port_path  # Physical USB topology path (e.g., "1-1.2")
        self.is_locked = False
        self.device_type = self._detect_device_type()
        # Create unique ID using serial number if available, otherwise use USB port path
        # This ensures each physical device has a unique identifier even if multiple
        # identical boards are connected (e.g., multiple Arduino Unos)
        if serial_number:
            self.unique_id = f"{vendor_id}:{product_id}:{serial_number}"
            self.id_type = "serial"
        elif usb_port_path:
            # Use physical USB port path for devices without serial numbers
            # This remains stable as long as device stays in same physical port
            self.unique_id = f"{vendor_id}:{product_id}:port:{usb_port_path}"
            self.id_type = "usb_port"
        else:
            # Fallback to bus:device for devices without serial numbers or port path
            self.unique_id = f"{vendor_id}:{product_id}:{bus}:{device}"
            self.id_type = "bus_device"

    def _detect_device_type(self) -> str:
        """Detect device type based on vendor/product IDs"""
        # Common Arduino vendor IDs and specific product IDs
        arduino_vendors = {
            "2341": "Arduino",  # Arduino LLC
            "1a86": "CH340",  # CH340 USB-Serial
            "0403": "FTDI",  # FTDI USB-Serial
            "10c4": "Silicon Labs",  # CP210x USB-Serial
            "067b": "Prolific",  # PL2303 USB-Serial
        }

        # Specific Arduino product IDs for vendor 2341
        arduino_products = {
            "003f": "Mega ADK",
            "0044": "Mega ADK R3",
            "0043": "Uno Rev3",
            "0042": "Mega 2560 Rev3",
            "0010": "Mega 2560",
            "003d": "Due Programming Port",
            "003e": "Due Native USB Port",
        }

        # Check if it's an Arduino device
        if self.vendor_id.lower() in arduino_vendors:
            # Add specific product name if known
            if (
                self.vendor_id.lower() == "2341"
                and self.product_id.lower() in arduino_products
            ):
                self.product_name = (
                    f"Arduino {arduino_products[self.product_id.lower()]}"
                )
            return "arduino"
        elif "arduino" in self.product_name.lower():
            return "arduino"
        elif any(
            term in self.product_name.lower()
            for term in ["serial", "uart", "usb-to-serial"]
        ):
            return "serial"
        else:
            return "unknown"

    def get_serial_port(self) -> Optional[str]:
        """Get the serial port associated with this USB device"""
        if self.device_type not in ["arduino", "serial"]:
            return None

        try:
            # Method 1: Direct check by vendor/product ID
            for port_pattern in ["/dev/ttyACM*", "/dev/ttyUSB*"]:
                ports = subprocess.run(
                    f"ls {port_pattern} 2>/dev/null",
                    capture_output=True,
                    text=True,
                    shell=True,
                )
                for port in ports.stdout.strip().split("\n"):
                    if port and os.path.exists(port):
                        # Check if this port belongs to our device
                        info = subprocess.run(
                            ["udevadm", "info", "--name=" + port, "--query=property"],
                            capture_output=True,
                            text=True,
                        )
                        info_lower = info.stdout.lower()

                        # Check vendor and product IDs (they might be in hex format)
                        vendor_match = (
                            f"id_vendor_id={self.vendor_id.lower()}" in info_lower
                        )
                        product_match = (
                            f"id_model_id={self.product_id.lower()}" in info_lower
                        )

                        if vendor_match and product_match:
                            return port

            # Method 2: Check sysfs for USB device to tty mapping
            # First, we need to find the actual USB path
            bus_num = int(self.bus)
            dev_num = int(self.device)

            # Look for the device in sysfs - it might be connected through a hub
            for path in os.listdir("/sys/bus/usb/devices/"):
                if path.startswith(f"{bus_num}-"):
                    # Check if this is our device by reading the devnum
                    devnum_path = f"/sys/bus/usb/devices/{path}/devnum"
                    if os.path.exists(devnum_path):
                        try:
                            with open(devnum_path, "r") as f:
                                if int(f.read().strip()) == dev_num:
                                    # Found our device, now look for tty
                                    for i in range(4):  # Check multiple interfaces
                                        tty_path = (
                                            f"/sys/bus/usb/devices/{path}/"
                                            f"{path}:1.{i}/tty"
                                        )
                                        if os.path.exists(tty_path):
                                            tty_devices = os.listdir(tty_path)
                                            if tty_devices:
                                                return f"/dev/{tty_devices[0]}"
                        except (OSError, IOError):
                            pass

        except (subprocess.CalledProcessError, OSError, FileNotFoundError, ValueError) as e:
            print(f"Error finding serial port for {self.get_display_name()}: {e}")

        return None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization"""
        serial_port = self.get_serial_port()
        return {
            "bus": self.bus,
            "device": self.device,
            "vendor_id": self.vendor_id,
            "product_id": self.product_id,
            "vendor_name": self.vendor_name,
            "product_name": self.product_name,
            "serial_number": self.serial_number,
            "unique_id": self.unique_id,
            "id_type": self.id_type,
            "port": self.port_path,
            "usb_port_path": self.usb_port_path,
            "serial_port": serial_port,
            "name": self.get_display_name(),
            "type": self.device_type,
            "status": "locked" if self.is_locked else "available",
            "locked": self.is_locked,
        }

    def get_display_name(self) -> str:
        """Get human-readable device name"""
        if self.vendor_name and self.product_name:
            return f"{self.vendor_name} {self.product_name}"
        elif self.product_name:
            return self.product_name
        elif self.vendor_name:
            return f"{self.vendor_name} Device"
        else:
            return f"USB Device {self.vendor_id}:{self.product_id}"


class USBManager:
    """Manages USB devices and VirtualHere integration"""

    def __init__(self):
        self.virtualhere_available = self._check_virtualhere()

    def _check_virtualhere(self) -> bool:
        """Check if VirtualHere is available"""
        try:
            result = subprocess.run(
                ["which", "vhclient"], capture_output=True, text=True
            )
            return result.returncode == 0
        except (subprocess.CalledProcessError, FileNotFoundError):
            return False

    def _get_usb_port_path(self, bus: str, device: str) -> str:
        """Get the physical USB port path for a device (e.g., '1-1.2')"""
        try:
            bus_num = int(bus)
            dev_num = int(device)

            # Look for the device in sysfs to find its USB topology path
            for path in os.listdir("/sys/bus/usb/devices/"):
                if path.startswith(f"{bus_num}-") and ":" not in path:
                    devnum_path = f"/sys/bus/usb/devices/{path}/devnum"
                    if os.path.exists(devnum_path):
                        with open(devnum_path, "r") as f:
                            if int(f.read().strip()) == dev_num:
                                # Found the device, return its USB path
                                return path
        except (OSError, FileNotFoundError, ValueError):
            pass
        return ""

    def _get_device_serial_number(self, bus: str, device: str) -> str:
        """Get serial number for a specific USB device"""
        try:
            # Method 1: Try using lsusb -v for the specific device
            cmd = ["lsusb", "-v", "-s", f"{int(bus)}:{int(device)}"]
            result = subprocess.run(
                cmd, capture_output=True, text=True, stderr=subprocess.DEVNULL
            )

            if result.returncode == 0:
                # Look for iSerial line in the output
                for line in result.stdout.split("\n"):
                    if "iSerial" in line and " 0 " not in line:
                        # Extract serial number from line like:
                        # "  iSerial                 3 9553034313735161C111"
                        parts = line.strip().split()
                        if len(parts) >= 3:
                            serial = parts[-1]
                            if serial and serial != "0":
                                return serial

            # Method 2: Try using udevadm to get serial number
            try:
                # Find the device path in sysfs
                bus_num = int(bus)
                dev_num = int(device)

                # Look for the device in sysfs
                for path in os.listdir("/sys/bus/usb/devices/"):
                    if path.startswith(f"{bus_num}-"):
                        devnum_path = f"/sys/bus/usb/devices/{path}/devnum"
                        if os.path.exists(devnum_path):
                            with open(devnum_path, "r") as f:
                                if int(f.read().strip()) == dev_num:
                                    # Found the device, now get serial
                                    serial_path = f"/sys/bus/usb/devices/{path}/serial"
                                    if os.path.exists(serial_path):
                                        with open(serial_path, "r") as f:
                                            serial = f.read().strip()
                                            if serial:
                                                return serial
            except (OSError, IOError):
                pass

        except (subprocess.CalledProcessError, OSError, FileNotFoundError, ValueError):
            # Silently fail - serial number is optional
            pass

        return ""

    def get_usb_devices(self) -> List[USBDevice]:
        """Get list of all USB devices"""
        devices = []

        try:
            # Use lsusb to get device information
            result = subprocess.run(["lsusb"], capture_output=True, text=True)

            if result.returncode != 0:
                return devices

            for line in result.stdout.strip().split("\n"):
                if not line.strip():
                    continue

                # Parse lsusb output:
                # Bus 001 Device 002: ID 2341:0043 Arduino LLC Arduino Uno Rev3
                match = re.match(
                    r"Bus (\d+) Device (\d+): ID ([0-9a-f]{4}):([0-9a-f]{4})\s*(.*)",
                    line,
                    re.IGNORECASE,
                )

                if match:
                    bus = match.group(1).zfill(3)
                    device = match.group(2).zfill(3)
                    vendor_id = match.group(3)
                    product_id = match.group(4)
                    description = match.group(5).strip()

                    # Parse vendor and product names from description
                    vendor_name = ""
                    product_name = ""

                    if description:
                        parts = description.split(" ", 2)
                        if len(parts) >= 2:
                            vendor_name = parts[0]
                            if len(parts) >= 3:
                                product_name = " ".join(parts[1:])
                            else:
                                product_name = parts[1]
                        else:
                            product_name = description

                    # Try to get serial number and USB port path for this device
                    serial_number = self._get_device_serial_number(bus, device)
                    usb_port_path = self._get_usb_port_path(bus, device)

                    device_obj = USBDevice(
                        bus,
                        device,
                        vendor_id,
                        product_id,
                        vendor_name,
                        product_name,
                        serial_number,
                        usb_port_path,
                    )

                    # Check if device is locked by VirtualHere
                    if self.virtualhere_available:
                        device_obj.is_locked = self._is_device_locked(
                            device_obj.port_path
                        )

                    devices.append(device_obj)

        except subprocess.CalledProcessError as e:
            print(f"Error running lsusb command: {e}")

        return devices

    def get_arduino_devices(self) -> List[USBDevice]:
        """Get Arduino-compatible devices"""
        all_devices = self.get_usb_devices()
        return [dev for dev in all_devices if dev.device_type == "arduino"]

    def get_device_by_unique_id(self, unique_id: str) -> Optional['USBDevice']:
        """Find a device by its unique ID."""
        devices = self.get_usb_devices()
        for device in devices:
            if device.unique_id == unique_id:
                return device
        return None

    def get_serial_devices(self) -> List[Dict]:
        """Get serial port devices for monitoring"""
        serial_devices = []

        try:
            # Look for serial ports
            for port_pattern in ["/dev/ttyUSB*", "/dev/ttyACM*", "/dev/ttyS*"]:
                result = subprocess.run(
                    ["ls", port_pattern], capture_output=True, text=True, shell=True
                )

                for line in result.stdout.strip().split("\n"):
                    if line and "/dev/tty" in line:
                        port = line.strip()

                        # Try to get device info
                        device_name = self._get_serial_device_name(port)

                        serial_devices.append(
                            {"port": port, "name": device_name, "type": "serial"}
                        )

        except subprocess.CalledProcessError as e:
            print(f"Error listing serial ports: {e}")

        return serial_devices

    def _get_serial_device_name(self, port: str) -> str:
        """Get descriptive name for serial device"""
        try:
            # Try to get device info from udev
            result = subprocess.run(
                ["udevadm", "info", "--name=" + port, "--query=property"],
                capture_output=True,
                text=True,
            )

            vendor = ""
            model = ""

            for line in result.stdout.split("\n"):
                if line.startswith("ID_VENDOR="):
                    vendor = line.split("=", 1)[1]
                elif line.startswith("ID_MODEL="):
                    model = line.split("=", 1)[1]

            if vendor and model:
                return f"{vendor} {model} ({port})"
            elif model:
                return f"{model} ({port})"
            else:
                return f"Serial Device ({port})"

        except subprocess.CalledProcessError:
            return f"Serial Device ({port})"

    def _is_device_locked(self, port_path: str) -> bool:
        """Check if device is locked by VirtualHere"""
        if not self.virtualhere_available:
            return False

        try:
            result = subprocess.run(
                ["vhclient", "-t", "LIST"], capture_output=True, text=True
            )
            return port_path in result.stdout
        except (subprocess.CalledProcessError, FileNotFoundError):
            return False

    def lock_device(self, port_path: str) -> Dict:
        """Lock device with VirtualHere"""
        if not self.virtualhere_available:
            return {"success": False, "message": "VirtualHere not available"}

        try:
            result = subprocess.run(
                ["vhclient", "-t", f"USE,{port_path}"], capture_output=True, text=True
            )

            if result.returncode == 0:
                return {"success": True, "message": "Device locked successfully"}
            else:
                return {"success": False, "message": f"Failed to lock: {result.stderr}"}

        except (subprocess.CalledProcessError, FileNotFoundError) as e:
            return {"success": False, "message": f"Lock command failed: {str(e)}"}

    def unlock_device(self, port_path: str) -> Dict:
        """Unlock device from VirtualHere"""
        if not self.virtualhere_available:
            return {"success": False, "message": "VirtualHere not available"}

        try:
            result = subprocess.run(
                ["vhclient", "-t", f"STOP USING,{port_path}"],
                capture_output=True,
                text=True,
            )

            if result.returncode == 0:
                return {"success": True, "message": "Device unlocked successfully"}
            else:
                return {
                    "success": False,
                    "message": f"Failed to unlock: {result.stderr}",
                }

        except (subprocess.CalledProcessError, FileNotFoundError) as e:
            return {"success": False, "message": f"Unlock command failed: {str(e)}"}

    def get_virtualhere_status(self) -> Dict:
        """Get VirtualHere server status"""
        if not self.virtualhere_available:
            return {"available": False, "message": "VirtualHere not installed"}

        try:
            result = subprocess.run(
                ["vhclient", "-t", "LIST"], capture_output=True, text=True
            )

            return {
                "available": True,
                "running": result.returncode == 0,
                "devices": result.stdout.strip().split("\n")
                if result.stdout.strip()
                else [],
            }
        except (subprocess.CalledProcessError, FileNotFoundError) as e:
            return {"available": True, "running": False, "error": str(e)}


def main():
    """Command line interface for testing"""
    import argparse

    parser = argparse.ArgumentParser(description="USB Device Manager")
    parser.add_argument(
        "command", choices=["list", "arduino", "serial", "lock", "unlock", "status"]
    )
    parser.add_argument("--port", help="Device port for lock/unlock operations")
    parser.add_argument("--json", action="store_true", help="Output in JSON format")

    args = parser.parse_args()

    manager = USBManager()

    if args.command == "list":
        devices = manager.get_usb_devices()
        if args.json:
            print(json.dumps([dev.to_dict() for dev in devices], indent=2))
        else:
            for device in devices:
                print(
                    f"{device.port_path}: {device.get_display_name()} "
                    f"({device.device_type}) {'[LOCKED]' if device.is_locked else ''}"
                )

    elif args.command == "arduino":
        devices = manager.get_arduino_devices()
        if args.json:
            print(json.dumps([dev.to_dict() for dev in devices], indent=2))
        else:
            for device in devices:
                print(f"{device.port_path}: {device.get_display_name()}")

    elif args.command == "serial":
        devices = manager.get_serial_devices()
        if args.json:
            print(json.dumps(devices, indent=2))
        else:
            for device in devices:
                print(f"{device['port']}: {device['name']}")

    elif args.command == "lock":
        if not args.port:
            print("Error: --port required for lock command")
            return 1
        result = manager.lock_device(args.port)
        print(result["message"])
        return 0 if result["success"] else 1

    elif args.command == "unlock":
        if not args.port:
            print("Error: --port required for unlock command")
            return 1
        result = manager.unlock_device(args.port)
        print(result["message"])
        return 0 if result["success"] else 1

    elif args.command == "status":
        status = manager.get_virtualhere_status()
        if args.json:
            print(json.dumps(status, indent=2))
        else:
            print(f"VirtualHere available: {status['available']}")
            if status["available"]:
                print(f"VirtualHere running: {status.get('running', False)}")


if __name__ == "__main__":
    import sys

    sys.exit(main() or 0)
