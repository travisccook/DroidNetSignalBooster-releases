#!/bin/bash
# Switch network mode script
# Called by web interface to switch between AP and client modes

set -e

# Check if we got a mode argument
if [ $# -ne 1 ]; then
    echo "Usage: $0 [ap|client]"
    exit 1
fi

MODE="$1"
MODE_FILE="/boot/firmware/droidnet-mode"
MODE_FILE_FALLBACK="/var/lib/droidnet/droidnet-mode"
LOG_FILE="/var/log/droidnet/mode-switch.log"

# Ensure log directory exists
mkdir -p "$(dirname "$LOG_FILE")"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

# Validate mode
if [ "$MODE" != "ap" ] && [ "$MODE" != "client" ]; then
    log "ERROR: Invalid mode: $MODE"
    exit 1
fi

log "Switching network mode to: $MODE"

# When user explicitly switches mode, clear any fallback flag
FALLBACK_FLAG="/var/lib/droidnet/is-fallback"
if [ -f "$FALLBACK_FLAG" ]; then
    rm -f "$FALLBACK_FLAG"
    log "Cleared fallback flag - this is a user-initiated mode change"
fi

# Update mode file
if [ -w "$(dirname "$MODE_FILE")" ]; then
    echo "$MODE" > "$MODE_FILE"
    log "Updated mode file: $MODE_FILE"
else
    # Fallback location
    mkdir -p "$(dirname "$MODE_FILE_FALLBACK")"
    echo "$MODE" > "$MODE_FILE_FALLBACK"
    log "Updated fallback mode file: $MODE_FILE_FALLBACK"
fi

# Find network controller PID and send SIGHUP to trigger mode switch
# Use systemctl to get the main PID to avoid child processes
CONTROLLER_PID=$(systemctl show -p MainPID droidnet-network-controller.service | cut -d= -f2)

if [ -n "$CONTROLLER_PID" ] && [ "$CONTROLLER_PID" != "0" ]; then
    log "Sending SIGHUP to network controller (PID: $CONTROLLER_PID)"
    kill -HUP "$CONTROLLER_PID"
    log "Mode switch signal sent successfully"
else
    # If controller not running, try to restart the service
    log "Network controller not running, restarting service..."
    if systemctl restart droidnet-network-controller; then
        log "Network controller service restarted"
    else
        log "ERROR: Failed to restart network controller service"
        exit 1
    fi
fi

log "Mode switch initiated for $MODE mode"
exit 0