#!/bin/bash

# PS3 Navigation Controller Pairing Script
# Enables pairing mode for 30 seconds

LOGFILE="/var/log/droidnet/controller-pairing.log"
TIMEOUT=30

# Ensure log directory exists
mkdir -p /var/log/droidnet

echo "[$(date)] Starting PS3 controller pairing mode" | tee -a $LOGFILE

# Enable Bluetooth if not already enabled
if ! systemctl is-active --quiet bluetooth; then
    echo "[$(date)] Starting Bluetooth service" | tee -a $LOGFILE
    systemctl start bluetooth
fi

# Put adapter in pairable mode
echo "[$(date)] Enabling pairing mode for $TIMEOUT seconds" | tee -a $LOGFILE

# Make adapter discoverable and pairable
bluetoothctl <<EOF
power on
agent on
default-agent
pairable on
discoverable on
EOF

echo "[$(date)] Pairing mode active. Instructions:" | tee -a $LOGFILE
echo "1. Connect PS3 Navigation Controller via USB" | tee -a $LOGFILE
echo "2. Press the PS button on the controller" | tee -a $LOGFILE
echo "3. Wait for lights to stop flashing" | tee -a $LOGFILE
echo "4. Disconnect USB cable" | tee -a $LOGFILE

# Sleep for timeout period
sleep $TIMEOUT

# Disable pairing mode
echo "[$(date)] Disabling pairing mode" | tee -a $LOGFILE

bluetoothctl <<EOF
discoverable off
pairable off
EOF

# Check if any PS3 controller was paired
PAIRED_DEVICES=$(bluetoothctl devices | grep -i "navigation controller\|playstation")

if [ -n "$PAIRED_DEVICES" ]; then
    echo "[$(date)] Successfully paired controller(s):" | tee -a $LOGFILE
    echo "$PAIRED_DEVICES" | tee -a $LOGFILE
    
    # Trust the device(s)
    while IFS= read -r device; do
        MAC=$(echo "$device" | awk '{print $2}')
        if [ -n "$MAC" ]; then
            echo "[$(date)] Trusting device $MAC" | tee -a $LOGFILE
            bluetoothctl trust "$MAC"
        fi
    done <<< "$PAIRED_DEVICES"
    
    exit 0
else
    echo "[$(date)] No PS3 controller was paired" | tee -a $LOGFILE
    exit 1
fi