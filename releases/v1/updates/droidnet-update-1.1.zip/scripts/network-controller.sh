#!/bin/bash
# Fix-Plan-32: Unified Network Controller
# Single control point for all network management

set -e

# Fix-Plan-02: Check if firstboot has completed
if [ ! -f "/var/lib/droidnet/firstboot-complete" ]; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Waiting for firstboot to complete..." >&2
    # Exit gracefully - systemd will restart us
    exit 0
fi

LOG_FILE="/var/log/droidnet/network-controller.log"
LOG_DIR="/boot/firmware/droidnet-logs"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$LOG_DIR"

# Check debug mode
DEBUG_MODE=0
if [ -f /opt/droidnet/config/debug.conf ]; then
    source /opt/droidnet/config/debug.conf
fi

# Fix-Plan-10: Error handler for robust fallback
error_handler() {
    local exit_code=$?
    local line_number=${1:-$LINENO}
    log "ERROR: Command failed with exit code $exit_code at line $line_number"
    
    # If we're in a critical fallback, ensure we complete it
    if [ "${IN_FALLBACK:-0}" = "1" ]; then
        log "CRITICAL: Error during fallback - attempting emergency recovery"
        emergency_ap_recovery
    fi
}

# Fix-Plan-10: Emergency recovery function
emergency_ap_recovery() {
    log "EMERGENCY: Forcing AP mode recovery"
    
    # Force mode to AP (most critical step)
    echo "ap" > "$MODE_FILE" 2>/dev/null || true
    
    # Kill everything
    systemctl stop NetworkManager hostapd dnsmasq 2>/dev/null || true
    killall NetworkManager hostapd dnsmasq 2>/dev/null || true
    
    # Force interface down and up
    ip link set wlan0 down 2>/dev/null || true
    sleep 2
    ip link set wlan0 up 2>/dev/null || true
    sleep 2
    
    # Try to start basic AP
    /usr/sbin/hostapd -B /etc/hostapd/hostapd.conf 2>/dev/null || true
    sleep 2
    
    # If still failing, schedule reboot
    if ! pgrep hostapd >/dev/null; then
        log "EMERGENCY: All recovery attempts failed - rebooting in 10 seconds"
        (sleep 10 && reboot) &
    fi
}

# Set error trap
trap 'error_handler $LINENO' ERR

log() {
    local msg="[$(date '+%Y-%m-%d %H:%M:%S')] $1"
    echo "$msg" | tee -a "$LOG_FILE"
    # Only log to boot partition if debug mode is enabled
    if [ "$DEBUG_MODE" = "1" ]; then
        echo "$msg" >> "$LOG_DIR/network-controller.log"
    fi
    logger -t droidnet-controller "$1"
}

error_exit() {
    log "ERROR: $1"
    exit 1
}

# Fix-Plan-34: MAC-based AP naming
get_mac_suffix() {
    local mac=$(cat /sys/class/net/wlan0/address 2>/dev/null | tr -d ':' | tail -c 5)
    echo "${mac:-0000}" | tr '[:lower:]' '[:upper:]'
}

# Read AP configuration from template if available
read_ap_config() {
    local template="/opt/droidnet/config/hostapd.conf"
    local ssid="DroidNet"
    local password="droidnet123"
    
    if [ -f "$template" ]; then
        # Extract SSID from template
        local template_ssid=$(grep "^ssid=" "$template" 2>/dev/null | cut -d= -f2)
        if [ -n "$template_ssid" ]; then
            # Only replace %%MAC_SUFFIX%% if it exists (default SSID)
            if echo "$template_ssid" | grep -q "%%MAC_SUFFIX%%"; then
                ssid=$(echo "$template_ssid" | sed "s/%%MAC_SUFFIX%%/$(get_mac_suffix)/g")
            else
                # User-defined SSID - use as-is
                ssid="$template_ssid"
            fi
        fi
        
        # Extract password from template
        local template_password=$(grep "^wpa_passphrase=" "$template" 2>/dev/null | cut -d= -f2)
        if [ -n "$template_password" ]; then
            password="$template_password"
        fi
    fi
    
    echo "$ssid|$password"
}

# Function to read network timeout configuration
read_network_timeout() {
    local config_file="/opt/droidnet/config/network-settings.json"
    local default_timeout=60
    
    # Check if config file exists
    if [ -f "$config_file" ]; then
        # Try to read timeout value using jq if available
        if command -v jq >/dev/null 2>&1; then
            local timeout=$(jq -r '.client_connection_timeout // empty' "$config_file" 2>/dev/null)
            if [ -n "$timeout" ] && [ "$timeout" -gt 0 ] 2>/dev/null; then
                echo "$timeout"
                return
            fi
        else
            # Fallback to grep/sed if jq not available
            local timeout=$(grep -o '"client_connection_timeout"[[:space:]]*:[[:space:]]*[0-9]\+' "$config_file" 2>/dev/null | sed 's/.*:[[:space:]]*//')
            if [ -n "$timeout" ] && [ "$timeout" -gt 0 ] 2>/dev/null; then
                echo "$timeout"
                return
            fi
        fi
    fi
    
    # Return default if file doesn't exist or parsing fails
    echo "$default_timeout"
}

# Network configuration
AP_IP="192.168.4.1"
AP_CONFIG=$(read_ap_config)
AP_SSID=$(echo "$AP_CONFIG" | cut -d'|' -f1)
AP_PASSWORD=$(echo "$AP_CONFIG" | cut -d'|' -f2)
AP_CHANNEL=6
CLIENT_TIMEOUT=300  # 5 minutes

# Fix-Plan-09: Track client state monitor PID
MONITOR_PID=""

# State tracking
STATE_FILE="/var/lib/droidnet/network-state"
MODE_FILE="/boot/firmware/droidnet-mode"
FALLBACK_FLAG="/var/lib/droidnet/is-fallback"
mkdir -p "$(dirname "$STATE_FILE")"

get_current_mode() {
    # Check web interface config first
    if [ -f "/opt/droidnet/config/wifi-config.json" ]; then
        if command -v jq >/dev/null 2>&1; then
            local web_mode=$(jq -r '.mode // empty' "/opt/droidnet/config/wifi-config.json" 2>/dev/null)
            if [ -n "$web_mode" ]; then
                # Update the mode file to match web config
                echo "$web_mode" > "$MODE_FILE"
                echo "$web_mode"
                return
            fi
        fi
    fi
    
    # Check mode file
    if [ -f "$MODE_FILE" ]; then
        local saved_mode=$(cat "$MODE_FILE")
        # If AP mode was due to fallback, always try client mode first
        if [ "$saved_mode" = "ap" ] && [ -f "$FALLBACK_FLAG" ]; then
            log "AP mode was from fallback - will attempt client mode" >&2
            echo "client"
            return
        fi
        echo "$saved_mode"
    else
        echo "ap"  # Default to AP mode
    fi
}

set_mode() {
    local mode=$1
    local is_fallback=${2:-false}
    echo "$mode" > "$MODE_FILE"
    if [ "$is_fallback" = "true" ]; then
        touch "$FALLBACK_FLAG"
    else
        rm -f "$FALLBACK_FLAG"
    fi
    log "Network mode set to: $mode (fallback: $is_fallback)"
}

save_state() {
    local state=$1
    echo "$state" > "$STATE_FILE"
    log "Network state: $state"
}

# Fix-Plan-03: Pre-flight hardware checks
pre_flight_checks() {
    log "Running pre-flight hardware checks..."
    
    # Check if wlan0 exists
    if [ ! -d "/sys/class/net/wlan0" ]; then
        error_exit "WiFi interface wlan0 not found"
    fi
    
    # Check and fix rfkill
    if command -v rfkill >/dev/null 2>&1; then
        log "Checking rfkill status..."
        rfkill list wifi | tee -a "$LOG_FILE"
        rfkill unblock wifi || true
        rfkill unblock wlan || true
        rfkill unblock all || true
        log "rfkill unblock completed"
    fi
    
    # Stop NetworkManager early to prevent conflicts
    if systemctl is-active --quiet NetworkManager; then
        log "Stopping NetworkManager to prevent conflicts..."
        systemctl stop NetworkManager || true
        sleep 2
    fi
    
    # Ensure interface is down
    log "Ensuring wlan0 is down before configuration..."
    ip link set wlan0 down || true
    sleep 1
    
    # Log interface state
    log "Interface state after pre-flight: $(ip link show wlan0 | grep -o 'state [^ ]*')"
    
    # Set regulatory domain
    if command -v iw >/dev/null 2>&1; then
        log "Setting regulatory domain to US..."
        iw reg set US || true
        sleep 1
        iw reg get | tee -a "$LOG_FILE"
    fi
}

# Run prerequisite scripts
run_prerequisites() {
    log "Running prerequisite scripts..."
    
    # Fix-Plan-03: Run pre-flight checks first
    pre_flight_checks
    
    # Fix-Plan-35: Disable NetworkManager in AP mode early
    if [ -x /opt/droidnet/scripts/disable-networkmanager-ap.sh ]; then
        /opt/droidnet/scripts/disable-networkmanager-ap.sh || {
            log "WARNING: NetworkManager disable script failed"
        }
    fi
    
    # Fix NetworkManager D-Bus dependencies
    if [ -x /opt/droidnet/scripts/fix-networkmanager-dbus.sh ]; then
        /opt/droidnet/scripts/fix-networkmanager-dbus.sh || {
            log "WARNING: NetworkManager D-Bus fix failed"
        }
    fi
    
    # Disable conflicting services
    if [ -x /opt/droidnet/scripts/disable-network-conflicts.sh ]; then
        /opt/droidnet/scripts/disable-network-conflicts.sh || {
            log "WARNING: Network conflict resolution failed"
        }
    fi
    
    # Fix-Plan-08: Ensure no conflicting services are running
    log "Ensuring no conflicting network services..."
    for service in dhcpcd dhcpcd5 systemd-networkd systemd-networkd-wait-online; do
        if systemctl is-active "$service" >/dev/null 2>&1; then
            log "WARNING: $service is still active, stopping..."
            systemctl stop "$service" 2>/dev/null || true
        fi
    done
}

# Check if WiFi interface exists
check_wifi_interface() {
    if ! ip link show wlan0 &>/dev/null; then
        error_exit "WiFi interface wlan0 not found"
    fi
    
    # Fix-Plan-35: RF-kill handled by dedicated service
    # No need to unblock here
}

# Check DHCP status for diagnostics
check_dhcp_status() {
    log "Checking DHCP status..."
    
    # Check if dnsmasq is listening on port 67
    if netstat -ulnp 2>/dev/null | grep -q ":67.*dnsmasq"; then
        log "✓ DNSMasq listening on DHCP port 67"
    else
        log "✗ DNSMasq NOT listening on DHCP port 67"
    fi
    
    # Check for DHCP leases
    if [ -f /var/lib/misc/dnsmasq.leases ]; then
        local lease_count=$(wc -l < /var/lib/misc/dnsmasq.leases)
        log "DHCP leases: $lease_count"
    else
        log "No DHCP lease file found"
    fi
    
    # Check dnsmasq process
    if pgrep dnsmasq > /dev/null; then
        log "✓ DNSMasq process running (PID: $(pgrep dnsmasq))"
    else
        log "✗ DNSMasq process NOT running"
    fi
}

# Function to configure NetworkManager for mode
configure_networkmanager_for_mode() {
    local mode=$1
    local nm_conf_99="/etc/NetworkManager/conf.d/99-unmanaged-devices.conf"
    local nm_conf_10="/etc/NetworkManager/conf.d/10-droidnet-unmanaged.conf"
    
    if [ "$mode" = "client" ]; then
        # Remove config files to allow NetworkManager to manage wlan0
        log "Configuring NetworkManager for client mode"
        
        # Remove the 99-unmanaged-devices.conf if it exists
        if [ -f "$nm_conf_99" ]; then
            log "Removing $nm_conf_99"
            rm -f "$nm_conf_99"
        fi
        
        # Comment out unmanaged line in 10-droidnet-unmanaged.conf
        if [ -f "$nm_conf_10" ]; then
            log "Modifying $nm_conf_10 for client mode"
            # Use a more robust sed command
            sed -i '/^unmanaged-devices=interface-name:wlan0/s/^/#/' "$nm_conf_10"
            # Verify the change
            if grep -q "^#unmanaged-devices=interface-name:wlan0" "$nm_conf_10"; then
                log "Successfully commented out unmanaged-devices line"
            else
                log "WARNING: Failed to comment out unmanaged-devices line"
            fi
        fi
    else
        # Configure to prevent NetworkManager from managing wlan0 in AP mode
        log "Configuring NetworkManager for AP mode"
        
        # Uncomment unmanaged line in 10-droidnet-unmanaged.conf
        if [ -f "$nm_conf_10" ]; then
            log "Modifying $nm_conf_10 for AP mode"
            # First remove any comment if it exists
            sed -i '/^#unmanaged-devices=interface-name:wlan0/s/^#//' "$nm_conf_10"
            # Verify the line is uncommented
            if grep -q "^unmanaged-devices=interface-name:wlan0" "$nm_conf_10"; then
                log "Successfully uncommented unmanaged-devices line"
            else
                log "WARNING: unmanaged-devices line may not be properly set"
            fi
        fi
        
        # Also create 99-unmanaged-devices.conf for redundancy
        mkdir -p /etc/NetworkManager/conf.d
        cat > "$nm_conf_99" << EOF
[keyfile]
unmanaged-devices=interface-name:wlan0
EOF
    fi
}

# Clear NetworkManager state files
clear_networkmanager_state() {
    log "Clearing NetworkManager state files..."
    
    # Stop any rfkill-related services that might interfere
    systemctl stop systemd-rfkill.service 2>/dev/null || true
    systemctl stop systemd-rfkill.socket 2>/dev/null || true
    
    # Remove ALL NetworkManager state
    rm -rf /var/lib/NetworkManager/*
    
    # Clear ALL systemd rfkill state
    rm -rf /var/lib/systemd/rfkill/*
    
    # Force unblock at kernel level
    rfkill unblock all
    rfkill unblock wifi
    rfkill unblock wlan
    
    # Use nmcli if available to force WiFi on
    if command -v nmcli >/dev/null 2>&1; then
        nmcli radio wifi on 2>/dev/null || true
    fi
    
    # Wait for changes to take effect
    sleep 3
    
    if [ "$DEBUG_MODE" = "1" ]; then
        log "=== State after aggressive clearing ==="
        monitor_rfkill_state
    fi
}

# Monitor rfkill state (debug mode only)
monitor_rfkill_state() {
    if [ "$DEBUG_MODE" = "1" ]; then
        local timestamp=$(date +%Y%m%d-%H%M%S)
        local state_file="$LOG_DIR/rfkill-state-$timestamp.log"
        
        {
            echo "=== RFKill State at $timestamp ==="
            rfkill list all 2>&1
            echo ""
            echo "=== NetworkManager State Files ==="
            ls -la /var/lib/NetworkManager/ 2>&1
            if [ -f /var/lib/NetworkManager/NetworkManager.state ]; then
                echo "NetworkManager.state content:"
                cat /var/lib/NetworkManager/NetworkManager.state 2>&1
            fi
            echo ""
            echo "=== systemd RFKill State Files ==="
            ls -la /var/lib/systemd/rfkill/ 2>&1
            for f in /var/lib/systemd/rfkill/*; do
                if [ -f "$f" ]; then
                    echo "Content of $f:"
                    cat "$f" 2>&1
                fi
            done
            echo ""
            echo "=== Processes controlling rfkill ==="
            ps aux | grep -E "(rfkill|NetworkManager|systemd-rfkill)" | grep -v grep 2>&1
            echo ""
            echo "=== systemd-rfkill service status ==="
            systemctl status systemd-rfkill --no-pager 2>&1 || true
            systemctl status systemd-rfkill.socket --no-pager 2>&1 || true
        } | tee -a "$LOG_FILE" > "$state_file"
        
        log "Debug state captured to $state_file"
    fi
}

# Stop AP services
stop_ap_services() {
    log "Stopping AP services..."
    
    # Fix-Plan-09: Kill any client state monitor
    if [ -n "$MONITOR_PID" ] && kill -0 "$MONITOR_PID" 2>/dev/null; then
        log "Stopping client state monitor (PID: $MONITOR_PID)"
        kill "$MONITOR_PID" 2>/dev/null || true
        MONITOR_PID=""
    fi
    
    # Fix-Plan-09: Capture state before stopping services
    if [ "$DEBUG_MODE" = "1" ]; then
        log "=== PRE-TRANSITION STATE ==="
        monitor_rfkill_state
    fi
    
    # Start rfkill monitor if in debug mode
    if [ "$DEBUG_MODE" = "1" ] && [ -x "/opt/droidnet/scripts/rfkill-race-monitor.sh" ]; then
        log "Starting rfkill race condition monitor..."
        /opt/droidnet/scripts/rfkill-race-monitor.sh &
    fi
    
    # Stop services
    if systemctl is-active --quiet hostapd; then
        log "Stopping hostapd..."
        systemctl stop hostapd || true
    fi
    
    if systemctl is-active --quiet dnsmasq; then
        log "Stopping dnsmasq..."
        systemctl stop dnsmasq || true
    fi
    
    # Wait for services to fully stop
    sleep 3
    
    # Mask services to prevent auto-start
    systemctl mask hostapd || true
    systemctl mask dnsmasq || true
    
    # Remove AP-specific dnsmasq config
    rm -f /etc/dnsmasq.d/droidnet-ap.conf
    
    # Fix-Plan-09: Ensure interface is not managed by anything
    cleanup_interface
    
    if [ "$DEBUG_MODE" = "1" ]; then
        log "=== POST-STOP-SERVICES STATE ==="
        monitor_rfkill_state
    fi
}

# Start AP mode using hostapd
start_ap_mode() {
    log "Starting AP mode..."
    save_state "starting_ap"
    
    # Re-read AP configuration in case it was updated
    AP_CONFIG=$(read_ap_config)
    AP_SSID=$(echo "$AP_CONFIG" | cut -d'|' -f1)
    AP_PASSWORD=$(echo "$AP_CONFIG" | cut -d'|' -f2)
    log "Using AP configuration: SSID=$AP_SSID"
    
    # Fix-Plan-10: Ensure we're starting with clean state
    set +e  # Don't exit on error in AP mode start
    systemctl stop NetworkManager hostapd dnsmasq 2>/dev/null || true
    
    # Ensure NetworkManager doesn't manage wlan0
    mkdir -p /etc/NetworkManager/conf.d
    cat > /etc/NetworkManager/conf.d/99-unmanaged-devices.conf << EOF
[keyfile]
unmanaged-devices=interface-name:wlan0
EOF
    
    # Stop NetworkManager if running
    if systemctl is-active --quiet NetworkManager; then
        log "Stopping NetworkManager for AP mode..."
        systemctl stop NetworkManager || true
    fi
    
    # Mask NetworkManager to prevent D-Bus activation
    systemctl mask NetworkManager || true
    
    # Check for dhcpcd static IP conflicts
    if [ -f /etc/dhcpcd.conf ]; then
        if grep -q "^interface wlan0" /etc/dhcpcd.conf && grep -q "^static ip_address=" /etc/dhcpcd.conf; then
            log "WARNING: Static IP configuration found in dhcpcd.conf - commenting out"
            # Comment out the wlan0 static configuration to prevent conflicts
            sed -i '/^interface wlan0/,/^$/s/^/#/' /etc/dhcpcd.conf
            # Restart dhcpcd to apply changes
            systemctl restart dhcpcd 2>/dev/null || true
        fi
    fi
    
    # Configure interface
    log "Configuring wlan0 for AP mode..."
    ip addr flush dev wlan0 || true
    ip link set dev wlan0 down || true
    sleep 1
    ip link set dev wlan0 up || true
    ip addr add ${AP_IP}/24 dev wlan0 || true
    
    # Create hostapd configuration
    # Fix-Plan-03: Add country_code and regulatory domain support
    cat > /etc/hostapd/hostapd.conf << EOF
interface=wlan0
driver=nl80211
ssid=${AP_SSID}
hw_mode=g
channel=${AP_CHANNEL}
ieee80211n=1
ieee80211d=1
country_code=US
wmm_enabled=1
ht_capab=[SHORT-GI-20][DSSS_CCK-40]
macaddr_acl=0
auth_algs=1
ignore_broadcast_ssid=0
wpa=2
wpa_passphrase=${AP_PASSWORD}
wpa_key_mgmt=WPA-PSK
wpa_pairwise=TKIP
rsn_pairwise=CCMP
ap_isolate=0
EOF
    
    # Create dnsmasq configuration
    log "Creating dnsmasq configuration for AP mode..."
    mkdir -p /etc/dnsmasq.d  # Ensure directory exists
    
    cat > /etc/dnsmasq.d/droidnet-ap.conf << EOF
# DroidNet AP Mode DNSMasq Configuration
# Generated by network-controller.sh

# Interface binding (critical for AP mode)
interface=wlan0
bind-interfaces
listen-address=${AP_IP}
except-interface=lo

# DHCP Configuration
dhcp-range=192.168.4.2,192.168.4.20,255.255.255.0,12h
dhcp-option=3,${AP_IP}    # Default gateway
dhcp-option=6,${AP_IP}    # DNS server
dhcp-authoritative

# DNS Configuration
server=8.8.8.8
server=8.8.4.4
domain-needed
bogus-priv
no-hosts
expand-hosts
domain=local
address=/droidnet.local/${AP_IP}

# Logging Configuration (respects debug mode)
EOF

    # Add logging based on debug mode
    if [ "$DEBUG_MODE" = "1" ]; then
        cat >> /etc/dnsmasq.d/droidnet-ap.conf << EOF
# Debug logging enabled
log-queries
log-dhcp
log-facility=/var/log/dnsmasq.log
EOF
    else
        cat >> /etc/dnsmasq.d/droidnet-ap.conf << EOF
# Standard logging
log-dhcp
log-facility=/var/log/dnsmasq.log
EOF
    fi
    
    # Ensure log file exists and is writable
    mkdir -p /var/log
    touch /var/log/dnsmasq.log
    chmod 644 /var/log/dnsmasq.log
    
    # Ensure DHCP leases directory exists
    mkdir -p /var/lib/misc
    touch /var/lib/misc/dnsmasq.leases
    chmod 644 /var/lib/misc/dnsmasq.leases
    
    # Ensure main dnsmasq.conf includes conf-dir
    if [ -f /etc/dnsmasq.conf ]; then
        if ! grep -q "^conf-dir=/etc/dnsmasq.d" /etc/dnsmasq.conf; then
            log "Adding conf-dir to main dnsmasq.conf..."
            echo "conf-dir=/etc/dnsmasq.d/,*.conf" >> /etc/dnsmasq.conf
        fi
    fi
    
    # Start services
    # Fix-Plan-03: Enhanced hostapd error capture
    log "Starting hostapd with enhanced error capture..."
    systemctl unmask hostapd || true
    
    # Ensure WiFi is unblocked before starting hostapd
    log "Ensuring WiFi is unblocked before starting hostapd..."
    rfkill unblock wifi
    rfkill unblock all
    sleep 1
    
    # Verify unblock worked
    if rfkill list | grep -q "Soft blocked: yes"; then
        log "WARNING: WiFi still soft blocked after unblock attempt"
    fi
    
    # Stop any existing hostapd
    systemctl stop hostapd 2>/dev/null || true
    killall hostapd 2>/dev/null || true
    sleep 1
    
    # Determine hostapd command
    local hostapd_cmd="/usr/sbin/hostapd"
    local hostapd_conf="/etc/hostapd/hostapd.conf"
    local hostapd_log="/var/log/hostapd.log"
    
    # Use debug wrapper if available and debug mode enabled
    if [ "$DEBUG_MODE" = "1" ] && [ -x /opt/droidnet/scripts/hostapd-debug-wrapper.sh ]; then
        hostapd_cmd="/opt/droidnet/scripts/hostapd-debug-wrapper.sh"
        log "Using hostapd debug wrapper"
    fi
    
    # Add debug flags if debug mode enabled
    local debug_flags=""
    if [ "$DEBUG_MODE" = "1" ]; then
        debug_flags="-dd -t"
        log "Debug mode enabled, using flags: $debug_flags"
    fi
    
    # Log the command we're running
    log "Command: $hostapd_cmd $debug_flags $hostapd_conf"
    
    # Capture dmesg before
    if [ "$DEBUG_MODE" = "1" ]; then
        dmesg | tail -20 > /tmp/dmesg-before-hostapd.log
    fi
    
    # Start hostapd with output capture
    $hostapd_cmd $debug_flags "$hostapd_conf" > "$hostapd_log" 2>&1 &
    local hostapd_pid=$!
    log "Started hostapd process with PID: $hostapd_pid"
    
    # Wait up to 5 seconds for hostapd to start
    local count=0
    local hostapd_running=false
    while [ $count -lt 5 ]; do
        sleep 1
        
        # Check if process is still running
        if ! kill -0 $hostapd_pid 2>/dev/null; then
            # Process died, capture error
            log "ERROR: hostapd process died"
            log "hostapd output:"
            if [ -f "$hostapd_log" ]; then
                cat "$hostapd_log" | tee -a "$LOG_FILE"
                # Copy to boot partition if debug mode
                if [ "$DEBUG_MODE" = "1" ]; then
                    cp "$hostapd_log" "$LOG_DIR/hostapd-failed.log"
                fi
            fi
            
            # Capture dmesg after
            if [ "$DEBUG_MODE" = "1" ]; then
                dmesg | tail -20 > /tmp/dmesg-after-hostapd.log
                log "dmesg changes:"
                diff /tmp/dmesg-before-hostapd.log /tmp/dmesg-after-hostapd.log | tee -a "$LOG_FILE" || true
            fi
            
            return 1
        fi
        
        # Check if AP is active
        if iw dev wlan0 info 2>/dev/null | grep -q "type AP"; then
            log "hostapd started successfully - AP mode confirmed"
            hostapd_running=true
            break
        fi
        
        count=$((count + 1))
    done
    
    if [ "$hostapd_running" = "false" ]; then
        log "ERROR: hostapd appears to be running but AP mode not detected"
        log "Interface info:"
        iw dev wlan0 info 2>&1 | tee -a "$LOG_FILE"
        
        # Try to get hostapd status via CLI if available
        if command -v hostapd_cli >/dev/null 2>&1; then
            log "hostapd_cli status:"
            hostapd_cli status 2>&1 | tee -a "$LOG_FILE" || true
        fi
        
        return 1
    fi
    
    log "Starting dnsmasq..."
    systemctl unmask dnsmasq || true
    
    # Fix-Plan-41: Check if override exists and might cause problems
    if [ -f /etc/systemd/system/dnsmasq.service.d/override.conf ]; then
        if grep -q "systemd-exec" /etc/systemd/system/dnsmasq.service.d/override.conf 2>/dev/null; then
            log "WARNING: Detected problematic dnsmasq override, removing..."
            rm -f /etc/systemd/system/dnsmasq.service.d/override.conf
            systemctl daemon-reload
        fi
    fi
    
    systemctl start dnsmasq || {
        log "ERROR: Failed to start dnsmasq"
        journalctl -u dnsmasq -n 50 >> "$LOG_FILE"
        return 1
    }
    
    # Ensure wlan0 interface is fully up before restarting dnsmasq
    log "Waiting for wlan0 interface to be ready..."
    local retry_count=0
    while [ $retry_count -lt 10 ]; do
        if ip link show wlan0 | grep -q "state UP"; then
            log "wlan0 interface is UP"
            break
        fi
        retry_count=$((retry_count + 1))
        sleep 1
    done
    
    # Restart dnsmasq to ensure new configuration is loaded
    # This is critical - without restart, DHCP won't work
    log "Restarting dnsmasq to ensure DHCP configuration is active..."
    local dhcp_retry=0
    local dhcp_working=false
    
    while [ $dhcp_retry -lt 5 ] && [ "$dhcp_working" = "false" ]; do
        # Kill any existing dnsmasq processes that might be holding the port
        if [ $dhcp_retry -gt 0 ]; then
            log "Killing any existing dnsmasq processes..."
            killall dnsmasq 2>/dev/null || true
            sleep 1
        fi
        
        systemctl restart dnsmasq || {
            log "WARNING: Failed to restart dnsmasq cleanly, attempt $((dhcp_retry + 1))/5"
            systemctl stop dnsmasq || true
            sleep 2
            systemctl start dnsmasq || log "Failed to start dnsmasq"
        }
        
        # Wait longer on Pi Zero W (slower processor)
        if grep -q "Raspberry Pi Zero" /proc/device-tree/model 2>/dev/null; then
            sleep 5
        else
            sleep 3
        fi
        
        # Check if DHCP is actually listening (use netstat as fallback if lsof not available)
        if command -v lsof >/dev/null 2>&1; then
            if lsof -i :67 2>/dev/null | grep -q dnsmasq; then
                dhcp_working=true
                log "✓ DNSMasq DHCP is now active on port 67"
            fi
        elif netstat -ulnp 2>/dev/null | grep -q ":67.*dnsmasq"; then
            dhcp_working=true
            log "✓ DNSMasq DHCP is now active on port 67"
        else
            dhcp_retry=$((dhcp_retry + 1))
            log "✗ DNSMasq DHCP not yet active, retry $dhcp_retry/5"
        fi
    done
    
    if [ "$dhcp_working" = "false" ]; then
        log "CRITICAL: DNSMasq DHCP failed to start after 5 attempts"
        # Continue trying in background since device can't operate without this
        (
            while true; do
                sleep 10
                systemctl restart dnsmasq
                if lsof -i :67 2>/dev/null | grep -q dnsmasq; then
                    log "✓ DNSMasq DHCP finally started in background"
                    break
                fi
                log "Background: Still trying to start DNSMasq DHCP..."
            done
        ) &
    fi
    
    # Call the existing check_dhcp_status function
    check_dhcp_status
    
    # Enable IP forwarding (kept for potential future use with other firewall solutions)
    echo 1 > /proc/sys/net/ipv4/ip_forward
    
    # Note: iptables commands removed as they are not needed for basic AP functionality
    # and the package may not be installed on all systems
    
    save_state "ap_active"
    log "AP mode started successfully"
    
    # Fix-Plan-35: Ensure web service is started after AP is up
    log "Starting web service..."
    systemctl start droidnet-web.service || log "WARNING: Failed to start web service"
    
    # Ensure avahi-daemon is properly configured for AP interface
    # Wait for avahi to be ready (it has dependencies on this service)
    local avahi_attempts=0
    local max_avahi_attempts=5
    
    while [ $avahi_attempts -lt $max_avahi_attempts ]; do
        if systemctl is-active --quiet avahi-daemon; then
            log "Avahi-daemon is active, verifying mDNS..."
            sleep 3  # Give avahi time to fully initialize
            
            # Verify mDNS is working
            if getent hosts $(hostname).local >/dev/null 2>&1; then
                log "mDNS verified working for $(hostname).local"
                break
            else
                log "mDNS verification failed, attempt $((avahi_attempts + 1))/$max_avahi_attempts"
                # Reload avahi to pick up interface changes
                systemctl reload-or-restart avahi-daemon
                sleep 5  # Wait longer for avahi to settle
            fi
        else
            log "Waiting for avahi-daemon to start, attempt $((avahi_attempts + 1))/$max_avahi_attempts"
            sleep 3
        fi
        avahi_attempts=$((avahi_attempts + 1))
    done
    
    if [ $avahi_attempts -eq $max_avahi_attempts ]; then
        log "WARNING: Could not verify mDNS after $max_avahi_attempts attempts"
    fi
    
    return 0
}

# Fix-Plan-09: Monitor client connection with timeout
monitor_client_connection() {
    local timeout=${1:-60}  # Default 60 seconds
    local start_time=$(date +%s)
    local connected=false
    
    log "Monitoring client connection (timeout: ${timeout}s)..."
    
    while [ $(($(date +%s) - start_time)) -lt $timeout ]; do
        # Check if we have an active WiFi connection
        if nmcli -t -f TYPE,STATE connection show --active | grep -q "^802-11-wireless:activated$"; then
            # Verify we have an IP address
            if ip addr show wlan0 | grep -q "inet "; then
                connected=true
                log "Client connection successful!"
                break
            fi
        fi
        
        # Check if NetworkManager gave up
        if journalctl -u NetworkManager -n 20 --no-pager | grep -q "state change:.*failed.*reason.*"; then
            log "NetworkManager reported connection failure"
            break
        fi
        
        sleep 2
    done
    
    if [ "$connected" = false ]; then
        log "Client connection failed or timed out after ${timeout}s"
        return 1
    fi
    
    return 0
}

# Fix-Plan-09: Clean interface state before mode switch
cleanup_interface() {
    log "Cleaning up interface state..."
    
    # Remove any lingering IP addresses
    ip addr flush dev wlan0 2>/dev/null || true
    
    # Clear ARP cache
    ip neigh flush dev wlan0 2>/dev/null || true
    
    # Ensure interface is down
    ip link set wlan0 down 2>/dev/null || true
    sleep 1
    
    # Bring interface back up
    ip link set wlan0 up 2>/dev/null || true
    sleep 1
    
    log "Interface cleanup complete"
}

# Fix-Plan-09: Monitor client state and fallback if connection lost
monitor_client_state() {
    log "Client state monitor started"
    
    while true; do
        sleep 30
        
        # Check if we're still in client mode
        local current_mode=$(get_current_mode)
        if [ "$current_mode" != "client" ]; then
            log "No longer in client mode, exiting monitor"
            break
        fi
        
        # Check if connection is still active
        if ! nmcli -t -f TYPE,STATE connection show --active | grep -q "^802-11-wireless:activated$"; then
            log "WiFi connection lost - initiating fallback to AP mode"
            
            # Fix-Plan-10: Update mode file FIRST
            set_mode "ap" "true"
            
            # Fix-Plan-10: Mark fallback state
            IN_FALLBACK=1
            
            # Stop NetworkManager with error handling
            systemctl stop NetworkManager 2>/dev/null || {
                log "WARNING: NetworkManager stop failed"
                killall NetworkManager 2>/dev/null || true
            }
            
            # Clean up interface
            cleanup_interface || true
            
            # Start AP mode with retries
            local retry=0
            while [ $retry -lt 3 ]; do
                if start_ap_mode; then
                    IN_FALLBACK=0
                    break
                fi
                retry=$((retry + 1))
                log "AP start failed, retry $retry/3"
                sleep 5
            done
            
            if [ $retry -eq 3 ]; then
                emergency_ap_recovery
            fi
            
            break
        fi
    done
    
    log "Client state monitor exited"
}

# Start client mode using NetworkManager
start_client_mode() {
    log "Starting client mode..."
    save_state "starting_client"
    
    # Stop any running AP services first
    stop_ap_services
    
    # Fix-Plan-09: Clean interface state
    cleanup_interface
    
    # Clear any NetworkManager state files that might interfere
    log "Clearing NetworkManager state files..."
    rm -rf /var/lib/NetworkManager/*.lease 2>/dev/null || true
    rm -rf /var/lib/NetworkManager/*.state 2>/dev/null || true
    rm -rf /run/NetworkManager/devices/* 2>/dev/null || true
    
    # Fix-Plan-09: More aggressive state clearing
    log "=== State after aggressive clearing ==="
    if [ "$DEBUG_MODE" = "1" ]; then
        monitor_rfkill_state
    fi
    
    # Ensure WiFi is unblocked
    rfkill unblock wifi || true
    rfkill unblock wlan || true
    
    # Fix-Plan-09: Wait for clean state
    log "Waiting for rfkill state to settle..."
    sleep 5
    
    # Configure NetworkManager to manage wlan0 in client mode
    configure_networkmanager_for_mode "client"
    
    # Unmask and start NetworkManager
    log "Unmasking NetworkManager..."
    systemctl unmask NetworkManager || true
    
    log "Starting NetworkManager..."
    systemctl start NetworkManager
    
    # Wait for NetworkManager to initialize
    sleep 3
    
    # Reload NetworkManager to ensure it picks up config changes
    log "Reloading NetworkManager configuration..."
    nmcli general reload || true
    sleep 2
    
    # Load saved WiFi configuration
    local wifi_config="/opt/droidnet/config/wifi-config.json"
    
    # Function to extract value from JSON without jq
    extract_json_value() {
        local key="$1"
        local file="$2"
        
        # First try simple format {"ssid": "value", "password": "value"}
        local value=$(grep "\"$key\"" "$file" | head -1 | sed 's/.*"'"$key"'"\s*:\s*"\([^"]*\)".*/\1/')
        
        # If not found and key is ssid, try networks array
        if [ -z "$value" ] && [ "$key" = "ssid" ]; then
            value=$(grep -A5 '"networks"' "$file" | grep '"ssid"' | head -1 | sed 's/.*"ssid"\s*:\s*"\([^"]*\)".*/\1/')
        fi
        
        # If not found and key is password, try psk in networks array
        if [ -z "$value" ] && [ "$key" = "password" ]; then
            value=$(grep -A5 '"networks"' "$file" | grep '"psk"' | head -1 | sed 's/.*"psk"\s*:\s*"\([^"]*\)".*/\1/')
        fi
        
        echo "$value"
    }
    
    # Try to load WiFi config with or without jq
    if [ -f "$wifi_config" ]; then
        local ssid=""
        local password=""
        
        if command -v jq >/dev/null 2>&1; then
            # Use jq if available
            ssid=$(jq -r '.ssid // empty' "$wifi_config" 2>/dev/null)
            password=$(jq -r '.password // empty' "$wifi_config" 2>/dev/null)
        fi
        
        # If jq failed or not available, use manual parsing
        if [ -z "$ssid" ]; then
            ssid=$(extract_json_value "ssid" "$wifi_config")
            password=$(extract_json_value "password" "$wifi_config")
        fi
        
        if [ -n "$ssid" ]; then
            log "Attempting to connect to network: $ssid"
            
            # Create NetworkManager connection profile
            nmcli connection delete "$ssid" 2>/dev/null || true
            nmcli connection add type wifi con-name "$ssid" ifname wlan0 ssid "$ssid" \
                wifi-sec.key-mgmt wpa-psk wifi-sec.psk "$password" \
                connection.autoconnect yes || {
                log "ERROR: Failed to create NetworkManager connection profile"
            }
            
            # Try to connect
            nmcli connection up "$ssid" 2>/dev/null || true
        fi
    fi
    
    # Fix-Plan-09: Monitor connection with timeout
    local connection_timeout=$(read_network_timeout)
    log "Using client connection timeout: ${connection_timeout}s"
    if monitor_client_connection "$connection_timeout"; then
        log "Client mode established successfully"
        save_state "client_active"
        # Clear fallback flag on successful connection
        rm -f "$FALLBACK_FLAG"
        set_mode "client"
        
        # Start monitoring for connection loss
        monitor_client_state &
        MONITOR_PID=$!
        log "Started client state monitor (PID: $MONITOR_PID)"
    else
        log "Client connection failed - initiating fallback to AP mode"
        save_state "client_failed"
        
        # Fix-Plan-10: Mark that we're in fallback (CRITICAL)
        IN_FALLBACK=1
        
        # Fix-Plan-10: Update mode file IMMEDIATELY (most critical step)
        log "Updating mode file to AP"
        set_mode "ap" "true"
        
        # Fix-Plan-10: Robust service stopping
        log "Stopping NetworkManager..."
        systemctl stop NetworkManager 2>/dev/null || {
            log "WARNING: NetworkManager stop failed, killing processes"
            killall NetworkManager 2>/dev/null || true
        }
        
        # Clean up the interface
        cleanup_interface || {
            log "WARNING: Interface cleanup failed, continuing anyway"
        }
        
        # Fix-Plan-10: Fallback with retries
        log "Starting fallback to AP mode..."
        local fallback_attempts=0
        local fallback_success=false
        
        while [ $fallback_attempts -lt 3 ] && [ "$fallback_success" = "false" ]; do
            fallback_attempts=$((fallback_attempts + 1))
            log "Fallback attempt $fallback_attempts/3"
            
            if start_ap_mode; then
                fallback_success=true
                log "Fallback to AP mode successful"
                IN_FALLBACK=0
                break
            else
                log "Fallback attempt $fallback_attempts failed"
                if [ $fallback_attempts -lt 3 ]; then
                    log "Waiting 5 seconds before retry..."
                    sleep 5
                    # Extra cleanup between attempts
                    systemctl stop hostapd dnsmasq 2>/dev/null || true
                    cleanup_interface || true
                fi
            fi
        done
        
        # Fix-Plan-10: Emergency recovery if all attempts failed
        if [ "$fallback_success" = "false" ]; then
            log "CRITICAL: All fallback attempts failed"
            emergency_ap_recovery
        fi
        
        IN_FALLBACK=0
    fi
}

# Main control logic
main() {
    log "=== DroidNet Network Controller Starting ==="
    log "Hostname: $(hostname)"
    log "WiFi MAC: $(cat /sys/class/net/wlan0/address 2>/dev/null || echo 'unknown')"
    
    # Run prerequisites
    run_prerequisites
    
    # Check WiFi interface
    check_wifi_interface
    
    # Get requested mode
    local mode=$(get_current_mode)
    log "Requested mode: $mode"
    
    case "$mode" in
        client)
            if start_client_mode; then
                log "Client mode active"
            else
                log "Client mode failed, falling back to AP mode"
                set_mode "ap" "true"
                start_ap_mode || error_exit "Failed to start AP mode"
            fi
            ;;
            
        ap|*)
            start_ap_mode || error_exit "Failed to start AP mode"
            ;;
    esac
    
    # Note: Monitoring is handled internally by this controller
    # wifi-state-monitor.sh is incompatible with hostapd-based AP mode
    
    log "Network controller initialization complete"
}

# Handle mode switch request via signal
handle_mode_switch() {
    log "Received mode switch request (SIGHUP)"
    
    # Re-read configuration
    local new_mode=$(get_current_mode)
    local current_state=$(cat "$STATE_FILE" 2>/dev/null || echo "unknown")
    
    # Check if mode actually changed
    if [[ "$current_state" == "ap_active" && "$new_mode" == "ap" ]] || \
       [[ "$current_state" == "client_active" && "$new_mode" == "client" ]]; then
        log "Mode unchanged, no action needed"
        return
    fi
    
    log "Mode change detected: switching to $new_mode"
    
    # Stop current mode services
    case "$current_state" in
        ap_active)
            log "Stopping AP services..."
            systemctl stop hostapd 2>/dev/null || true
            systemctl stop dnsmasq 2>/dev/null || true
            killall hostapd 2>/dev/null || true
            ip link set wlan0 down || true
            ip addr flush dev wlan0 || true
            sleep 2
            ;;
        client_active)
            log "Stopping client services..."
            systemctl stop NetworkManager 2>/dev/null || true
            ip link set wlan0 down || true
            ip addr flush dev wlan0 || true
            sleep 2
            ;;
    esac
    
    # Start new mode
    case "$new_mode" in
        client)
            if start_client_mode; then
                log "Successfully switched to client mode"
            else
                log "Client mode failed, falling back to AP"
                set_mode "ap" "true"
                start_ap_mode || log "CRITICAL: Failed to start AP fallback"
            fi
            ;;
        ap|*)
            start_ap_mode || log "CRITICAL: Failed to start AP mode"
            ;;
    esac
}

# Handle signals
trap 'log "Received shutdown signal"; exit 0' SIGTERM SIGINT
trap 'handle_mode_switch' SIGHUP

# Run main function
main

# Keep service running with periodic health checks
while true; do
    sleep 60
    
    # Health check: Verify services are still running correctly
    current_state=$(cat "$STATE_FILE" 2>/dev/null || echo "unknown")
    case "$current_state" in
        ap_active)
            # Check if hostapd process exists and AP mode is active
            hostapd_ok=false
            if pgrep -f "hostapd" >/dev/null && iw dev wlan0 info 2>/dev/null | grep -q "type AP"; then
                hostapd_ok=true
            fi
            
            if [ "$hostapd_ok" = "false" ]; then
                log "WARNING: hostapd not running or AP mode inactive, attempting recovery..."
                start_ap_mode || log "ERROR: AP recovery failed"
            fi
            
            # Check dnsmasq separately (it uses systemd)
            if ! systemctl is-active --quiet dnsmasq; then
                log "WARNING: dnsmasq not running, attempting recovery..."
                systemctl restart dnsmasq || log "ERROR: dnsmasq recovery failed"
            fi
            ;;
        client_active)
            if ! systemctl is-active --quiet NetworkManager; then
                log "WARNING: NetworkManager not running, attempting recovery..."
                start_client_mode || {
                    log "Client recovery failed, switching to AP"
                    set_mode "ap" "true"
                    start_ap_mode
                }
            fi
            ;;
    esac
done