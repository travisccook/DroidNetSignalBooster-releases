#!/bin/bash
#
# Expand root partition on first boot
# This is called from firstboot-configure.sh
#

# Function to log with timestamp
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] PARTITION: $1"
}

# Check if we need to expand
ROOT_PART=$(findmnt -n -o SOURCE /)
ROOT_DEV=$(lsblk -n -o PKNAME $ROOT_PART)
ROOT_PART_NUM=$(echo $ROOT_PART | grep -o '[0-9]*$')

# Get current partition end and disk size
PART_END=$(fdisk -l /dev/$ROOT_DEV | grep "^$ROOT_PART" | awk '{print $3}')
DISK_SIZE=$(fdisk -l /dev/$ROOT_DEV | grep "Disk /dev/$ROOT_DEV" | awk '{print $5}')
DISK_SECTORS=$(fdisk -l /dev/$ROOT_DEV | grep "Disk /dev/$ROOT_DEV" | awk '{print $7}')

# Check if partition is already expanded (within 1% of disk size)
PART_SIZE=$(lsblk -b -n -o SIZE $ROOT_PART)
if [ -n "$DISK_SIZE" ] && [ -n "$PART_SIZE" ]; then
    EXPANSION_THRESHOLD=$((DISK_SIZE * 99 / 100))
    if [ "$PART_SIZE" -ge "$EXPANSION_THRESHOLD" ]; then
        log "Root partition already expanded (${PART_SIZE} bytes of ${DISK_SIZE} bytes)"
        exit 0
    fi
fi

log "Expanding root partition..."
log "Device: $ROOT_PART on /dev/$ROOT_DEV"

# Get partition start
PART_START=$(fdisk -l /dev/$ROOT_DEV | grep "^$ROOT_PART" | awk '{print $2}')

# Expand partition
if echo ", +" | sfdisk -N $ROOT_PART_NUM /dev/$ROOT_DEV --force >/dev/null 2>&1; then
    log "Partition table updated successfully"
    
    # Try to reload partition table
    partprobe /dev/$ROOT_DEV 2>/dev/null || true
    
    # Resize filesystem
    if resize2fs $ROOT_PART >/dev/null 2>&1; then
        log "Filesystem expanded successfully"
        
        # Get new size
        NEW_SIZE=$(df -h / | tail -1 | awk '{print $2}')
        log "Root partition expanded to $NEW_SIZE"
    else
        log "WARNING: Failed to resize filesystem - will retry on next boot"
    fi
else
    log "WARNING: Failed to expand partition - will retry on next boot"
fi