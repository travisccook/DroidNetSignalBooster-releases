#!/usr/bin/env python3
"""
GPIO Serial Communication Module
Provides software serial functionality on GPIO pins using pigpio
"""

import logging
from typing import Optional

from config.constants import BAUD_RATE_MAESTRO

logger = logging.getLogger(__name__)

# Try to import pigpio
try:
    import pigpio

    PIGPIO_AVAILABLE = True
except ImportError:
    PIGPIO_AVAILABLE = False
    logger.warning("pigpio not available - GPIO serial will not work")


class GPIOSerial:
    """Software serial implementation using pigpio"""

    def __init__(self, gpio_pin: int, baud_rate: int = BAUD_RATE_MAESTRO) -> None:
        self.gpio_pin = gpio_pin
        self.baud_rate = baud_rate
        self.pi: Optional['pigpio.pi'] = None
        self.connected = False

        if not PIGPIO_AVAILABLE:
            raise RuntimeError("pigpio module not available")

    def connect(self):
        """Connect to pigpio daemon"""
        try:
            self.pi = pigpio.pi()
            if not self.pi.connected:
                raise RuntimeError("Failed to connect to pigpio daemon")

            # Configure pin as output
            self.pi.set_mode(self.gpio_pin, pigpio.OUTPUT)
            # Set to idle state (high)
            self.pi.write(self.gpio_pin, 1)

            self.connected = True
            logger.info(
                f"GPIO serial initialized on pin {self.gpio_pin} at {self.baud_rate} baud"
            )

        except Exception as e:
            if self.pi:
                self.pi.stop()
            raise RuntimeError(f"Failed to initialize GPIO serial: {e}")

    def write(self, data):
        """Write data to GPIO serial"""
        if not self.connected:
            self.connect()

        # Calculate bit timing in microseconds
        bit_time_us = int(1000000 / self.baud_rate)

        # Convert string to bytes if needed
        if isinstance(data, str):
            data = data.encode("utf-8")

        # Send each byte
        for byte in data:
            # Start bit (low)
            self.pi.write(self.gpio_pin, 0)
            self.pi.gpioDelay(bit_time_us)

            # Data bits (LSB first)
            for i in range(8):
                bit = (byte >> i) & 1
                self.pi.write(self.gpio_pin, bit)
                self.pi.gpioDelay(bit_time_us)

            # Stop bit (high)
            self.pi.write(self.gpio_pin, 1)
            self.pi.gpioDelay(bit_time_us)

        logger.debug(f"Sent {len(data)} bytes to GPIO {self.gpio_pin}")

    def close(self):
        """Close GPIO serial connection"""
        if self.pi is not None and self.connected:
            # Set pin back to input
            self.pi.set_mode(self.gpio_pin, pigpio.INPUT)
            self.pi.stop()
            self.connected = False
            logger.info(f"GPIO serial closed on pin {self.gpio_pin}")


def send_gpio_serial(gpio_pin, data, baud_rate=BAUD_RATE_MAESTRO):
    """Simple function to send data via GPIO serial"""
    try:
        gpio_serial = GPIOSerial(gpio_pin, baud_rate)
        gpio_serial.connect()
        gpio_serial.write(data)
        gpio_serial.close()
        return True
    except Exception as e:
        logger.error(f"Error sending GPIO serial: {e}")
        return False


def test_gpio_serial(gpio_pin=27, baud_rate=BAUD_RATE_MAESTRO):
    """Test GPIO serial output"""
    print(f"Testing GPIO serial on pin {gpio_pin} at {baud_rate} baud")

    if not PIGPIO_AVAILABLE:
        print("ERROR: pigpio not available")
        return False

    try:
        # Send test message
        test_message = "Hello from GPIO serial!\r\n"
        success = send_gpio_serial(gpio_pin, test_message, baud_rate)

        if success:
            print(f"Successfully sent: {repr(test_message)}")
        else:
            print("Failed to send test message")

        return success

    except Exception as e:
        print(f"Test failed: {e}")
        return False


if __name__ == "__main__":
    # Run test when executed directly
    import sys

    # Get pin from command line or use default
    pin = int(sys.argv[1]) if len(sys.argv) > 1 else 27
    baud = int(sys.argv[2]) if len(sys.argv) > 2 else BAUD_RATE_MAESTRO

    test_gpio_serial(pin, baud)
