"""
Import helper module for DroidNet Signal Booster.
Centralizes Python path configuration to avoid duplicate sys.path.insert() calls.
"""
import sys
import os
from pathlib import Path

# Define project paths
PROJECT_ROOT = Path("/opt/droidnet")
SCRIPTS_DIR = PROJECT_ROOT / "scripts"
WEB_DIR = PROJECT_ROOT / "web"

def setup_paths():
    """Add project directories to Python path if not already present."""
    paths_to_add = [
        str(PROJECT_ROOT),
        str(SCRIPTS_DIR),
        str(WEB_DIR),
    ]

    for path in paths_to_add:
        if path not in sys.path:
            sys.path.insert(0, path)

# Auto-setup on import
setup_paths()
