/**
 * Tab Manager Component
 * Handles tab configuration, ordering, and visibility
 */

(function() {
    'use strict';

    // Tab display names mapping
    const TAB_LABELS = {
        'dashboard': 'Dashboard',
        'devices': 'USB Devices',
        'flash': 'Firmware Flash',
        'serial': 'Serial Monitor',
        'wifi': 'Config',
        'victron': 'Victron',
        'wcb': 'WCB',
        'comlink': 'Comlink',
        'display': 'Display',
        'maestro': 'Maestro'
    };

    // Current config
    let currentConfig = null;
    let draggedItem = null;

    /**
     * Initialize tab manager
     */
    function initTabManager() {
        console.log('TabManager: Initializing...');
        loadTabConfig();
    }

    /**
     * Load tab configuration from server
     */
    function loadTabConfig() {
        fetch('/api/ui/config')
            .then(response => response.json())
            .then(data => {
                if (data.success && data.config) {
                    currentConfig = data.config;
                    applyTabConfig(currentConfig);
                }
            })
            .catch(error => {
                console.error('TabManager: Error loading config:', error);
            });
    }

    /**
     * Apply tab configuration to the UI
     */
    function applyTabConfig(config) {
        if (!config || !config.tabs) return;

        // Support both old and new class names
        const tabNav = document.querySelector('.nav-tabs') || document.querySelector('.tabs');
        if (!tabNav) return;

        const order = config.tabs.order || [];
        const visibility = config.tabs.visibility || {};

        // Reorder tab buttons (support both old and new class names)
        const buttons = {};
        tabNav.querySelectorAll('.nav-tab, .tab-button').forEach(btn => {
            const tabName = getTabNameFromButton(btn);
            if (tabName) {
                buttons[tabName] = btn;
            }
        });

        // Clear and re-add in order
        const fragment = document.createDocumentFragment();
        order.forEach(tabName => {
            if (buttons[tabName]) {
                const btn = buttons[tabName];
                // Apply visibility
                if (visibility[tabName] === false) {
                    btn.style.display = 'none';
                } else {
                    btn.style.display = '';
                }
                fragment.appendChild(btn);
            }
        });

        // Add any remaining buttons not in order
        Object.keys(buttons).forEach(tabName => {
            if (!order.includes(tabName)) {
                fragment.appendChild(buttons[tabName]);
            }
        });

        tabNav.innerHTML = '';
        tabNav.appendChild(fragment);

        console.log('TabManager: Configuration applied');
    }

    /**
     * Get tab name from button element
     */
    function getTabNameFromButton(btn) {
        const onclick = btn.getAttribute('onclick');
        if (onclick) {
            const match = onclick.match(/showTab\(['"]([^'"]+)['"]\)/);
            if (match) return match[1];
        }
        return null;
    }

    /**
     * Open tab settings modal
     */
    window.openTabSettings = function() {
        const modal = document.getElementById('tab-settings-modal');
        if (!modal) return;

        renderTabConfigList();

        // Sync theme toggle with current state
        const themeToggle = document.getElementById('theme-toggle');
        if (themeToggle) {
            themeToggle.checked = document.body.classList.contains('dark-mode');
        }

        modal.style.display = 'flex';
    };

    /**
     * Close tab settings modal
     */
    window.closeTabSettings = function() {
        const modal = document.getElementById('tab-settings-modal');
        if (modal) {
            modal.style.display = 'none';
        }
    };

    /**
     * Render the tab configuration list in the modal
     */
    function renderTabConfigList() {
        const list = document.getElementById('tab-config-list');
        if (!list || !currentConfig) return;

        const order = currentConfig.tabs.order || Object.keys(TAB_LABELS);
        const visibility = currentConfig.tabs.visibility || {};

        list.innerHTML = order.map(tabName => {
            const label = TAB_LABELS[tabName] || tabName;
            const isVisible = visibility[tabName] !== false;
            const isCore = ['dashboard', 'devices', 'flash', 'serial', 'wifi'].includes(tabName);

            return `
                <div class="tab-config-item" data-tab="${tabName}" draggable="true">
                    <span class="drag-handle">&#9776;</span>
                    <label class="tab-config-label">
                        <input type="checkbox"
                               class="tab-visibility-checkbox"
                               data-tab="${tabName}"
                               ${isVisible ? 'checked' : ''}
                               onchange="toggleTabVisibility('${tabName}', this.checked)">
                        <span class="tab-name">${label}</span>
                        ${isCore ? '<span class="tab-badge">Core</span>' : '<span class="tab-badge feature">Feature</span>'}
                    </label>
                </div>
            `;
        }).join('');

        // Setup drag and drop
        setupDragAndDrop();
    }

    /**
     * Setup drag and drop for tab reordering
     * Uses event delegation to avoid memory leaks from repeatedly adding/removing listeners
     */
    function setupDragAndDrop() {
        const list = document.getElementById('tab-config-list');
        if (!list) return;

        // Remove old listeners if they exist (use flags to track)
        if (list._dragHandlersAttached) return;

        // Use event delegation on the parent list
        list.addEventListener('dragstart', function(e) {
            if (e.target.classList.contains('tab-config-item')) {
                handleDragStart.call(e.target, e);
            }
        });

        list.addEventListener('dragend', function(e) {
            if (e.target.classList.contains('tab-config-item')) {
                handleDragEnd.call(e.target, e);
            }
        });

        list.addEventListener('dragover', function(e) {
            if (e.target.closest('.tab-config-item')) {
                handleDragOver.call(e.target.closest('.tab-config-item'), e);
            }
        });

        list.addEventListener('drop', function(e) {
            if (e.target.closest('.tab-config-item')) {
                handleDrop.call(e.target.closest('.tab-config-item'), e);
            }
        });

        list.addEventListener('dragenter', function(e) {
            if (e.target.closest('.tab-config-item')) {
                handleDragEnter.call(e.target.closest('.tab-config-item'), e);
            }
        });

        list.addEventListener('dragleave', function(e) {
            if (e.target.closest('.tab-config-item')) {
                handleDragLeave.call(e.target.closest('.tab-config-item'), e);
            }
        });

        // Mark that handlers have been attached
        list._dragHandlersAttached = true;
    }

    function handleDragStart(e) {
        draggedItem = this;
        this.classList.add('dragging');
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/plain', this.dataset.tab);
    }

    function handleDragEnd(e) {
        this.classList.remove('dragging');
        document.querySelectorAll('.tab-config-item').forEach(item => {
            item.classList.remove('drag-over');
        });
        draggedItem = null;
    }

    function handleDragOver(e) {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
    }

    function handleDragEnter(e) {
        e.preventDefault();
        if (this !== draggedItem) {
            this.classList.add('drag-over');
        }
    }

    function handleDragLeave(e) {
        this.classList.remove('drag-over');
    }

    function handleDrop(e) {
        e.preventDefault();
        this.classList.remove('drag-over');

        if (draggedItem && this !== draggedItem) {
            const list = document.getElementById('tab-config-list');
            const items = Array.from(list.querySelectorAll('.tab-config-item'));
            const draggedIndex = items.indexOf(draggedItem);
            const dropIndex = items.indexOf(this);

            if (draggedIndex < dropIndex) {
                this.parentNode.insertBefore(draggedItem, this.nextSibling);
            } else {
                this.parentNode.insertBefore(draggedItem, this);
            }
        }
    }

    /**
     * Toggle tab visibility
     */
    window.toggleTabVisibility = function(tabName, visible) {
        if (!currentConfig) return;
        if (!currentConfig.tabs.visibility) {
            currentConfig.tabs.visibility = {};
        }
        currentConfig.tabs.visibility[tabName] = visible;
    };

    /**
     * Save tab configuration
     */
    window.saveTabConfig = function() {
        const list = document.getElementById('tab-config-list');
        if (!list) return;

        // Get new order from DOM
        const newOrder = Array.from(list.querySelectorAll('.tab-config-item'))
            .map(item => item.dataset.tab);

        // Get visibility from checkboxes
        const visibility = {};
        list.querySelectorAll('.tab-visibility-checkbox').forEach(checkbox => {
            visibility[checkbox.dataset.tab] = checkbox.checked;
        });

        const config = {
            tabs: {
                order: newOrder,
                visibility: visibility
            },
            version: 1
        };

        // Save to server
        fetch('/api/ui/config', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(config)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                currentConfig = config;
                applyTabConfig(config);
                closeTabSettings();
                console.log('TabManager: Configuration saved');
            } else {
                alert('Failed to save configuration: ' + (data.error || 'Unknown error'));
            }
        })
        .catch(error => {
            console.error('TabManager: Error saving config:', error);
            alert('Failed to save configuration');
        });
    };

    /**
     * Reset tab configuration to default
     */
    window.resetTabConfig = function() {
        const defaultConfig = {
            tabs: {
                order: Object.keys(TAB_LABELS),
                visibility: Object.keys(TAB_LABELS).reduce((acc, key) => {
                    acc[key] = true;
                    return acc;
                }, {})
            },
            version: 1
        };

        // Save default config
        fetch('/api/ui/config', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(defaultConfig)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                currentConfig = defaultConfig;
                applyTabConfig(defaultConfig);
                renderTabConfigList();
                console.log('TabManager: Configuration reset to default');
            }
        })
        .catch(error => {
            console.error('TabManager: Error resetting config:', error);
        });
    };

    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initTabManager);
    } else {
        initTabManager();
    }

})();
