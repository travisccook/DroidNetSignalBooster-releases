#!/bin/bash
# Comprehensive change script for DroidNet updates
# This is executed automatically during update installation
#
# Fixes applied:
# 1. Comlink JSON history corruption detection and repair
# 2. Missing dependencies installation (avahi-utils, pyusb, victron-ble)
# 3. Victron telemetry storage validation

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "=============================================="
echo "=== DroidNet Update - Applying Changes ==="
echo "=============================================="
echo ""

# ============================================================================
# 1. Comlink JSON Fix
# ============================================================================

echo "=== Step 1: Comlink History Validation ==="

# Copy the fix script to a permanent location
if [ -f "$SCRIPT_DIR/scripts/fix_comlink_json_v2.py" ] || [ -f "scripts/fix_comlink_json_v2.py" ]; then
    FIX_SCRIPT=""
    [ -f "$SCRIPT_DIR/scripts/fix_comlink_json_v2.py" ] && FIX_SCRIPT="$SCRIPT_DIR/scripts/fix_comlink_json_v2.py"
    [ -f "scripts/fix_comlink_json_v2.py" ] && FIX_SCRIPT="scripts/fix_comlink_json_v2.py"

    if [ -n "$FIX_SCRIPT" ]; then
        cp "$FIX_SCRIPT" /opt/droidnet/scripts/fix_comlink_json_v2.py 2>/dev/null || true
        chmod +x /opt/droidnet/scripts/fix_comlink_json_v2.py 2>/dev/null || true
    fi
fi

# Check if Comlink history file exists and needs fixing
HISTORY_FILE="/opt/droidnet/data/comlink_history.json"
if [ -f "$HISTORY_FILE" ]; then
    echo "Checking Comlink history file..."

    # Try to parse the JSON file
    if ! python3 -c "import json; json.load(open('$HISTORY_FILE'))" 2>/dev/null; then
        echo "Comlink history file is corrupted, attempting recovery..."

        # Backup the corrupted file
        cp "$HISTORY_FILE" "${HISTORY_FILE}.corrupted.$(date +%Y%m%d_%H%M%S)"

        # Run the fix script if it exists
        if [ -f "/opt/droidnet/scripts/fix_comlink_json_v2.py" ]; then
            python3 /opt/droidnet/scripts/fix_comlink_json_v2.py "$HISTORY_FILE" || {
                echo "Recovery failed, creating new empty history"
                echo '{"commands": []}' > "$HISTORY_FILE"
            }
        else
            # Fallback: create empty history
            echo '{"commands": []}' > "$HISTORY_FILE"
            echo "Created new empty history file"
        fi
    else
        echo "[OK] Comlink history file is valid"
    fi
else
    echo "No existing Comlink history file found"
fi

echo ""

# ============================================================================
# 2. Victron Telemetry Storage Validation
# ============================================================================

echo "=== Step 2: Victron Telemetry Validation ==="

VICTRON_FILE="/opt/droidnet/data/victron_telemetry.json"
if [ -f "$VICTRON_FILE" ]; then
    if ! python3 -c "import json; json.load(open('$VICTRON_FILE'))" 2>/dev/null; then
        echo "Victron telemetry file is corrupted, resetting..."
        cp "$VICTRON_FILE" "${VICTRON_FILE}.corrupted.$(date +%Y%m%d_%H%M%S)"
        echo '{"latest": null, "history": [], "saved_at": null}' > "$VICTRON_FILE"
        echo "[OK] Victron telemetry file reset"
    else
        echo "[OK] Victron telemetry file is valid"
    fi
else
    echo "No existing Victron telemetry file found"
fi

echo ""

# ============================================================================
# 3. Install Missing Dependencies
# ============================================================================

echo "=== Step 3: Installing Missing Dependencies ==="

# Check for and run the fix-missing-dependencies script
FIX_DEPS_SCRIPT=""
[ -f "$SCRIPT_DIR/changes/fix-missing-dependencies.sh" ] && FIX_DEPS_SCRIPT="$SCRIPT_DIR/changes/fix-missing-dependencies.sh"
[ -f "changes/fix-missing-dependencies.sh" ] && FIX_DEPS_SCRIPT="changes/fix-missing-dependencies.sh"
[ -f "/opt/droidnet/updates/changes/fix-missing-dependencies.sh" ] && FIX_DEPS_SCRIPT="/opt/droidnet/updates/changes/fix-missing-dependencies.sh"

if [ -n "$FIX_DEPS_SCRIPT" ] && [ -f "$FIX_DEPS_SCRIPT" ]; then
    echo "Running dependency installation script..."
    bash "$FIX_DEPS_SCRIPT" || {
        echo "Warning: Some dependencies may not have been installed"
    }
else
    # Inline dependency checks if script not found
    echo "Checking critical dependencies..."

    # Check avahi-utils
    if ! command -v avahi-browse >/dev/null 2>&1; then
        echo "Installing avahi-utils..."
        apt-get update -qq 2>/dev/null || true
        apt-get install -y -qq avahi-utils 2>/dev/null || echo "Warning: Could not install avahi-utils"
    else
        echo "[OK] avahi-utils installed"
    fi

    # Check pyusb
    if ! python3 -c "import usb.core" 2>/dev/null; then
        echo "Installing pyusb..."
        pip3 install --break-system-packages pyusb 2>/dev/null || echo "Warning: Could not install pyusb"
    else
        echo "[OK] pyusb installed"
    fi

    # Check victron-ble
    if ! python3 -c "from victron_ble.devices import detect_device_type" 2>/dev/null; then
        echo "Installing victron-ble dependencies..."
        pip3 install --break-system-packages dbus-fast bleak victron-ble 2>/dev/null || echo "Warning: Could not install victron-ble"
    else
        echo "[OK] victron-ble installed"
    fi
fi

echo ""

# ============================================================================
# 4. Install esptool if missing (required for ESP32 flashing)
# ============================================================================

echo "=== Step 4: Checking esptool Installation ==="

# Disable exit-on-error for esptool section (we handle errors explicitly)
set +e

install_python_package_from_tarball() {
    local tarball="$1"
    local pkg_name="$2"

    cd /tmp || return 1
    tar -xzf "$tarball" || { echo "Error: Failed to extract $tarball"; return 1; }

    # Find the extracted directory
    local pkg_dir=$(find /tmp -maxdepth 1 -type d -name "${pkg_name}-*" | head -1)
    if [ -z "$pkg_dir" ]; then
        echo "Error: Could not find extracted ${pkg_name} directory"
        return 1
    fi

    # Install the package directly to site-packages
    if [ -d "$pkg_dir/$pkg_name" ]; then
        cp -r "$pkg_dir/$pkg_name" /usr/local/lib/python3.11/dist-packages/
        echo "  Installed ${pkg_name} module"
    elif [ -d "$pkg_dir/src/$pkg_name" ]; then
        cp -r "$pkg_dir/src/$pkg_name" /usr/local/lib/python3.11/dist-packages/
        echo "  Installed ${pkg_name} module (from src)"
    else
        echo "Warning: Could not find ${pkg_name} module in tarball"
    fi

    # Clean up
    rm -rf "$pkg_dir"
    return 0
}

install_esptool_from_tarball() {
    local tarball="$1"
    echo "Installing esptool from bundled tarball..."

    # First install intelhex dependency if available
    local intelhex_tarball=""
    [ -f "$SCRIPT_DIR/intelhex-2.3.0.tar.gz" ] && intelhex_tarball="$SCRIPT_DIR/intelhex-2.3.0.tar.gz"
    [ -f "intelhex-2.3.0.tar.gz" ] && intelhex_tarball="intelhex-2.3.0.tar.gz"

    if [ -n "$intelhex_tarball" ] && [ -f "$intelhex_tarball" ]; then
        echo "  Installing intelhex dependency..."
        install_python_package_from_tarball "$intelhex_tarball" "intelhex"
    fi

    # Install esptool
    install_python_package_from_tarball "$tarball" "esptool"

    # Create the executable script
    # Note: Don't create esptool.py symlink as it causes import conflicts
    cat > /usr/local/bin/esptool << 'ESPTOOL_WRAPPER'
#!/usr/bin/python3
import sys
import os

# Ensure we don't import from the script directory
script_dir = os.path.dirname(os.path.abspath(__file__))
if script_dir in sys.path:
    sys.path.remove(script_dir)

from esptool import main
main()
ESPTOOL_WRAPPER

    chmod +x /usr/local/bin/esptool
    # Remove any existing esptool.py symlink that could cause import conflicts
    rm -f /usr/local/bin/esptool.py

    echo "esptool installed from tarball"
    return 0
}

# Function to check esptool functionality
check_esptool() {
    # First check if esptool command exists
    if ! command -v esptool >/dev/null 2>&1; then
        return 1
    fi

    # Try to import esptool module
    python3 -c "import esptool" 2>/dev/null
    return $?
}

# Check if esptool is functional
if check_esptool; then
    echo "[OK] esptool is installed and functional"
else
    echo "esptool is missing or non-functional, installing..."

    # Try to find bundled tarball in update package (offline installation)
    # Prefer 4.7.0 for compatibility (doesn't require rich_click)
    ESPTOOL_TARBALL=""
    [ -f "$SCRIPT_DIR/esptool-4.7.0.tar.gz" ] && ESPTOOL_TARBALL="$SCRIPT_DIR/esptool-4.7.0.tar.gz"
    [ -f "esptool-4.7.0.tar.gz" ] && ESPTOOL_TARBALL="esptool-4.7.0.tar.gz"
    [ -f "$SCRIPT_DIR/esptool-5.0.0.tar.gz" ] && ESPTOOL_TARBALL="$SCRIPT_DIR/esptool-5.0.0.tar.gz"
    [ -f "esptool-5.0.0.tar.gz" ] && ESPTOOL_TARBALL="esptool-5.0.0.tar.gz"

    INSTALL_SUCCESS=false

    # Install from bundled tarball (offline installation)
    if [ -n "$ESPTOOL_TARBALL" ] && [ -f "$ESPTOOL_TARBALL" ]; then
        if install_esptool_from_tarball "$ESPTOOL_TARBALL"; then
            INSTALL_SUCCESS=true
        fi
    else
        echo "Error: esptool tarball not found in update package"
        echo "Expected: esptool-5.0.0.tar.gz or esptool-5.1.0.tar.gz"
    fi

    # Verify installation
    if [ "$INSTALL_SUCCESS" = true ]; then
        # Test import and capture any errors
        IMPORT_ERROR=$(python3 -c "import esptool" 2>&1)
        if [ $? -eq 0 ]; then
            echo "[OK] esptool installed successfully"

            # Create marker file
            mkdir -p /var/lib/droidnet
            touch /var/lib/droidnet/esptool-installed
        else
            # Check what dependency is missing
            if echo "$IMPORT_ERROR" | grep -q "intelhex"; then
                echo "[WARNING] esptool installed but intelhex dependency missing"
                echo "         Ensure intelhex tarball is included in update packages"
            elif echo "$IMPORT_ERROR" | grep -q "click"; then
                echo "[WARNING] esptool installed but click dependency missing"
                echo "         Install python3-click on the device"
            else
                echo "[WARNING] esptool installation incomplete: $IMPORT_ERROR"
            fi
        fi
    else
        echo "[WARNING] esptool installation failed - ESP32 flashing will not work"
        echo "         Ensure esptool tarball is included in update packages"
    fi
fi

# Re-enable exit-on-error
set -e

echo ""

# ============================================================================
# 5. Ensure data directory exists with correct permissions
# ============================================================================

echo "=== Step 5: Directory Permissions ==="

mkdir -p /opt/droidnet/data
chmod 755 /opt/droidnet/data
echo "[OK] Data directory verified"

echo ""
echo "=============================================="
echo "=== DroidNet Update Changes Applied ==="
echo "=============================================="
echo ""
echo "Services will be restarted by the update manager."
echo ""