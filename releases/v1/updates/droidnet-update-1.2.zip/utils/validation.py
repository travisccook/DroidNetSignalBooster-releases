"""Validation utilities for DroidNetSignalBooster."""

import re
from typing import Tuple, Optional


def validate_serial_port(port: str) -> Tuple[bool, Optional[str]]:
    """Validate serial port path format.

    Args:
        port: Serial port path to validate

    Returns:
        Tuple of (is_valid, error_message)
        - is_valid: True if the port path is valid
        - error_message: Error description if invalid, None if valid

    Examples:
        >>> validate_serial_port("/dev/ttyACM0")
        (True, None)
        >>> validate_serial_port("/dev/ttyUSB5")
        (True, None)
        >>> validate_serial_port("")
        (False, 'Port path cannot be empty')
        >>> validate_serial_port("/dev/invalid")
        (False, 'Invalid port path format: /dev/invalid')
    """
    if not port:
        return False, "Port path cannot be empty"
    if not re.match(r"^/dev/(ttyACM|ttyUSB|ttyS|maestro_)\d*$", port):
        return False, f"Invalid port path format: {port}"
    return True, None
