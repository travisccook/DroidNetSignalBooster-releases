"""Configuration file handling utilities.

This module provides utilities for loading and saving JSON configuration files
with robust error handling and atomic writes.
"""

import json
import logging
import os
import tempfile
from pathlib import Path
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


def load_json_config(filepath: str, defaults: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Load JSON configuration from a file with fallback to defaults.

    Args:
        filepath: Path to the JSON configuration file.
        defaults: Default configuration dictionary to use if file doesn't exist
                 or is invalid. If None, an empty dict is used.

    Returns:
        Dictionary containing the configuration. If the file exists and is valid,
        the loaded config is merged with defaults (loaded values take precedence).
        If the file doesn't exist or contains invalid JSON, returns the defaults.

    Examples:
        >>> config = load_json_config('/path/to/config.json', {'port': 8080})
        >>> port = config.get('port', 8080)
    """
    if defaults is None:
        defaults = {}

    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            loaded_config = json.load(f)

        # Merge defaults with loaded config (loaded config takes precedence)
        merged_config = defaults.copy()
        merged_config.update(loaded_config)
        return merged_config

    except FileNotFoundError:
        logger.debug(f"Config file not found: {filepath}. Using defaults.")
        return defaults.copy()

    except json.JSONDecodeError as e:
        logger.warning(
            f"Invalid JSON in config file {filepath}: {e}. Using defaults."
        )
        return defaults.copy()

    except Exception as e:
        logger.error(
            f"Unexpected error loading config from {filepath}: {e}. Using defaults."
        )
        return defaults.copy()


def save_json_config(filepath: str, config: Dict[str, Any], indent: int = 2) -> bool:
    """Save configuration to a JSON file atomically.

    This function writes the configuration to a temporary file first, then
    atomically renames it to the target filepath. This prevents partial writes
    and corruption if the process is interrupted.

    Args:
        filepath: Path where the configuration file should be saved.
        config: Configuration dictionary to save.
        indent: Number of spaces for JSON indentation (default: 2).

    Returns:
        True if the file was saved successfully, False otherwise.

    Examples:
        >>> config = {'port': 8080, 'debug': True}
        >>> success = save_json_config('/path/to/config.json', config)
        >>> if success:
        ...     print("Config saved successfully")
    """
    try:
        # Ensure parent directory exists
        Path(filepath).parent.mkdir(parents=True, exist_ok=True)

        # Write to a temporary file in the same directory as the target file
        # This ensures the temp file is on the same filesystem for atomic rename
        target_dir = os.path.dirname(os.path.abspath(filepath))
        with tempfile.NamedTemporaryFile(
            mode='w',
            encoding='utf-8',
            dir=target_dir,
            delete=False,
            suffix='.tmp'
        ) as temp_file:
            json.dump(config, temp_file, indent=indent, ensure_ascii=False)
            temp_file.flush()
            os.fsync(temp_file.fileno())  # Ensure data is written to disk
            temp_filename = temp_file.name

        # Atomically replace the target file with the temp file
        os.replace(temp_filename, filepath)
        logger.debug(f"Successfully saved config to {filepath}")
        return True

    except (OSError, IOError, TypeError, ValueError) as e:
        logger.error(f"Failed to save config to {filepath}: {e}")
        # Clean up temp file if it exists
        try:
            if 'temp_filename' in locals() and os.path.exists(temp_filename):
                os.unlink(temp_filename)
        except Exception:
            pass
        return False

    except Exception as e:
        logger.error(f"Unexpected error saving config to {filepath}: {e}")
        return False
