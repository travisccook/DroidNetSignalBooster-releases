#!/usr/bin/env python3
"""
Repair corrupted Comlink history JSON file
Attempts to salvage as many commands as possible from corrupted file
"""

import json
import sys
import re
import time


def repair_history_file(file_path):
    """Attempt to repair corrupted history JSON"""
    print(f"Repairing {file_path}...")

    # Read the corrupted file
    with open(file_path, "r") as f:
        content = f.read()

    # Try to find all command entries using regex
    # Pattern: timestamp, command, source, target, status
    command_pattern = (
        r'\{\s*"timestamp":\s*([\d.]+),\s*'
        r'"command":\s*"([^"]*(?:\\.[^"]*)*)",\s*'
        r'"source":\s*"([^"]*(?:\\.[^"]*)*)",\s*'
        r'"target":\s*"([^"]*)",\s*'
        r'"status":\s*"([^"]*)"\s*\}'
    )

    matches = re.finditer(command_pattern, content, re.MULTILINE | re.DOTALL)

    recovered_commands = []
    for match in matches:
        try:
            cmd = {
                "timestamp": float(match.group(1)),
                "command": match.group(2),
                "source": match.group(3),
                "target": match.group(4),
                "status": match.group(5),
            }
            recovered_commands.append(cmd)
        except Exception as e:
            print(f"Warning: Failed to parse command: {e}")
            continue

    # Sort by timestamp
    recovered_commands.sort(key=lambda x: x["timestamp"])

    # Create new history
    repaired_history = {
        "commands": recovered_commands,
        "repaired_at": time.time(),
        "repaired_count": len(recovered_commands),
    }

    # Backup original
    backup_path = file_path + ".backup." + str(int(time.time()))
    print(f"Backing up original to {backup_path}")
    with open(backup_path, "w") as f:
        f.write(content)

    # Write repaired version
    print(f"Writing repaired history with {len(recovered_commands)} commands")
    with open(file_path, "w") as f:
        json.dump(repaired_history, f, indent=2)

    print("✓ Repair complete!")
    return len(recovered_commands)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python3 repair_comlink_history.py <path_to_history_file>")
        sys.exit(1)

    file_path = sys.argv[1]
    try:
        count = repair_history_file(file_path)
        print(f"\nRecovered {count} commands")
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)
