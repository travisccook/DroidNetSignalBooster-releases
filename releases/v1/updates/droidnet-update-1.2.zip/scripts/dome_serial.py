#!/usr/bin/env python3
"""
Syren 10 Motor Controller Serial Communication
Handles packet serial protocol for dome motor control
"""

import time
import logging
import serial


class SyrenController:
    """
    Syren 10 motor controller interface
    Uses packet serial protocol at 9600 baud
    """

    def __init__(self, port: str = "/dev/ttyAMA0", address: int = 0x81):
        """
        Initialize Syren controller

        Args:
            port: Serial port path (hardware UART)
            address: Device address (default 0x81/129)
        """
        self.logger = logging.getLogger(__name__)
        self.port = port
        self.address = address
        self.serial = None
        self.last_speed = 0
        self.connected = False

        # Command constants
        self.CMD_FORWARD = 0
        self.CMD_REVERSE = 1
        self.CMD_RAMP = 7

        # Try to initialize serial connection
        self._init_serial()

    def _init_serial(self) -> bool:
        """Initialize serial port connection"""
        try:
            self.serial = serial.Serial(
                port=self.port,
                baudrate=9600,
                bytesize=serial.EIGHTBITS,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                timeout=0.1,
            )
            self.connected = True
            self.logger.info(f"Connected to Syren 10 on {self.port}")
            return True
        except Exception as e:
            self.logger.error(f"Failed to open serial port {self.port}: {e}")
            self.connected = False
            return False

    def send_packet(self, command: int, value: int) -> bool:
        """
        Send packet to Syren controller

        Packet format: [Address][Command][Value][Checksum]
        Checksum = (Address + Command + Value) & 0x7F

        Args:
            command: Command byte (0=forward, 1=reverse, etc)
            value: Speed/data value (0-126)

        Returns:
            True if sent successfully
        """
        if not self.connected or not self.serial:
            return False

        try:
            # Ensure value is in valid range
            value = max(0, min(126, value))

            # Calculate checksum
            checksum = (self.address + command + value) & 0x7F

            # Build packet
            packet = bytes([self.address, command, value, checksum])

            # Send packet
            self.serial.write(packet)
            self.serial.flush()

            self.logger.debug(f"Sent packet: {packet.hex()}")
            return True

        except Exception as e:
            self.logger.error(f"Error sending packet: {e}")
            return False

    def init_motor(self) -> bool:
        """
        Initialize motor controller
        Sends autobaud byte and stops motor
        """
        if not self.connected or not self.serial:
            return False

        try:
            # Send autobaud byte
            self.serial.write(b"\xAA")
            self.serial.flush()
            time.sleep(0.1)

            # Send timeout configuration (2 seconds)
            # Command 14 = Set serial timeout
            # Value 100 = 100 * 20ms = 2 seconds
            self.send_packet(14, 100)
            time.sleep(0.1)

            # Stop motor
            self.stop()

            self.logger.info("Motor controller initialized")
            return True

        except Exception as e:
            self.logger.error(f"Error initializing motor: {e}")
            return False

    def set_motor_speed(self, speed: int, scale_factor: float = 1.0) -> bool:
        """
        Set motor speed

        Args:
            speed: Motor speed (-127 to 127, 0 = stop)
            scale_factor: Speed scaling factor (0.0 to 1.0)

        Returns:
            True if command sent successfully
        """
        # Apply scale factor
        scaled_speed = int(speed * scale_factor)

        # Clamp to valid range
        scaled_speed = max(-127, min(127, scaled_speed))

        # Determine command and value
        if scaled_speed >= 0:
            # Forward
            command = self.CMD_FORWARD
            value = min(scaled_speed, 126)
        else:
            # Reverse
            command = self.CMD_REVERSE
            value = min(abs(scaled_speed), 126)

        # Send command
        success = self.send_packet(command, value)

        if success:
            self.last_speed = scaled_speed
            self.logger.debug(f"Set motor speed: {scaled_speed}")

        return success

    def stop(self) -> bool:
        """Stop motor immediately"""
        return self.set_motor_speed(0)

    def ramp_to_speed(self, target_speed: int, ramp_time: int = 10) -> bool:
        """
        Ramp motor to target speed over time

        Args:
            target_speed: Target speed (-127 to 127)
            ramp_time: Ramp time value (1-127, units depend on controller config)

        Returns:
            True if command sent successfully
        """
        # This uses the ramp command for smooth acceleration
        # First set the ramp rate
        if not self.send_packet(self.CMD_RAMP, min(ramp_time, 127)):
            return False

        # Then set target speed
        return self.set_motor_speed(target_speed)

    def close(self) -> None:
        """Close serial connection"""
        if self.serial:
            try:
                self.stop()  # Stop motor before closing
                self.serial.close()
                self.logger.info("Serial connection closed")
            except Exception as e:
                self.logger.error(f"Error closing serial: {e}")

        self.connected = False

    def __del__(self):
        """Cleanup on deletion"""
        self.close()


# Test/Debug functionality
if __name__ == "__main__":
    import sys

    # Set up logging
    logging.basicConfig(
        level=logging.DEBUG,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    # Create controller
    controller = SyrenController()

    if not controller.connected:
        print("Failed to connect to Syren controller")
        sys.exit(1)

    # Initialize
    if not controller.init_motor():
        print("Failed to initialize motor")
        sys.exit(1)

    print("Syren 10 controller ready")
    print("Commands: f=forward, r=reverse, s=stop, q=quit")
    print("Example: f50 (forward at speed 50)")

    try:
        while True:
            cmd = input("> ").strip().lower()

            if cmd == "q":
                break
            elif cmd == "s":
                controller.stop()
                print("Motor stopped")
            elif cmd.startswith("f"):
                try:
                    speed = int(cmd[1:])
                    controller.set_motor_speed(speed)
                    print(f"Forward at speed {speed}")
                except ValueError:
                    print("Invalid speed")
            elif cmd.startswith("r"):
                try:
                    speed = int(cmd[1:])
                    controller.set_motor_speed(-speed)
                    print(f"Reverse at speed {speed}")
                except ValueError:
                    print("Invalid speed")
            else:
                print("Unknown command")

    except KeyboardInterrupt:
        print("\nShutting down...")
    finally:
        controller.close()
