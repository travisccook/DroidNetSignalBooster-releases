#!/bin/bash
# Direct installation of esptool v4.7.0 without pip
# This extracts the Python package directly
# Supports offline installation with bundled tarball
# Using 4.7.0 for compatibility (doesn't require rich_click)

set -e

ESPTOOL_VERSION="4.7.0"
ESPTOOL_TARBALL="esptool-${ESPTOOL_VERSION}.tar.gz"

echo "Installing esptool v${ESPTOOL_VERSION} (direct method)..."

cd /tmp

# Check for local tarball first (offline installation)
LOCAL_TARBALL=""
[ -f "/opt/droidnet/updates/${ESPTOOL_TARBALL}" ] && LOCAL_TARBALL="/opt/droidnet/updates/${ESPTOOL_TARBALL}"
[ -f "/tmp/${ESPTOOL_TARBALL}" ] && LOCAL_TARBALL="/tmp/${ESPTOOL_TARBALL}"

if [ -n "$LOCAL_TARBALL" ]; then
    echo "Using local tarball: $LOCAL_TARBALL"
    cp "$LOCAL_TARBALL" "/tmp/${ESPTOOL_TARBALL}"
else
    echo "Downloading esptool source..."
    wget -q "https://files.pythonhosted.org/packages/source/e/esptool/esptool-${ESPTOOL_VERSION}.tar.gz" -O "${ESPTOOL_TARBALL}"
fi

tar -xzf "${ESPTOOL_TARBALL}"

# Install the package directly to site-packages
cd "esptool-${ESPTOOL_VERSION}"
cp -r esptool /usr/local/lib/python3.11/dist-packages/

# Create the executable script
# Note: Don't create esptool.py symlink as it causes import conflicts
cat > /usr/local/bin/esptool << 'EOF'
#!/usr/bin/python3
import sys
import os

# Ensure we don't import from the script directory
script_dir = os.path.dirname(os.path.abspath(__file__))
if script_dir in sys.path:
    sys.path.remove(script_dir)

from esptool import main
main()
EOF

chmod +x /usr/local/bin/esptool
# Remove any existing esptool.py symlink that could cause import conflicts
rm -f /usr/local/bin/esptool.py

# Create marker file
mkdir -p /var/lib/droidnet
touch /var/lib/droidnet/esptool-installed

# Test basic import
python3 -c "import esptool" && echo "esptool module installed successfully"

# Clean up
rm -rf "/tmp/esptool-${ESPTOOL_VERSION}"*

echo "esptool v${ESPTOOL_VERSION} installed!"
