#!/bin/bash
# Video Player Control Script
# Manages pause, resume, and stop operations for video playback

PID_FILE="/var/run/droidnet-video.pid"
LOG_FILE="/var/log/droidnet/video-player.log"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ERROR: $1" | tee -a "$LOG_FILE" >&2
}

# Get the PID of the current video player
get_pid() {
    if [[ -f "$PID_FILE" ]]; then
        cat "$PID_FILE"
    fi
}

# Check if video is playing
is_playing() {
    local pid=$(get_pid)
    if [[ -n "$pid" ]] && kill -0 "$pid" 2>/dev/null; then
        return 0
    fi
    return 1
}

# Pause video playback
pause_video() {
    local pid=$(get_pid)
    if [[ -z "$pid" ]]; then
        log_error "No video is playing"
        echo '{"success": false, "error": "No video is playing"}'
        return 1
    fi

    if ! kill -0 "$pid" 2>/dev/null; then
        log_error "Video process not found (PID: $pid)"
        rm -f "$PID_FILE"
        echo '{"success": false, "error": "Video process not found"}'
        return 1
    fi

    # Send STOP signal to pause
    if kill -STOP "$pid" 2>/dev/null; then
        log "Paused video playback (PID: $pid)"
        echo '{"success": true, "message": "Video paused"}'
        return 0
    else
        log_error "Failed to pause video (PID: $pid)"
        echo '{"success": false, "error": "Failed to pause video"}'
        return 1
    fi
}

# Resume video playback
resume_video() {
    local pid=$(get_pid)
    if [[ -z "$pid" ]]; then
        log_error "No video is playing"
        echo '{"success": false, "error": "No video is playing"}'
        return 1
    fi

    if ! kill -0 "$pid" 2>/dev/null; then
        log_error "Video process not found (PID: $pid)"
        rm -f "$PID_FILE"
        echo '{"success": false, "error": "Video process not found"}'
        return 1
    fi

    # Send CONT signal to resume
    if kill -CONT "$pid" 2>/dev/null; then
        log "Resumed video playback (PID: $pid)"
        echo '{"success": true, "message": "Video resumed"}'
        return 0
    else
        log_error "Failed to resume video (PID: $pid)"
        echo '{"success": false, "error": "Failed to resume video"}'
        return 1
    fi
}

# Stop video playback and turn off display
stop_video() {
    local pid=$(get_pid)
    if [[ -z "$pid" ]]; then
        log_error "No video is playing"
        echo '{"success": false, "error": "No video is playing"}'
        return 1
    fi

    # Send TERM signal to stop
    if kill -TERM "$pid" 2>/dev/null; then
        log "Stopped video playback (PID: $pid)"

        # Wait a moment for process to clean up
        sleep 0.5

        # Turn off HDMI
        if command -v vcgencmd &> /dev/null; then
            vcgencmd display_power 0 &>> "$LOG_FILE"
            log "HDMI power set to: 0"
        fi

        # Clean up PID file
        rm -f "$PID_FILE"

        echo '{"success": true, "message": "Video stopped"}'
        return 0
    else
        log_error "Failed to stop video (PID: $pid)"
        echo '{"success": false, "error": "Failed to stop video"}'
        return 1
    fi
}

# Get video playback status
get_status() {
    local pid=$(get_pid)

    if [[ -z "$pid" ]]; then
        echo '{"success": true, "playing": false, "paused": false}'
        return 0
    fi

    if ! kill -0 "$pid" 2>/dev/null; then
        # Process doesn't exist, clean up
        rm -f "$PID_FILE"
        echo '{"success": true, "playing": false, "paused": false}'
        return 0
    fi

    # Check if process is stopped (paused)
    local state=$(ps -o state= -p "$pid" 2>/dev/null | tr -d ' ')
    if [[ "$state" == "T" ]]; then
        echo '{"success": true, "playing": true, "paused": true, "pid": '$pid'}'
    else
        echo '{"success": true, "playing": true, "paused": false, "pid": '$pid'}'
    fi

    return 0
}

# Main command handler
case "${1:-}" in
    pause)
        pause_video
        ;;
    resume)
        resume_video
        ;;
    stop)
        stop_video
        ;;
    status)
        get_status
        ;;
    *)
        echo "Usage: $0 {pause|resume|stop|status}"
        exit 1
        ;;
esac
