#!/bin/bash
# Check for hostname collisions and find available hostname
# Returns an available hostname based on collision detection

LOG="/var/log/droidnet-hostname.log"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$LOG"
}

# Check if a hostname is already in use on the network
check_hostname_available() {
    local hostname="$1"
    
    # Use avahi-resolve to check if hostname exists (with timeout)
    if command -v avahi-resolve >/dev/null 2>&1; then
        if timeout 2 avahi-resolve -n "${hostname}.local" >/dev/null 2>&1; then
            return 1  # Hostname in use
        fi
    fi
    
    # Fallback to ping check (with short timeout)
    if timeout 2 ping -c 1 -W 1 "${hostname}.local" >/dev/null 2>&1; then
        return 1  # Hostname in use
    fi
    
    # Skip getent check as it can also hang
    # if getent hosts "${hostname}.local" >/dev/null 2>&1; then
    #     return 1  # Hostname in use
    # fi
    
    return 0  # Hostname available
}

# Find an available hostname starting from base
find_available_hostname() {
    local base="$1"
    local hostname="$base"
    local counter=2
    
    # First try the base name
    if check_hostname_available "$hostname"; then
        echo "$hostname"
        return 0
    fi
    
    # Try with incrementing numbers
    while [ $counter -le 99 ]; do
        hostname="${base}-$(printf "%02d" $counter)"
        if check_hostname_available "$hostname"; then
            echo "$hostname"
            return 0
        fi
        counter=$((counter + 1))
    done
    
    # If all numbered options are taken, return base with timestamp
    echo "${base}-$(date +%s | tail -c 5)"
}

# Main logic
main() {
    local requested_name="${1:-droidnet}"
    
    log "Checking hostname availability for: $requested_name"
    
    # Find available hostname
    local available_name=$(find_available_hostname "$requested_name")
    
    log "Available hostname found: $available_name"
    echo "$available_name"
}

# Run if executed directly
if [ "${BASH_SOURCE[0]}" == "${0}" ]; then
    main "$@"
fi