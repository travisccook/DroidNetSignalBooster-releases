#!/usr/bin/env python3
"""
PS3 Navigation Controller Manager for DroidNet
Handles Bluetooth connection, button mapping, and command routing
"""

import sys
import time
import json
import logging
import threading
from typing import Dict, Optional, Any
from datetime import datetime
from pathlib import Path

try:
    from evdev import InputDevice, ecodes, list_devices
except ImportError:
    print("Error: evdev module not found. Install with: pip3 install evdev")
    sys.exit(1)

# Import our serial handlers
from dome_serial import SyrenController
from marcduino_serial import MarcduinoController

# Import constants
from config.constants import CONFIG_DIR, LOG_DIR

# Import config helpers
sys.path.insert(0, "/opt/droidnet")
from utils.config_helpers import load_json_config, save_json_config

# Constants
CONTROLLER_CONFIG = CONFIG_DIR / "controller_config.json"
LAST_MAC_FILE = CONFIG_DIR / "last_controller.conf"
CONTROLLER_ENABLED_FLAG = CONFIG_DIR / "controller_enabled"

# PS3 Navigation Controller button mappings
PS3_NAV_BUTTONS = {
    103: "UP",  # D-pad up
    108: "DOWN",  # D-pad down
    105: "LEFT",  # D-pad left
    106: "RIGHT",  # D-pad right
    304: "CROSS",  # X button
    305: "CIRCLE",  # O button
    310: "L1",  # L1 shoulder
    311: "L2",  # L2 trigger
    317: "L3",  # Left stick click
    316: "PS",  # PlayStation button
}

# Analog stick constants
ANALOG_X = 0  # ABS_X
ANALOG_Y = 1  # ABS_Y
ANALOG_CENTER = 128
DEFAULT_DEADZONE = 10

# Timing constants (matching SHADOWMDC2B5)
CONTROLLER_READ_INTERVAL = 0.01  # 10ms
MOTOR_UPDATE_INTERVAL = 0.05  # 50ms minimum
SAFETY_TIMEOUT = 0.3  # 300ms
DISCONNECT_TIMEOUT = 10.0  # 10 seconds

# Default configuration
DEFAULT_CONFIG = {
    "dome_speed": 100,
    "stick_deadzone": 10,
    "serial_latency": 25,
    "dome_serial_port": "/dev/ttyAMA0",
    "marcduino_gpio_pin": 17,
    "last_controller_mac": "",
    "button_mappings": [
        {
            "primary": "UP",
            "modifier": None,
            "command": "%T1",
            "description": "Random Happy",
        },
        {
            "primary": "DOWN",
            "modifier": None,
            "command": "%T2",
            "description": "Random Angry",
        },
        {
            "primary": "LEFT",
            "modifier": None,
            "command": "%T3",
            "description": "Random Scared",
        },
        {
            "primary": "RIGHT",
            "modifier": None,
            "command": "%T4",
            "description": "Random Sad",
        },
    ],
}


class ControllerManager:
    """Main controller manager class"""

    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.running = False
        self.device = None
        self.config = self.load_config()

        # Initialize serial controllers
        self.dome_controller = None
        self.marcduino_controller = None
        self.init_serial_controllers()

        # State tracking
        self.connected = False
        self.last_activity = time.time()
        self.last_motor_update = 0
        self.current_buttons = set()
        self.battery_level = 0
        self.last_dome_speed = 0

        # Threading
        self.read_thread = None
        self.watchdog_thread = None

    def load_config(self) -> Dict[str, Any]:
        """Load configuration from file or create default"""
        config = load_json_config(str(CONTROLLER_CONFIG), defaults=DEFAULT_CONFIG.copy())

        # Save default config if file doesn't exist
        if not CONTROLLER_CONFIG.exists():
            self.save_config(config)

        return config

    def save_config(self, config: Dict[str, Any]) -> None:
        """Save configuration to file"""
        if not save_json_config(str(CONTROLLER_CONFIG), config):
            self.logger.error("Failed to save controller configuration")

    def init_serial_controllers(self) -> None:
        """Initialize serial communication controllers"""
        try:
            # Initialize Syren 10 controller for dome
            self.dome_controller = SyrenController(
                port=self.config.get("dome_serial_port", "/dev/ttyAMA0"), address=0x81
            )
            self.dome_controller.init_motor()

            # Initialize Marcduino controller
            self.marcduino_controller = MarcduinoController(
                gpio_pin=self.config.get("marcduino_gpio_pin", 17), baud=9600
            )
        except (OSError, PermissionError) as e:
            self.logger.error(f"Serial port access error: {e}")
        except ValueError as e:
            self.logger.error(f"Invalid serial configuration: {e}")

    def find_ps3_controller(self) -> Optional[str]:
        """Find PS3 Navigation Controller device"""
        devices = [InputDevice(path) for path in list_devices()]

        for device in devices:
            # Check for PS3 Navigation Controller
            # Vendor ID: 0x054c (Sony), Product ID: 0x042f (Navigation Controller)
            if device.info.vendor == 0x054C and device.info.product == 0x042F:
                return device.path

            # Also check by name
            if (
                "Navigation Controller" in device.name
                or "PLAYSTATION(R)3" in device.name
            ):
                return device.path

        return None

    def connect(self) -> bool:
        """Connect to PS3 controller"""
        try:
            # Try to find controller
            device_path = self.find_ps3_controller()

            if not device_path:
                # Try to reconnect to last known MAC if available
                last_mac = self.load_last_mac()
                if last_mac:
                    self.logger.info(f"Attempting to reconnect to {last_mac}")
                    # This would trigger Bluetooth reconnection
                    # For now, just wait and retry
                    time.sleep(2)
                    device_path = self.find_ps3_controller()

            if device_path:
                self.device = InputDevice(device_path)
                self.connected = True
                self.last_activity = time.time()

                # Save MAC for future reconnection
                # Note: evdev doesn't directly expose MAC, would need bluetoothctl

                self.logger.info(f"Connected to controller: {self.device.name}")
                return True

        except (OSError, PermissionError) as e:
            self.logger.error(f"Device access error: {e}")
        except ValueError as e:
            self.logger.error(f"Invalid device configuration: {e}")

        return False

    def load_last_mac(self) -> Optional[str]:
        """Load last connected controller MAC address"""
        try:
            if LAST_MAC_FILE.exists():
                return LAST_MAC_FILE.read_text().strip()
        except (OSError, IOError):
            pass
        return None

    def save_last_mac(self, mac: str) -> None:
        """Save controller MAC address for reconnection"""
        try:
            CONFIG_DIR.mkdir(parents=True, exist_ok=True)
            LAST_MAC_FILE.write_text(mac)
        except (OSError, IOError) as e:
            self.logger.error(f"File error saving MAC: {e}")

    def read_controller(self) -> None:
        """Main controller reading loop"""
        last_status_write = 0
        status_write_interval = 0.5  # Write status every 500ms

        while self.running and self.connected:
            try:
                # Read events with timeout
                events = self.device.read()

                for event in events:
                    self.last_activity = time.time()

                    # Handle button events
                    if event.type == ecodes.EV_KEY:
                        button = PS3_NAV_BUTTONS.get(event.code)
                        if button:
                            if event.value == 1:  # Button pressed
                                self.current_buttons.add(button)
                                self.handle_button_press(button)
                            elif event.value == 0:  # Button released
                                self.current_buttons.discard(button)

                    # Handle analog stick
                    elif event.type == ecodes.EV_ABS:
                        if event.code == ANALOG_X:
                            self.handle_analog_stick(event.value)

                # Write status file periodically
                current_time = time.time()
                if current_time - last_status_write >= status_write_interval:
                    self.write_status_file()
                    last_status_write = int(current_time)

                time.sleep(CONTROLLER_READ_INTERVAL)

            except BlockingIOError:
                # No events available
                time.sleep(CONTROLLER_READ_INTERVAL)
            except (OSError, IOError) as e:
                self.logger.error(f"Device I/O error reading controller: {e}")
                self.connected = False
                break

    def handle_button_press(self, button: str) -> None:
        """Handle button press with modifier checking"""
        # Check for button combinations
        for mapping in self.config["button_mappings"]:
            if mapping["primary"] == button:
                # Check if modifier is required and pressed
                modifier = mapping.get("modifier")
                if modifier is None or modifier in self.current_buttons:
                    # Send command
                    command = mapping.get("command", "")
                    if command and self.marcduino_controller:
                        self.marcduino_controller.send_command(command)
                        desc = mapping.get("description", "Unknown")
                        self.logger.info(f"Sent command: {command} ({desc})")
                    break

    def handle_analog_stick(self, x_value: int) -> None:
        """Handle analog stick input for dome control"""
        # Apply deadzone
        deadzone = self.config.get("stick_deadzone", DEFAULT_DEADZONE)
        center_offset = x_value - ANALOG_CENTER

        if abs(center_offset) < deadzone:
            speed = 0
        else:
            # Map to -127 to 127 range
            if center_offset > 0:
                speed = int((center_offset - deadzone) * 127 / (127 - deadzone))
            else:
                speed = int((center_offset + deadzone) * 127 / (127 - deadzone))

        # Apply dome speed scaling
        scale_factor = self.config.get("dome_speed", 100) / 127.0

        # Only update motor if enough time has passed and speed changed
        current_time = time.time()
        if (
            current_time - self.last_motor_update >= MOTOR_UPDATE_INTERVAL
            and speed != self.last_dome_speed
        ):
            if self.dome_controller:
                self.dome_controller.set_motor_speed(speed, scale_factor)
                self.last_dome_speed = speed
                self.last_motor_update = int(current_time)

    def watchdog(self) -> None:
        """Safety watchdog for timeouts"""
        while self.running:
            try:
                current_time = time.time()

                # Check for safety timeout (stop motors)
                if current_time - self.last_activity > SAFETY_TIMEOUT:
                    if self.last_dome_speed != 0:
                        self.logger.warning("Safety timeout - stopping dome")
                        if self.dome_controller:
                            self.dome_controller.stop()
                        self.last_dome_speed = 0

                # Check for disconnect timeout
                if current_time - self.last_activity > DISCONNECT_TIMEOUT:
                    self.logger.warning("Controller timeout - disconnecting")
                    self.connected = False
                    if self.device:
                        self.device.close()
                    break

                time.sleep(0.1)  # Check every 100ms

            except (OSError, RuntimeError) as e:
                self.logger.error(f"Watchdog error: {e}")

    def start(self) -> None:
        """Start controller manager"""
        self.running = True

        # Main connection loop
        while self.running:
            try:
                if not self.connected:
                    self.logger.info("Searching for controller...")
                    if self.connect():
                        # Start read thread
                        self.read_thread = threading.Thread(target=self.read_controller)
                        self.read_thread.daemon = True
                        self.read_thread.start()

                        # Start watchdog thread
                        self.watchdog_thread = threading.Thread(target=self.watchdog)
                        self.watchdog_thread.daemon = True
                        self.watchdog_thread.start()

                        # Wait for threads
                        self.read_thread.join()
                        self.watchdog_thread.join()
                    else:
                        # Wait before retrying
                        time.sleep(5)

            except KeyboardInterrupt:
                break
            except (OSError, RuntimeError) as e:
                self.logger.error(f"Main loop error: {e}")
                time.sleep(5)

    def stop(self) -> None:
        """Stop controller manager"""
        self.running = False
        self.connected = False

        # Stop dome
        if self.dome_controller:
            self.dome_controller.stop()

        # Close device
        if self.device:
            self.device.close()

        # Write final status
        self.write_status_file()

    def get_status(self) -> Dict[str, Any]:
        """Get current controller status"""
        return {
            "connected": self.connected,
            "battery": self.battery_level,
            "last_update": datetime.now().isoformat(),
            "current_buttons": list(self.current_buttons),
            "dome_speed": self.last_dome_speed,
        }

    def write_status_file(self) -> None:
        """Write current status to file for web API"""
        try:
            status_dir = Path("/var/run/droidnet")
            status_dir.mkdir(parents=True, exist_ok=True)

            status_file = status_dir / "controller_status.json"
            status = self.get_status()

            with open(status_file, "w") as f:
                json.dump(status, f)
        except (OSError, IOError) as e:
            self.logger.error(f"File error writing status: {e}")


def main():
    """Main entry point"""
    # Set up logging
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        handlers=[
            logging.FileHandler(str(LOG_DIR / "controller.log")),
            logging.StreamHandler(),
        ],
    )

    # Check if controller is enabled
    if not CONTROLLER_ENABLED_FLAG.exists():
        logging.info("Controller feature is disabled")
        sys.exit(0)

    # Create and start manager
    manager = ControllerManager()

    try:
        manager.start()
    except KeyboardInterrupt:
        logging.info("Shutting down controller manager")
    finally:
        manager.stop()


if __name__ == "__main__":
    main()
