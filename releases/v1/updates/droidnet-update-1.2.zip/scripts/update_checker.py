#!/usr/bin/env python3
"""
DroidNet Update Checker

Periodically checks GitHub releases for available updates and stores
the result for the web interface to display.

Can run as:
- Oneshot: python3 update_checker.py --force
- Daemon: python3 update_checker.py --daemon
"""

import json
import logging
import ssl
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Optional

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from config.constants import CONFIG_DIR, RUNTIME_DIR, PROJECT_ROOT

# Configuration paths
UPDATE_CONFIG_FILE = CONFIG_DIR / "update-config.json"
UPDATE_AVAILABLE_FILE = RUNTIME_DIR / "update-available.json"
VERSION_FILE = PROJECT_ROOT / "VERSION"
MAJOR_VERSION_FILE = PROJECT_ROOT / "MAJOR_VERSION"

# Default configuration
DEFAULT_CONFIG: dict[str, Any] = {
    "auto_check_enabled": True,
    "check_interval_hours": 24,
    "releases_url": "https://raw.githubusercontent.com/travisccook/DroidNetSignalBooster-releases/main/releases.json",
    "last_check_timestamp": 0,
    "dismissed_version": None,
}

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("update_checker")


class UpdateChecker:
    """Checks GitHub releases for available updates."""

    def __init__(self) -> None:
        self.config = self._load_config()

    def _load_config(self) -> dict[str, Any]:
        """Load update configuration with defaults."""
        try:
            if UPDATE_CONFIG_FILE.exists():
                with open(UPDATE_CONFIG_FILE) as f:
                    config = json.load(f)
                    # Merge with defaults
                    merged = DEFAULT_CONFIG.copy()
                    merged.update(config)
                    return merged
        except Exception as e:
            logger.error(f"Failed to load config: {e}")
        return DEFAULT_CONFIG.copy()

    def _save_config(self) -> None:
        """Save configuration atomically."""
        try:
            CONFIG_DIR.mkdir(parents=True, exist_ok=True)
            temp_file = UPDATE_CONFIG_FILE.with_suffix(".tmp")
            with open(temp_file, "w") as f:
                json.dump(self.config, f, indent=2)
            temp_file.replace(UPDATE_CONFIG_FILE)
        except Exception as e:
            logger.error(f"Failed to save config: {e}")

    def get_current_version(self) -> tuple[str, str]:
        """Get current version and major version.

        Returns:
            Tuple of (full_version, major_version)
        """
        current_version = "1.0"
        major_version = "1"

        try:
            if VERSION_FILE.exists():
                current_version = VERSION_FILE.read_text().strip()
            if MAJOR_VERSION_FILE.exists():
                major_version = MAJOR_VERSION_FILE.read_text().strip()
            else:
                # Extract major from version string
                major_version = current_version.split(".")[0]
        except Exception as e:
            logger.error(f"Failed to read version: {e}")

        return current_version, major_version

    def fetch_releases_index(self) -> Optional[dict[str, Any]]:
        """Fetch releases.json from GitHub."""
        try:
            url = self.config["releases_url"]
            logger.info(f"Fetching releases from: {url}")

            # Create SSL context for HTTPS
            ctx = ssl.create_default_context()

            request = urllib.request.Request(
                url, headers={"User-Agent": "DroidNet-UpdateChecker/1.0"}
            )

            with urllib.request.urlopen(request, context=ctx, timeout=30) as response:
                data = json.loads(response.read().decode("utf-8"))
                logger.info("Successfully fetched releases index")
                return data

        except urllib.error.HTTPError as e:
            logger.error(f"HTTP error fetching releases: {e.code}")
        except urllib.error.URLError as e:
            logger.error(f"URL error fetching releases: {e.reason}")
        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON in releases: {e}")
        except Exception as e:
            logger.error(f"Failed to fetch releases: {e}")

        return None

    def compare_versions(self, current: str, available: str) -> bool:
        """Returns True if available is newer than current."""
        try:
            current_parts = [int(x) for x in current.split(".")]
            available_parts = [int(x) for x in available.split(".")]

            # Pad with zeros if needed
            while len(current_parts) < 2:
                current_parts.append(0)
            while len(available_parts) < 2:
                available_parts.append(0)

            return available_parts > current_parts
        except ValueError:
            # Fall back to string comparison for non-numeric versions
            logger.warning(
                f"Non-numeric version comparison: {current} vs {available}"
            )
            return available > current

    def check_for_updates(self, force: bool = False) -> Optional[dict[str, Any]]:
        """Check for available updates.

        Args:
            force: If True, skip rate limiting check

        Returns:
            Update info dict if update available, None otherwise
        """
        current_version, major_version = self.get_current_version()
        logger.info(
            f"Current version: {current_version}, major: {major_version}"
        )

        # Check if we should skip (rate limiting)
        if not force:
            last_check = self.config.get("last_check_timestamp", 0)
            interval_seconds = self.config.get("check_interval_hours", 24) * 3600
            time_since_check = time.time() - last_check
            if time_since_check < interval_seconds:
                logger.debug(
                    f"Skipping check - {time_since_check:.0f}s since last check, "
                    f"interval is {interval_seconds}s"
                )
                return None

        # Fetch releases index
        releases = self.fetch_releases_index()
        if not releases:
            logger.warning("Could not fetch releases index")
            return None

        # Update last check timestamp
        self.config["last_check_timestamp"] = int(time.time())
        self._save_config()

        # Find update for our major version
        latest_info = releases.get("latest", {}).get(major_version)
        if not latest_info:
            logger.info(f"No updates available for major version {major_version}")
            self._clear_update_available()
            return None

        available_version = latest_info.get("version")
        if not available_version:
            logger.warning("No version field in latest release info")
            return None

        # Check if dismissed
        if available_version == self.config.get("dismissed_version"):
            logger.info(f"Version {available_version} was dismissed by user")
            return None

        # Compare versions
        if self.compare_versions(current_version, available_version):
            update_info = {
                "available": True,
                "current_version": current_version,
                "available_version": available_version,
                "major_version": major_version,
                "download_url": latest_info.get("download_url"),
                "checksum_sha256": latest_info.get("checksum_sha256"),
                "size_bytes": latest_info.get("size_bytes", 0),
                "changelog": latest_info.get("changelog", []),
                "checked_at": int(time.time()),
                "release_date": latest_info.get("release_date"),
            }

            self._save_update_available(update_info)
            logger.info(
                f"Update available: {current_version} -> {available_version}"
            )
            return update_info
        else:
            logger.info(f"Already on latest version: {current_version}")
            self._clear_update_available()
            return None

    def _save_update_available(self, info: dict[str, Any]) -> None:
        """Save update available state."""
        try:
            RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
            temp_file = UPDATE_AVAILABLE_FILE.with_suffix(".tmp")
            with open(temp_file, "w") as f:
                json.dump(info, f, indent=2)
            temp_file.replace(UPDATE_AVAILABLE_FILE)
            logger.debug(f"Saved update info to {UPDATE_AVAILABLE_FILE}")
        except Exception as e:
            logger.error(f"Failed to save update state: {e}")

    def _clear_update_available(self) -> None:
        """Clear update available state."""
        try:
            if UPDATE_AVAILABLE_FILE.exists():
                UPDATE_AVAILABLE_FILE.unlink()
                logger.debug("Cleared update available state")
        except Exception as e:
            logger.error(f"Failed to clear update state: {e}")


def main() -> None:
    """Run update check."""
    import argparse

    parser = argparse.ArgumentParser(description="DroidNet Update Checker")
    parser.add_argument(
        "--force", action="store_true", help="Force check ignoring rate limit"
    )
    parser.add_argument(
        "--daemon",
        action="store_true",
        help="Run as daemon with periodic checks",
    )
    parser.add_argument(
        "--verbose", "-v", action="store_true", help="Enable verbose logging"
    )
    args = parser.parse_args()

    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    checker = UpdateChecker()

    if args.daemon:
        logger.info("Starting update checker daemon")
        while True:
            try:
                checker.check_for_updates()
            except Exception as e:
                logger.error(f"Check failed: {e}")

            # Sleep for check interval
            interval = checker.config.get("check_interval_hours", 24) * 3600
            logger.info(f"Next check in {interval / 3600:.1f} hours")
            time.sleep(interval)
    else:
        result = checker.check_for_updates(force=args.force)
        if result:
            print(json.dumps(result, indent=2))
            sys.exit(0)
        else:
            current, major = checker.get_current_version()
            print(f"No updates available (current: v{current})")
            sys.exit(1)


if __name__ == "__main__":
    main()
