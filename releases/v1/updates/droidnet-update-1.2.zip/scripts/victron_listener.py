#!/usr/bin/env python3
"""
Victron Smart Shunt BLE Listener

Monitors Victron Smart Shunt BLE advertisements using the victron-ble library.
Based on the WCBListener pattern for consistency with existing architecture.
"""

import asyncio
import logging
import time
import sys
import os
import threading
from typing import Optional, Callable, Dict, Any, List
from dataclasses import dataclass, asdict
from datetime import datetime

# Scan timing constants - periodic scanning to reduce CPU load
SCAN_DURATION = 3.0  # Seconds to scan (catch at least 2-3 Victron broadcasts at 1Hz)
SCAN_INTERVAL_PI_ZERO_W = 30.0  # Pause between scans on Pi Zero W (constrained CPU)
SCAN_INTERVAL_PI_ZERO_2 = 15.0  # Pause between scans on Pi Zero 2
SCAN_INTERVAL_DEFAULT = 10.0  # Pause between scans on Pi 3/4


def _get_pi_model():
    """Get Pi model for scan interval configuration."""
    # Try to import from web server module
    try:
        # Add parent directory to path if needed
        parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        web_dir = os.path.join(parent_dir, "web")
        if web_dir not in sys.path:
            sys.path.insert(0, web_dir)
        from server import get_pi_model

        return get_pi_model()
    except ImportError:
        pass

    # Fallback: detect directly from /proc/cpuinfo
    try:
        with open("/proc/cpuinfo", "r") as f:
            cpuinfo = f.read()
        if "Pi Zero W" in cpuinfo and "BCM2835" in cpuinfo:
            return "pi_zero_w"
        elif "Pi Zero 2" in cpuinfo:
            return "pi_zero_2"
        elif "Pi 3" in cpuinfo:
            return "pi_3"
        elif "Pi 4" in cpuinfo:
            return "pi_4"
    except Exception:
        pass

    return "unknown"


def _get_scan_interval():
    """Get appropriate scan interval based on Pi model."""
    pi_model = _get_pi_model()
    if pi_model == "pi_zero_w":
        return SCAN_INTERVAL_PI_ZERO_W
    elif pi_model == "pi_zero_2":
        return SCAN_INTERVAL_PI_ZERO_2
    else:
        return SCAN_INTERVAL_DEFAULT


try:
    from bleak import BleakScanner
    from bleak.exc import BleakError

    try:
        from bleak.exc import BleakBluetoothNotAvailableError
    except ImportError:
        # Older versions of bleak don't have this specific exception
        BleakBluetoothNotAvailableError = None
    from victron_ble.devices import detect_device_type

    VICTRON_BLE_AVAILABLE = True
except ImportError:
    VICTRON_BLE_AVAILABLE = False
    BleakBluetoothNotAvailableError = None
    logging.warning("victron-ble library not installed. Run: pip install victron-ble")

logger = logging.getLogger(__name__)


@dataclass
class VictronTelemetry:
    """Parsed Victron telemetry data."""

    # Core measurements
    voltage: float  # Battery voltage (V)
    current: float  # Battery current (A) - positive=charging, negative=discharging
    power: float  # Instantaneous power (W)
    soc: float  # State of charge (%)
    consumed_ah: float  # Consumed amp-hours (Ah)
    time_remaining: Optional[int]  # Time to go (minutes)

    # Optional measurements
    aux_voltage: Optional[float] = None  # Auxiliary voltage (V)
    temperature: Optional[float] = None  # Temperature (°C)

    # Alarms
    alarms: List[str] = None  # List of active alarm descriptions

    # Metadata
    timestamp: float = 0.0  # Unix timestamp
    rssi: int = 0  # Signal strength (dBm)

    def __post_init__(self):
        """Initialize mutable defaults."""
        if self.alarms is None:
            self.alarms = []


class VictronListener:
    """
    Always-on listener for Victron BLE advertisements.

    Uses the BLE Advertising protocol (Instant Readout) which:
    - Requires no pairing/connection
    - Broadcasts encrypted data continuously
    - Allows multiple simultaneous listeners
    - Updates approximately once per second
    """

    def __init__(
        self,
        mac_address: str,
        encryption_key: str,
        event_bus=None,
        on_telemetry: Optional[Callable] = None,
    ):
        """
        Initialize Victron BLE listener.

        Args:
            mac_address: Device MAC address (AA:BB:CC:DD:EE:FF)
            encryption_key: 32-character hexadecimal encryption key
            event_bus: Optional EventBus for publishing telemetry
            on_telemetry: Optional callback for telemetry updates
        """
        if not VICTRON_BLE_AVAILABLE:
            raise ImportError(
                "victron-ble library not available. Install with: pip install victron-ble"
            )

        self.mac_address = mac_address.upper()
        self.encryption_key = encryption_key.lower()
        self.event_bus = event_bus
        self.on_telemetry = on_telemetry

        # State
        self._scanner: Optional[BleakScanner] = None
        self._running = False
        self._last_telemetry: Optional[VictronTelemetry] = None
        self._last_update_time: float = 0.0
        self._last_callback_time: float = 0.0  # For rate limiting
        self._device_type = None  # Will be detected from first advertisement

        # Periodic scanning state
        self._scan_interval = _get_scan_interval()
        self._scan_duration = SCAN_DURATION
        self._scan_window_start: float = 0.0  # When current scan window started
        self._in_scan_window = False  # Whether we're currently in a scan window

        # Thread-based scanner control (avoids asyncio.sleep blocking)
        self._scan_thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._loop: Optional[asyncio.AbstractEventLoop] = None

        # Statistics
        self.stats = {
            "packets_received": 0,
            "packets_decrypted": 0,
            "decrypt_errors": 0,
            "last_rssi": 0,
            "connected": False,
            "scan_cycles": 0,  # Track scan cycles for debugging
        }

        # Bluetooth hardware error tracking
        self._bluetooth_unavailable = False
        self._bluetooth_error_message: Optional[str] = None
        self._consecutive_bt_failures = 0
        self._last_bt_error_log_time: float = 0.0
        self._bt_log_throttle_interval = 300  # Log once every 5 minutes when unavailable

        pi_model = _get_pi_model()
        logger.info(
            f"VictronListener initialized for device {self.mac_address[:8]}... "
            f"(Pi model: {pi_model}, scan interval: {self._scan_interval}s)"
        )

    async def start(self):
        """Start listening for BLE advertisements using thread-based periodic scanning."""
        if self._running:
            logger.warning("VictronListener already running")
            return

        self._running = True
        self._stop_event.clear()
        self._loop = asyncio.get_event_loop()

        logger.info(
            f"Starting Victron BLE scanning for {self.mac_address} "
            f"(scan {self._scan_duration}s, pause {self._scan_interval}s)"
        )

        # Start the scan management thread (scanner is created per cycle)
        self._scan_thread = threading.Thread(
            target=self._scan_loop_thread,
            name="VictronScanLoop",
            daemon=True,
        )
        self._scan_thread.start()

        self.stats["connected"] = True
        logger.info("Victron BLE scanner thread started")

    def _scan_loop_thread(self):
        """
        Thread-based scan loop that periodically starts/stops the BLE scanner.

        Uses threading.Event.wait() for timing instead of asyncio.sleep(),
        which avoids blocking issues on CPU-constrained devices.
        """
        while not self._stop_event.is_set():
            try:
                # Start scanning
                self._in_scan_window = True
                self._scan_window_start = time.time()
                self.stats["scan_cycles"] += 1
                logger.debug(
                    f"Victron scan cycle {self.stats['scan_cycles']}: "
                    f"scanning for {self._scan_duration}s"
                )

                # Create a new scanner for each cycle (Bleak scanners can't be restarted)
                future = asyncio.run_coroutine_threadsafe(
                    self._create_and_start_scanner(), self._loop
                )
                try:
                    future.result(timeout=10.0)  # Wait up to 10s for scanner to start
                    # Scanner started successfully - reset Bluetooth error state
                    if self._bluetooth_unavailable:
                        logger.info("Bluetooth hardware recovered - scanner started")
                        self._bluetooth_unavailable = False
                        self._bluetooth_error_message = None
                        self._consecutive_bt_failures = 0
                except Exception as e:
                    error_str = str(e)
                    error_name = type(e).__name__

                    # Detect Bluetooth hardware unavailability
                    is_bt_unavailable = (
                        (BleakBluetoothNotAvailableError is not None
                         and isinstance(e, BleakBluetoothNotAvailableError))
                        or "No Bluetooth adapters found" in error_str
                        or "BluetoothNotAvailable" in error_name
                        or "dbus-org.bluez.service" in error_str  # Service not running
                        or "org.bluez" in error_str.lower()  # Bluez service issues
                    )

                    if is_bt_unavailable:
                        self._bluetooth_unavailable = True
                        self._bluetooth_error_message = error_str
                        self._consecutive_bt_failures += 1

                        # Throttle logging: ERROR for first 3, then periodic warnings
                        now = time.time()
                        if self._consecutive_bt_failures <= 3:
                            logger.error(
                                f"Bluetooth hardware unavailable: {error_name}: {e}"
                            )
                            self._last_bt_error_log_time = now
                        elif (now - self._last_bt_error_log_time
                              >= self._bt_log_throttle_interval):
                            logger.warning(
                                f"Bluetooth still unavailable after "
                                f"{self._consecutive_bt_failures} attempts"
                            )
                            self._last_bt_error_log_time = now
                        # else: silently skip logging
                    else:
                        # Other errors - log normally
                        logger.error(f"Failed to start scanner: {error_name}: {e}")

                    self._stop_event.wait(5.0)  # Wait before retry
                    continue

                # Scan for duration (using threading.Event.wait, not asyncio.sleep)
                if self._stop_event.wait(self._scan_duration):
                    break  # Stop requested

                # Stop scanning
                self._in_scan_window = False
                logger.debug(
                    f"Victron scan cycle {self.stats['scan_cycles']}: "
                    f"pausing for {self._scan_interval}s"
                )

                future = asyncio.run_coroutine_threadsafe(
                    self._stop_scanner(), self._loop
                )
                try:
                    future.result(timeout=5.0)
                except Exception as e:
                    logger.warning(f"Error stopping scanner: {type(e).__name__}: {e}")

                # Pause between scans (using threading.Event.wait)
                if self._stop_event.wait(self._scan_interval):
                    break  # Stop requested

            except Exception as e:
                logger.error(f"Scan loop error: {type(e).__name__}: {e}", exc_info=True)
                self._stop_event.wait(5.0)  # Wait before retry

        logger.info("Victron scan loop thread exiting")

    async def _create_and_start_scanner(self):
        """Create a fresh scanner and start it."""
        # Stop any existing scanner first
        if self._scanner:
            try:
                await self._scanner.stop()
            except Exception:
                pass
            self._scanner = None

        # Create new scanner
        try:
            self._scanner = BleakScanner(
                detection_callback=self._on_advertisement,
                scanning_mode="passive",
            )
        except Exception:
            self._scanner = BleakScanner(detection_callback=self._on_advertisement)

        await self._scanner.start()

    async def _stop_scanner(self):
        """Stop and cleanup the scanner."""
        if self._scanner:
            try:
                await self._scanner.stop()
            except Exception:
                pass
            self._scanner = None

    async def stop(self):
        """Stop listening for BLE advertisements."""
        if not self._running:
            return

        self._running = False
        logger.info("Stopping Victron BLE scanning")

        # Signal the scan thread to stop
        self._stop_event.set()

        # Wait for thread to finish (with timeout)
        if self._scan_thread and self._scan_thread.is_alive():
            self._scan_thread.join(timeout=5.0)

        # Stop the scanner if it's running
        if self._scanner:
            try:
                await self._scanner.stop()
            except Exception:
                pass  # Ignore errors during cleanup
            self._scanner = None

        self._in_scan_window = False
        self.stats["connected"] = False
        logger.info("Victron BLE scanner stopped")

    def _on_advertisement(self, device, advertisement_data):
        """
        Process incoming BLE advertisement.

        Scanner start/stop is managed by the scan loop thread, so this callback
        only needs to filter by MAC and rate-limit.

        Args:
            device: BleakDevice object
            advertisement_data: AdvertisementData object
        """
        # Filter by MAC address (only process our target device)
        if device.address.upper() != self.mac_address:
            return

        self.stats["packets_received"] += 1
        self.stats["last_rssi"] = advertisement_data.rssi

        # Reset Bluetooth error state if we're receiving data
        if self._bluetooth_unavailable:
            logger.info("Bluetooth hardware recovered - receiving data")
            self._bluetooth_unavailable = False
            self._bluetooth_error_message = None
            self._consecutive_bt_failures = 0

        # Rate limiting: skip processing if we already processed one recently
        # Victron broadcasts at ~1Hz, no need to process more than 1/second
        now = time.time()
        if now - self._last_callback_time < 1.0:
            return  # Already have recent data, skip this one
        self._last_callback_time = now

        try:
            # Extract Victron manufacturer data (manufacturer ID 0x02E1 = 737)
            # advertisement_data.manufacturer_data is a dict: {manufacturer_id: bytes}
            VICTRON_MANUFACTURER_ID = 0x02E1  # 737
            manufacturer_data = advertisement_data.manufacturer_data.get(
                VICTRON_MANUFACTURER_ID
            )

            if not manufacturer_data:
                # No Victron manufacturer data in this advertisement
                return

            # Parse manufacturer data to detect device type
            if self._device_type is None:
                self._device_type = detect_device_type(manufacturer_data)
                if self._device_type:
                    logger.info(f"Detected Victron device type: {self._device_type}")

            # Decrypt and parse the advertisement using victron-ble
            if self._device_type:
                parsed_data = self._device_type(self.encryption_key).parse(
                    manufacturer_data
                )

                if parsed_data:
                    # Convert to our telemetry format
                    telemetry = self._convert_to_telemetry(
                        parsed_data, advertisement_data.rssi
                    )

                    self.stats["packets_decrypted"] += 1
                    self._last_telemetry = telemetry
                    self._last_update_time = telemetry.timestamp

                    # Publish to event bus
                    if self.event_bus:
                        asyncio.create_task(
                            self.event_bus.publish("victron_telemetry", telemetry)
                        )

                    # Call custom callback
                    if self.on_telemetry:
                        asyncio.create_task(self.on_telemetry(telemetry))

                    logger.debug(
                        f"Victron telemetry: {telemetry.voltage}V, "
                        f"{telemetry.current}A, {telemetry.soc}%, "
                        f"RSSI: {telemetry.rssi}dBm"
                    )

        except Exception as e:
            self.stats["decrypt_errors"] += 1
            # AdvertisementKeyMismatchError is expected for non-telemetry
            # advertisement types (beacons, keep-alives, etc.)
            # Don't log these - they happen ~10 times/second for normal BLE traffic
            error_name = type(e).__name__
            if error_name == "AdvertisementKeyMismatchError":
                return  # Silently ignore expected errors
            # Only log unexpected errors, and without full traceback
            logger.warning(f"Unexpected error parsing Victron advertisement: {e}")

    def _convert_to_telemetry(self, parsed_data, rssi: int) -> VictronTelemetry:
        """
        Convert victron-ble parsed data to VictronTelemetry format.

        Args:
            parsed_data: DeviceData object from victron-ble parser (e.g., BatteryMonitorData)
            rssi: Signal strength

        Returns:
            VictronTelemetry object
        """
        # victron-ble returns device-specific data objects with getter methods
        # Common methods: get_voltage(), get_current(), get_soc(), etc.

        # Safely get values using getter methods
        voltage = self._safe_get(parsed_data, "get_voltage", 0.0)
        current = self._safe_get(parsed_data, "get_current", 0.0)
        soc = self._safe_get(parsed_data, "get_soc", 0.0)
        consumed_ah = self._safe_get(parsed_data, "get_consumed_ah", 0.0)
        remaining_mins = self._safe_get(parsed_data, "get_remaining_mins", None)
        starter_voltage = self._safe_get(parsed_data, "get_starter_voltage", None)
        midpoint_voltage = self._safe_get(parsed_data, "get_midpoint_voltage", None)
        temperature = self._safe_get(parsed_data, "get_temperature", None)

        telemetry = VictronTelemetry(
            voltage=float(voltage) if voltage is not None else 0.0,
            current=float(current) if current is not None else 0.0,
            power=float(voltage * current) if voltage and current else 0.0,
            soc=float(soc) if soc is not None else 0.0,
            consumed_ah=float(consumed_ah) if consumed_ah is not None else 0.0,
            time_remaining=remaining_mins,
            aux_voltage=starter_voltage or midpoint_voltage,
            temperature=temperature,
            alarms=self._parse_alarms(parsed_data),
            timestamp=datetime.now().timestamp(),
            rssi=rssi,
        )

        return telemetry

    def _safe_get(self, obj, method_name: str, default=None):
        """Safely call a getter method on an object, returning default if not available."""
        method = getattr(obj, method_name, None)
        if method and callable(method):
            try:
                return method()
            except Exception:
                return default
        return default

    def _parse_alarms(self, parsed_data) -> List[str]:
        """
        Parse alarm flags from victron-ble data.

        Args:
            parsed_data: DeviceData object from victron-ble parser

        Returns:
            List of alarm descriptions
        """
        alarms = []

        # Try to get alarm data using getter method
        alarm_data = self._safe_get(parsed_data, "get_alarm", None)

        if alarm_data:
            # Alarm data structure varies by device, check common flags
            if hasattr(alarm_data, "low_voltage") and alarm_data.low_voltage:
                alarms.append("Low Voltage")
            if hasattr(alarm_data, "high_voltage") and alarm_data.high_voltage:
                alarms.append("High Voltage")
            if hasattr(alarm_data, "low_soc") and alarm_data.low_soc:
                alarms.append("Low State of Charge")
            if (
                hasattr(alarm_data, "low_starter_voltage")
                and alarm_data.low_starter_voltage
            ):
                alarms.append("Low Starter Voltage")
            if (
                hasattr(alarm_data, "high_starter_voltage")
                and alarm_data.high_starter_voltage
            ):
                alarms.append("High Starter Voltage")
            if hasattr(alarm_data, "low_temperature") and alarm_data.low_temperature:
                alarms.append("Low Temperature")
            if hasattr(alarm_data, "high_temperature") and alarm_data.high_temperature:
                alarms.append("High Temperature")

        return alarms

    def get_latest_telemetry(self) -> Optional[VictronTelemetry]:
        """
        Get the most recent telemetry reading.

        Returns:
            Latest VictronTelemetry or None if no data received
        """
        return self._last_telemetry

    def is_connected(self) -> bool:
        """
        Check if listener is actively receiving data.

        Returns:
            True if data received within last 60 seconds, False otherwise
        """
        if not self._running or not self.stats["connected"]:
            return False
        # Check if we've received data recently (within 60 seconds)
        import time

        if self._last_update_time == 0:
            return False
        return (time.time() - self._last_update_time) < 60

    def get_stats(self) -> Dict[str, Any]:
        """
        Get listener statistics.

        Returns:
            Dict with packet counts, error counts, etc.
        """
        return {
            **self.stats,
            "connected": self.is_connected(),  # Use actual connection check
            "last_update": self._last_update_time,
            "running": self._running,
            "bluetooth_available": not self._bluetooth_unavailable,
            "bluetooth_error": self._bluetooth_error_message,
            "consecutive_bt_failures": self._consecutive_bt_failures,
        }

    def get_bluetooth_status(self) -> Dict[str, Any]:
        """
        Get Bluetooth hardware status.

        Returns:
            Dict with bluetooth availability and error info
        """
        return {
            "available": not self._bluetooth_unavailable,
            "error": self._bluetooth_error_message,
            "consecutive_failures": self._consecutive_bt_failures,
        }

    def to_dict(self) -> Dict[str, Any]:
        """
        Serialize listener state to dictionary.

        Returns:
            Dict representation of listener state
        """
        return {
            "mac_address": self.mac_address,
            "running": self._running,
            "stats": self.get_stats(),
            "latest_telemetry": (
                asdict(self._last_telemetry) if self._last_telemetry else None
            ),
        }
