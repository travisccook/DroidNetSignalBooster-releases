## DroidNet Signal Booster v1.2

### Highlights

This release focuses on WCB backup reliability improvements and introduces the new Droid tab for managing multiple Signal Boosters within a single droid.

### New Features

**Droid Tab (Beta)**
- New tab for managing multiple Signal Boosters installed in one droid
- Grid-based UI showing status of each connected device
- Option to preserve active tab when switching between devices
- *Note: This feature is a work in progress. Device switching behavior is still being refined.*

**Universal `droidnet.local` Access**
- Your Signal Booster is now always reachable at `droidnet.local` in client mode
- Works in addition to any custom hostname you've configured (e.g., `c2-body.local`)
- Provides a consistent, predictable address for accessing your device without needing to remember custom hostnames

**WCB v5.6+ Support**
- Full backup/restore for broadcast I/O, serial monitor mappings, and PWM settings
- Auto-refresh backup list when backup data is parsed

### Bug Fixes

**WCB Serial Communication**
- Fixed device switch race condition causing connection errors
- Fixed WebSocket error handler race condition
- Fixed auto-backup race condition and stale buffering state
- Fixed duplicate messages and false "data loss" warnings

**Flash Tab**
- Fixed device count badge not updating when devices are connected/disconnected

**Victron Integration**
- Improved Bluetooth error handling and recovery
