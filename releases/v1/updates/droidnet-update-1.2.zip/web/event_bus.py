"""
EventBus - Async publish/subscribe pattern for serial events

Part of the serial communication architecture refactor.
See docs/SERIAL_ARCHITECTURE_PLAN.md for details.
"""

import asyncio
import logging
from typing import Dict, List, Callable, Any

logger = logging.getLogger(__name__)


class EventBus:
    """
    Asynchronous event bus for pub/sub pattern.

    Allows multiple subscribers to listen for events and receive notifications
    when events are published. All callbacks are executed concurrently.

    Example:
        bus = EventBus()

        async def handler(data):
            print(f"Received: {data}")

        bus.subscribe('data', handler)
        await bus.publish('data', {'line': 'Hello'})
    """

    def __init__(self):
        """Initialize empty event bus."""
        self.subscribers: Dict[str, List[Callable]] = {}
        self._lock = asyncio.Lock()  # Protect subscriber list modifications

    def subscribe(self, event: str, callback: Callable) -> None:
        """
        Register callback for event type.

        Args:
            event: Event type to subscribe to (e.g., 'data', 'error', 'status')
            callback: Async function to call when event occurs

        Note:
            Callback must be an async function or coroutine.
            Callback receives event data as single argument.
        """
        if event not in self.subscribers:
            self.subscribers[event] = []

        if callback not in self.subscribers[event]:
            self.subscribers[event].append(callback)
            logger.debug(f"Subscriber added for event '{event}' (total: {len(self.subscribers[event])})")

    def unsubscribe(self, event: str, callback: Callable) -> bool:
        """
        Remove callback from event type.

        Args:
            event: Event type to unsubscribe from
            callback: Callback function to remove

        Returns:
            True if callback was found and removed, False otherwise
        """
        if event in self.subscribers:
            try:
                self.subscribers[event].remove(callback)
                logger.debug(f"Subscriber removed from event '{event}' (remaining: {len(self.subscribers[event])})")

                # Clean up empty event lists
                if not self.subscribers[event]:
                    del self.subscribers[event]

                return True
            except ValueError:
                return False
        return False

    async def publish(self, event: str, data: Any) -> None:
        """
        Notify all subscribers of event.

        Args:
            event: Event type to publish
            data: Data to pass to subscribers

        Note:
            All subscribers are called concurrently with asyncio.gather.
            Exceptions in callbacks are caught and logged, not propagated.
        """
        if event not in self.subscribers:
            return  # No subscribers for this event

        # Create snapshot of subscribers to avoid modification during iteration
        callbacks = self.subscribers[event].copy()

        if not callbacks:
            return

        logger.debug(f"Publishing event '{event}' to {len(callbacks)} subscriber(s)")

        # Execute all callbacks concurrently
        results = await asyncio.gather(
            *[self._safe_callback(cb, data, event) for cb in callbacks],
            return_exceptions=True
        )

        # Log any exceptions that occurred
        for result in results:
            if isinstance(result, Exception):
                logger.error(f"Error in event handler for '{event}': {result}")

    async def _safe_callback(self, callback: Callable, data: Any, event: str) -> None:
        """
        Safely execute callback with error handling.

        Args:
            callback: Callback to execute
            data: Data to pass to callback
            event: Event name (for logging)
        """
        try:
            if asyncio.iscoroutinefunction(callback):
                await callback(data)
            else:
                # Support sync callbacks by running in executor
                loop = asyncio.get_event_loop()
                await loop.run_in_executor(None, callback, data)
        except Exception as e:
            logger.error(f"Exception in callback for event '{event}': {e}", exc_info=True)
            raise  # Re-raise so gather can catch it

    def subscriber_count(self, event: str = None) -> int:
        """
        Get number of subscribers.

        Args:
            event: Specific event type, or None for total across all events

        Returns:
            Number of subscribers
        """
        if event is not None:
            return len(self.subscribers.get(event, []))

        return sum(len(callbacks) for callbacks in self.subscribers.values())

    def get_events(self) -> List[str]:
        """
        Get list of all event types with subscribers.

        Returns:
            List of event type names
        """
        return list(self.subscribers.keys())

    def clear(self) -> None:
        """Remove all subscribers from all events."""
        count = self.subscriber_count()
        self.subscribers.clear()
        logger.debug(f"EventBus cleared, removed {count} subscriber(s)")
