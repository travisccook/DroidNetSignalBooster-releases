#!/usr/bin/env python3
"""
DroidNet Signal Booster - Lightweight Web Server
Serves the web interface and provides API endpoints for device management
"""

import os
import sys
import json
import subprocess
import asyncio
import websockets
import threading
import time
import socket
import logging
import re
import shutil
import tempfile
import hashlib
import zlib
import zipfile
from datetime import datetime
from pathlib import Path
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, unquote
from typing import Optional, Dict, List, Any

# Add parent directory to path for imports
# Import constants first for path management
_temp_root = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_temp_root))

from config.constants import (
    PROJECT_ROOT,
    CONFIG_DIR,
    SCRIPTS_DIR,
    WEB_DIR,
    LOG_DIR,
    RUNTIME_DIR,
    DATA_DIR,
    NETWORK_STATE_FILE,
    DROIDNET_MODE_FILE,
    DROIDNET_MODE_FILE_BOOT,
    UPDATE_LOG_FILE,
    UPDATE_STATUS_FILE,
    LAST_UPDATE_COMPLETED_FILE,
    UPDATE_EXECUTOR_SCRIPT,
)

# Now update sys.path with the constant
sys.path[0] = str(PROJECT_ROOT)

# Import handlers from modularized modules
from handlers.device_handlers import (
    get_usb_devices,
    get_arduino_devices,
    get_serial_devices,
    is_device_locked,
    lock_device,
    unlock_device,
    detect_board_type,
)
from handlers.system_handlers import (
    get_pi_model,
    get_system_status,
    get_uptime,
    get_load_average,
    get_cpu_usage,
    get_memory_usage,
    get_cpu_temperature,
    get_disk_usage,
    get_service_status,
    get_services_status_batch,
    get_services_status_summary,
    get_wifi_signal_strength,
    get_network_latency,
    format_uptime,
    get_dashboard_status,
    get_top_processes,
    get_current_version,
    get_system_info,
)
from handlers.firmware_handlers import (
    flash_firmware,
    flash_firmware_legacy,
)
from handlers.comlink_handlers import (
    get_comlink_config,
    update_comlink_config,
    get_comlink_status,
    get_comlink_devices,
    get_comlink_history,
    calculate_comlink_statistics,
    clear_comlink_history,
    send_comlink_command,
    log_comlink_command,
    clean_command_string,
    send_serial_command,
    send_gpio_serial_command,
)
from handlers.wcb_handlers import (
    get_wcb_config,
    get_wcb_devices,
    update_wcb_config,
    toggle_wcb_device,
    get_wcb_alwayson_config,
    save_wcb_alwayson_config,
    get_wcb_listeners_status,
    get_wcb_listener_status,
    start_wcb_listener,
    stop_wcb_listener,
    get_serial_history,
    send_wcb_command,
    get_wcb_preset_commands,
    save_wcb_preset_commands,
    reset_wcb_preset_commands,
)
from handlers.wcb_backup_handlers import (
    handle_get_backup_config,
    handle_set_backup_config,
    handle_get_backup_list,
    handle_get_backup_history,
    handle_get_backup_content,
    handle_get_restore_commands,
    handle_get_restore_info,
    handle_compare_backups,
    handle_trigger_backup,
    handle_restore_backup,
    handle_clear_all_backups,
)
from handlers.victron_handlers import (
    get_victron_manager,
    get_victron_config,
    get_victron_feature_config,
    get_victron_status,
    get_victron_latest_telemetry,
    get_victron_telemetry_history,
    update_victron_device_config,
    update_victron_config,
    update_victron_feature_config,
    start_victron_monitoring_api,
    stop_victron_monitoring_api,
    delete_victron_device_api,
    victron_reconnect_api,
    restart_bluetooth_api,
    get_victron_logs,
)
from handlers.network_handlers import (
    get_wifi_status,
    scan_wifi_networks,
    connect_wifi,
    save_network_to_config,
    create_nm_connection,
    sync_network_configs,
    get_saved_networks,
    forget_network,
    get_wifi_mode,
    set_wifi_mode,
    make_permanent_ap,
    retry_client_mode,
    update_network_config,
    get_network_priorities,
    set_network_priority,
    get_ap_config,
    set_ap_config,
    get_virtualhere_status,
    toggle_virtualhere,
    get_network_settings,
    set_network_settings,
    discover_droidnet_devices,
)
from handlers.droid_handlers import (
    get_aggregate_status,
    get_updates_summary,
    remove_known_device,
    start_batch_update,
    get_batch_update_status,
    start_batch_flash,
    get_batch_flash_status,
    is_valid_hostname,
)

# Import handler modules themselves for setting dependencies
from handlers import (
    comlink_handlers,
    wcb_handlers,
    victron_handlers,
    firmware_handlers,
    wcb_backup_handlers,
)

# Optional imports with availability flags
try:
    from usb_manager import USBManager

    USB_MANAGER_AVAILABLE = True
except ImportError:
    USB_MANAGER_AVAILABLE = False

try:
    from wcb_listener import WCBListener

    WCB_LISTENER_AVAILABLE = True
except ImportError:
    WCB_LISTENER_AVAILABLE = False

try:
    from maestro_configurator import (
        ChannelSettings,
        ChannelMode,
        HomeMode,
        MaestroConfigurator,
    )

    MAESTRO_AVAILABLE = True
except ImportError:
    MAESTRO_AVAILABLE = False

try:
    from victron_config import load_victron_config

    VICTRON_CONFIG_AVAILABLE = True
except ImportError:
    VICTRON_CONFIG_AVAILABLE = False

try:
    from maestro_manager import get_maestro_manager

    MAESTRO_MANAGER_AVAILABLE = True
except ImportError:
    MAESTRO_MANAGER_AVAILABLE = False

try:
    from wcb_backup_manager import get_backup_manager

    WCB_BACKUP_MANAGER_AVAILABLE = True
except ImportError:
    WCB_BACKUP_MANAGER_AVAILABLE = False

try:
    from maestro_script_generator import generate_mcc_style_script
    from maestro_compiler import compile_script, MaestroCompiler

    MAESTRO_COMPILER_AVAILABLE = True
except ImportError:
    MAESTRO_COMPILER_AVAILABLE = False

try:
    import psutil

    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False

try:
    from web.port_handler import PortHandler

    PORT_HANDLER_AVAILABLE = True
except ImportError:
    PORT_HANDLER_AVAILABLE = False

try:
    from web.asyncio_loop_thread import AsyncioEventLoopThread

    ASYNCIO_LOOP_THREAD_AVAILABLE = True
except ImportError:
    ASYNCIO_LOOP_THREAD_AVAILABLE = False

# Configuration
WEB_PORT = 80
WS_PORT = 8080
WEB_ROOT = str(WEB_DIR)
LOG_FILE = "web.log"

# Discovery hostname redirect configuration
# When a device claims droidnet.local, we redirect to the actual hostname
DISCOVERY_HOSTNAME = "droidnet"  # The shared discovery hostname (without .local)
HOSTNAME_CACHE_TTL = 60  # Seconds to cache hostname lookup

# Cached hostname state (module-level for performance)
_cached_hostname: Optional[str] = None
_hostname_cache_time: float = 0
_hostname_cache_lock = threading.Lock()


def get_cached_hostname() -> str:
    """
    Get the system hostname with caching to avoid subprocess overhead.
    Returns the hostname (without .local suffix).
    Thread-safe implementation for use in ThreadingHTTPServer.
    """
    global _cached_hostname, _hostname_cache_time
    now = time.time()

    # Check if cache is valid without lock (fast path)
    if (
        _cached_hostname is not None
        and (now - _hostname_cache_time) <= HOSTNAME_CACHE_TTL
    ):
        return _cached_hostname

    # Cache miss or expired - acquire lock and refresh
    with _hostname_cache_lock:
        # Double-check after acquiring lock (another thread may have refreshed)
        if (
            _cached_hostname is not None
            and (now - _hostname_cache_time) <= HOSTNAME_CACHE_TTL
        ):
            return _cached_hostname

        try:
            result = subprocess.run(
                ["hostname"], capture_output=True, text=True, timeout=5
            )
            _cached_hostname = result.stdout.strip()
            _hostname_cache_time = time.time()
        except Exception:
            # Fallback to socket.gethostname() if subprocess fails
            _cached_hostname = socket.gethostname()
            _hostname_cache_time = time.time()

    return _cached_hostname or "unknown"


# Set up logging
def setup_logging():
    """Configure logging for the web server"""
    # Ensure log directory exists
    Path(LOG_DIR).mkdir(parents=True, exist_ok=True)

    # Configure logging
    log_file_path = os.path.join(LOG_DIR, LOG_FILE)

    # Check if debug mode is enabled
    debug_mode = False
    debug_conf = str(CONFIG_DIR / "debug.conf")
    if os.path.exists(debug_conf):
        try:
            with open(debug_conf, "r") as f:
                for line in f:
                    if line.strip().startswith("DEBUG_MODE=1"):
                        debug_mode = True
                        break
        except (OSError, IOError):
            pass

    log_level = logging.DEBUG if debug_mode else logging.INFO

    logging.basicConfig(
        level=log_level,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        handlers=[
            logging.FileHandler(log_file_path),
            logging.StreamHandler(sys.stdout),
        ],
    )

    logger = logging.getLogger(__name__)
    if debug_mode:
        logger.info("Debug mode enabled - verbose logging active")

    # Silence noisy third-party loggers even in debug mode
    # bleak's D-Bus manager logs every BLE advertisement at DEBUG level
    noisy_loggers = [
        "bleak",
        "bleak.backends",
        "bleak.backends.bluezdbus",
        "bleak.backends.bluezdbus.manager",
        "bleak.backends.bluezdbus.client",
        "dbus_fast",
    ]
    for logger_name in noisy_loggers:
        logging.getLogger(logger_name).setLevel(logging.WARNING)

    return logger


# Initialize logger
logger = setup_logging()


def get_thread_config():
    """Get appropriate thread configuration for Pi model.

    Queue sizes increased to prevent SYN flooding under moderate load.
    The queue_size determines how many connections can wait in the
    listen queue before being rejected.
    """
    pi_model = get_pi_model()

    configs = {
        # Pi Zero W: Limited resources, but needs enough queue to handle
        # concurrent connections from iOS app + web interface + comlink
        "pi_zero_w": {"max_threads": 4, "queue_size": 15},
        "pi_zero_2": {"max_threads": 6, "queue_size": 20},
        "pi_3": {"max_threads": 10, "queue_size": 30},
        "pi_4": {"max_threads": 12, "queue_size": 40},
        "unknown": {"max_threads": 6, "queue_size": 20},  # Conservative default
    }

    config = configs.get(pi_model, configs["unknown"])
    logger.info(f"Detected Pi model: {pi_model}, Thread config: {config}")
    return config, pi_model


# Global thread limiter (will be initialized in main)
thread_limit = None
request_counter = 0
request_timing_log = []


class SerialPortManager:
    """Manages serial port access and device baud rate preferences"""

    # Device-specific WCB listener limits
    MAX_LISTENERS_BY_MODEL = {
        "pi_zero_w": 2,
        "pi_zero_2": 4,
        "pi_3": 8,
        "pi_4": 8,
        "unknown": 2,  # Conservative default
    }

    def __init__(self, event_loop_thread=None):
        self.config_file = str(CONFIG_DIR / "device-serial-config.json")
        self.device_config = self.load_device_config()
        self._lock = threading.Lock()

        # Persistent event loop for async operations
        self.event_loop_thread = event_loop_thread

        # Serial port handlers (accessed only from event loop thread)
        self.port_handlers = {}  # port -> PortHandler instance

        # WCB always-on listeners (accessed only from event loop thread)
        self.wcb_listeners = {}  # port -> WCBListener instance

        # Import USB manager for device identification
        sys.path.insert(0, str(SCRIPTS_DIR))
        if USB_MANAGER_AVAILABLE:
            self.usb_manager = USBManager()
        else:
            logger.warning("USBManager not available - device tracking limited")
            self.usb_manager = None

    def load_device_config(self):
        """Load device serial configuration from file"""
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, "r") as f:
                    return json.load(f)
            except (json.JSONDecodeError, OSError, FileNotFoundError) as e:
                logger.error(
                    f"Failed to load device serial config from {self.config_file}: {e}"
                )

        return {"devices": {}}

    def save_device_config(self):
        """Save device serial configuration to file"""
        try:
            os.makedirs(os.path.dirname(self.config_file), exist_ok=True)
            with open(self.config_file, "w") as f:
                json.dump(self.device_config, f, indent=2)
        except OSError as e:
            logger.error(
                f"Failed to save device serial config to {self.config_file}: {e}"
            )

    def get_device_id_for_port(self, port):
        """Get unique device ID for a serial port"""
        if not self.usb_manager:
            return port  # Fallback to port path

        try:
            devices = self.usb_manager.get_usb_devices()
            for device in devices:
                if device.get_serial_port() == port:
                    return device.unique_id or port
        except Exception as e:
            logger.error(f"Failed to get device ID for {port}: {e}")

        return port

    def get_device_name_for_port(self, port):
        """Get device name for a serial port"""
        if not self.usb_manager:
            return os.path.basename(port)

        try:
            devices = self.usb_manager.get_usb_devices()
            for device in devices:
                if device.get_serial_port() == port:
                    return device.name or os.path.basename(port)
        except Exception as e:
            logger.error(f"Failed to get device name for {port}: {e}")

        return os.path.basename(port)

    def update_device_baud_rate(self, port, baud_rate):
        """Update the saved baud rate for a device"""
        device_id = self.get_device_id_for_port(port)
        device_name = self.get_device_name_for_port(port)

        with self._lock:
            if device_id not in self.device_config["devices"]:
                self.device_config["devices"][device_id] = {}

            self.device_config["devices"][device_id].update(
                {
                    "last_successful_baud": baud_rate,
                    "last_connected": datetime.utcnow().isoformat() + "Z",
                    "name": device_name,
                    "port": port,
                }
            )

            self.save_device_config()
            logger.info(
                f"Updated baud rate for {device_name} ({device_id}): {baud_rate}"
            )

    def get_device_baud_rate(self, port, default=115200):
        """Get the saved baud rate for a device"""
        device_id = self.get_device_id_for_port(port)

        with self._lock:
            device_info = self.device_config["devices"].get(device_id, {})
            baud = device_info.get("last_successful_baud", default)

        logger.debug(f"Baud rate for {port} ({device_id}): {baud}")
        return baud

    async def _get_or_create_handler(
        self, port: str, baud: int, always_on: bool = False
    ):
        """
        Get existing PortHandler or create new one (internal async version).
        Must be called from the event loop thread.

        Args:
            port: Serial port path
            baud: Baud rate
            always_on: If True, reconnect forever with backoff

        Returns:
            PortHandler instance for this port
        """
        # No lock needed - always called from same event loop thread
        if port in self.port_handlers:
            handler = self.port_handlers[port]
            logger.debug(f"Returning existing handler for {port}")
            return handler

        # Create new handler
        if not PORT_HANDLER_AVAILABLE:
            raise ImportError("PortHandler is not available")

        handler = PortHandler(port, baud, always_on=always_on)
        self.port_handlers[port] = handler

        # Start handler in this event loop
        await handler.start()

        logger.info(
            f"Created new PortHandler for {port} at {baud} baud "
            f"(always_on={always_on})"
        )

        return handler

    def get_or_create_handler_sync(self, port: str, baud: int, always_on: bool = False):
        """
        Thread-safe synchronous wrapper for get_or_create_handler.
        Can be called from HTTP request threads.

        Args:
            port: Serial port path
            baud: Baud rate
            always_on: If True, reconnect forever with backoff

        Returns:
            PortHandler instance
        """
        if not self.event_loop_thread:
            raise RuntimeError("Event loop thread not initialized")

        return self.event_loop_thread.run_coroutine(
            self._get_or_create_handler(port, baud, always_on)
        )

    async def _close_handler(self, port: str):
        """
        Close and remove PortHandler for a port (internal async version).
        Must be called from the event loop thread.

        Args:
            port: Serial port path
        """
        if port in self.port_handlers:
            handler = self.port_handlers[port]
            await handler.stop()
            del self.port_handlers[port]
            logger.info(f"Closed PortHandler for {port}")

    def close_handler_sync(self, port: str):
        """
        Thread-safe synchronous wrapper for close_handler.
        Can be called from HTTP request threads.

        Args:
            port: Serial port path
        """
        if not self.event_loop_thread:
            raise RuntimeError("Event loop thread not initialized")

        return self.event_loop_thread.run_coroutine(self._close_handler(port))

    def get_handler(self, port: str):
        """
        Get existing PortHandler without creating one.

        Args:
            port: Serial port path

        Returns:
            PortHandler instance or None if not found

        Note:
            Thread-safe for read-only access (dict lookups are atomic in CPython)
        """
        return self.port_handlers.get(port)

    def get_all_handlers(self):
        """
        Get all active PortHandler instances.

        Returns:
            Dict of port -> PortHandler

        Note:
            Thread-safe for read-only access
        """
        return self.port_handlers.copy()

    def get_handler_stats(self, port: str):
        """
        Get statistics for a PortHandler.

        Args:
            port: Serial port path

        Returns:
            Statistics dict or None if handler doesn't exist
        """
        handler = self.get_handler(port)
        if handler:
            return handler.get_stats()
        return None

    async def _start_wcb_listener(self, port: str, baud: int):
        """
        Start WCB always-on listener for a port (internal async version).
        Must be called from the event loop thread.

        Args:
            port: Serial port path
            baud: Baud rate

        Returns:
            WCBListener instance

        Raises:
            RuntimeError: If listener limit for this device is exceeded
        """
        # Check if listener already exists
        if port in self.wcb_listeners:
            logger.debug(f"WCB listener already active for {port}")
            return self.wcb_listeners[port]

        # Check device limit
        pi_model = get_pi_model()
        max_listeners = self.MAX_LISTENERS_BY_MODEL.get(pi_model, 2)
        if len(self.wcb_listeners) >= max_listeners:
            raise RuntimeError(
                f"Maximum {max_listeners} WCB listeners allowed on {pi_model}. "
                f"Stop an existing listener first."
            )

        # Get or create PortHandler with always_on=True
        handler = await self._get_or_create_handler(port, baud, always_on=True)

        # Create WCBListener
        if not WCB_LISTENER_AVAILABLE:
            raise RuntimeError("WCBListener not available")

        sys.path.insert(0, str(SCRIPTS_DIR))

        # Get device ID for this port
        device_id = self.get_device_id_for_port(port)

        # Create listener with port and device_id for backup integration
        listener = WCBListener(handler, port=port, device_id=device_id)

        # Set backup manager for passive capture
        if WCB_BACKUP_MANAGER_AVAILABLE:
            try:
                listener.backup_manager = get_backup_manager()
            except Exception as e:
                logger.debug(f"Backup manager not available for listener: {e}")

        await listener.start()

        self.wcb_listeners[port] = listener
        logger.info(
            f"Started WCB listener for {port} at {baud} baud "
            f"({len(self.wcb_listeners)}/{max_listeners})"
        )

        return listener

    def start_wcb_listener_sync(self, port: str, baud: int):
        """
        Thread-safe synchronous wrapper for start_wcb_listener.
        Can be called from HTTP request threads.

        Args:
            port: Serial port path
            baud: Baud rate

        Returns:
            WCBListener instance
        """
        if not self.event_loop_thread:
            raise RuntimeError("Event loop thread not initialized")

        return self.event_loop_thread.run_coroutine(
            self._start_wcb_listener(port, baud)
        )

    async def _stop_wcb_listener(self, port: str):
        """
        Stop WCB listener for a port (internal async version).
        Must be called from the event loop thread.

        Args:
            port: Serial port path
        """
        if port not in self.wcb_listeners:
            logger.warning(f"No WCB listener found for {port}")
            return

        # Get the listener and unsubscribe it from the handler
        listener = self.wcb_listeners[port]
        handler = self.port_handlers.get(port)

        if handler and hasattr(listener, "_on_serial_data"):
            # Unsubscribe the listener's callback
            handler.unsubscribe("data", listener._on_serial_data)
            logger.debug(f"Unsubscribed WCB listener callback for {port}")

        # Remove WCBListener reference
        del self.wcb_listeners[port]
        logger.info(f"Stopped WCB listener for {port}")

        # Check if PortHandler has other subscribers (WebSocket clients, etc.)
        if handler:
            stats = handler.get_stats()
            subscriber_count = stats.get("subscriber_count", 0)

            # If no subscribers remain, stop and remove the PortHandler
            if subscriber_count == 0:
                logger.info(f"No subscribers remain for {port}, stopping PortHandler")
                await self._close_handler(port)
            else:
                logger.info(
                    f"PortHandler for {port} has {subscriber_count} other "
                    f"subscriber(s), keeping it running"
                )

    def stop_wcb_listener_sync(self, port: str):
        """
        Thread-safe synchronous wrapper for stop_wcb_listener.
        Can be called from HTTP request threads.

        Args:
            port: Serial port path
        """
        if not self.event_loop_thread:
            raise RuntimeError("Event loop thread not initialized")

        return self.event_loop_thread.run_coroutine(self._stop_wcb_listener(port))

    async def _send_to_port(self, port: str, data: str, default_baud: int = 115200):
        """
        Send data to a serial port (internal async version).
        Taps into existing handler if available, otherwise creates temporary handler.

        Args:
            port: Serial port path
            data: Data to send
            default_baud: Default baud rate if no saved rate exists

        Returns:
            Tuple of (success: bool, used_baud: int)
        """
        try:
            # Check if there's an existing handler
            handler = self.port_handlers.get(port)
            baud_rate = default_baud

            if handler:
                # Use existing handler (might be WCB always-on listener)
                logger.info(f"Using existing PortHandler for {port}")
                baud_rate = handler.baud
            else:
                # Create temporary handler
                logger.info(f"Creating temporary handler for {port} to send data")

                # Try to get saved baud rate from device config
                try:
                    with open(self.config_file, "r") as f:
                        config = json.load(f)
                        for info in config.values():
                            if info.get("port") == port:
                                baud_rate = info.get(
                                    "last_successful_baud", default_baud
                                )
                                logger.info(
                                    f"Using saved baud rate {baud_rate} for {port}"
                                )
                                break
                except Exception:
                    pass

                # Create handler
                if not PORT_HANDLER_AVAILABLE:
                    raise ImportError("PortHandler is not available")

                handler = PortHandler(port, baud_rate, always_on=False)
                self.port_handlers[port] = handler
                await handler.start()

            # Send data
            await handler.write(data)
            logger.info(f"Sent data to {port}: {repr(data)}")

            # Clean up temporary handler if no subscribers
            if not handler.always_on:
                # Give a moment for the data to be sent
                await asyncio.sleep(0.1)

                # Check if there are subscribers (other than ourselves)
                stats = handler.get_stats()
                if stats.get("subscriber_count", 0) == 0:
                    logger.info(f"Closing temporary handler for {port}")
                    await self._close_handler(port)

            return (True, baud_rate)

        except Exception as e:
            logger.error(f"Error sending to port {port}: {e}", exc_info=True)
            return (False, default_baud)

    def send_to_port_sync(self, port: str, data: str, default_baud: int = 115200):
        """
        Thread-safe synchronous wrapper for send_to_port.
        Can be called from HTTP request threads (e.g., Comlink).

        Args:
            port: Serial port path
            data: Data to send
            default_baud: Default baud rate if no saved rate exists

        Returns:
            Tuple of (success: bool, used_baud: int)
        """
        if not self.event_loop_thread:
            raise RuntimeError("Event loop thread not initialized")

        return self.event_loop_thread.run_coroutine(
            self._send_to_port(port, data, default_baud)
        )

    def get_wcb_listener(self, port: str):
        """
        Get WCBListener for a port.

        Args:
            port: Serial port path

        Returns:
            WCBListener instance or None

        Note:
            Thread-safe for read-only access (dict lookups are atomic in CPython)
        """
        return self.wcb_listeners.get(port)

    def get_all_wcb_listeners(self):
        """
        Get all active WCB listeners.

        Returns:
            Dict of port -> WCBListener

        Note:
            Thread-safe for read-only access
        """
        return self.wcb_listeners.copy()

    def get_always_on_ports(self):
        """
        Get info about all ports with active WCB listeners.

        Returns:
            List of dicts with port and device_id for each active listener

        Note:
            Used by backup manager for scheduled backups
        """
        result = []
        for port, listener in self.wcb_listeners.items():
            device_id = getattr(
                listener, "device_id", None
            ) or self.get_device_id_for_port(port)
            result.append(
                {
                    "port": port,
                    "device_id": device_id,
                }
            )
        return result


# ========== Maestro Listener Activator ==========


class MaestroListenerActivator:
    """
    Manages on-demand MaestroListener activation with idle timeout.
    Starts listener on first WebSocket connect, stops 30s after last disconnect.
    """

    IDLE_TIMEOUT_SECONDS = 30.0

    def __init__(self, maestro_mgr, loop_thread):
        self.manager = maestro_mgr
        self.loop_thread = loop_thread
        self._lock = threading.Lock()
        self._connection_counts: Dict[str, int] = {}  # port -> count
        self._idle_timers: Dict[str, Any] = {}  # port -> Future

    def on_connect(self, port: str) -> bool:
        """Called on WebSocket connect. Returns True if listener ready."""
        with self._lock:
            # Cancel pending idle timer
            if port in self._idle_timers:
                self._idle_timers.pop(port).cancel()
                logger.debug(f"Cancelled Maestro idle timeout for {port}")

            # Increment count
            self._connection_counts[port] = self._connection_counts.get(port, 0) + 1

            # Start listener if first connection
            if self._connection_counts[port] == 1:
                return self._start_listener(port)
            return True

    def on_disconnect(self, port: str):
        """Called on WebSocket disconnect."""
        with self._lock:
            count = self._connection_counts.get(port, 0)
            if count > 0:
                self._connection_counts[port] = count - 1

            # Schedule idle timeout if no connections remain
            if self._connection_counts.get(port, 0) == 0:
                self._schedule_idle_timeout(port)

    def _start_listener(self, port: str) -> bool:
        """Start the MaestroListener for a port (must hold lock)."""
        device = self.manager.get_device(port)
        if not device or not device.listener:
            return False
        if device.listener._running:
            return True  # Already running
        try:
            self.loop_thread.run_coroutine(device.listener.start())
            logger.info(f"Started Maestro listener for {port} (on-demand)")
            return True
        except Exception as e:
            logger.error(f"Failed to start Maestro listener for {port}: {e}")
            return False

    def _schedule_idle_timeout(self, port: str):
        """Schedule listener stop after idle timeout (must hold lock)."""

        async def idle_task():
            await asyncio.sleep(self.IDLE_TIMEOUT_SECONDS)
            # Check if still idle and stop listener
            # Note: We can't hold lock while awaiting, so check-then-act
            with self._lock:
                if self._connection_counts.get(port, 0) > 0:
                    return  # Client reconnected, don't stop
                self._idle_timers.pop(port, None)

            # Stop listener outside of lock (stop() is async)
            device = self.manager.get_device(port)
            if device and device.listener and device.listener._running:
                try:
                    await device.listener.stop()
                    logger.info(f"Stopped Maestro listener for {port} (idle timeout)")
                except Exception as e:
                    logger.error(f"Failed to stop Maestro listener for {port}: {e}")

        future = self.loop_thread.run_coroutine_async(idle_task())
        self._idle_timers[port] = future
        logger.debug(
            f"Scheduled Maestro idle timeout for {port} in {self.IDLE_TIMEOUT_SECONDS}s"
        )


# Global instances (initialized in main())
event_loop_thread = None
serial_port_manager = None
maestro_manager = None
maestro_listener_activator = None


# System metrics history for dashboard charts (15 min at 5s intervals = 180 samples)
class DroidNetHandler(SimpleHTTPRequestHandler):
    """Custom HTTP handler for DroidNet API and static files"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=WEB_ROOT, **kwargs)

    def log_request(self, code="-", size="-"):
        """Override to use logger instead of stderr"""
        if isinstance(code, int) and code >= 400:
            logger.warning(f"{self.command} {self.path} - {code}")
        else:
            logger.info(f"{self.command} {self.path} - {code}")

    def log_error(self, format, *args):
        """Override to use logger instead of stderr"""
        logger.error(format % args)

    @staticmethod
    def is_debug_mode():
        """Check if system is running in debug mode"""
        debug_conf = str(CONFIG_DIR / "debug.conf")
        if os.path.exists(debug_conf):
            try:
                with open(debug_conf, "r") as f:
                    for line in f:
                        if line.strip().startswith("DEBUG_MODE=1"):
                            return True
            except (OSError, IOError) as e:
                logger.debug(f"Error reading debug config: {e}")
        return False

    def should_redirect_to_actual_hostname(self) -> bool:
        """
        Check if this request came via droidnet.local and should be
        redirected to the device's actual hostname.

        This enables the discovery feature where any DroidNet device
        can be found at droidnet.local, but users are then redirected
        to the actual hostname for clarity.
        """
        # Don't redirect WebSocket upgrades - they need to stay connected
        if self.headers.get("Upgrade", "").lower() == "websocket":
            return False

        # Don't redirect API calls with no_redirect param (for scripts)
        parsed = urlparse(self.path)
        params = parse_qs(parsed.query)
        if "no_redirect" in params:
            return False

        # Get the Host header
        host_header = self.headers.get("Host", "")
        if not host_header:
            return False

        # Extract hostname (remove port if present)
        request_hostname = host_header.split(":")[0].lower()

        # Only redirect if accessed via the discovery hostname
        # Match "droidnet.local" or just "droidnet"
        if request_hostname not in (
            f"{DISCOVERY_HOSTNAME}.local",
            DISCOVERY_HOSTNAME,
        ):
            return False

        # Get our actual hostname
        actual_hostname = get_cached_hostname().lower()

        # Don't redirect if our actual hostname IS "droidnet"
        # (we are the canonical droidnet.local)
        if actual_hostname == DISCOVERY_HOSTNAME:
            return False

        return True

    def send_discovery_redirect(self):
        """
        Send a redirect response to the actual hostname.

        Uses 307 for POST/PUT/DELETE to preserve the HTTP method and body.
        Uses 302 for GET/HEAD since browsers handle these correctly.
        Neither is cached since the device answering droidnet.local can change.
        """
        actual_hostname = get_cached_hostname()

        # Preserve port if non-standard (e.g., droidnet.local:8080)
        host_header = self.headers.get("Host", "")
        port_suffix = ""
        if ":" in host_header:
            port = host_header.split(":")[-1]
            if port not in ("80", "443"):
                port_suffix = f":{port}"

        new_url = f"http://{actual_hostname}.local{port_suffix}{self.path}"

        logger.debug(f"Redirecting from droidnet.local to {actual_hostname}.local")

        # Use 307 for methods with bodies to preserve them
        # 302 would convert POST to GET per HTTP spec
        if self.command in ("POST", "PUT", "DELETE", "PATCH"):
            self.send_response(307)
        else:
            self.send_response(302)

        self.send_header("Location", new_url)
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        self.end_headers()

    def handle(self):
        """Override handle to add thread pool limiting and timing"""
        global request_counter, thread_limit

        if thread_limit is None:
            # Fallback if not initialized (shouldn't happen)
            super().handle()
            return

        start_time = time.time()
        request_id = f"{threading.current_thread().ident}-{int(start_time*1000)}"

        # Log thread pool state
        active_threads = thread_limit._initial_value - thread_limit._value
        max_threads = thread_limit._initial_value
        logger.debug(
            f"[{request_id}] Thread pool: {active_threads}/{max_threads} active"
        )

        # Try to acquire thread slot
        acquired = thread_limit.acquire(blocking=False)
        if not acquired:
            logger.warning(f"[{request_id}] Thread pool full, waiting for slot...")
            thread_limit.acquire(blocking=True)

        try:
            # Increment request counter
            request_counter += 1

            # Log memory usage every 100 requests
            if request_counter % 100 == 0 and PSUTIL_AVAILABLE:
                try:
                    process = psutil.Process()
                    memory_mb = process.memory_info().rss / 1024 / 1024
                    msg = f"Memory usage: {memory_mb:.1f}MB "
                    msg += f"after {request_counter} requests"
                    logger.info(msg)
                except Exception:
                    pass

            # Process the request
            super().handle()

        finally:
            # Release thread slot
            thread_limit.release()

            # Log request completion time
            duration = time.time() - start_time
            if duration > 1.0:  # Log slow requests
                logger.warning(
                    f"[{request_id}] Request completed in {duration:.3f}s (slow)"
                )
            else:
                logger.debug(f"[{request_id}] Request completed in {duration:.3f}s")

    def do_GET(self):
        """Handle GET requests for API and static files"""
        # Check for discovery hostname redirect
        if self.should_redirect_to_actual_hostname():
            self.send_discovery_redirect()
            return

        parsed_path = urlparse(self.path)
        logger.debug(f"GET request: {self.path}")

        if parsed_path.path.startswith("/api/"):
            self.handle_api_get(parsed_path)
        elif parsed_path.path == "/logs":
            if self.is_debug_mode():
                self.serve_logs_page()
            else:
                self.send_error(404, "Not Found")
        elif parsed_path.path == "/console":
            if self.is_debug_mode():
                self.serve_console_page()
            else:
                self.send_error(404, "Not Found")
        else:
            # Serve static files with conditional navigation
            if parsed_path.path == "/" or parsed_path.path == "/index.html":
                self.serve_index_with_conditional_nav()
            else:
                super().do_GET()

    def do_POST(self):
        """Handle POST requests for API endpoints"""
        # Check for discovery hostname redirect
        if self.should_redirect_to_actual_hostname():
            self.send_discovery_redirect()
            return

        parsed_path = urlparse(self.path)
        logger.debug(f"POST request: {self.path}")

        if parsed_path.path.startswith("/api/"):
            self.handle_api_post(parsed_path)
        else:
            self.send_error(404)

    def do_PUT(self):
        """Handle PUT requests for API endpoints"""
        # Check for discovery hostname redirect
        if self.should_redirect_to_actual_hostname():
            self.send_discovery_redirect()
            return

        parsed_path = urlparse(self.path)
        logger.debug(f"PUT request: {self.path}")

        if parsed_path.path.startswith("/api/"):
            self.handle_api_put(parsed_path)
        else:
            self.send_error(404)

    def do_DELETE(self):
        """Handle DELETE requests for API endpoints"""
        # Check for discovery hostname redirect
        if self.should_redirect_to_actual_hostname():
            self.send_discovery_redirect()
            return

        parsed_path = urlparse(self.path)
        logger.debug(f"DELETE request: {self.path}")

        if parsed_path.path == "/api/device/name":
            # Reset to automatic naming
            result = set_device_name("")
            self.send_json(result)
        elif parsed_path.path == "/api/comlink/history":
            result = clear_comlink_history()
            self.send_json(result)
        elif parsed_path.path.startswith("/api/display/video/"):
            # Extract and decode video name from path
            video_name = unquote(parsed_path.path.split("/")[-1])
            result = delete_display_video(video_name)
            self.send_json(result)
        elif parsed_path.path.startswith("/api/display/images/"):
            # Extract and decode image name from path
            image_name = unquote(parsed_path.path.split("/")[-1])
            result = delete_image(image_name)
            self.send_json(result)
        elif parsed_path.path == "/api/victron/device":
            result = delete_victron_device_api()
            self.send_json(result)
        # ===== WCB Backup API (DELETE) =====
        elif parsed_path.path.startswith("/api/wcb/backup/"):
            # DELETE /api/wcb/backup/<filename> - Delete backup
            parts = parsed_path.path.split("/")
            if len(parts) >= 5:
                filename = unquote(parts[4])
                result = wcb_backup_handlers.handle_delete_backup(filename)
                self.send_json(result)
            else:
                self.send_json({"error": "Invalid path"}, status=400)
        # ===== Maestro Library API (DELETE) =====
        elif parsed_path.path.startswith("/api/maestro/sequences/"):
            # DELETE /api/maestro/sequences/<id> - Delete sequence
            parts = parsed_path.path.split("/")
            if len(parts) >= 5:
                sequence_id = unquote(parts[4])
                result = delete_maestro_sequence(sequence_id)
                self.send_json(result)
            else:
                self.send_json({"error": "Invalid path"}, status=400)
        elif parsed_path.path.startswith("/api/maestro/scripts/"):
            # DELETE /api/maestro/scripts/<id> - Delete script
            parts = parsed_path.path.split("/")
            if len(parts) >= 5:
                script_id = unquote(parts[4])
                result = delete_maestro_script(script_id)
                self.send_json(result)
            else:
                self.send_json({"error": "Invalid path"}, status=400)
        elif parsed_path.path == "/api/maestro/library/clear":
            # DELETE /api/maestro/library/clear?device_serial=xxx - Clear all sequences for device
            query_params = parse_qs(parsed_path.query)
            device_serial = query_params.get("device_serial", [None])[0]
            result = clear_maestro_library(device_serial)
            self.send_json(result)
        # ===== Droid Fleet API (DELETE) =====
        elif parsed_path.path.startswith("/api/droid/devices/"):
            # DELETE /api/droid/devices/<hostname> - Remove known device
            parts = parsed_path.path.split("/")
            if len(parts) >= 5:
                hostname = unquote(parts[4])
                # Validate hostname to prevent path traversal
                if not is_valid_hostname(hostname):
                    self.send_json({"error": "Invalid hostname format"}, status=400)
                    return
                result = remove_known_device(hostname)
                self.send_json({"success": result, "hostname": hostname})
            else:
                self.send_json({"error": "Invalid path"}, status=400)
        else:
            self.send_error(404)

    def do_HEAD(self):
        """Handle HEAD requests with discovery redirect support.

        Python's SimpleHTTPRequestHandler.do_HEAD() bypasses do_GET(),
        so we need explicit redirect handling here.
        """
        # Check for discovery hostname redirect
        if self.should_redirect_to_actual_hostname():
            self.send_discovery_redirect()
            return

        # Fall back to default HEAD handling
        super().do_HEAD()

    def handle_api_get(self, parsed_path):
        """Handle API GET requests"""
        try:
            if parsed_path.path == "/api/devices":
                self.send_json(get_usb_devices())
            elif parsed_path.path == "/api/devices/arduino":
                self.send_json(get_arduino_devices())
            elif parsed_path.path == "/api/devices/serial":
                self.send_json(get_serial_devices())
            elif parsed_path.path == "/api/status":
                self.send_json(get_system_status())
            elif parsed_path.path == "/api/dashboard/status":
                self.send_json(get_dashboard_status())
            elif parsed_path.path == "/api/services/status":
                self.send_json(get_services_status_summary())
            elif parsed_path.path == "/api/dashboard/processes":
                self.send_json(get_top_processes())
            elif parsed_path.path == "/api/ui/config":
                self.send_json(get_ui_config())
            elif parsed_path.path == "/api/wifi/status":
                self.send_json(get_wifi_status())
            elif parsed_path.path == "/api/wifi/scan":
                self.send_json(scan_wifi_networks())
            elif parsed_path.path == "/api/logs":
                self.send_json(get_system_logs())
            elif parsed_path.path == "/api/system-info":
                self.send_json(get_system_info())
            elif parsed_path.path == "/api/system/update-status":
                self.send_json(get_update_status())
            elif parsed_path.path == "/api/system/update-stream":
                logger.info(f"Update stream requested from {self.client_address}")
                self.handle_update_stream()
            elif parsed_path.path == "/api/system/update-available":
                self.send_json(get_github_update_available())
            elif parsed_path.path == "/api/system/update-config":
                self.send_json(get_github_update_config())
            elif parsed_path.path == "/api/system/discovery":
                self.send_json(get_discovery_status())
            elif parsed_path.path == "/api/test-deployment":
                self.send_json(
                    {
                        "status": "OK",
                        "message": "Deployment successful",
                        "timestamp": time.time(),
                    }
                )
            elif parsed_path.path == "/api/device/name":
                self.send_json(get_device_name())
            elif parsed_path.path == "/api/devices/names":
                self.send_json(get_device_names())
            elif parsed_path.path == "/api/device-serial-config":
                self.send_json(get_device_serial_config())
            elif parsed_path.path == "/api/wifi/saved":
                self.send_json(get_saved_networks())
            elif parsed_path.path == "/api/wifi/mode":
                self.send_json(get_wifi_mode())
            elif parsed_path.path == "/api/wifi/priorities":
                self.send_json(get_network_priorities())
            elif parsed_path.path == "/api/wifi/sync":
                self.send_json(sync_network_configs())
            elif parsed_path.path == "/api/ap/config":
                self.send_json(get_ap_config())
            elif parsed_path.path == "/api/virtualhere/status":
                self.send_json(get_virtualhere_status())
            elif parsed_path.path == "/api/network/settings":
                self.send_json(get_network_settings())
            elif parsed_path.path == "/api/network/discover-devices":
                self.send_json(discover_droidnet_devices())
            # ===== Droid Fleet API (GET) =====
            elif parsed_path.path == "/api/droid/devices":
                self.send_json(get_aggregate_status())
            elif parsed_path.path == "/api/droid/updates/status":
                self.send_json(get_batch_update_status())
            elif parsed_path.path == "/api/droid/updates/summary":
                self.send_json(get_updates_summary())
            elif parsed_path.path == "/api/droid/flash/status":
                self.send_json(get_batch_flash_status())
            elif parsed_path.path == "/api/debug-mode":
                self.send_json({"debug_mode": self.is_debug_mode()})
            elif parsed_path.path == "/api/detect/board":
                # Detect board type for a given port
                params = parse_qs(parsed_path.query)
                port = params.get("port", [""])[0]
                if port:
                    self.send_json(detect_board_type(port))
                else:
                    self.send_json({"error": "No port specified"}, status=400)
            elif parsed_path.path == "/api/wcb/config":
                self.send_json(get_wcb_config())
            elif parsed_path.path == "/api/wcb/alwayson/config":
                self.send_json(get_wcb_alwayson_config())
            elif parsed_path.path == "/api/wcb/devices":
                self.send_json(get_wcb_devices())
            elif parsed_path.path == "/api/wcb/listeners":
                self.send_json(get_wcb_listeners_status())
            elif parsed_path.path == "/api/wcb/listener/status":
                params = parse_qs(parsed_path.query)
                port = params.get("port", [""])[0]
                if port:
                    self.send_json(get_wcb_listener_status(port))
                else:
                    self.send_json({"error": "No port specified"}, status=400)
            elif parsed_path.path == "/api/wcb/preset-commands":
                params = parse_qs(parsed_path.query)
                device_id = params.get("device_id", [None])[0]
                self.send_json(get_wcb_preset_commands(device_id))
            # WCB Backup API - GET endpoints
            elif parsed_path.path == "/api/wcb/backup/config":
                self.send_json(handle_get_backup_config())
            elif parsed_path.path == "/api/wcb/backup/list":
                params = parse_qs(parsed_path.query)
                device_id = params.get("device_id", [None])[0]
                page = params.get("page", ["1"])[0]
                self.send_json(handle_get_backup_list(device_id, page))
            elif parsed_path.path == "/api/wcb/backup/history":
                params = parse_qs(parsed_path.query)
                device_id = params.get("device_id", [None])[0]
                page = params.get("page", ["1"])[0]
                self.send_json(handle_get_backup_history(device_id, page))
            elif parsed_path.path == "/api/wcb/backup/content":
                params = parse_qs(parsed_path.query)
                filename = params.get("filename", [""])[0]
                if filename:
                    self.send_json(handle_get_backup_content(filename))
                else:
                    self.send_json({"error": "filename required"}, status=400)
            elif parsed_path.path == "/api/wcb/backup/restore":
                params = parse_qs(parsed_path.query)
                filename = params.get("filename", [""])[0]
                mode = params.get("mode", ["configured"])[0]
                if filename:
                    self.send_json(handle_get_restore_commands(filename, mode))
                else:
                    self.send_json({"error": "filename required"}, status=400)
            elif parsed_path.path == "/api/wcb/backup/restore-info":
                params = parse_qs(parsed_path.query)
                filename = params.get("filename", [""])[0]
                if filename:
                    self.send_json(handle_get_restore_info(filename))
                else:
                    self.send_json({"error": "filename required"}, status=400)
            elif parsed_path.path == "/api/wcb/backup/diff":
                params = parse_qs(parsed_path.query)
                file1 = params.get("file1", [""])[0]
                file2 = params.get("file2", [""])[0]
                if file1 and file2:
                    self.send_json(handle_compare_backups(file1, file2))
                else:
                    self.send_json({"error": "file1 and file2 required"}, status=400)
            elif parsed_path.path == "/api/serial/history":
                params = parse_qs(parsed_path.query)
                port = params.get("port", [""])[0]
                limit = params.get("limit", [None])[0]
                if limit:
                    limit = int(limit)
                if port:
                    self.send_json(get_serial_history(port, limit))
                else:
                    self.send_json({"error": "No port specified"}, status=400)
            elif parsed_path.path == "/api/comlink/config":
                self.send_json(get_comlink_config())
            elif parsed_path.path == "/api/comlink/status":
                self.send_json(get_comlink_status())
            elif parsed_path.path == "/api/comlink/devices":
                self.send_json(get_comlink_devices())
            elif parsed_path.path == "/api/comlink/history":
                params = parse_qs(parsed_path.query)
                filter_type = params.get("filter", ["all"])[0]
                self.send_json(get_comlink_history(filter_type))
            elif parsed_path.path == "/api/display/status":
                self.send_json(get_display_status())
            elif parsed_path.path == "/api/display/diagnostics":
                self.send_json(get_display_diagnostics())
            elif parsed_path.path == "/api/maestro/config":
                self.send_json(get_maestro_feature_config())
            elif parsed_path.path == "/api/maestro/devices":
                self.send_json(get_maestro_devices())
            elif parsed_path.path.startswith(
                "/api/maestro/device/"
            ) and parsed_path.path.endswith("/status"):
                # Extract port from path: /api/maestro/device/<port>/status
                parts = parsed_path.path.split("/")
                if len(parts) >= 5:
                    port = unquote(parts[4])
                    self.send_json(get_maestro_device_status(port))
                else:
                    self.send_json({"error": "Invalid path"}, status=400)
            elif parsed_path.path.startswith(
                "/api/maestro/device/"
            ) and parsed_path.path.endswith("/servos"):
                # Extract port from path: /api/maestro/device/<port>/servos
                parts = parsed_path.path.split("/")
                if len(parts) >= 5:
                    port = unquote(parts[4])
                    self.send_json(get_maestro_servos(port))
                else:
                    self.send_json({"error": "Invalid path"}, status=400)
            elif parsed_path.path.startswith(
                "/api/maestro/device/"
            ) and parsed_path.path.endswith("/config"):
                # Extract port from path: /api/maestro/device/<port>/config
                parts = parsed_path.path.split("/")
                if len(parts) >= 5:
                    port = unquote(parts[4])
                    self.send_json(get_maestro_config(port))
                else:
                    self.send_json({"error": "Invalid path"}, status=400)
            elif parsed_path.path.startswith(
                "/api/maestro/device/"
            ) and parsed_path.path.endswith("/channels"):
                # GET /api/maestro/device/<port>/channels - Read all channel settings
                parts = parsed_path.path.split("/")
                if len(parts) >= 5:
                    port = unquote(parts[4])
                    self.send_json(get_maestro_channels(port))
                else:
                    self.send_json({"error": "Invalid path"}, status=400)
            elif parsed_path.path.startswith(
                "/api/maestro/device/"
            ) and parsed_path.path.endswith("/export"):
                # GET /api/maestro/device/<port>/export - Export config as JSON
                parts = parsed_path.path.split("/")
                if len(parts) >= 5:
                    port = unquote(parts[4])
                    self.send_json(maestro_export_config(port))
                else:
                    self.send_json({"error": "Invalid path"}, status=400)
            elif parsed_path.path.startswith(
                "/api/maestro/device/"
            ) and parsed_path.path.endswith("/names"):
                # GET /api/maestro/device/<serial>/names - Get channel names
                parts = parsed_path.path.split("/")
                if len(parts) >= 5:
                    serial_number = unquote(parts[4])
                    self.send_json(get_maestro_channel_names(serial_number))
                else:
                    self.send_json({"error": "Invalid path"}, status=400)
            elif parsed_path.path.startswith(
                "/api/maestro/device/"
            ) and parsed_path.path.endswith("/serial-mode"):
                # GET /api/maestro/device/<serial>/serial-mode - Check serial mode
                parts = parsed_path.path.split("/")
                if len(parts) >= 5:
                    serial_number = unquote(parts[4])
                    self.send_json(check_maestro_serial_mode(serial_number))
                else:
                    self.send_json({"error": "Invalid path"}, status=400)
            # ===== Maestro Library API (GET) =====
            elif parsed_path.path == "/api/maestro/sequences":
                # GET /api/maestro/sequences - List all sequences
                params = parse_qs(parsed_path.query)
                device_serial = params.get("device_serial", [None])[0]
                self.send_json(get_maestro_sequences(device_serial))
            elif parsed_path.path.startswith("/api/maestro/sequences/"):
                # GET /api/maestro/sequences/<id> - Get single sequence
                parts = parsed_path.path.split("/")
                if len(parts) >= 5:
                    sequence_id = unquote(parts[4])
                    self.send_json(get_maestro_sequence(sequence_id))
                else:
                    self.send_json({"error": "Invalid path"}, status=400)
            elif parsed_path.path == "/api/maestro/scripts":
                # GET /api/maestro/scripts - List all scripts
                params = parse_qs(parsed_path.query)
                device_serial = params.get("device_serial", [None])[0]
                self.send_json(get_maestro_scripts(device_serial))
            elif parsed_path.path.startswith("/api/maestro/scripts/"):
                # GET /api/maestro/scripts/<id> - Get single script
                parts = parsed_path.path.split("/")
                if len(parts) >= 5:
                    script_id = unquote(parts[4])
                    self.send_json(get_maestro_script(script_id))
                else:
                    self.send_json({"error": "Invalid path"}, status=400)
            elif parsed_path.path.startswith("/api/maestro/sync-state/"):
                # GET /api/maestro/sync-state/<serial> - Get device sync state
                parts = parsed_path.path.split("/")
                if len(parts) >= 5:
                    device_serial = unquote(parts[4])
                    self.send_json(get_maestro_sync_state(device_serial))
                else:
                    self.send_json({"error": "Invalid path"}, status=400)
            elif parsed_path.path.startswith("/api/maestro/export-mcc/"):
                # GET /api/maestro/export-mcc/<serial>/<port> - Export as MCC XML
                parts = parsed_path.path.split("/")
                if len(parts) >= 6:
                    device_serial = unquote(parts[4])
                    port = unquote(parts[5])
                    self.send_json(export_mcc_from_library(device_serial, port))
                else:
                    self.send_json({"error": "Invalid path"}, status=400)
            elif parsed_path.path == "/api/display/images/status":
                self.send_json(get_image_status())
            elif parsed_path.path == "/api/display/images/diagnostics":
                self.send_json(get_image_diagnostics())
            elif parsed_path.path == "/api/victron/config":
                self.send_json(get_victron_config())
            elif parsed_path.path == "/api/victron/feature-config":
                self.send_json(get_victron_feature_config())
            elif parsed_path.path == "/api/victron/status":
                self.send_json(get_victron_status())
            elif parsed_path.path == "/api/victron/telemetry":
                self.send_json(get_victron_latest_telemetry())
            elif parsed_path.path == "/api/victron/history":
                params = parse_qs(parsed_path.query)
                limit = params.get("limit", [None])[0]
                seconds = params.get("seconds", [None])[0]
                if limit:
                    limit = int(limit)
                if seconds:
                    seconds = int(seconds)
                self.send_json(get_victron_telemetry_history(limit, seconds))
            elif parsed_path.path == "/api/victron/logs":
                self.send_json(get_victron_logs())
            else:
                self.send_error(404)
        except Exception as e:
            logger.error(f"Error in handle_api_get: {e}", exc_info=True)
            self.send_json({"error": str(e)}, status=500)

    def handle_api_post(self, parsed_path):
        """Handle API POST requests"""
        try:
            content_length = int(self.headers.get("Content-Length", 0))
            post_data = self.rfile.read(content_length)

            if parsed_path.path == "/api/flash":
                self.handle_firmware_flash(post_data)
            elif parsed_path.path == "/api/devices/lock":
                data = json.loads(post_data.decode())
                result = lock_device(data["port"])
                self.send_json(result)
            elif parsed_path.path == "/api/devices/unlock":
                data = json.loads(post_data.decode())
                result = unlock_device(data["port"])
                self.send_json(result)
            elif parsed_path.path == "/api/wifi/connect":
                data = json.loads(post_data.decode())
                result = connect_wifi(data["ssid"], data.get("password", ""))
                self.send_json(result)
            elif parsed_path.path == "/api/console":
                # Emergency console endpoint - use with caution!
                data = json.loads(post_data.decode())
                result = self.execute_console_command(data.get("command", ""))
                self.send_json(result)
            elif parsed_path.path == "/api/script":
                # Execute uploaded script
                data = json.loads(post_data.decode())
                result = self.execute_script(
                    data.get("script", ""), data.get("interpreter", "bash")
                )
                self.send_json(result)
            elif parsed_path.path == "/api/device/name":
                data = json.loads(post_data.decode())
                result = set_device_name(data.get("name", ""))
                self.send_json(result)
            elif parsed_path.path == "/api/devices/names":
                data = json.loads(post_data.decode())
                result = set_device_custom_name(
                    data.get("device_id", ""), data.get("name", "")
                )
                self.send_json(result)
            elif parsed_path.path == "/api/ui/config":
                data = json.loads(post_data.decode())
                result = save_ui_config(data)
                self.send_json(result)
            elif parsed_path.path == "/api/wifi/forget":
                data = json.loads(post_data.decode())
                result = forget_network(data.get("ssid", ""))
                self.send_json(result)
            elif parsed_path.path == "/api/wifi/mode":
                data = json.loads(post_data.decode())
                result = set_wifi_mode(data.get("mode", ""))
                self.send_json(result)
            elif parsed_path.path == "/api/wifi/make-permanent-ap":
                # Convert temporary AP mode to permanent
                result = make_permanent_ap()
                self.send_json(result)
            elif parsed_path.path == "/api/wifi/retry-client":
                # Retry client mode connection
                result = retry_client_mode()
                self.send_json(result)
            elif parsed_path.path == "/api/wifi/config":
                data = json.loads(post_data.decode())
                result = update_network_config(data)
                self.send_json(result)
            elif parsed_path.path == "/api/virtualhere/toggle":
                data = json.loads(post_data.decode())
                result = toggle_virtualhere(data.get("enable", False))
                self.send_json(result)
            elif parsed_path.path == "/api/wifi/priority":
                data = json.loads(post_data.decode())
                result = set_network_priority(
                    data.get("ssid", ""), data.get("priority", 0)
                )
                self.send_json(result)
            elif parsed_path.path == "/api/ap/config":
                data = json.loads(post_data.decode())
                result = set_ap_config(data.get("ssid", ""), data.get("password", ""))
                self.send_json(result)
            elif parsed_path.path == "/api/network/settings":
                data = json.loads(post_data.decode())
                result = set_network_settings(data)
                self.send_json(result)
            # ===== Droid Fleet API (POST) =====
            elif parsed_path.path == "/api/droid/updates/batch":
                data = json.loads(post_data.decode())
                devices = data.get("devices", [])
                result = start_batch_update(devices)
                self.send_json(result)
            elif parsed_path.path == "/api/droid/flash/start":
                # Multi-device flash requires special handling for firmware file
                self.handle_droid_flash(post_data)
            elif parsed_path.path == "/api/system/reboot":
                result = reboot_device()
                self.send_json(result)
            elif parsed_path.path == "/api/system/update":
                self.handle_system_update(post_data)
            elif parsed_path.path == "/api/system/clear-update-status":
                # Clear update status and completion marker
                try:
                    status_file = str(RUNTIME_DIR / "update-status.json")
                    completion_marker = str(RUNTIME_DIR / "last-update-completed.json")

                    if os.path.exists(status_file):
                        os.unlink(status_file)
                    if os.path.exists(completion_marker):
                        os.unlink(completion_marker)

                    self.send_json(
                        {"success": True, "message": "Update status cleared"}
                    )
                except Exception as e:
                    self.send_json({"success": False, "error": str(e)})
            elif parsed_path.path == "/api/system/check-updates":
                result = check_github_updates()
                self.send_json(result)
            elif parsed_path.path == "/api/system/update-config":
                data = json.loads(post_data.decode())
                result = save_github_update_config(data)
                self.send_json(result)
            elif parsed_path.path == "/api/system/dismiss-update":
                data = json.loads(post_data.decode())
                result = dismiss_github_update(data.get("version"))
                self.send_json(result)
            elif parsed_path.path == "/api/system/download-update":
                self.handle_github_download_update()
            elif parsed_path.path == "/api/system/install-downloaded-update":
                data = json.loads(post_data.decode())
                result = install_downloaded_update(data.get("package_path"))
                self.send_json(result)
            elif parsed_path.path == "/api/wcb/config":
                data = json.loads(post_data.decode())
                result = update_wcb_config(data)
                status = 200 if result.get("success", False) else 400
                self.send_json(result, status=status)
            elif parsed_path.path == "/api/wcb/alwayson/config":
                data = json.loads(post_data.decode())
                config = data.get("config", {})
                result = save_wcb_alwayson_config(config)
                status = 200 if result.get("success", False) else 500
                self.send_json(result, status=status)
            elif parsed_path.path == "/api/wcb/device":
                data = json.loads(post_data.decode())
                result = toggle_wcb_device(
                    data.get("device_id", ""), data.get("enabled", False)
                )
                status = 200 if result.get("success", False) else 400
                self.send_json(result, status=status)
            elif parsed_path.path == "/api/wcb/listener/start":
                data = json.loads(post_data.decode())
                result = start_wcb_listener(
                    data.get("port", ""), data.get("baud", 115200)
                )
                status = 200 if result.get("success", False) else 400
                self.send_json(result, status=status)
            elif parsed_path.path == "/api/wcb/listener/stop":
                data = json.loads(post_data.decode())
                result = stop_wcb_listener(data.get("port", ""))
                status = 200 if result.get("success", False) else 400
                self.send_json(result, status=status)
            elif parsed_path.path == "/api/wcb/command":
                data = json.loads(post_data.decode())
                result = send_wcb_command(
                    data.get("port", ""),
                    data.get("command", ""),
                    data.get("timeout", 5.0),
                )
                status = 200 if result.get("success", False) else 400
                self.send_json(result, status=status)
            elif parsed_path.path == "/api/wcb/preset-commands":
                data = json.loads(post_data.decode())
                result = save_wcb_preset_commands(
                    data.get("device_id", ""),
                    data.get("presets", []),
                )
                status = 200 if result.get("success", False) else 400
                self.send_json(result, status=status)
            elif parsed_path.path == "/api/wcb/preset-commands/reset":
                data = json.loads(post_data.decode())
                result = reset_wcb_preset_commands(data.get("device_id", ""))
                status = 200 if result.get("success", False) else 400
                self.send_json(result, status=status)
            # WCB Backup API - POST endpoints
            elif parsed_path.path == "/api/wcb/backup/config":
                data = json.loads(post_data.decode())
                result = handle_set_backup_config(data)
                status = 200 if result.get("success", False) else 400
                self.send_json(result, status=status)
            elif parsed_path.path == "/api/wcb/backup/trigger":
                data = json.loads(post_data.decode())
                result = handle_trigger_backup(data)
                status = 200 if result.get("success", False) else 400
                self.send_json(result, status=status)
            elif parsed_path.path == "/api/wcb/backup/restore":
                data = json.loads(post_data.decode())
                result = handle_restore_backup(data)
                status = 200 if result.get("success", False) else 400
                self.send_json(result, status=status)
            elif parsed_path.path == "/api/wcb/backup/clear":
                result = handle_clear_all_backups()
                status = 200 if result.get("success", False) else 400
                self.send_json(result, status=status)
            elif parsed_path.path == "/api/comlink/config":
                data = json.loads(post_data.decode())
                result = update_comlink_config(data)
                self.send_json(result)
            elif parsed_path.path == "/api/display/play":
                data = json.loads(post_data.decode())
                result = play_display_video(data.get("video", ""))
                self.send_json(result)
            elif parsed_path.path == "/api/display/pause":
                result = pause_display_video()
                self.send_json(result)
            elif parsed_path.path == "/api/display/resume":
                result = resume_display_video()
                self.send_json(result)
            elif parsed_path.path == "/api/display/stop":
                result = stop_display_video()
                self.send_json(result)
            elif parsed_path.path == "/api/display/upload":
                self.handle_display_upload(post_data)
            elif parsed_path.path == "/api/display/images/show":
                data = json.loads(post_data.decode())
                result = show_image(data.get("image", ""))
                self.send_json(result)
            elif parsed_path.path == "/api/display/images/hide":
                result = stop_image()
                self.send_json(result)
            elif parsed_path.path == "/api/display/images/upload":
                self.handle_image_upload(post_data)
            elif parsed_path.path == "/api/comlink/send":
                data = json.loads(post_data.decode())
                result = send_comlink_command(data)
                self.send_json(result)
            elif parsed_path.path == "/api/victron/device":
                data = json.loads(post_data.decode())
                result = update_victron_device_config(data)
                self.send_json(result)
            elif parsed_path.path == "/api/victron/start":
                result = start_victron_monitoring_api()
                self.send_json(result)
            elif parsed_path.path == "/api/victron/stop":
                result = stop_victron_monitoring_api()
                self.send_json(result)
            elif parsed_path.path == "/api/victron/reconnect":
                result = victron_reconnect_api()
                self.send_json(result)
            elif parsed_path.path == "/api/victron/restart-bluetooth":
                result = restart_bluetooth_api()
                self.send_json(result)
            elif parsed_path.path == "/api/victron/config":
                data = json.loads(post_data.decode())
                result = update_victron_config(data)
                self.send_json(result)
            elif parsed_path.path == "/api/victron/feature-config":
                data = json.loads(post_data.decode())
                result = update_victron_feature_config(data)
                self.send_json(result)
            elif parsed_path.path == "/api/devices/refresh":
                # Force refresh of USB device cache
                # Clear any cached device data if caching is implemented
                logger.info("Device refresh requested")
                if not USB_MANAGER_AVAILABLE:
                    self.send_json(
                        {
                            "status": "refresh_failed",
                            "error": "USBManager not available",
                        }
                    )
                else:
                    try:
                        # Create new instance to force fresh device scan
                        sys.path.insert(0, str(SCRIPTS_DIR))
                        manager = USBManager()
                        devices = manager.get_usb_devices()

                        logger.info(
                            f"Device refresh completed - found {len(devices)} devices"
                        )
                        self.send_json(
                            {"status": "refreshed", "device_count": len(devices)}
                        )
                    except Exception as e:
                        logger.error(f"Error refreshing devices: {e}")
                        self.send_json({"status": "refresh_failed", "error": str(e)})
            elif (
                parsed_path.path.startswith("/api/maestro/device/")
                and "/servo/" in parsed_path.path
            ):
                # Extract port and channel: /api/maestro/device/<port>/servo/<ch>
                parts = parsed_path.path.split("/")
                if len(parts) >= 7 and parts[5] == "servo":
                    port = unquote(parts[4])
                    channel = int(parts[6])
                    data = json.loads(post_data.decode())
                    result = set_maestro_target(port, channel, data.get("target", 6000))
                    self.send_json(result)
                else:
                    self.send_json({"error": "Invalid path"}, status=400)
            elif parsed_path.path.startswith(
                "/api/maestro/device/"
            ) and parsed_path.path.endswith("/home"):
                # Extract port: /api/maestro/device/<port>/home
                parts = parsed_path.path.split("/")
                if len(parts) >= 5:
                    port = unquote(parts[4])
                    result = maestro_go_home(port)
                    self.send_json(result)
                else:
                    self.send_json({"error": "Invalid path"}, status=400)
            elif parsed_path.path.startswith(
                "/api/maestro/device/"
            ) and parsed_path.path.endswith("/script/run"):
                # Extract port: /api/maestro/device/<port>/script/run
                parts = parsed_path.path.split("/")
                if len(parts) >= 5:
                    port = unquote(parts[4])
                    data = json.loads(post_data.decode())
                    result = maestro_run_script(port, data.get("subroutine"))
                    self.send_json(result)
                else:
                    self.send_json({"error": "Invalid path"}, status=400)
            elif parsed_path.path.startswith(
                "/api/maestro/device/"
            ) and parsed_path.path.endswith("/script/stop"):
                # Extract port: /api/maestro/device/<port>/script/stop
                parts = parsed_path.path.split("/")
                if len(parts) >= 5:
                    port = unquote(parts[4])
                    result = maestro_stop_script(port)
                    self.send_json(result)
                else:
                    self.send_json({"error": "Invalid path"}, status=400)
            elif parsed_path.path == "/api/maestro/config":
                data = json.loads(post_data.decode())
                result = update_maestro_feature_config(data)
                self.send_json(result)
            elif parsed_path.path == "/api/maestro/detect":
                result = maestro_detect_devices()
                self.send_json(result)
            elif parsed_path.path == "/api/maestro/add":
                data = json.loads(post_data.decode())
                result = maestro_add_device(
                    data.get("port", ""),
                    data.get("serial_number"),
                    data.get("start_listener", True),
                )
                self.send_json(result)
            elif parsed_path.path == "/api/maestro/remove":
                data = json.loads(post_data.decode())
                result = maestro_remove_device(data.get("port", ""))
                self.send_json(result)
            elif parsed_path.path.startswith(
                "/api/maestro/device/"
            ) and parsed_path.path.endswith("/import"):
                # POST /api/maestro/device/<port>/import - Import config from JSON
                parts = parsed_path.path.split("/")
                if len(parts) >= 5:
                    port = unquote(parts[4])
                    data = json.loads(post_data.decode())
                    result = maestro_import_config(port, data)
                    self.send_json(result)
                else:
                    self.send_json({"error": "Invalid path"}, status=400)
            elif parsed_path.path.startswith(
                "/api/maestro/device/"
            ) and parsed_path.path.endswith("/serial-mode/fix"):
                # POST /api/maestro/device/<serial>/serial-mode/fix - Fix serial mode
                parts = parsed_path.path.split("/")
                if len(parts) >= 5:
                    serial_number = unquote(parts[4])
                    self.send_json(fix_maestro_serial_mode(serial_number))
                else:
                    self.send_json({"error": "Invalid path"}, status=400)
            # ===== Maestro Library API (POST) =====
            elif parsed_path.path == "/api/maestro/sequences":
                # POST /api/maestro/sequences - Create new sequence
                data = json.loads(post_data.decode())
                result = create_maestro_sequence(data)
                self.send_json(result)
            elif parsed_path.path == "/api/maestro/scripts":
                # POST /api/maestro/scripts - Create new script
                data = json.loads(post_data.decode())
                result = create_maestro_script(data)
                self.send_json(result)
            elif parsed_path.path == "/api/maestro/import-mcc":
                # POST /api/maestro/import-mcc - Import MCC XML file
                data = json.loads(post_data.decode())
                xml_content = data.get("xml", "")
                device_serial = data.get("device_serial", "")
                if not xml_content or not device_serial:
                    self.send_json(
                        {"success": False, "error": "xml and device_serial required"},
                        status=400,
                    )
                else:
                    result = import_mcc_to_library(xml_content, device_serial)
                    self.send_json(result)
            elif parsed_path.path == "/api/maestro/sync":
                # POST /api/maestro/sync - Sync library to device
                data = json.loads(post_data.decode())
                device_serial = data.get("device_serial", "")
                port = data.get("port", "")
                if not device_serial or not port:
                    self.send_json(
                        {"success": False, "error": "device_serial and port required"},
                        status=400,
                    )
                else:
                    result = sync_library_to_device(device_serial, port)
                    self.send_json(result)
            elif parsed_path.path == "/api/maestro/compile":
                # POST /api/maestro/compile - Compile script (without upload)
                data = json.loads(post_data.decode())
                device_serial = data.get("device_serial", "")
                script_source = data.get("script", None)
                if not device_serial:
                    self.send_json(
                        {"success": False, "error": "device_serial required"},
                        status=400,
                    )
                elif script_source:
                    # Compile provided script
                    bytecode, errors, sub_map = compile_script(script_source)
                    if errors:
                        self.send_json({"success": False, "errors": errors})
                    else:
                        self.send_json(
                            {
                                "success": True,
                                "bytecode_size": len(bytecode),
                                "subroutine_map": {
                                    str(k): v for k, v in sub_map.items()
                                },
                            }
                        )
                else:
                    # Generate script from library
                    result = compile_library_to_script(device_serial)
                    self.send_json(result)
            else:
                self.send_error(404)
        except Exception as e:
            logger.error(f"Error in handle_api_post: {e}", exc_info=True)
            self.send_json({"error": str(e)}, status=500)

    def handle_api_put(self, parsed_path):
        """Handle API PUT requests"""
        try:
            content_length = int(self.headers.get("Content-Length", 0))
            put_data = self.rfile.read(content_length)

            if (
                parsed_path.path.startswith("/api/maestro/device/")
                and "/channels/" in parsed_path.path
            ):
                # PUT /api/maestro/device/<port>/channels/<ch> - Write channel settings
                parts = parsed_path.path.split("/")
                if len(parts) >= 7:
                    port = unquote(parts[4])
                    channel = int(parts[6])
                    data = json.loads(put_data.decode())
                    result = set_maestro_channel_settings(port, channel, data)
                    self.send_json(result)
                else:
                    self.send_json({"error": "Invalid path"}, status=400)
            elif parsed_path.path.startswith(
                "/api/maestro/device/"
            ) and parsed_path.path.endswith("/names"):
                # PUT /api/maestro/device/<serial>/names - Update channel names
                parts = parsed_path.path.split("/")
                if len(parts) >= 5:
                    serial_number = unquote(parts[4])
                    data = json.loads(put_data.decode())
                    result = update_maestro_channel_names(serial_number, data)
                    self.send_json(result)
                else:
                    self.send_json({"error": "Invalid path"}, status=400)
            # ===== Maestro Library API (PUT) =====
            elif parsed_path.path.startswith("/api/maestro/sequences/"):
                # PUT /api/maestro/sequences/<id> - Update sequence
                parts = parsed_path.path.split("/")
                if len(parts) >= 5:
                    sequence_id = unquote(parts[4])
                    data = json.loads(put_data.decode())
                    result = update_maestro_sequence(sequence_id, data)
                    self.send_json(result)
                else:
                    self.send_json({"error": "Invalid path"}, status=400)
            elif parsed_path.path.startswith("/api/maestro/scripts/"):
                # PUT /api/maestro/scripts/<id> - Update script
                parts = parsed_path.path.split("/")
                if len(parts) >= 5:
                    script_id = unquote(parts[4])
                    data = json.loads(put_data.decode())
                    result = update_maestro_script(script_id, data)
                    self.send_json(result)
                else:
                    self.send_json({"error": "Invalid path"}, status=400)
            else:
                self.send_error(404)
        except Exception as e:
            logger.error(f"Error in handle_api_put: {e}", exc_info=True)
            self.send_json({"error": str(e)}, status=500)

    def handle_firmware_flash(self, post_data):
        """Handle firmware flashing (multipart form data)"""
        logger.info("Processing firmware flash request")
        # Improved multipart parsing that handles binary data correctly
        boundary = self.headers.get("Content-Type").split("boundary=")[1].encode()

        firmware_data = None
        device_port = None
        board_type = None
        flash_address = None

        # ESP32 additional files
        bootloader_data = None
        partitions_data = None
        otadata_data = None

        # Split parts more carefully
        delimiter = b"--" + boundary
        parts = post_data.split(delimiter)

        for part in parts:
            if not part or part == b"--\r\n":
                continue

            # Find the end of headers (double CRLF)
            header_end = part.find(b"\r\n\r\n")
            if header_end == -1:
                continue

            headers = part[:header_end]
            # Content starts after the double CRLF
            content = part[header_end + 4 :]

            # Remove trailing boundary markers if present
            if content.endswith(b"\r\n"):
                content = content[:-2]

            if b'name="firmware_file"' in headers or b'name="hex_file"' in headers:
                firmware_data = content
                logger.info(f"Firmware data size: {len(content)} bytes")
            elif b'name="device_port"' in headers:
                device_port = content.decode().strip()
            elif b'name="board_type"' in headers:
                board_type_raw = content.decode().strip()
                # Check if auto-detect was requested
                if board_type_raw == "auto" or not board_type_raw:
                    board_type = None
                else:
                    board_type = board_type_raw
            elif b'name="bootloader_file"' in headers:
                bootloader_data = content
            elif b'name="partitions_file"' in headers:
                partitions_data = content
            elif b'name="otadata_file"' in headers:
                otadata_data = content
            elif b'name="binary_type"' in headers:
                # binary_type would be extracted here if needed
                pass
            elif b'name="flash_address"' in headers:
                flash_address = content.decode().strip()

        if firmware_data and device_port:
            # Check if we have additional ESP32 files
            additional_files = {}
            if bootloader_data or partitions_data or otadata_data:
                # Save additional files temporarily
                if bootloader_data:
                    with tempfile.NamedTemporaryFile(suffix=".bin", delete=False) as f:
                        f.write(bootloader_data)
                        additional_files["bootloader"] = f.name

                if partitions_data:
                    with tempfile.NamedTemporaryFile(suffix=".bin", delete=False) as f:
                        f.write(partitions_data)
                        additional_files["partitions"] = f.name

                if otadata_data:
                    with tempfile.NamedTemporaryFile(suffix=".bin", delete=False) as f:
                        f.write(otadata_data)
                        additional_files["otadata"] = f.name

            # Flash with or without board type (auto-detect if None)
            result = flash_firmware(
                firmware_data, device_port, board_type, additional_files, flash_address
            )

            # Clean up temp files
            for file_path in additional_files.values():
                if os.path.exists(file_path):
                    os.unlink(file_path)

            self.send_json(result)
        else:
            self.send_json({"error": "Missing required fields"}, status=400)

    def handle_droid_flash(self, post_data):
        """Handle multi-device firmware flashing (multipart form data)"""
        logger.info("Processing multi-device flash request")

        # Validate Content-Type header
        content_type = self.headers.get("Content-Type", "")
        if "boundary=" not in content_type:
            self.send_json({"error": "Invalid Content-Type header"}, status=400)
            return

        try:
            boundary = content_type.split("boundary=")[1].encode()
        except IndexError:
            self.send_json({"error": "Could not parse boundary"}, status=400)
            return

        firmware_data = None
        targets_json = None
        board_type = "auto"

        # Split parts
        delimiter = b"--" + boundary
        parts = post_data.split(delimiter)

        for part in parts:
            if not part or part == b"--\r\n":
                continue

            header_end = part.find(b"\r\n\r\n")
            if header_end == -1:
                continue

            headers = part[:header_end]
            content = part[header_end + 4 :]

            if content.endswith(b"\r\n"):
                content = content[:-2]

            if b'name="firmware_file"' in headers:
                firmware_data = content
                logger.info(f"Droid flash firmware size: {len(content)} bytes")
            elif b'name="targets"' in headers:
                targets_json = content.decode().strip()
            elif b'name="board_type"' in headers:
                board_type_raw = content.decode().strip()
                if board_type_raw and board_type_raw != "auto":
                    board_type = board_type_raw

        if firmware_data and targets_json:
            try:
                targets = json.loads(targets_json)
                result = start_batch_flash(targets, firmware_data, board_type)
                self.send_json(result)
            except json.JSONDecodeError as e:
                self.send_json({"error": f"Invalid targets JSON: {e}"}, status=400)
        else:
            self.send_json({"error": "Missing firmware_file or targets"}, status=400)

    def execute_console_command(self, command):
        """Execute a console command - FOR EMERGENCY USE ONLY"""
        if not command:
            return {"success": False, "error": "No command provided"}

        # Basic security check - prevent obvious dangerous commands
        dangerous_patterns = ["rm -rf /", "dd if=", "mkfs", "> /dev/"]
        for pattern in dangerous_patterns:
            if pattern in command:
                return {"success": False, "error": "Dangerous command blocked"}

        try:
            # Execute command with timeout
            result = subprocess.run(
                command, shell=True, capture_output=True, text=True, timeout=30
            )

            return {
                "success": True,
                "output": result.stdout,
                "error": result.stderr,
                "returncode": result.returncode,
            }
        except subprocess.TimeoutExpired:
            return {"success": False, "error": "Command timed out after 30 seconds"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def execute_script(self, script_content, interpreter="bash"):
        """Execute a script with specified interpreter"""
        if not script_content:
            return {"success": False, "error": "No script provided"}

        # Validate interpreter
        valid_interpreters = ["bash", "python3", "sh"]
        if interpreter not in valid_interpreters:
            return {
                "success": False,
                "error": f"Invalid interpreter. Use one of: {valid_interpreters}",
            }

        try:
            # Save script to temporary file
            with tempfile.NamedTemporaryFile(
                mode="w", suffix=".tmp", delete=False
            ) as f:
                f.write(script_content)
                script_path = f.name

            # Make executable if bash/sh
            if interpreter in ["bash", "sh"]:
                os.chmod(script_path, 0o755)

            # Execute script
            result = subprocess.run(
                [interpreter, script_path], capture_output=True, text=True, timeout=60
            )

            # Clean up
            os.unlink(script_path)

            return {
                "success": True,
                "output": result.stdout,
                "error": result.stderr,
                "returncode": result.returncode,
            }
        except subprocess.TimeoutExpired:
            os.unlink(script_path)
            return {"success": False, "error": "Script timed out after 60 seconds"}
        except Exception as e:
            if "script_path" in locals():
                os.unlink(script_path)
            return {"success": False, "error": str(e)}

    def send_json(self, data, status=200):
        """Send JSON response"""
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()

        json_data = json.dumps(data).encode()
        self.wfile.write(json_data)

    def handle_system_update(self, post_data):
        """Handle system update file upload (multipart form data)"""
        try:
            # Parse multipart data
            boundary = self.headers.get("Content-Type").split("boundary=")[1].encode()

            update_file_data = None
            filename = None

            # Split parts
            delimiter = b"--" + boundary
            parts = post_data.split(delimiter)

            for part in parts:
                if not part or part == b"--\r\n":
                    continue

                # Find the end of headers
                header_end = part.find(b"\r\n\r\n")
                if header_end == -1:
                    continue

                headers = part[:header_end]
                content = part[header_end + 4 :]

                # Remove trailing boundary markers more carefully
                # The content might end with \r\n--boundary--\r\n or just \r\n
                if content.endswith(b"\r\n"):
                    content = content[:-2]
                elif content.endswith(b"\n"):
                    content = content[:-1]

                if b'name="update_file"' in headers:
                    update_file_data = content
                    # Extract filename from headers
                    if b'filename="' in headers:
                        start = headers.find(b'filename="') + 10
                        end = headers.find(b'"', start)
                        filename = headers[start:end].decode()

            if not update_file_data:
                self.send_json(
                    {"success": False, "error": "No update file provided"}, status=400
                )
                return

            # Log file details for debugging
            logger.info(
                f"Received update file: {filename}, size: {len(update_file_data)} bytes"
            )

            # Calculate checksum for verification
            checksum = hashlib.sha256(update_file_data).hexdigest()
            logger.info(f"Update file checksum: {checksum}")

            # Process the update
            result = handle_update_upload(update_file_data, filename or "update.zip")
            self.send_json(result)

        except Exception as e:
            logger.error(f"Error handling update: {e}", exc_info=True)
            self.send_json({"success": False, "error": str(e)}, status=500)

    def handle_update_stream(self):
        """Handle server-sent events stream for update progress"""
        logger.info("handle_update_stream called")
        try:
            # Send headers for SSE
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "keep-alive")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()

            # Monitor update log file
            log_file = str(UPDATE_LOG_FILE)
            status_file = str(UPDATE_STATUS_FILE)
            last_position = 0

            # Ensure log directory and file exist
            os.makedirs(os.path.dirname(log_file), exist_ok=True)
            if not os.path.exists(log_file):
                open(log_file, "a").close()

            # Send initial connection message
            self.wfile.write(
                b"data: "
                + json.dumps(
                    {"type": "connected", "message": "Connected to update stream"}
                ).encode()
                + b"\n\n"
            )
            self.wfile.flush()

            # Monitor for updates
            while True:
                try:
                    # Check status file
                    if os.path.exists(status_file):
                        with open(status_file, "r") as f:
                            status = json.load(f)

                        if status.get("status") == "completed":
                            # Send completion event
                            self.wfile.write(
                                b"data: "
                                + json.dumps(
                                    {
                                        "type": "complete",
                                        "version": status.get("result", {}).get(
                                            "version", "unknown"
                                        ),
                                        "message": "Update completed successfully",
                                    }
                                ).encode()
                                + b"\n\n"
                            )
                            self.wfile.flush()
                            break
                        elif status.get("status") == "failed":
                            # Send error event
                            self.wfile.write(
                                b"data: "
                                + json.dumps(
                                    {
                                        "type": "error",
                                        "error": status.get("error", "Update failed"),
                                    }
                                ).encode()
                                + b"\n\n"
                            )
                            self.wfile.flush()
                            break

                    # Read new log lines
                    if os.path.exists(log_file):
                        with open(log_file, "r") as f:
                            f.seek(last_position)
                            new_lines = f.readlines()
                            last_position = f.tell()

                        for line in new_lines:
                            line = line.strip()
                            if line:
                                # Parse log level from line
                                level = "info"
                                if "ERROR" in line:
                                    level = "error"
                                elif "WARNING" in line:
                                    level = "warning"
                                elif "SUCCESS" in line or "completed" in line.lower():
                                    level = "success"

                                # Send log event
                                self.wfile.write(
                                    b"data: "
                                    + json.dumps(
                                        {"type": "log", "message": line, "level": level}
                                    ).encode()
                                    + b"\n\n"
                                )
                                self.wfile.flush()

                    # Small delay to prevent CPU spinning
                    time.sleep(0.5)

                except (BrokenPipeError, ConnectionResetError):
                    # Client disconnected
                    break
                except Exception as e:
                    logger.error(f"Error in update stream: {e}")
                    break

        except Exception as e:
            logger.error(f"Error setting up update stream: {e}")
            self.send_error(500)

    def handle_github_download_update(self):
        """Handle GitHub update download with SSE progress streaming."""
        logger.info("GitHub download update requested")
        try:
            # Send headers for SSE
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "keep-alive")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()

            # Import downloader
            from scripts.update_downloader import UpdateDownloader

            downloader = UpdateDownloader()

            def send_event(event_type, data):
                """Send SSE event."""
                event_data = {"type": event_type, **data}
                self.wfile.write(b"data: " + json.dumps(event_data).encode() + b"\n\n")
                self.wfile.flush()

            def progress_callback(downloaded, total):
                """Progress callback for download."""
                percent = round((downloaded / total) * 100, 1) if total > 0 else 0
                send_event(
                    "progress",
                    {
                        "downloaded": downloaded,
                        "total": total,
                        "percent": percent,
                    },
                )

            # Send start event
            send_event("start", {"message": "Starting download"})

            # Perform download with progress
            result_path = downloader.download_update(
                progress_callback=progress_callback
            )

            if result_path:
                send_event(
                    "complete",
                    {
                        "success": True,
                        "package_path": str(result_path),
                        "message": "Download complete",
                    },
                )
            else:
                send_event(
                    "complete",
                    {
                        "success": False,
                        "error": "Download failed - check logs for details",
                    },
                )

        except BrokenPipeError:
            logger.warning("Client disconnected during download")
        except Exception as e:
            logger.error(f"Error during GitHub download: {e}")
            try:
                self.wfile.write(
                    b"data: "
                    + json.dumps({"type": "error", "error": str(e)}).encode()
                    + b"\n\n"
                )
                self.wfile.flush()
            except Exception:
                pass

    def handle_display_upload(self, post_data):
        """Handle Display video file upload (multipart form data)"""
        try:
            logger.info("Processing Display video upload")

            # Parse multipart data
            boundary = self.headers.get("Content-Type").split("boundary=")[1].encode()

            video_data = None
            filename = None

            # Split parts
            delimiter = b"--" + boundary
            parts = post_data.split(delimiter)

            for part in parts:
                if not part or part == b"--\r\n":
                    continue

                # Find the end of headers
                header_end = part.find(b"\r\n\r\n")
                if header_end == -1:
                    continue

                headers = part[:header_end]
                content = part[header_end + 4 :]

                # Remove trailing boundary markers
                if content.endswith(b"\r\n"):
                    content = content[:-2]

                if b'name="video_file"' in headers:
                    video_data = content
                    # Extract filename from Content-Disposition header
                    if b"filename=" in headers:
                        filename_match = headers.split(b"filename=")[1].split(b"\r\n")[
                            0
                        ]
                        filename = filename_match.strip(b'"').decode()
                        logger.info(
                            f"Video filename: {filename}, size: {len(content)} bytes"
                        )

            if video_data and filename:
                result = upload_display_video(filename, video_data)
                self.send_json(result)
            else:
                self.send_json(
                    {"success": False, "error": "No video file provided"}, status=400
                )

        except Exception as e:
            logger.error(f"Error handling display upload: {e}", exc_info=True)
            self.send_json({"success": False, "error": str(e)}, status=500)

    def handle_image_upload(self, post_data):
        """Handle Display image file upload (multipart form data)"""
        try:
            logger.info("Processing Display image upload")

            # Parse multipart data
            boundary = self.headers.get("Content-Type").split("boundary=")[1].encode()

            image_data = None
            filename = None

            # Split parts
            delimiter = b"--" + boundary
            parts = post_data.split(delimiter)

            for part in parts:
                if not part or part == b"--\r\n":
                    continue

                # Find the end of headers
                header_end = part.find(b"\r\n\r\n")
                if header_end == -1:
                    continue

                headers = part[:header_end]
                content = part[header_end + 4 :]

                # Remove trailing boundary markers
                if content.endswith(b"\r\n"):
                    content = content[:-2]

                if b'name="image_file"' in headers:
                    image_data = content
                    # Extract filename from Content-Disposition header
                    if b"filename=" in headers:
                        filename_match = headers.split(b"filename=")[1].split(b"\r\n")[
                            0
                        ]
                        filename = filename_match.strip(b'"').decode()
                        logger.info(
                            f"Image filename: {filename}, size: {len(content)} bytes"
                        )

            if image_data and filename:
                result = upload_image(filename, image_data)
                self.send_json(result)
            else:
                self.send_json(
                    {"success": False, "error": "No image file provided"}, status=400
                )

        except Exception as e:
            logger.error(f"Error handling image upload: {e}", exc_info=True)
            self.send_json({"success": False, "error": str(e)}, status=500)

    def serve_index_with_conditional_nav(self):
        """Serve index.html with conditional debug navigation"""
        try:
            index_path = os.path.join(WEB_ROOT, "index.html")
            with open(index_path, "r") as f:
                html_content = f.read()

            # Force cache refresh by updating the version parameter
            cache_buster = str(int(time.time()))
            html_content = html_content.replace(
                "app.js?v=20250710-resize", f"app.js?v={cache_buster}"
            )
            html_content = html_content.replace(
                "app.js?v=20250722-update-fix", f"app.js?v={cache_buster}"
            )

            # If not debug mode, remove debug navigation links
            if not self.is_debug_mode():
                # Remove the debug navigation links
                html_content = html_content.replace(
                    (
                        '<a href="/logs" target="_blank" style="color: #00ff00; '
                        'text-decoration: none; font-size: 14px; margin-left: 20px;">'
                        "📋 Debug Logs</a>"
                    ),
                    "",
                )
                html_content = html_content.replace(
                    (
                        '<a href="/console" target="_blank" style="color: #ff6600; '
                        'text-decoration: none; font-size: 14px; margin-left: 10px;">'
                        "🔧 Console</a>"
                    ),
                    "",
                )

            # Send the modified HTML
            # IMPORTANT: Encode first, then use byte length for Content-Length
            # (len(string) != len(bytes) for non-ASCII characters like emojis)
            encoded_content = html_content.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(encoded_content)))
            self.end_headers()
            self.wfile.write(encoded_content)

        except Exception as e:
            self.send_error(500, f"Internal Server Error: {str(e)}")

    def serve_logs_page(self):
        """Serve the logs viewing page"""
        logs_html = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DroidNet System Logs</title>
    <style>
        body {
            font-family: monospace;
            margin: 20px;
            background: #1a1a1a;
            color: #00ff00;
        }
        .container { max-width: 1200px; margin: 0 auto; }
        .log-section { margin: 20px 0; border: 1px solid #333; background: #222; }
        .log-header {
            background: #333;
            padding: 10px;
            font-weight: bold;
            cursor: pointer;
        }
        .log-content {
            padding: 10px;
            max-height: 400px;
            overflow-y: auto;
            white-space: pre-wrap;
        }
        .collapsed .log-content { display: none; }
        .error { color: #ff4444; }
        .success { color: #44ff44; }
        .timeout { color: #ffaa44; }
        .nav { margin-bottom: 20px; }
        .nav a { color: #00ff00; margin-right: 20px; text-decoration: none; }
        .nav a:hover { text-decoration: underline; }
        .refresh-btn {
            background: #007700;
            color: white;
            border: none;
            padding: 10px 20px;
            margin: 10px 0;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="nav">
            <a href="/">← Back to Main Interface</a>
            <button class="refresh-btn" onclick="location.reload()">
                Refresh Logs
            </button>
            <button class="refresh-btn" onclick="exportLogs()">Export All Logs</button>
        </div>
        <h1>DroidNet System Logs & Information</h1>
        <div id="logs-container">Loading logs...</div>
        <div id="info-container" style="margin-top: 40px;">Loading system info...</div>
    </div>
    
    <!-- Export Modal -->
    <div id="exportModal" class="modal" style="display: none; position: fixed;
         z-index: 1000; left: 0; top: 0; width: 100%; height: 100%;
         background-color: rgba(0,0,0,0.5);">
        <div class="modal-content" style="background-color: #222; margin: 5% auto;
             padding: 20px; border: 1px solid #0f0; width: 80%; max-width: 800px;
             max-height: 80vh; overflow-y: auto; border-radius: 8px;">
            <div class="modal-header" style="display: flex;
                 justify-content: space-between; align-items: center;
                 margin-bottom: 20px;">
                <h2 style="color: #0f0; margin: 0;">Export All Logs</h2>
                <span class="close" onclick="closeExportModal()"
                      style="color: #0f0; font-size: 28px; font-weight: bold;
                      cursor: pointer;">&times;</span>
            </div>
            <button onclick="copyToClipboard()" style="background: #007700;
                    color: white; border: none; padding: 10px 20px;
                    margin-bottom: 10px; cursor: pointer;">Copy to Clipboard</button>
            <div id="export-content" style="background: #111; padding: 15px;
                 border-radius: 4px; font-family: monospace; font-size: 0.85em;
                 white-space: pre-wrap; word-break: break-all; max-height: 400px;
                 overflow-y: auto; color: #0f0;"></div>
        </div>
    </div>
    
    <script>
        function toggleSection(header) {
            const section = header.parentElement;
            section.classList.toggle('collapsed');
        }
        
        function loadLogs() {
            fetch('/api/logs')
                .then(response => response.json())
                .then(data => {
                    const container = document.getElementById('logs-container');
                    if (data.error) {
                        container.innerHTML = (
                            `<div class="error">Error: ${data.error}</div>`
                        );
                        return;
                    }
                    
                    let html = `<h2>System Logs (Updated: ${data.timestamp})</h2>`;
                    
                    Object.entries(data.logs).forEach(([name, log]) => {
                        const statusClass = log.status || 'success';
                        html += `
                            <div class="log-section">
                                <div class="log-header ${statusClass}"
                                     onclick="toggleSection(this)">
                                    ${name.replace(/-/g, ' ').toUpperCase()}
                                    [${log.status}]
                                </div>
                                <div class="log-content">${log.content}</div>
                            </div>
                        `;
                    });
                    
                    container.innerHTML = html;
                })
                .catch(error => {
                    document.getElementById('logs-container').innerHTML = (
                        `<div class="error">Failed to load logs: ${error}</div>`
                    );
                });
        }
        
        function loadSystemInfo() {
            fetch('/api/system-info')
                .then(response => response.json())
                .then(data => {
                    const container = document.getElementById('info-container');
                    if (data.error) {
                        container.innerHTML = (
                            `<div class="error">Error: ${data.error}</div>`
                        );
                        return;
                    }
                    
                    let html = (
                        `<h2>System Information (Updated: ${data.timestamp})</h2>`
                    );
                    
                    Object.entries(data.info).forEach(([name, info]) => {
                        const statusClass = info.status || 'success';
                        html += `
                            <div class="log-section collapsed">
                                <div class="log-header ${statusClass}"
                                     onclick="toggleSection(this)">
                                    ${name.replace(/_/g, ' ').toUpperCase()}
                                    [${info.status}]
                                </div>
                                <div class="log-content">${info.content}</div>
                            </div>
                        `;
                    });
                    
                    container.innerHTML = html;
                })
                .catch(error => {
                    document.getElementById('info-container').innerHTML = (
                        `<div class="error">Failed to load system info: ${error}</div>`
                    );
                });
        }
        
        // Export functionality
        let allLogsData = {};
        let allInfoData = {};
        
        function exportLogs() {
            // Show modal
            document.getElementById('exportModal').style.display = 'block';
            
            // Combine all logs into export format
            let exportText = '=== DROIDNET SYSTEM LOGS EXPORT ===\\n';
            exportText += 'Generated: ' + new Date().toISOString() + '\\n\\n';
            
            // Add service logs
            Object.entries(allLogsData).forEach(([name, log]) => {
                exportText += `=== ${name.toUpperCase()} ===\\n`;
                exportText += log.content + '\\n\\n';
            });
            
            // Add system info
            exportText += '\\n=== SYSTEM INFORMATION ===\\n\\n';
            Object.entries(allInfoData).forEach(([name, info]) => {
                exportText += `=== ${name.replace(/_/g, ' ').toUpperCase()} ===\\n`;
                exportText += info.content + '\\n\\n';
            });
            
            document.getElementById('export-content').textContent = exportText;
        }
        
        function closeExportModal() {
            document.getElementById('exportModal').style.display = 'none';
        }
        
        function copyToClipboard() {
            const exportContent = document.getElementById('export-content');
            const text = exportContent.textContent;
            
            // Create temporary textarea
            const textarea = document.createElement('textarea');
            textarea.value = text;
            document.body.appendChild(textarea);
            textarea.select();
            
            try {
                document.execCommand('copy');
                alert('Logs copied to clipboard!');
            } catch (err) {
                alert('Failed to copy logs. Please select and copy manually.');
            }
            
            document.body.removeChild(textarea);
        }
        
        // Modified loadLogs to store data
        function loadLogs() {
            fetch('/api/logs')
                .then(response => response.json())
                .then(data => {
                    const container = document.getElementById('logs-container');
                    if (data.error) {
                        container.innerHTML = (
                            `<div class="error">Error: ${data.error}</div>`
                        );
                        return;
                    }
                    
                    allLogsData = data.logs;  // Store for export
                    
                    let html = `<h2>System Logs (Updated: ${data.timestamp})</h2>`;
                    
                    Object.entries(data.logs).forEach(([name, log]) => {
                        const statusClass = log.status || 'success';
                        html += `
                            <div class="log-section">
                                <div class="log-header ${statusClass}"
                                     onclick="toggleSection(this)">
                                    ${name} [${log.status}]
                                </div>
                                <div class="log-content">${log.content}</div>
                            </div>
                        `;
                    });
                    
                    container.innerHTML = html;
                })
                .catch(error => {
                    document.getElementById('logs-container').innerHTML = (
                        `<div class="error">Failed to load logs: ${error}</div>`
                    );
                });
        }
        
        // Modified loadSystemInfo to store data
        function loadSystemInfo() {
            fetch('/api/system-info')
                .then(response => response.json())
                .then(data => {
                    const container = document.getElementById('info-container');
                    if (data.error) {
                        container.innerHTML = (
                            `<div class="error">Error: ${data.error}</div>`
                        );
                        return;
                    }
                    
                    allInfoData = data;  // Store for export
                    
                    let html = '<h2>System Information</h2>';
                    
                    Object.entries(data).forEach(([name, info]) => {
                        if (name === 'timestamp') return;
                        const statusClass = info.status || 'success';
                        html += `
                            <div class="log-section collapsed">
                                <div class="log-header ${statusClass}"
                                     onclick="toggleSection(this)">
                                    ${name.replace(/_/g, ' ').toUpperCase()}
                                    [${info.status}]
                                </div>
                                <div class="log-content">${info.content}</div>
                            </div>
                        `;
                    });
                    
                    container.innerHTML = html;
                })
                .catch(error => {
                    document.getElementById('info-container').innerHTML = (
                        `<div class="error">Failed to load system info: ${error}</div>`
                    );
                });
        }
        
        // Load data on page load
        window.onload = function() {
            loadLogs();
            loadSystemInfo();
        };
    </script>
</body>
</html>"""

        self.send_response(200)
        self.send_header("Content-Type", "text/html")
        self.end_headers()
        self.wfile.write(logs_html.encode())

    def serve_console_page(self):
        """Serve the emergency console page"""
        console_html = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DroidNet Emergency Console</title>
    <style>
        body {
            background: #000;
            color: #0f0;
            font-family: 'Courier New', monospace;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        h1 {
            color: #0f0;
            text-shadow: 0 0 10px #0f0;
            margin-bottom: 10px;
        }
        .warning {
            color: #ff0;
            background: #330;
            padding: 10px;
            border: 1px solid #ff0;
            margin-bottom: 20px;
        }
        #terminal {
            background: #111;
            border: 1px solid #0f0;
            padding: 10px;
            height: 400px;
            overflow-y: auto;
            font-size: 14px;
            white-space: pre-wrap;
            word-wrap: break-word;
            margin-bottom: 10px;
        }
        #command-input {
            width: 100%;
            background: #111;
            border: 1px solid #0f0;
            color: #0f0;
            padding: 10px;
            font-family: inherit;
            font-size: 14px;
            box-sizing: border-box;
        }
        .output { color: #fff; }
        .error { color: #f00; }
        .prompt { color: #0f0; }
        .success { color: #0f0; }
        button {
            background: #111;
            border: 1px solid #0f0;
            color: #0f0;
            padding: 10px 20px;
            cursor: pointer;
            margin: 10px 5px 0 0;
            font-family: inherit;
        }
        button:hover {
            background: #0f0;
            color: #000;
        }
        .script-section {
            margin-top: 30px;
            border-top: 1px solid #333;
            padding-top: 20px;
        }
        textarea {
            width: 100%;
            background: #111;
            border: 1px solid #0f0;
            color: #0f0;
            padding: 10px;
            font-family: inherit;
            font-size: 14px;
            box-sizing: border-box;
            height: 200px;
        }
        select {
            background: #111;
            border: 1px solid #0f0;
            color: #0f0;
            padding: 5px;
            margin-left: 10px;
        }
        .back-link {
            color: #0f0;
            text-decoration: none;
            display: inline-block;
            margin-bottom: 20px;
        }
        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="/" class="back-link">← Back to Main Interface</a>
        <h1>DroidNet Emergency Console</h1>
        <div class="warning">
            ⚠️ WARNING: This console runs commands as root.
            Use with extreme caution!
        </div>
        
        <div id="terminal"></div>
        <input type="text" id="command-input" placeholder="Enter command..." autofocus>
        
        <div>
            <button onclick="runCommand('systemctl status ssh')">SSH Status</button>
            <button onclick="runCommand('systemctl status droidnet-web')">
                Web Status
            </button>
            <button onclick="runCommand('ip addr')">Network Info</button>
            <button onclick="runCommand('ps aux | grep python')">
                Python Processes
            </button>
            <button onclick="runCommand('journalctl -u droidnet-web -n 20')">
                Web Logs
            </button>
            <button onclick="clearTerminal()">Clear</button>
        </div>
        
        <div class="script-section">
            <h2>Script Executor</h2>
            <textarea id="script-content" 
                      placeholder="Paste your script here..."></textarea>
            <div>
                <label>Interpreter:</label>
                <select id="interpreter">
                    <option value="bash">Bash</option>
                    <option value="python3">Python3</option>
                    <option value="sh">Shell (sh)</option>
                </select>
                <button onclick="runScript()">Run Script</button>
            </div>
        </div>
    </div>

    <script>
        const terminal = document.getElementById('terminal');
        const commandInput = document.getElementById('command-input');
        
        function addToTerminal(text, className = '') {
            const line = document.createElement('div');
            line.className = className;
            line.textContent = text;
            terminal.appendChild(line);
            terminal.scrollTop = terminal.scrollHeight;
        }
        
        function runCommand(cmd) {
            if (!cmd) return;
            
            addToTerminal(`$ ${cmd}`, 'prompt');
            
            fetch('/api/console', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({command: cmd})
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    if (data.output) addToTerminal(data.output, 'output');
                    if (data.error) addToTerminal(data.error, 'error');
                    if (data.returncode !== 0) {
                        addToTerminal(`Exit code: ${data.returncode}`, 'error');
                    }
                } else {
                    addToTerminal(data.error || 'Command failed', 'error');
                }
            })
            .catch(err => {
                addToTerminal(`Error: ${err.message}`, 'error');
            });
        }
        
        function runScript() {
            const script = document.getElementById('script-content').value;
            const interpreter = document.getElementById('interpreter').value;
            
            if (!script.trim()) {
                addToTerminal('No script content provided', 'error');
                return;
            }
            
            addToTerminal(`Running ${interpreter} script...`, 'prompt');
            
            fetch('/api/script', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({script: script, interpreter: interpreter})
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    if (data.output) addToTerminal(data.output, 'output');
                    if (data.error) addToTerminal(data.error, 'error');
                    addToTerminal(
                        `Script completed with exit code: ${data.returncode}`, 
                        data.returncode === 0 ? 'success' : 'error'
                    );
                } else {
                    addToTerminal(data.error || 'Script execution failed', 'error');
                }
            })
            .catch(err => {
                addToTerminal(`Error: ${err.message}`, 'error');
            });
        }
        
        commandInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                const cmd = commandInput.value.trim();
                if (cmd) {
                    runCommand(cmd);
                    commandInput.value = '';
                }
            }
        });
        
        function clearTerminal() {
            terminal.innerHTML = '';
        }
        
        // Initial message
        addToTerminal('DroidNet Emergency Console Ready', 'success');
        addToTerminal(
            'This console has root access. Use with extreme caution!', 
            'error'
        );
        addToTerminal('Common commands available as buttons above.', 'output');
    </script>
</body>
</html>"""

        self.send_response(200)
        self.send_header("Content-Type", "text/html")
        self.end_headers()
        self.wfile.write(console_html.encode())


# Device Management Functions (now imported from handlers.device_handlers)
# System Status Functions (now imported from handlers.system_handlers)
# Firmware Functions (now imported from handlers.firmware_handlers)

# UI Configuration Functions
UI_CONFIG_FILE = str(CONFIG_DIR / "ui-config.json")

DEFAULT_UI_CONFIG = {
    "tabs": {
        "order": [
            "dashboard",
            "devices",
            "flash",
            "serial",
            "wifi",
            "victron",
            "wcb",
            "comlink",
            "display",
            "maestro",
        ],
        "visibility": {
            "dashboard": True,
            "devices": True,
            "flash": True,
            "serial": True,
            "wifi": True,
            "victron": True,
            "wcb": True,
            "comlink": True,
            "display": True,
            "maestro": True,
        },
    },
    "version": 1,
}


def get_ui_config() -> Dict[str, Any]:
    """Get UI configuration (tab order, visibility, etc.)"""
    try:
        if os.path.exists(UI_CONFIG_FILE):
            with open(UI_CONFIG_FILE, "r") as f:
                config = json.load(f)
                # Merge with defaults to ensure all keys exist
                merged = DEFAULT_UI_CONFIG.copy()
                merged.update(config)
                return {"success": True, "config": merged}
        else:
            return {"success": True, "config": DEFAULT_UI_CONFIG}
    except Exception as e:
        logger.error(f"Error reading UI config: {e}", exc_info=True)
        return {"success": False, "error": str(e), "config": DEFAULT_UI_CONFIG}


def save_ui_config(config):
    """Save UI configuration"""
    try:
        # Ensure directory exists
        config_dir = os.path.dirname(UI_CONFIG_FILE)
        if not os.path.exists(config_dir):
            os.makedirs(config_dir, mode=0o755)

        # Validate config structure
        if "tabs" not in config:
            return {"success": False, "error": "Invalid config: missing 'tabs' key"}

        # Save config
        with open(UI_CONFIG_FILE, "w") as f:
            json.dump(config, f, indent=2)

        logger.info("UI configuration saved")
        return {"success": True, "message": "Configuration saved"}
    except Exception as e:
        logger.error(f"Error saving UI config: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def get_system_logs():
    """Get comprehensive system logs for debugging"""
    logs = {}

    try:
        # DroidNet service logs
        droidnet_services = [
            "droidnet-web",
            "droidnet-virtualhere",
            "droidnet-network-controller",  # Main network management service
            "droidnet-controller",  # PS3 controller service
            "droidnet-comlink",  # Comlink integration service
            "droidnet-boot-diagnostic",
            "droidnet-monitor",
            "droidnet-firstboot",  # Initial setup service
            "droidnet-rfkill-unblock",  # WiFi hardware unblock
            "hostapd",
            "dnsmasq",
            "avahi-daemon",
        ]

        for service in droidnet_services:
            try:
                result = subprocess.run(
                    [
                        "journalctl",
                        "-u",
                        service,
                        "--no-pager",
                        "-n",
                        "50",
                        "--output=short-iso",
                    ],
                    capture_output=True,
                    text=True,
                    timeout=10,
                )
                if result.returncode == 0:
                    logs[f"{service}-journal"] = {
                        "content": result.stdout
                        if result.stdout.strip()
                        else "-- No entries --",
                        "status": "success",
                    }
                else:
                    # Check if service doesn't exist
                    if (
                        "not found" in result.stderr.lower()
                        or "no such" in result.stderr.lower()
                    ):
                        logs[f"{service}-journal"] = {
                            "content": "Service not installed",
                            "status": "warning",
                        }
                    else:
                        logs[f"{service}-journal"] = {
                            "content": f"Error: {result.stderr}",
                            "status": "error",
                        }
            except subprocess.TimeoutExpired:
                logs[f"{service}-journal"] = {
                    "content": "Log fetch timed out",
                    "status": "timeout",
                }
            except Exception as e:
                logs[f"{service}-journal"] = {
                    "content": f"Error fetching logs: {str(e)}",
                    "status": "error",
                }

        # System logs
        system_logs = {
            "dmesg": [
                "sh",
                "-c",
                "dmesg -T | tail -n 50",
            ],  # Show last 50 lines with timestamps
            "messages": [
                "journalctl",
                "--no-pager",
                "-n",
                "50",
                "-p",
                "info",
            ],  # Use journalctl instead of syslog
            "kernel": [
                "journalctl",
                "-k",
                "--no-pager",
                "-n",
                "30",
            ],  # Use journalctl for kernel logs
            "boot.log": ["journalctl", "-b", "--no-pager", "-n", "30"],
        }

        for log_name, cmd in system_logs.items():
            try:
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
                logs[log_name] = {
                    "content": result.stdout
                    if result.returncode == 0
                    else f"Error: {result.stderr}",
                    "status": "success" if result.returncode == 0 else "error",
                }
            except subprocess.TimeoutExpired:
                logs[log_name] = {"content": "Log fetch timed out", "status": "timeout"}
            except Exception as e:
                logs[log_name] = {"content": f"Error: {str(e)}", "status": "error"}

        # Network status
        try:
            result = subprocess.run(
                ["ip", "addr", "show"], capture_output=True, text=True, timeout=5
            )
            logs["network-interfaces"] = {
                "content": result.stdout,
                "status": "success" if result.returncode == 0 else "error",
            }
        except Exception as e:
            logs["network-interfaces"] = {
                "content": f"Error: {str(e)}",
                "status": "error",
            }

        # WiFi status details
        try:
            result = subprocess.run(
                ["iwconfig"], capture_output=True, text=True, timeout=5
            )
            logs["wifi-config"] = {
                "content": result.stdout,
                "status": "success" if result.returncode == 0 else "error",
            }
        except Exception as e:
            logs["wifi-config"] = {"content": f"Error: {str(e)}", "status": "error"}

        # DroidNet specific log files
        log_files = {
            "flash-log": str(LOG_DIR / "flash.log"),  # Firmware flash operations
            "web-log": str(LOG_DIR / "web.log"),  # Threading & request logs
            "network-controller-log": str(LOG_DIR / "network-controller.log"),
            "mode-switch-log": str(LOG_DIR / "mode-switch.log"),
            "wifi-setup-log": str(LOG_DIR / "wifi-setup.log"),
            "hostname-log": "/var/log/droidnet-hostname.log",
            "hostapd-log": "/var/log/hostapd.log",
            "comlink-log": str(LOG_DIR / "comlink.log"),
            "controller-pairing-log": str(LOG_DIR / "controller-pairing.log"),
            "esptool-install-log": str(LOG_DIR / "esptool-install.log"),
            "firstboot-log": str(LOG_DIR / "firstboot.log"),
            "dnsmasq-log": "/var/log/dnsmasq.log",
            "led-errors-log": str(LOG_DIR / "led-errors.log"),
            "rfkill-race-monitor-log": str(LOG_DIR / "rfkill-race-monitor.log"),
            "monitor-starts-log": str(LOG_DIR / "monitor-starts.log"),
            "recovery-log": str(LOG_DIR / "recovery.log"),
            "hostapd-debug-log": "/var/log/hostapd-debug.log",
        }

        for log_name, log_path in log_files.items():
            try:
                if os.path.exists(log_path):
                    # Get last 100 lines of the log file
                    result = subprocess.run(
                        ["tail", "-n", "100", log_path],
                        capture_output=True,
                        text=True,
                        timeout=5,
                    )
                    logs[log_name] = {
                        "content": result.stdout
                        if result.stdout
                        else "Log file is empty",
                        "status": "success" if result.returncode == 0 else "error",
                    }
                else:
                    logs[log_name] = {
                        "content": f"Log file not found: {log_path}",
                        "status": "warning",
                    }
            except Exception as e:
                logs[log_name] = {
                    "content": f"Error reading log: {str(e)}",
                    "status": "error",
                }

        # Network state files
        try:
            # Current network state
            state_file = str(NETWORK_STATE_FILE)
            if os.path.exists(state_file):
                with open(state_file, "r") as f:
                    state_content = f.read().strip()
                logs["network-state"] = {
                    "content": f"Current state: {state_content}",
                    "status": "success",
                }
            else:
                logs["network-state"] = {
                    "content": "State file not found",
                    "status": "warning",
                }

            # Configured mode
            mode_files = [
                str(DROIDNET_MODE_FILE_BOOT),
                str(DROIDNET_MODE_FILE),
            ]
            mode_content = None
            for mode_file in mode_files:
                if os.path.exists(mode_file):
                    with open(mode_file, "r") as f:
                        mode_content = f.read().strip()
                    break

            if mode_content:
                logs["configured-mode"] = {
                    "content": f"Configured mode: {mode_content}",
                    "status": "success",
                }
            else:
                logs["configured-mode"] = {
                    "content": "No mode file found",
                    "status": "warning",
                }

            # Active NetworkManager connections
            try:
                # Check if NetworkManager is active first
                nm_check = subprocess.run(
                    ["systemctl", "is-active", "NetworkManager"],
                    capture_output=True,
                    text=True,
                    timeout=2,
                )

                if nm_check.returncode == 0 and nm_check.stdout.strip() == "active":
                    # Only run nmcli if NetworkManager is active
                    result = subprocess.run(
                        ["nmcli", "con", "show", "--active"],
                        capture_output=True,
                        text=True,
                        timeout=5,
                    )
                    logs["active-connections"] = {
                        "content": result.stdout
                        if result.stdout
                        else "No active connections",
                        "status": "success" if result.returncode == 0 else "error",
                    }
                else:
                    logs["active-connections"] = {
                        "content": "NetworkManager not available in AP mode",
                        "status": "info",
                    }
            except subprocess.TimeoutExpired:
                logs["active-connections"] = {
                    "content": "Command timed out",
                    "status": "timeout",
                }
            except Exception as e:
                logs["active-connections"] = {
                    "content": f"Error: {str(e)}",
                    "status": "error",
                }
        except Exception as e:
            logs["network-state-info"] = {
                "content": f"Error: {str(e)}",
                "status": "error",
            }

        # Victron monitoring data (for diagnostic exports)
        try:
            from handlers.victron_handlers import (
                get_victron_status,
                get_victron_latest_telemetry,
                get_victron_config,
                VICTRON_MODULES_AVAILABLE,
            )

            if VICTRON_MODULES_AVAILABLE:
                # Get Victron status
                try:
                    status_result = get_victron_status()
                    if status_result.get("success"):
                        status = status_result.get("status", {})
                        status_text = (
                            f"Monitoring: {'Active' if status.get('is_monitoring') else 'Inactive'}\n"
                            f"Device Connected: {status.get('device_connected', False)}\n"
                            f"Last Update: {status.get('last_update', 'Never')}\n"
                            f"Samples Collected: {status.get('samples_collected', 0)}\n"
                            f"Connection State: {status.get('connection_state', 'unknown')}"
                        )
                        logs["victron-status"] = {
                            "content": status_text,
                            "status": "success",
                        }
                    else:
                        logs["victron-status"] = {
                            "content": f"Status unavailable: {status_result.get('error', 'Unknown error')}",
                            "status": "warning",
                        }
                except Exception as e:
                    logs["victron-status"] = {
                        "content": f"Error getting status: {str(e)}",
                        "status": "error",
                    }

                # Get latest telemetry
                try:
                    telemetry_result = get_victron_latest_telemetry()
                    if telemetry_result.get("success") and telemetry_result.get(
                        "telemetry"
                    ):
                        t = telemetry_result["telemetry"]
                        telemetry_text = (
                            f"Voltage: {t.get('voltage', 'N/A')} V\n"
                            f"Current: {t.get('current', 'N/A')} A\n"
                            f"Power: {t.get('power', 'N/A')} W\n"
                            f"State of Charge: {t.get('soc', 'N/A')}%\n"
                            f"Consumed Ah: {t.get('consumed_ah', 'N/A')} Ah\n"
                            f"Time Remaining: {t.get('time_remaining', 'N/A')} min\n"
                            f"Temperature: {t.get('temperature', 'N/A')} C\n"
                            f"RSSI: {t.get('rssi', 'N/A')} dBm\n"
                            f"Timestamp: {t.get('timestamp', 'N/A')}"
                        )
                        if t.get("alarms"):
                            telemetry_text += f"\nAlarms: {', '.join(t['alarms'])}"
                        logs["victron-telemetry"] = {
                            "content": telemetry_text,
                            "status": "success",
                        }
                    else:
                        logs["victron-telemetry"] = {
                            "content": "No telemetry data available",
                            "status": "info",
                        }
                except Exception as e:
                    logs["victron-telemetry"] = {
                        "content": f"Error getting telemetry: {str(e)}",
                        "status": "error",
                    }

                # Get config (without sensitive encryption key)
                try:
                    config_result = get_victron_config()
                    if config_result.get("success"):
                        config = config_result.get("config", {})
                        device = config.get("device", {})
                        config_text = (
                            f"Device Name: {device.get('name', 'Not configured')}\n"
                            f"MAC Address: {device.get('mac', 'Not configured')}\n"
                            f"Enabled: {device.get('enabled', False)}\n"
                            f"Auto-start: {config.get('auto_start', False)}\n"
                            f"History Retention: {config.get('history_retention_seconds', 3600)} seconds"
                        )
                        logs["victron-config"] = {
                            "content": config_text,
                            "status": "success",
                        }
                    else:
                        logs["victron-config"] = {
                            "content": "No Victron device configured",
                            "status": "info",
                        }
                except Exception as e:
                    logs["victron-config"] = {
                        "content": f"Error getting config: {str(e)}",
                        "status": "error",
                    }
            else:
                logs["victron-status"] = {
                    "content": "Victron modules not available (victron-ble not installed)",
                    "status": "warning",
                }
        except Exception as e:
            logs["victron-info"] = {
                "content": f"Victron data unavailable: {str(e)}",
                "status": "warning",
            }

        return {
            "logs": logs,
            "timestamp": subprocess.run(
                ["date", "+%Y-%m-%d %H:%M:%S"], capture_output=True, text=True
            ).stdout.strip(),
        }

    except Exception as e:
        return {"error": f"Failed to get logs: {str(e)}"}


# Device Name Management Functions
def get_device_name():
    """Get current device hostname and configuration"""
    try:
        # Get current hostname
        hostname = subprocess.run(
            ["hostname"], capture_output=True, text=True
        ).stdout.strip()

        # Check if it's user-configured
        user_configured = False
        config_file = "/opt/droidnet/config/device-name.conf"

        if os.path.exists(config_file):
            try:
                with open(config_file, "r") as f:
                    saved_name = f.read().strip()
                    if saved_name:
                        user_configured = True
            except (OSError, IOError):
                pass

        return {
            "hostname": hostname,
            "user_configured": user_configured,
            "success": True,
        }
    except Exception as e:
        return {"success": False, "error": str(e)}


def set_device_name(name):
    """Set custom device hostname"""
    try:
        # Validate name
        if name:
            # Allow letters, numbers, and hyphens only
            if not re.match(r"^[a-zA-Z0-9-]+$", name):
                return {
                    "success": False,
                    "error": "Invalid name. Use only letters, numbers, and hyphens.",
                }

            if len(name) > 32:
                return {
                    "success": False,
                    "error": "Name too long. Maximum 32 characters.",
                }

        # Save user preference
        config_dir = "/opt/droidnet/config"
        os.makedirs(config_dir, exist_ok=True)

        config_file = os.path.join(config_dir, "device-name.conf")

        if name:
            # Save custom name
            with open(config_file, "w") as f:
                f.write(name)
        else:
            # Remove custom name to use automatic
            if os.path.exists(config_file):
                os.unlink(config_file)
            # Also remove assigned name to get fresh assignment
            assigned_file = os.path.join(config_dir, "assigned-name.conf")
            if os.path.exists(assigned_file):
                os.unlink(assigned_file)

        # Apply the new hostname
        result = subprocess.run(
            ["/opt/droidnet/scripts/set-unique-hostname.sh"],
            capture_output=True,
            text=True,
        )

        if result.returncode == 0:
            # Get the new hostname
            new_hostname = subprocess.run(
                ["hostname"], capture_output=True, text=True
            ).stdout.strip()
            return {
                "success": True,
                "hostname": new_hostname,
                "message": (
                    f"Device name updated to {new_hostname}. "
                    f"Changes will take effect in a few seconds. "
                    f"Access via {new_hostname}.local"
                ),
            }
        else:
            return {"success": False, "error": "Failed to update hostname"}

    except Exception as e:
        return {"success": False, "error": str(e)}


# WebSocket Serial Monitor Handler
async def serial_websocket_handler(websocket, path=None):
    """
    Handle WebSocket connections using PortHandler architecture.

    Uses event subscriptions instead of direct serial access, allowing
    multiple clients to monitor the same port simultaneously.
    """
    logger.info("WebSocket connection received")
    sender_task = None  # Initialize for cleanup in finally block
    processor_task = None  # Initialize for cleanup in finally block

    # Handle both old and new websockets library signatures
    if path is None:
        if hasattr(websocket, "path"):
            path = websocket.path
        elif hasattr(websocket, "request"):
            path = (
                websocket.request.path
                if hasattr(websocket.request, "path")
                else "/api/serial/ws"
            )
        else:
            path = "/api/serial/ws"

    # Parse query parameters
    query_string = ""
    if hasattr(websocket, "query_string"):
        query_string = websocket.query_string
    elif "?" in path:
        query_string = path.split("?", 1)[1]

    query = parse_qs(query_string) if query_string else {}

    port = query.get("port", [""])[0] if query else ""
    baud = int(query.get("baud", ["115200"])[0] if query else "115200")
    readonly = query.get("readonly", ["false"])[0].lower() == "true" if query else False

    logger.info(
        f"Serial connection request: port={port}, baud={baud}, readonly={readonly}"
    )

    if not port:
        logger.warning("No port specified, closing connection")
        await websocket.close(code=1002, reason="No port specified")
        return

    handler = None
    running = True
    is_temporary = False  # Track if we created a temporary PortHandler

    try:
        # Check if there's an existing WCB listener (always-on monitoring)
        wcb_listener = serial_port_manager.get_wcb_listener(port)

        if wcb_listener:
            # Tap into existing always-on listener's PortHandler
            handler = serial_port_manager.get_handler(port)
            if not handler:
                await websocket.send(
                    f"Error: WCB listener exists but no handler found for {port}"
                )
                await websocket.close(code=1011, reason="Handler not found")
                return

            logger.info(f"WebSocket tapping into existing WCB listener for {port}")
            is_temporary = False
        else:
            # No always-on listener - create temporary PortHandler for this session
            # This is used by Serial Monitor tab and WCB tab when device not always-on
            logger.info(
                f"Creating temporary PortHandler for {port} (WebSocket session)"
            )

            # Use synchronous wrapper to create handler in event loop thread
            handler = serial_port_manager.get_or_create_handler_sync(
                port, baud, always_on=False
            )
            is_temporary = True

        # Update device baud rate on successful connection
        serial_port_manager.update_device_baud_rate(port, baud)

        # Send connection success message
        mode_str = " (read-only)" if readonly else ""
        connection_type = " (always-on)" if not is_temporary else " (temporary)"
        await websocket.send(
            f"Connected to {port} at {baud} baud{mode_str}{connection_type}"
        )

        # Queue-based sender to guarantee serial transmission
        # This prevents frame interleaving when sending large messages
        send_queue = asyncio.Queue()
        seq_counter = [0]

        async def queue_sender():
            """Dedicated task to send messages serially from queue"""
            send_count = 0
            error_count = 0
            logger.debug(f"[WS-QUEUE] Sender started for {port}")
            try:
                while running:
                    try:
                        msg = await asyncio.wait_for(send_queue.get(), timeout=1.0)
                        await websocket.send(msg)
                        send_count += 1
                        # Log queue depth every 50 messages if queue is backing up
                        if send_count % 50 == 0 and send_queue.qsize() > 10:
                            logger.warning(
                                f"[WS-QUEUE] Backpressure: sent={send_count} "
                                f"queued={send_queue.qsize()}"
                            )
                    except asyncio.TimeoutError:
                        continue  # Check running flag
                    except websockets.exceptions.ConnectionClosed as e:
                        logger.debug(f"[WS-QUEUE] Connection closed: {e}")
                        break
                    except Exception as e:
                        # Don't let individual send errors stop the queue
                        error_count += 1
                        logger.error(f"[WS-QUEUE] Send error #{error_count}: {e}")
                        if error_count > 10:
                            logger.error("[WS-QUEUE] Too many errors, stopping sender")
                            break
            except Exception as e:
                logger.error(f"[WS-QUEUE] Fatal error: {e}")
            finally:
                logger.debug(
                    f"[WS-QUEUE] Sender stopped for {port}: "
                    f"sent={send_count} errors={error_count} remaining={send_queue.qsize()}"
                )

        # Start queue sender task
        sender_task = asyncio.create_task(queue_sender())

        # Subscribe to serial events from PortHandler
        # Use a raw data queue to minimize callback work and prevent serial overflow
        raw_data_queue = asyncio.Queue()

        # Chunking constants for large message reliability
        CHUNK_THRESHOLD = 1000  # Lines >= this get chunked
        CHUNK_SIZE = 800  # Size of each chunk (leaves room for JSON overhead)

        async def on_serial_data(event):
            """Queue raw serial data immediately - minimal processing to prevent overflow"""
            try:
                if running:
                    # Just queue the raw event - processing happens in separate task
                    raw_data_queue.put_nowait(event)
            except Exception as e:
                logger.error(f"Error queueing raw data: {e}")

        async def data_processor():
            """Process raw data and prepare for WebSocket - runs as separate task"""
            try:
                while running:
                    try:
                        event = await asyncio.wait_for(
                            raw_data_queue.get(), timeout=1.0
                        )

                        direction = event.get("direction", "received")
                        line = event["line"]

                        seq_counter[0] += 1
                        current_seq = seq_counter[0]

                        # Calculate hash of complete line for integrity checking
                        line_hash = format(
                            zlib.crc32(line.encode("utf-8")) & 0xFFFFFFFF, "08x"
                        )
                        line_len = len(line)

                        if line_len >= CHUNK_THRESHOLD:
                            # Chunk the message to prevent WebSocket frame corruption
                            chunk_id = f"{current_seq}-{int(time.time() * 1000)}"
                            chunks = [
                                line[i : i + CHUNK_SIZE]
                                for i in range(0, line_len, CHUNK_SIZE)
                            ]
                            total_chunks = len(chunks)

                            for idx, chunk_content in enumerate(chunks):
                                is_final = idx == total_chunks - 1
                                msg = {
                                    "seq": current_seq,
                                    "line": chunk_content,
                                    "direction": direction,
                                    "chunk": {
                                        "id": chunk_id,
                                        "index": idx,
                                        "total": total_chunks,
                                        "final": is_final,
                                    },
                                }
                                # Only include hash/len on final chunk
                                if is_final:
                                    msg["hash"] = line_hash
                                    msg["len"] = line_len

                                send_queue.put_nowait(json.dumps(msg))
                        else:
                            # Regular message - no chunking needed
                            msg = json.dumps(
                                {
                                    "seq": current_seq,
                                    "line": line,
                                    "direction": direction,
                                    "hash": line_hash,
                                    "len": line_len,
                                }
                            )
                            send_queue.put_nowait(msg)

                    except asyncio.TimeoutError:
                        continue  # Check running flag
            except Exception as e:
                logger.error(f"Data processor error: {e}")

        # Start data processor task
        processor_task = asyncio.create_task(data_processor())

        async def on_status_event(event):
            """Forward status events to WebSocket"""
            try:
                if running and event.get("status") in ["reconnecting", "error"]:
                    await websocket.send(
                        f"[STATUS] {event['status']}: {event.get('message', '')}"
                    )
            except Exception:
                pass

        # Subscribe to events
        handler.subscribe("data", on_serial_data)
        handler.subscribe("status", on_status_event)

        # Write handler - forwards WebSocket messages to PortHandler
        async def write_handler():
            nonlocal running
            try:
                async for message in websocket:
                    if not readonly:
                        try:
                            await handler.write(message)
                        except Exception as e:
                            logger.error(f"Write error: {e}")
                            await websocket.send(f"Write error: {str(e)}")
            except websockets.exceptions.ConnectionClosed:
                logger.debug("WebSocket closed during write")
                running = False

        # Heartbeat handler
        async def heartbeat():
            nonlocal running
            while running:
                try:
                    await websocket.ping()
                    await asyncio.sleep(30)
                except Exception:
                    logger.warning("Heartbeat failed")
                    running = False
                    break

        # Run handlers
        if readonly:
            # Read-only: just heartbeat
            await heartbeat()
        else:
            # Read-write: both write and heartbeat
            await asyncio.gather(write_handler(), heartbeat(), return_exceptions=True)

    except Exception as e:
        logger.error(f"Error in WebSocket handler: {e}", exc_info=True)
        try:
            await websocket.send(f"Error: {str(e)}")
        except Exception:
            pass

    finally:
        running = False

        # Cancel processor task
        if processor_task:
            processor_task.cancel()
            try:
                await processor_task
            except asyncio.CancelledError:
                pass

        # Cancel sender task
        if sender_task:
            sender_task.cancel()
            try:
                await sender_task
            except asyncio.CancelledError:
                pass

        # Unsubscribe from events
        if handler:
            try:
                handler.unsubscribe("data", on_serial_data)
                handler.unsubscribe("status", on_status_event)
            except Exception:
                pass

            # If this was a temporary connection, close PortHandler
            # if no subscribers remain
            if is_temporary:
                try:
                    stats = handler.get_stats()
                    subscriber_count = stats.get("subscriber_count", 0)

                    if subscriber_count == 0:
                        logger.info(
                            f"Temporary WebSocket connection closed for {port}, "
                            f"no subscribers remain - closing PortHandler"
                        )
                        serial_port_manager.close_handler_sync(port)
                    else:
                        logger.info(
                            f"Temporary WebSocket closed for {port}, but "
                            f"{subscriber_count} other subscriber(s) remain"
                        )
                except Exception as e:
                    logger.error(f"Error cleaning up temporary handler for {port}: {e}")

        logger.debug("WebSocket handler exiting")


def start_websocket_server():
    """Start WebSocket server for serial communication and Maestro control"""

    async def websocket_router(websocket, path):
        """Route WebSocket connections to appropriate handlers"""
        logger.debug(f"WebSocket connection to path: {path}")

        # Route to appropriate handler based on path
        if path.startswith("/api/maestro/ws"):
            await maestro_websocket_handler(websocket, path)
        else:
            # Default to serial handler for /api/serial/ws and others
            await serial_websocket_handler(websocket, path)

    async def start():
        try:
            # Start the WebSocket server with router
            await websockets.serve(websocket_router, "0.0.0.0", WS_PORT)
            logger.info(f"WebSocket server started on port {WS_PORT}")
            # Keep the server running
            await asyncio.Future()  # Run forever
        except Exception as e:
            logger.error(f"WebSocket server error: {e}", exc_info=True)

    # Create and set new event loop for this thread
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    try:
        loop.run_until_complete(start())
    except KeyboardInterrupt:
        pass
    finally:
        loop.close()


# ========== Phase 2: New API Endpoints ==========


def get_serial_ports_status():
    """
    Get status of all active PortHandler instances.

    Returns dict with port information, statistics, and subscriber counts.
    """
    try:
        handlers = serial_port_manager.get_all_handlers()
        ports_info = []

        for port, handler in handlers.items():
            stats = handler.get_stats()
            device_name = serial_port_manager.get_device_name_for_port(port)

            ports_info.append(
                {
                    "port": port,
                    "device_name": device_name,
                    "baud": handler.baud,
                    "status": "connected" if stats["connected"] else "disconnected",
                    "always_on": handler.always_on,
                    "uptime_seconds": stats["uptime_seconds"],
                    "bytes_sent": stats["bytes_sent"],
                    "bytes_received": stats["bytes_received"],
                    "lines_sent": stats["lines_sent"],
                    "lines_received": stats["lines_received"],
                    "error_count": stats["error_count"],
                    "reconnect_count": stats["reconnect_count"],
                    "last_activity": stats["last_activity"],
                    "last_error": stats["last_error"],
                    "subscriber_count": stats["subscriber_count"],
                }
            )

        return {"success": True, "ports": ports_info}

    except Exception as e:
        logger.error(f"Error getting port status: {e}")
        return {"success": False, "error": str(e)}


def get_serial_health():
    """
    Get overall serial system health.

    Returns health status, error counts, and warnings.
    """
    try:
        handlers = serial_port_manager.get_all_handlers()
        total_errors = 0
        warnings = []
        active_ports = 0
        always_on_count = 0

        for port, handler in handlers.items():
            stats = handler.get_stats()
            total_errors += stats["error_count"]

            if stats["connected"]:
                active_ports += 1

            if handler.always_on:
                always_on_count += 1

            # Check for warnings
            if stats["reconnect_count"] > 3:
                warnings.append(
                    f"{port}: {stats['reconnect_count']} reconnection attempts"
                )

            if stats["error_count"] > 10:
                warnings.append(f"{port}: {stats['error_count']} errors")

        # Determine overall status
        if total_errors > 20:
            status = "error"
        elif total_errors > 0 or len(warnings) > 0:
            status = "warning"
        else:
            status = "ok"

        return {
            "success": True,
            "status": status,
            "active_ports": active_ports,
            "always_on_monitors": always_on_count,
            "total_error_count": total_errors,
            "warnings": warnings,
            "architecture_version": "2.0",
        }

    except Exception as e:
        logger.error(f"Error getting serial health: {e}")
        return {"success": False, "error": str(e)}


# New API Functions for Enhanced Features
def get_device_serial_config():
    """Get device serial port configuration"""
    try:
        return serial_port_manager.device_config
    except Exception as e:
        logger.error(f"Error getting device serial config: {e}")
        return {"devices": {}}


def get_device_names():
    """Get custom device names mapping"""
    try:
        config_file = "/opt/droidnet/config/device-names.json"
        if os.path.exists(config_file):
            with open(config_file, "r") as f:
                names = json.load(f)
                # Migrate old vendor:product format to new unique_id format if needed
                # This allows backward compatibility
                return names
        return {}
    except Exception as e:
        return {"error": str(e)}


def set_device_custom_name(device_id, name):
    """Set custom name for a specific USB device"""
    try:
        config_dir = "/opt/droidnet/config"
        os.makedirs(config_dir, exist_ok=True)

        config_file = os.path.join(config_dir, "device-names.json")

        # Load existing names
        names = {}
        if os.path.exists(config_file):
            with open(config_file, "r") as f:
                names = json.load(f)

        # Update or remove name
        if name:
            names[device_id] = name
        elif device_id in names:
            del names[device_id]

        # Save updated names
        with open(config_file, "w") as f:
            json.dump(names, f, indent=2)

        return {"success": True}
    except Exception as e:
        return {"success": False, "error": str(e)}


def reboot_device():
    """Reboot the device"""
    try:
        logger.warning("Device reboot requested")
        # Schedule reboot in 2 seconds to allow response to be sent
        subprocess.Popen(
            ["sudo", "shutdown", "-r", "+0"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

        return {
            "success": True,
            "message": "Device is rebooting. Please wait 30-60 seconds.",
        }
    except Exception as e:
        return {"success": False, "error": str(e)}


def handle_update_upload(update_file_data, filename):
    """Handle system update file upload"""
    temp_file = None
    job_file = None
    try:
        # Save uploaded file to temporary location
        with tempfile.NamedTemporaryFile(mode="wb", suffix=".zip", delete=False) as tf:
            tf.write(update_file_data)
            temp_file = tf.name

        logger.info(
            f"Update file uploaded: {filename}, size: {len(update_file_data)} bytes"
        )

        # Verify the saved file
        saved_size = os.path.getsize(temp_file)
        logger.info(f"Saved file size: {saved_size} bytes")

        if saved_size != len(update_file_data):
            logger.error(
                f"File size mismatch! Original: {len(update_file_data)}, Saved: {saved_size}"  # noqa: E501
            )

        # Quick ZIP validation
        try:
            with zipfile.ZipFile(temp_file, "r") as zf:
                file_list = zf.namelist()
                logger.info(f"ZIP contains {len(file_list)} files")
                if "manifest.json" in file_list:
                    logger.info("manifest.json found in uploaded ZIP")
                else:
                    logger.error("manifest.json NOT found in uploaded ZIP!")
                    logger.error(f"Files in ZIP: {file_list[:10]}...")
        except Exception as e:
            logger.error(f"Failed to validate ZIP: {e}")

        # Create job file for executor
        job_data = {
            "package_path": temp_file,
            "filename": filename,
            "start_time": time.time(),
        }

        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as jf:
            json.dump(job_data, jf)
            job_file = jf.name

        # Save initial status
        update_status = {
            "status": "processing",
            "filename": filename,
            "start_time": time.time(),
            "progress": "Starting update executor...",
        }

        status_file = str(UPDATE_STATUS_FILE)
        os.makedirs(os.path.dirname(status_file), exist_ok=True)
        with open(status_file, "w") as f:
            json.dump(update_status, f)

        # Spawn update executor as detached process
        executor_path = str(UPDATE_EXECUTOR_SCRIPT)
        cmd = [sys.executable, executor_path, job_file]

        logger.info(f"Spawning update executor: {' '.join(cmd)}")

        # Use proper subprocess flags to detach from parent
        if os.name != "nt":  # Unix/Linux
            # Create new process group and session
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
                start_new_session=True,  # Detach from parent session
                close_fds=True,  # Close all file descriptors
            )
            logger.info(f"Update executor started with PID: {process.pid}")
        else:  # Windows
            process = subprocess.Popen(
                cmd,
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
            )

        # Don't wait for the process - let it run independently
        # The executor will clean up temp files when done

        return {
            "success": True,
            "message": "Update process started",
            "executor_pid": process.pid,
            "status_url": "/api/system/update-status",
        }

    except Exception as e:
        logger.error(f"Update upload error: {e}")
        # Clean up files on error
        if temp_file and os.path.exists(temp_file):
            try:
                os.unlink(temp_file)
            except Exception:
                pass
        if job_file and os.path.exists(job_file):
            try:
                os.unlink(job_file)
            except Exception:
                pass
        return {"success": False, "error": str(e)}


def get_update_status():
    """Get current update status"""
    try:
        status_file = str(UPDATE_STATUS_FILE)
        completion_marker = str(LAST_UPDATE_COMPLETED_FILE)
        current_version = get_current_version()

        # Check if there's an active status file
        if os.path.exists(status_file):
            with open(status_file, "r") as f:
                status = json.load(f)

            # Add duration if in progress
            if status.get("status") == "processing":
                status["duration"] = time.time() - status.get("start_time", 0)

            # Add current version if not present
            if "current_version" not in status:
                status["current_version"] = current_version

            return status

        # Check for completion marker (status file was cleaned up)
        elif os.path.exists(completion_marker):
            try:
                with open(completion_marker, "r") as f:
                    completion_data = json.load(f)

                # Return completed status from marker
                return {
                    "status": "completed",
                    "message": (
                        f"Last update completed successfully to version "
                        f"{completion_data.get('version')}"
                    ),
                    "current_version": current_version,
                    "new_version": completion_data.get("version"),
                    "completed_at": completion_data.get("timestamp"),
                    "from_marker": True,
                }
            except Exception:
                pass

        # No update in progress or completed
        return {
            "status": "idle",
            "message": "No update in progress",
            "current_version": current_version,
        }

    except Exception as e:
        logger.error(f"Error getting update status: {e}")
        return {"status": "error", "error": str(e)}


# ============================================================================
# GitHub Update API
# ============================================================================

# Configuration paths for GitHub updates
GITHUB_UPDATE_CONFIG_FILE = CONFIG_DIR / "update-config.json"
GITHUB_UPDATE_AVAILABLE_FILE = RUNTIME_DIR / "update-available.json"

DEFAULT_GITHUB_UPDATE_CONFIG = {
    "auto_check_enabled": True,
    "check_interval_hours": 24,
    "releases_url": "https://raw.githubusercontent.com/travisccook/DroidNetSignalBooster-releases/main/releases.json",
    "last_check_timestamp": 0,
    "dismissed_version": None,
}


def get_github_update_available():
    """Get current GitHub update availability status."""
    try:
        current_version = get_current_version()

        if GITHUB_UPDATE_AVAILABLE_FILE.exists():
            with open(GITHUB_UPDATE_AVAILABLE_FILE, "r") as f:
                info = json.load(f)
                # Ensure current version is included
                info["current_version"] = current_version
                return info

        return {
            "available": False,
            "current_version": current_version,
            "message": "No update information available",
        }
    except Exception as e:
        logger.error(f"Error getting GitHub update available: {e}")
        return {"available": False, "error": str(e)}


def get_github_update_config():
    """Get GitHub update checker configuration."""
    try:
        config = DEFAULT_GITHUB_UPDATE_CONFIG.copy()

        if GITHUB_UPDATE_CONFIG_FILE.exists():
            with open(GITHUB_UPDATE_CONFIG_FILE, "r") as f:
                saved_config = json.load(f)
                config.update(saved_config)

        return config
    except Exception as e:
        logger.error(f"Error getting GitHub update config: {e}")
        return {"error": str(e)}


def get_discovery_status():
    """
    Get the status of the droidnet.local discovery service.
    Returns information about whether this device is the current owner.
    """
    try:
        # Get our hostname and IP
        hostname = get_cached_hostname()
        own_ip = None

        try:
            result = subprocess.run(
                ["ip", "-4", "addr", "show", "wlan0"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            for line in result.stdout.split("\n"):
                if "inet " in line:
                    own_ip = line.split()[1].split("/")[0]
                    break
        except Exception as e:
            logger.debug(f"Error getting own IP: {e}")

        # Check if droidnet.local resolves and to what IP
        resolved_ip = None
        try:
            result = subprocess.run(
                ["avahi-resolve", "-n", "-4", "droidnet.local"],
                capture_output=True,
                text=True,
                timeout=3,
            )
            if result.returncode == 0 and result.stdout.strip():
                parts = result.stdout.strip().split()
                if len(parts) >= 2:
                    resolved_ip = parts[-1]
        except Exception as e:
            logger.debug(f"Error resolving droidnet.local: {e}")

        # Check if discovery service is running
        service_active = False
        try:
            result = subprocess.run(
                ["systemctl", "is-active", "droidnet-discovery"],
                capture_output=True,
                text=True,
            )
            service_active = result.stdout.strip() == "active"
        except Exception as e:
            logger.debug(f"Error checking discovery service status: {e}")

        # Determine ownership
        is_owner = resolved_ip is not None and resolved_ip == own_ip
        is_canonical = hostname.lower() == DISCOVERY_HOSTNAME

        return {
            "success": True,
            "hostname": hostname,
            "own_ip": own_ip,
            "discovery_hostname": f"{DISCOVERY_HOSTNAME}.local",
            "resolved_ip": resolved_ip,
            "is_owner": is_owner,
            "is_canonical": is_canonical,
            "service_active": service_active,
            "message": (
                "This device is the canonical droidnet.local"
                if is_canonical
                else (
                    "This device is currently serving droidnet.local"
                    if is_owner
                    else (
                        f"droidnet.local is served by {resolved_ip}"
                        if resolved_ip
                        else "droidnet.local is not available on the network"
                    )
                )
            ),
        }
    except Exception as e:
        logger.error(f"Error getting discovery status: {e}")
        return {"success": False, "error": str(e)}


def save_github_update_config(config_data):
    """Save GitHub update checker configuration."""
    try:
        # Load existing config
        existing = {}
        if GITHUB_UPDATE_CONFIG_FILE.exists():
            with open(GITHUB_UPDATE_CONFIG_FILE, "r") as f:
                existing = json.load(f)

        # Update with new values (whitelist allowed fields)
        allowed_fields = ["auto_check_enabled", "check_interval_hours"]
        for field in allowed_fields:
            if field in config_data:
                existing[field] = config_data[field]

        # Save atomically
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        temp_file = GITHUB_UPDATE_CONFIG_FILE.with_suffix(".tmp")
        with open(temp_file, "w") as f:
            json.dump(existing, f, indent=2)
        temp_file.replace(GITHUB_UPDATE_CONFIG_FILE)

        return {"success": True, "message": "Update settings saved"}
    except Exception as e:
        logger.error(f"Error saving GitHub update config: {e}")
        return {"success": False, "error": str(e)}


def check_github_updates():
    """Trigger immediate update check via update_checker module."""
    try:
        # Import here to avoid circular imports
        from scripts.update_checker import UpdateChecker

        checker = UpdateChecker()
        result = checker.check_for_updates(force=True)

        if result:
            return {
                "success": True,
                "update_available": True,
                **result,
            }
        else:
            return {
                "success": True,
                "update_available": False,
                "current_version": get_current_version(),
                "message": "Already on latest version",
            }
    except Exception as e:
        logger.error(f"Error checking for GitHub updates: {e}")
        return {"success": False, "error": str(e)}


def dismiss_github_update(version):
    """Dismiss notification for a specific version."""
    try:
        if not version:
            return {"success": False, "error": "Version required"}

        # Update config to dismiss this version
        config = {}
        if GITHUB_UPDATE_CONFIG_FILE.exists():
            with open(GITHUB_UPDATE_CONFIG_FILE, "r") as f:
                config = json.load(f)

        config["dismissed_version"] = version

        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        temp_file = GITHUB_UPDATE_CONFIG_FILE.with_suffix(".tmp")
        with open(temp_file, "w") as f:
            json.dump(config, f, indent=2)
        temp_file.replace(GITHUB_UPDATE_CONFIG_FILE)

        # Clear update available notification
        if GITHUB_UPDATE_AVAILABLE_FILE.exists():
            GITHUB_UPDATE_AVAILABLE_FILE.unlink()

        return {"success": True, "message": f"Update {version} dismissed"}
    except Exception as e:
        logger.error(f"Error dismissing GitHub update: {e}")
        return {"success": False, "error": str(e)}


def install_downloaded_update(package_path):
    """Install an already-downloaded update package."""
    try:
        if not package_path:
            return {"success": False, "error": "Package path required"}

        package_path = Path(package_path)
        if not package_path.exists():
            return {"success": False, "error": f"Package not found: {package_path}"}

        # Validate it's a zip file with manifest
        if not zipfile.is_zipfile(package_path):
            return {"success": False, "error": "Invalid package format"}

        with zipfile.ZipFile(package_path, "r") as zf:
            if "manifest.json" not in zf.namelist():
                return {"success": False, "error": "Package missing manifest.json"}

        # Create job file for update executor
        job_file = RUNTIME_DIR / "update-job.json"
        RUNTIME_DIR.mkdir(parents=True, exist_ok=True)

        job_data = {
            "package_path": str(package_path),
            "timestamp": time.time(),
            "source": "github_download",
        }

        with open(job_file, "w") as f:
            json.dump(job_data, f, indent=2)

        # Launch update executor
        executor_path = str(UPDATE_EXECUTOR_SCRIPT)
        process = subprocess.Popen(
            [sys.executable, executor_path],
            start_new_session=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

        logger.info(f"Started update executor (PID: {process.pid}) for {package_path}")

        return {
            "success": True,
            "message": "Update installation started",
            "status_url": "/api/system/update-status",
        }
    except Exception as e:
        logger.error(f"Error installing downloaded update: {e}")
        return {"success": False, "error": str(e)}


# ============================================================================
# Display Video Playback API
# ============================================================================


def get_display_status():
    """Get Display feature status and capabilities"""
    try:
        # Check if Pi model is supported
        supported = is_display_supported()

        # Get video directory info
        video_dir = "/opt/droidnet/videos"
        os.makedirs(video_dir, exist_ok=True)

        # Get list of videos
        videos = []
        if os.path.exists(video_dir):
            for filename in os.listdir(video_dir):
                if filename.lower().endswith((".mp4", ".mkv", ".avi", ".mov", ".webm")):
                    filepath = os.path.join(video_dir, filename)
                    stat = os.stat(filepath)
                    videos.append(
                        {
                            "name": filename,
                            "size": stat.st_size,
                            "modified": stat.st_mtime,
                        }
                    )

        videos.sort(key=lambda x: x["modified"], reverse=True)

        # Check if video player is available
        # video-player.sh uses ffmpeg to output directly to framebuffer
        ffmpeg_available = (
            subprocess.run(["which", "ffmpeg"], capture_output=True).returncode == 0
        )
        mpv_available = (
            subprocess.run(["which", "mpv"], capture_output=True).returncode == 0
        )
        omxplayer_available = (
            subprocess.run(["which", "omxplayer"], capture_output=True).returncode == 0
        )

        # Check HDMI status
        hdmi_power = None
        try:
            result = subprocess.run(
                ["vcgencmd", "display_power"], capture_output=True, text=True
            )
            if result.returncode == 0:
                # Output is "display_power=0" or "display_power=1"
                hdmi_power = "on" if "=1" in result.stdout else "off"
        except Exception:
            pass

        return {
            "success": True,
            "supported": supported,
            "pi_model": get_pi_model(),
            "videos": videos,
            "video_count": len(videos),
            "video_dir": video_dir,
            "players": {
                "ffmpeg": ffmpeg_available,
                "mpv": mpv_available,
                "omxplayer": omxplayer_available,
                "any": ffmpeg_available or mpv_available or omxplayer_available,
            },
            "hdmi_power": hdmi_power,
        }

    except Exception as e:
        logger.error(f"Error getting display status: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def is_display_supported():
    """Check if current Pi model supports Display feature"""
    model = get_pi_model()
    return model in ["pi_zero_2", "pi_3", "pi_4"]


def play_display_video(video_name):
    """Play a video on the display (or resume if paused)"""
    try:
        # Check if supported
        if not is_display_supported():
            return {
                "success": False,
                "error": (
                    "Display feature not supported on this Pi model "
                    "(requires Pi Zero 2W, Pi 3, or Pi 4)"
                ),
            }

        # Check if a video is paused - if so, resume it
        control_script = "/opt/droidnet/scripts/video-control.sh"
        if os.path.exists(control_script):
            result = subprocess.run(
                [control_script, "status"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            try:
                status = json.loads(result.stdout)
                if status.get("playing") and status.get("paused"):
                    # Resume paused video
                    logger.info("Resuming paused video")
                    return resume_display_video()
            except (json.JSONDecodeError, subprocess.TimeoutExpired):
                pass

        # Stop any currently playing video first
        logger.info("Stopping any currently playing video")
        stop_display_video()

        # Small delay to ensure cleanup
        time.sleep(0.5)

        # Check if video exists
        video_dir = "/opt/droidnet/videos"
        video_path = os.path.join(video_dir, video_name)

        # Try with common extensions if no extension provided
        if not os.path.exists(video_path):
            for ext in [".mp4", ".mkv", ".avi", ".mov", ".webm"]:
                test_path = os.path.join(video_dir, video_name + ext)
                if os.path.exists(test_path):
                    video_path = test_path
                    video_name = video_name + ext
                    break

        if not os.path.exists(video_path):
            return {"success": False, "error": f"Video not found: {video_name}"}

        # Run video player script in background
        script_path = "/opt/droidnet/scripts/video-player.sh"
        if not os.path.exists(script_path):
            return {
                "success": False,
                "error": "Video player script not found",
            }

        # Start video playback in background
        logger.info(f"Starting video playback: {video_name}")
        subprocess.Popen(
            [script_path, video_name],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

        return {
            "success": True,
            "message": f"Playing video: {video_name}",
            "video": video_name,
        }

    except Exception as e:
        logger.error(f"Error playing video: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def pause_display_video():
    """Pause the currently playing video"""
    try:
        # Check if supported
        if not is_display_supported():
            return {
                "success": False,
                "error": "Display feature not supported on this Pi model",
            }

        # Run video control script
        script_path = "/opt/droidnet/scripts/video-control.sh"
        if not os.path.exists(script_path):
            return {
                "success": False,
                "error": "Video control script not found",
            }

        result = subprocess.run(
            [script_path, "pause"],
            capture_output=True,
            text=True,
            timeout=5,
        )

        # Parse JSON output
        try:
            output = json.loads(result.stdout)
            return output
        except json.JSONDecodeError:
            return {"success": False, "error": "Invalid response from video control"}

    except Exception as e:
        logger.error(f"Error pausing video: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def resume_display_video():
    """Resume the paused video"""
    try:
        # Check if supported
        if not is_display_supported():
            return {
                "success": False,
                "error": "Display feature not supported on this Pi model",
            }

        # Run video control script
        script_path = "/opt/droidnet/scripts/video-control.sh"
        if not os.path.exists(script_path):
            return {
                "success": False,
                "error": "Video control script not found",
            }

        result = subprocess.run(
            [script_path, "resume"],
            capture_output=True,
            text=True,
            timeout=5,
        )

        # Parse JSON output
        try:
            output = json.loads(result.stdout)
            return output
        except json.JSONDecodeError:
            return {"success": False, "error": "Invalid response from video control"}

    except Exception as e:
        logger.error(f"Error resuming video: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def stop_display_video():
    """Stop the currently playing video and turn off display"""
    try:
        # Check if supported
        if not is_display_supported():
            return {
                "success": False,
                "error": "Display feature not supported on this Pi model",
            }

        # Kill all video player processes forcefully to ensure cleanup
        logger.info("Killing all video player processes")
        try:
            subprocess.run(["pkill", "-9", "ffmpeg"], timeout=5, capture_output=True)
            subprocess.run(["pkill", "-9", "mpv"], timeout=5, capture_output=True)
            subprocess.run(["pkill", "-9", "omxplayer"], timeout=5, capture_output=True)
        except subprocess.TimeoutExpired:
            pass

        # Clear the framebuffer to remove last frame
        # 720x576x4 bytes (BGRA) = 1,658,880 bytes = ~1.6MB, use 2MB to be safe
        try:
            logger.info("Clearing framebuffer")
            subprocess.run(
                ["dd", "if=/dev/zero", "of=/dev/fb0", "bs=1M", "count=2"],
                timeout=5,
                capture_output=True,
                check=False,
            )
        except Exception as e:
            logger.warning(f"Failed to clear framebuffer: {e}")

        # Turn off HDMI display
        try:
            logger.info("Turning off HDMI display")
            subprocess.run(
                ["vcgencmd", "display_power", "0"],
                timeout=5,
                capture_output=True,
                check=False,
            )
        except Exception as e:
            logger.warning(f"Failed to turn off display: {e}")

        # Clean up PID file
        pid_file = "/var/run/droidnet-video.pid"
        try:
            if os.path.exists(pid_file):
                os.remove(pid_file)
        except Exception:
            pass

        logger.info("Video stopped and display powered off")
        return {"success": True, "message": "Video stopped"}

    except Exception as e:
        logger.error(f"Error stopping video: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def sanitize_video_filename(filename):
    """Sanitize video filename to prevent special character issues"""
    # Get the base name and extension
    name, ext = os.path.splitext(os.path.basename(filename))

    # Remove or replace problematic characters
    # Keep only alphanumeric, hyphens, underscores, and spaces
    name = re.sub(r"[^\w\s-]", "", name)

    # Replace multiple spaces with single space
    name = re.sub(r"\s+", " ", name)

    # Replace spaces with hyphens
    name = name.replace(" ", "-")

    # Remove multiple consecutive hyphens
    name = re.sub(r"-+", "-", name)

    # Remove leading/trailing hyphens
    name = name.strip("-")

    # Ensure name is not empty
    if not name:
        name = "video"

    # Reconstruct filename with sanitized name
    return f"{name}{ext.lower()}"


def upload_display_video(filename, file_data):
    """Upload a video file to the display library"""
    try:
        # Check if supported
        if not is_display_supported():
            return {
                "success": False,
                "error": "Display feature not supported on this Pi model",
            }

        # Validate filename
        if not filename.lower().endswith((".mp4", ".mkv", ".avi", ".mov", ".webm")):
            return {
                "success": False,
                "error": "Invalid file type. Supported: .mp4, .mkv, .avi, .mov, .webm",
            }

        # Sanitize filename to remove special characters and spaces
        original_filename = filename
        filename = sanitize_video_filename(filename)

        if original_filename != filename:
            logger.info(f"Sanitized filename: '{original_filename}' -> '{filename}'")

        # Save video
        video_dir = "/opt/droidnet/videos"
        os.makedirs(video_dir, exist_ok=True)

        video_path = os.path.join(video_dir, filename)

        # Handle duplicate filenames by adding a number suffix
        if os.path.exists(video_path):
            name, ext = os.path.splitext(filename)
            counter = 1
            while os.path.exists(video_path):
                filename = f"{name}-{counter}{ext}"
                video_path = os.path.join(video_dir, filename)
                counter += 1
            logger.info(f"File exists, using new name: {filename}")

        with open(video_path, "wb") as f:
            f.write(file_data)

        file_size = os.path.getsize(video_path)

        logger.info(f"Uploaded video: {filename} ({file_size} bytes)")

        return {
            "success": True,
            "message": f"Video uploaded successfully: {filename}",
            "filename": filename,
            "size": file_size,
        }

    except Exception as e:
        logger.error(f"Error uploading video: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def delete_display_video(video_name):
    """Delete a video from the display library"""
    try:
        video_dir = "/opt/droidnet/videos"
        video_path = os.path.join(video_dir, video_name)

        if not os.path.exists(video_path):
            return {"success": False, "error": f"Video not found: {video_name}"}

        # Check if file is in video directory (security check)
        real_path = os.path.realpath(video_path)
        real_dir = os.path.realpath(video_dir)
        if not real_path.startswith(real_dir):
            return {"success": False, "error": "Invalid file path"}

        os.remove(video_path)
        logger.info(f"Deleted video: {video_name}")

        return {"success": True, "message": f"Video deleted: {video_name}"}

    except Exception as e:
        logger.error(f"Error deleting video: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def get_display_diagnostics():
    """Get diagnostic information for the Display feature"""
    try:
        diagnostics = {
            "timestamp": time.time(),
            "pi_model": get_pi_model(),
            "supported": is_display_supported(),
        }

        # Check video player availability
        for player in ["mpv", "omxplayer", "vcgencmd"]:
            result = subprocess.run(["which", player], capture_output=True, text=True)
            diagnostics[f"{player}_installed"] = result.returncode == 0
            if result.returncode == 0:
                diagnostics[f"{player}_path"] = result.stdout.strip()

        # Check HDMI status
        try:
            result = subprocess.run(
                ["vcgencmd", "display_power"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            diagnostics["hdmi_status"] = result.stdout.strip()
            diagnostics["hdmi_available"] = result.returncode == 0
        except Exception as e:
            diagnostics["hdmi_status"] = f"Error: {e}"
            diagnostics["hdmi_available"] = False

        # Check video directory
        video_dir = "/opt/droidnet/videos"
        diagnostics["video_dir"] = video_dir
        diagnostics["video_dir_exists"] = os.path.exists(video_dir)
        diagnostics["video_dir_writable"] = (
            os.access(video_dir, os.W_OK) if os.path.exists(video_dir) else False
        )

        # Check disk space
        if os.path.exists(video_dir):
            stat = os.statvfs(video_dir)
            free_space = stat.f_bavail * stat.f_frsize
            diagnostics["disk_space_free_mb"] = free_space / (1024 * 1024)

        # Check video player script
        script_path = "/opt/droidnet/scripts/video-player.sh"
        diagnostics["video_player_script_exists"] = os.path.exists(script_path)
        diagnostics["video_player_script_executable"] = (
            os.access(script_path, os.X_OK) if os.path.exists(script_path) else False
        )

        # Check recent logs
        log_file = "/var/log/droidnet/video-player.log"
        if os.path.exists(log_file):
            try:
                with open(log_file, "r") as f:
                    lines = f.readlines()
                    diagnostics["recent_log_entries"] = lines[-10:]
            except Exception:
                diagnostics["recent_log_entries"] = []

        return {"success": True, "diagnostics": diagnostics}

    except Exception as e:
        logger.error(f"Error getting display diagnostics: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


# ========== Maestro API Functions ==========


# ========== Maestro Library (Sequences & Scripts Storage) ==========

import uuid
import xml.etree.ElementTree as ET
import threading

MAESTRO_LIBRARY_PATH = "/opt/droidnet/config/maestro-library.json"
MAESTRO_SYNC_STATE_PATH = "/opt/droidnet/config/maestro-sync-state.json"

# Thread locks for file operations
_maestro_library_lock = threading.Lock()
_maestro_sync_state_lock = threading.Lock()


class MaestroLibrary:
    """Manages server-side storage of Maestro sequences and scripts.

    Since Maestro devices are "black boxes" (we can't read what's on them),
    our library becomes the source of truth for sequences and scripts.

    This class is thread-safe for concurrent access from multiple HTTP requests.
    """

    def __init__(self, library_path: str = MAESTRO_LIBRARY_PATH):
        self.library_path = library_path
        self._lock = _maestro_library_lock
        self._ensure_library_exists()

    def _ensure_library_exists(self):
        """Create library file if it doesn't exist."""
        os.makedirs(os.path.dirname(self.library_path), exist_ok=True)
        if not os.path.exists(self.library_path):
            self._save_library({"sequences": {}, "scripts": {}})

    def _load_library(self) -> dict:
        """Load library from disk. Must be called within lock."""
        try:
            with open(self.library_path, "r") as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Error loading Maestro library: {e}")
            return {"sequences": {}, "scripts": {}}

    def _save_library(self, library: dict):
        """Save library to disk atomically. Must be called within lock."""
        try:
            # Write to temp file first for atomic operation
            temp_path = self.library_path + ".tmp"
            with open(temp_path, "w") as f:
                json.dump(library, f, indent=2)
            # Atomic rename (on POSIX systems)
            os.replace(temp_path, self.library_path)
        except Exception as e:
            logger.error(f"Error saving Maestro library: {e}")
            # Clean up temp file if it exists
            try:
                if os.path.exists(temp_path):
                    os.unlink(temp_path)
            except Exception:
                pass
            raise

    # ===== Sequence Operations =====

    def list_sequences(self, device_serial: Optional[str] = None) -> List[dict]:
        """List all sequences, optionally filtered by device."""
        with self._lock:
            library = self._load_library()
            sequences = list(library.get("sequences", {}).values())
        if device_serial:
            sequences = [
                s for s in sequences if s.get("device_serial") == device_serial
            ]
        # Sort by name for consistent ordering (affects subroutine indices)
        return sorted(sequences, key=lambda s: s.get("name", ""))

    def get_sequence(self, sequence_id: str) -> Optional[dict]:
        """Get a single sequence by ID."""
        with self._lock:
            library = self._load_library()
            return library.get("sequences", {}).get(sequence_id)

    def create_sequence(
        self, name: str, device_serial: str, frames: List[dict]
    ) -> dict:
        """Create a new sequence."""
        with self._lock:
            library = self._load_library()
            sequence_id = str(uuid.uuid4())

            sequence = {
                "id": sequence_id,
                "name": name,
                "device_serial": device_serial,
                "frames": frames,
                "created": datetime.now().isoformat(),
                "modified": datetime.now().isoformat(),
            }

            library["sequences"][sequence_id] = sequence
            self._save_library(library)
            return sequence

    def update_sequence(self, sequence_id: str, updates: dict) -> Optional[dict]:
        """Update an existing sequence."""
        with self._lock:
            library = self._load_library()
            if sequence_id not in library.get("sequences", {}):
                return None

            sequence = library["sequences"][sequence_id]
            allowed_fields = ["name", "frames", "device_serial"]
            for field in allowed_fields:
                if field in updates:
                    sequence[field] = updates[field]
            sequence["modified"] = datetime.now().isoformat()

            self._save_library(library)
            return sequence

    def delete_sequence(self, sequence_id: str) -> bool:
        """Delete a sequence."""
        with self._lock:
            library = self._load_library()
            if sequence_id not in library.get("sequences", {}):
                return False

            del library["sequences"][sequence_id]
            self._save_library(library)
            return True

    # ===== Script Operations =====

    def list_scripts(self, device_serial: Optional[str] = None) -> List[dict]:
        """List all scripts, optionally filtered by device."""
        with self._lock:
            library = self._load_library()
            scripts = list(library.get("scripts", {}).values())
        if device_serial:
            scripts = [s for s in scripts if s.get("device_serial") == device_serial]
        return sorted(scripts, key=lambda s: s.get("name", ""))

    def get_script(self, script_id: str) -> Optional[dict]:
        """Get a single script by ID."""
        with self._lock:
            library = self._load_library()
            return library.get("scripts", {}).get(script_id)

    def create_script(self, name: str, device_serial: str, source: str) -> dict:
        """Create a new script."""
        with self._lock:
            library = self._load_library()
            script_id = str(uuid.uuid4())

            script = {
                "id": script_id,
                "name": name,
                "device_serial": device_serial,
                "source": source,
                "created": datetime.now().isoformat(),
                "modified": datetime.now().isoformat(),
            }

            library["scripts"][script_id] = script
            self._save_library(library)
            return script

    def update_script(self, script_id: str, updates: dict) -> Optional[dict]:
        """Update an existing script."""
        with self._lock:
            library = self._load_library()
            if script_id not in library.get("scripts", {}):
                return None

            script = library["scripts"][script_id]
            allowed_fields = ["name", "source", "device_serial"]
            for field in allowed_fields:
                if field in updates:
                    script[field] = updates[field]
            script["modified"] = datetime.now().isoformat()

            self._save_library(library)
            return script

    def delete_script(self, script_id: str) -> bool:
        """Delete a script."""
        with self._lock:
            library = self._load_library()
            if script_id not in library.get("scripts", {}):
                return False

            del library["scripts"][script_id]
            self._save_library(library)
            return True


class MaestroSyncState:
    """Tracks what has been synced to each Maestro device.

    Since we can't read from the device, we track:
    - Last sync timestamp
    - Hash of what was uploaded
    - Subroutine index → sequence name mapping

    This class is thread-safe for concurrent access from multiple HTTP requests.
    """

    def __init__(self, state_path: str = MAESTRO_SYNC_STATE_PATH):
        self.state_path = state_path
        self._lock = _maestro_sync_state_lock
        self._ensure_state_exists()

    def _ensure_state_exists(self):
        """Create state file if it doesn't exist."""
        os.makedirs(os.path.dirname(self.state_path), exist_ok=True)
        if not os.path.exists(self.state_path):
            self._save_state({})

    def _load_state(self) -> dict:
        """Load state from disk. Must be called within lock."""
        try:
            with open(self.state_path, "r") as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Error loading sync state: {e}")
            return {}

    def _save_state(self, state: dict):
        """Save state to disk atomically. Must be called within lock."""
        try:
            temp_path = self.state_path + ".tmp"
            with open(temp_path, "w") as f:
                json.dump(state, f, indent=2)
            os.replace(temp_path, self.state_path)
        except Exception as e:
            logger.error(f"Error saving sync state: {e}")
            try:
                if os.path.exists(temp_path):
                    os.unlink(temp_path)
            except Exception:
                pass
            raise

    def get_device_state(self, device_serial: str) -> Optional[dict]:
        """Get sync state for a device."""
        with self._lock:
            state = self._load_state()
            return state.get(device_serial)

    def update_device_state(
        self,
        device_serial: str,
        script_hash: str,
        subroutine_map: dict,
        sequence_ids: List[str],
    ):
        """Update sync state after uploading to device."""
        with self._lock:
            state = self._load_state()
            state[device_serial] = {
                "last_sync": datetime.now().isoformat(),
                "script_hash": script_hash,
                "subroutine_map": subroutine_map,
                "sequence_ids": sequence_ids,
            }
            self._save_state(state)

    def clear_device_state(self, device_serial: str):
        """Clear sync state for a device (e.g., after external changes)."""
        with self._lock:
            state = self._load_state()
            if device_serial in state:
                del state[device_serial]
                self._save_state(state)


# Initialize library and sync state managers
maestro_library = MaestroLibrary()
maestro_sync_state = MaestroSyncState()


# ===== MCC XML Parsing =====


def parse_mcc_settings(xml_content: str) -> dict:
    """Parse Maestro Control Center XML export file.

    MCC exports contain:
    - Device settings (serial mode, baud rate, timeouts)
    - Channel configurations with names
    - Sequences (frames with positions and durations)
    - Scripts (source code)
    """
    try:
        root = ET.fromstring(xml_content)

        result = {
            "settings": {},
            "channels": [],
            "sequences": [],
            "script": None,
        }

        # Parse device settings
        for setting_name in [
            "NeverSuspend",
            "SerialMode",
            "FixedBaudRate",
            "SerialTimeout",
            "EnableCrc",
            "SerialDeviceNumber",
            "SerialMiniSscOffset",
        ]:
            elem = root.find(setting_name)
            if elem is not None:
                value = elem.text
                # Convert boolean strings
                if value == "true":
                    value = True
                elif value == "false":
                    value = False
                # Convert numeric strings
                elif value and value.isdigit():
                    value = int(value)
                result["settings"][setting_name] = value

        # Parse channels
        channels_elem = root.find("Channels")
        if channels_elem is not None:
            # Get MiniMaestro-specific attributes
            result["settings"]["MiniMaestroServoPeriod"] = int(
                channels_elem.get("MiniMaestroServoPeriod", "80000")
            )
            result["settings"]["ServoMultiplier"] = int(
                channels_elem.get("ServoMultiplier", "1")
            )

            for idx, ch in enumerate(channels_elem.findall("Channel")):
                channel = {
                    "index": idx,
                    "name": ch.get("name", ""),
                    "mode": ch.get("mode", "Servo"),
                    "min": int(ch.get("min", "3968")),
                    "max": int(ch.get("max", "8000")),
                    "homemode": ch.get("homemode", "Off"),
                    "home": int(ch.get("home", "6000")),
                    "speed": int(ch.get("speed", "0")),
                    "acceleration": int(ch.get("acceleration", "0")),
                    "neutral": int(ch.get("neutral", "6000")),
                    "range": int(ch.get("range", "1905")),
                }
                result["channels"].append(channel)

        # Parse sequences
        sequences_elem = root.find("Sequences")
        if sequences_elem is not None:
            for seq in sequences_elem.findall("Sequence"):
                sequence = {
                    "name": seq.get("name", ""),
                    "frames": [],
                }
                for frame in seq.findall("Frame"):
                    positions_text = frame.text or ""
                    positions = [int(p) for p in positions_text.split() if p]
                    sequence["frames"].append(
                        {
                            "name": frame.get("name", ""),
                            "duration": int(frame.get("duration", "500")),
                            "positions": positions,
                        }
                    )
                result["sequences"].append(sequence)

        # Parse script
        script_elem = root.find("Script")
        if script_elem is not None and script_elem.text:
            result["script"] = {
                "source": script_elem.text.strip(),
                "done": script_elem.get("ScriptDone") == "true",
            }

        return result

    except ET.ParseError as e:
        raise ValueError(f"Invalid XML format: {e}")
    except Exception as e:
        raise ValueError(f"Error parsing MCC settings: {e}")


def generate_mcc_xml(
    settings: dict,
    channels: List[dict],
    sequences: List[dict],
    script: Optional[str] = None,
) -> str:
    """Generate MCC-compatible XML export.

    This creates an XML file that can be imported by Maestro Control Center.
    """
    root = ET.Element("UscSettings", version="1")

    # Add comment
    root.insert(
        0,
        ET.Comment(
            "Pololu Maestro servo controller settings file, "
            "http://www.pololu.com/catalog/product/1350"
        ),
    )

    # Add device settings
    for name, value in settings.items():
        if name in ["MiniMaestroServoPeriod", "ServoMultiplier"]:
            continue  # These go in Channels element
        elem = ET.SubElement(root, name)
        if isinstance(value, bool):
            elem.text = "true" if value else "false"
        else:
            elem.text = str(value)

    # Add channels
    channels_elem = ET.SubElement(
        root,
        "Channels",
        MiniMaestroServoPeriod=str(settings.get("MiniMaestroServoPeriod", 80000)),
        ServoMultiplier=str(settings.get("ServoMultiplier", 1)),
    )

    for idx, ch in enumerate(channels):
        # Add channel comment
        channels_elem.append(ET.Comment(f"Channel {idx}"))
        ET.SubElement(
            channels_elem,
            "Channel",
            name=ch.get("name", ""),
            mode=ch.get("mode", "Servo"),
            min=str(ch.get("min", 3968)),
            max=str(ch.get("max", 8000)),
            homemode=ch.get("homemode", "Off"),
            home=str(ch.get("home", 6000)),
            speed=str(ch.get("speed", 0)),
            acceleration=str(ch.get("acceleration", 0)),
            neutral=str(ch.get("neutral", 6000)),
            range=str(ch.get("range", 1905)),
        )

    # Add sequences
    sequences_elem = ET.SubElement(root, "Sequences")
    for seq in sequences:
        seq_elem = ET.SubElement(sequences_elem, "Sequence", name=seq.get("name", ""))
        for frame in seq.get("frames", []):
            positions = frame.get("positions", [])
            frame_elem = ET.SubElement(
                seq_elem,
                "Frame",
                name=frame.get("name", ""),
                duration=str(frame.get("duration", 500)),
            )
            frame_elem.text = " ".join(str(p) for p in positions)

    # Add script
    if script:
        script_elem = ET.SubElement(root, "Script", ScriptDone="true")
        script_elem.text = script

    # Generate XML string
    return ET.tostring(root, encoding="unicode", xml_declaration=False)


# ===== Library API Functions =====


def get_maestro_sequences(device_serial: Optional[str] = None):
    """Get all sequences from the library."""
    try:
        sequences = maestro_library.list_sequences(device_serial)
        return {"success": True, "sequences": sequences}
    except Exception as e:
        logger.error(f"Error getting sequences: {e}")
        return {"success": False, "error": str(e)}


def get_maestro_sequence(sequence_id: str):
    """Get a single sequence by ID."""
    try:
        sequence = maestro_library.get_sequence(sequence_id)
        if sequence is None:
            return {"success": False, "error": "Sequence not found"}
        return {"success": True, "sequence": sequence}
    except Exception as e:
        logger.error(f"Error getting sequence: {e}")
        return {"success": False, "error": str(e)}


def create_maestro_sequence(data: dict):
    """Create a new sequence."""
    try:
        name = data.get("name")
        device_serial = data.get("device_serial")
        frames = data.get("frames", [])

        if not name:
            return {"success": False, "error": "Name is required"}
        if not device_serial:
            return {"success": False, "error": "Device serial is required"}

        sequence = maestro_library.create_sequence(name, device_serial, frames)
        return {"success": True, "sequence": sequence}
    except Exception as e:
        logger.error(f"Error creating sequence: {e}")
        return {"success": False, "error": str(e)}


def update_maestro_sequence(sequence_id: str, data: dict):
    """Update an existing sequence."""
    try:
        sequence = maestro_library.update_sequence(sequence_id, data)
        if sequence is None:
            return {"success": False, "error": "Sequence not found"}
        return {"success": True, "sequence": sequence}
    except Exception as e:
        logger.error(f"Error updating sequence: {e}")
        return {"success": False, "error": str(e)}


def delete_maestro_sequence(sequence_id: str):
    """Delete a sequence."""
    try:
        success = maestro_library.delete_sequence(sequence_id)
        if not success:
            return {"success": False, "error": "Sequence not found"}
        return {"success": True}
    except Exception as e:
        logger.error(f"Error deleting sequence: {e}")
        return {"success": False, "error": str(e)}


def clear_maestro_library(device_serial: Optional[str] = None):
    """Clear all sequences for a device (factory reset)."""
    try:
        if not device_serial:
            return {"success": False, "error": "device_serial required"}

        sequences = maestro_library.list_sequences(device_serial=device_serial)
        deleted_count = 0
        for seq in sequences:
            if maestro_library.delete_sequence(seq["id"]):
                deleted_count += 1

        logger.info(f"Cleared {deleted_count} sequences for device {device_serial}")
        return {"success": True, "deleted": deleted_count}
    except Exception as e:
        logger.error(f"Error clearing library: {e}")
        return {"success": False, "error": str(e)}


def get_maestro_scripts(device_serial: Optional[str] = None):
    """Get all scripts from the library."""
    try:
        scripts = maestro_library.list_scripts(device_serial)
        return {"success": True, "scripts": scripts}
    except Exception as e:
        logger.error(f"Error getting scripts: {e}")
        return {"success": False, "error": str(e)}


def get_maestro_script(script_id: str):
    """Get a single script by ID."""
    try:
        script = maestro_library.get_script(script_id)
        if script is None:
            return {"success": False, "error": "Script not found"}
        return {"success": True, "script": script}
    except Exception as e:
        logger.error(f"Error getting script: {e}")
        return {"success": False, "error": str(e)}


def create_maestro_script(data: dict):
    """Create a new script."""
    try:
        name = data.get("name")
        device_serial = data.get("device_serial")
        source = data.get("source", "")

        if not name:
            return {"success": False, "error": "Name is required"}
        if not device_serial:
            return {"success": False, "error": "Device serial is required"}

        script = maestro_library.create_script(name, device_serial, source)
        return {"success": True, "script": script}
    except Exception as e:
        logger.error(f"Error creating script: {e}")
        return {"success": False, "error": str(e)}


def update_maestro_script(script_id: str, data: dict):
    """Update an existing script."""
    try:
        script = maestro_library.update_script(script_id, data)
        if script is None:
            return {"success": False, "error": "Script not found"}
        return {"success": True, "script": script}
    except Exception as e:
        logger.error(f"Error updating script: {e}")
        return {"success": False, "error": str(e)}


def delete_maestro_script(script_id: str):
    """Delete a script."""
    try:
        success = maestro_library.delete_script(script_id)
        if not success:
            return {"success": False, "error": "Script not found"}
        return {"success": True}
    except Exception as e:
        logger.error(f"Error deleting script: {e}")
        return {"success": False, "error": str(e)}


def get_maestro_sync_state(device_serial: str):
    """Get sync state for a device."""
    try:
        state = maestro_sync_state.get_device_state(device_serial)
        return {"success": True, "state": state}
    except Exception as e:
        logger.error(f"Error getting sync state: {e}")
        return {"success": False, "error": str(e)}


def import_mcc_to_library(xml_content: str, device_serial: str):
    """Import MCC XML export into the library.

    This parses the MCC file and REPLACES all sequences for this device.
    Existing sequences are deleted before importing new ones.
    """
    try:
        parsed = parse_mcc_settings(xml_content)

        imported = {"sequences": 0, "scripts": 0, "channels": 0}

        # Delete ALL existing sequences for this device first
        existing_sequences = maestro_library.list_sequences(device_serial=device_serial)
        for seq in existing_sequences:
            maestro_library.delete_sequence(seq["id"])
        logger.info(
            f"Cleared {len(existing_sequences)} existing sequences for device {device_serial}"
        )

        # Import sequences
        for seq in parsed.get("sequences", []):
            # Convert frames to our format
            frames = []
            for frame in seq.get("frames", []):
                positions = {}
                for idx, pos in enumerate(frame.get("positions", [])):
                    if pos != 0:  # Only store non-zero positions
                        positions[str(idx)] = pos
                frames.append(
                    {
                        "name": frame.get("name", ""),
                        "duration": frame.get("duration", 500),
                        "positions": positions,
                    }
                )

            maestro_library.create_sequence(
                name=seq.get("name", f"Sequence {imported['sequences']}"),
                device_serial=device_serial,
                frames=frames,
            )
            imported["sequences"] += 1

        # Import script if present
        if parsed.get("script") and parsed["script"].get("source"):
            maestro_library.create_script(
                name="Imported Script",
                device_serial=device_serial,
                source=parsed["script"]["source"],
            )
            imported["scripts"] += 1

        imported["channels"] = len(parsed.get("channels", []))

        return {
            "success": True,
            "imported": imported,
            "channels": parsed.get("channels", []),
        }

    except ValueError as e:
        return {"success": False, "error": str(e)}
    except Exception as e:
        logger.error(f"Error importing MCC file: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def export_mcc_from_library(device_serial: str, port: str):
    """Export library data as MCC-compatible XML.

    Combines device settings (read from device) with library sequences/scripts.
    """
    try:
        if maestro_manager is None:
            return {"success": False, "error": "Maestro manager not initialized"}

        device = maestro_manager.get_device(port)
        if device is None:
            return {"success": False, "error": f"Device not found: {port}"}

        # Get device settings
        settings = {
            "NeverSuspend": False,
            "SerialMode": "UART_FIXED_BAUD_RATE",
            "FixedBaudRate": 9600,
            "SerialTimeout": 0,
            "EnableCrc": False,
            "SerialDeviceNumber": 1,
            "SerialMiniSscOffset": 0,
            "MiniMaestroServoPeriod": 80000,
            "ServoMultiplier": 1,
        }

        # Get channel settings from device if available
        channels = []
        if device.configurator:
            try:
                channel_settings = device.configurator.get_all_channel_settings()
                channel_names_result = get_maestro_channel_names(device_serial)
                channel_names = channel_names_result.get("names", {})

                for ch_idx, ch_settings in channel_settings.items():
                    channels.append(
                        {
                            "name": channel_names.get(str(ch_idx), ""),
                            "mode": ch_settings.mode.name
                            if hasattr(ch_settings.mode, "name")
                            else "Servo",
                            "min": ch_settings.minimum,
                            "max": ch_settings.maximum,
                            "homemode": ch_settings.home_mode.name
                            if hasattr(ch_settings.home_mode, "name")
                            else "Off",
                            "home": ch_settings.home_position,
                            "speed": ch_settings.speed,
                            "acceleration": ch_settings.acceleration,
                            "neutral": ch_settings.neutral,
                            "range": ch_settings.range,
                        }
                    )
            except Exception as e:
                logger.warning(f"Could not read channel settings from device: {e}")

        # Fill in missing channels with defaults
        total_channels = device.model_info.get("channels", 18)
        while len(channels) < total_channels:
            channels.append(
                {
                    "name": "",
                    "mode": "Servo",
                    "min": 3968,
                    "max": 8000,
                    "homemode": "Off",
                    "home": 6000,
                    "speed": 0,
                    "acceleration": 0,
                    "neutral": 6000,
                    "range": 1905,
                }
            )

        # Get sequences from library
        sequences = maestro_library.list_sequences(device_serial)

        # Convert sequences to MCC format
        mcc_sequences = []
        for seq in sequences:
            frames = []
            for frame in seq.get("frames", []):
                # Convert positions dict to list
                positions = [0] * total_channels
                for ch_str, pos in frame.get("positions", {}).items():
                    ch_idx = int(ch_str)
                    if 0 <= ch_idx < total_channels:
                        positions[ch_idx] = pos
                frames.append(
                    {
                        "name": frame.get("name", ""),
                        "duration": frame.get("duration", 500),
                        "positions": positions,
                    }
                )
            mcc_sequences.append(
                {
                    "name": seq.get("name", ""),
                    "frames": frames,
                }
            )

        # Get script if any
        scripts = maestro_library.list_scripts(device_serial)
        script_source = scripts[0].get("source") if scripts else None

        # Generate XML
        xml_content = generate_mcc_xml(settings, channels, mcc_sequences, script_source)

        return {"success": True, "xml": xml_content}

    except Exception as e:
        logger.error(f"Error exporting MCC format: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


# ===== Script Compilation and Upload =====


def compile_library_to_script(device_serial: str):
    """
    Generate MCC-style script from library sequences.

    Returns script source and subroutine map.
    """
    if not MAESTRO_COMPILER_AVAILABLE:
        return {"success": False, "error": "Compiler not available"}

    try:
        # Get sequences for this device
        sequences = maestro_library.list_sequences(device_serial)
        if not sequences:
            return {"success": False, "error": "No sequences in library"}

        # Convert to format expected by generator
        gen_sequences = []
        for seq in sequences:
            gen_sequences.append(
                {"name": seq.get("name", "unnamed"), "frames": seq.get("frames", [])}
            )

        # Generate script
        script_source = generate_mcc_style_script(gen_sequences)

        # Create subroutine map
        subroutine_map = {
            str(i): seq.get("name", f"sequence_{i}") for i, seq in enumerate(sequences)
        }

        return {
            "success": True,
            "script": script_source,
            "subroutine_map": subroutine_map,
            "sequence_count": len(sequences),
        }

    except Exception as e:
        logger.error(f"Error generating script: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def compile_and_upload_script(device_serial: str, port: str, script_source: str = None):
    """
    Compile script and upload to device.

    If script_source is None, generates from library sequences.
    """
    if not MAESTRO_COMPILER_AVAILABLE:
        return {"success": False, "error": "Compiler not available"}

    if maestro_manager is None:
        return {"success": False, "error": "Maestro manager not initialized"}

    try:
        device = maestro_manager.get_device(port)
        if device is None:
            return {"success": False, "error": f"Device not found: {port}"}

        # Generate script from library if not provided
        if script_source is None:
            gen_result = compile_library_to_script(device_serial)
            if not gen_result["success"]:
                return gen_result
            script_source = gen_result["script"]
            subroutine_map = gen_result["subroutine_map"]
        else:
            subroutine_map = {}

        # Compile to bytecode
        bytecode, errors, sub_map = compile_script(script_source)

        if errors:
            return {"success": False, "error": "Compilation failed", "errors": errors}

        if not bytecode:
            return {"success": False, "error": "Compilation produced no bytecode"}

        # Update subroutine map from compiler
        if sub_map:
            subroutine_map = {str(k): v for k, v in sub_map.items()}

        # Upload to device
        if hasattr(device, "configurator") and device.configurator:
            # Erase existing script
            device.configurator.erase_script()

            # Write new script
            success = device.configurator.write_script(bytecode)
            if not success:
                return {"success": False, "error": "Failed to write script to device"}
        else:
            return {"success": False, "error": "Device configurator not available"}

        # Calculate script hash for sync tracking
        import hashlib

        script_hash = hashlib.sha256(bytecode).hexdigest()[:16]

        # Update sync state
        sequence_ids = [
            seq["id"] for seq in maestro_library.list_sequences(device_serial)
        ]
        maestro_sync_state.update_device_state(
            device_serial=device_serial,
            script_hash=script_hash,
            subroutine_map=subroutine_map,
            sequence_ids=sequence_ids,
        )

        return {
            "success": True,
            "bytecode_size": len(bytecode),
            "script_hash": script_hash,
            "subroutine_map": subroutine_map,
        }

    except Exception as e:
        logger.error(f"Error compiling/uploading script: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def sync_library_to_device(device_serial: str, port: str):
    """
    Sync library sequences to device.

    This generates an MCC-style script from all sequences,
    compiles it to bytecode, and uploads to the device.
    """
    return compile_and_upload_script(device_serial, port)


def get_maestro_feature_config():
    """Get Maestro feature configuration (enabled/disabled)."""
    try:
        config_path = "/opt/droidnet/config/maestro_feature_config.json"

        # Default configuration
        default_config = {
            "enabled": False,
        }

        if os.path.exists(config_path):
            with open(config_path, "r") as f:
                saved_config = json.load(f)
                default_config.update(saved_config)

        return {"success": True, "config": default_config}
    except Exception as e:
        logger.error(f"Error getting Maestro feature config: {e}")
        return {"success": False, "error": str(e)}


def update_maestro_feature_config(data):
    """Update Maestro feature configuration (enabled/disabled)."""
    try:
        config_path = "/opt/droidnet/config/maestro_feature_config.json"
        os.makedirs(os.path.dirname(config_path), exist_ok=True)

        # Get current config
        current_result = get_maestro_feature_config()
        if not current_result["success"]:
            return current_result

        current_config = current_result["config"]

        # Update with new values
        current_config.update(data)

        # Save config
        with open(config_path, "w") as f:
            json.dump(current_config, f, indent=4)

        return {"success": True, "config": current_config}
    except Exception as e:
        logger.error(f"Error updating Maestro feature config: {e}")
        return {"success": False, "error": str(e)}


def get_maestro_channel_names(serial_number: str):
    """Get channel names for a Maestro device (stored locally, not on device)."""
    try:
        config_path = "/opt/droidnet/config/maestro_channel_names.json"

        if not os.path.exists(config_path):
            return {"success": True, "names": {}}

        with open(config_path, "r") as f:
            all_names = json.load(f)

        # Return names for this specific device
        device_names = all_names.get(serial_number, {})
        return {"success": True, "names": device_names}
    except Exception as e:
        logger.error(f"Error getting channel names for {serial_number}: {e}")
        return {"success": False, "error": str(e)}


def update_maestro_channel_names(serial_number: str, names: dict):
    """Update channel names for a Maestro device (stored locally)."""
    try:
        config_path = "/opt/droidnet/config/maestro_channel_names.json"
        os.makedirs(os.path.dirname(config_path), exist_ok=True)

        # Load existing names
        all_names = {}
        if os.path.exists(config_path):
            with open(config_path, "r") as f:
                all_names = json.load(f)

        # Update names for this device
        if serial_number not in all_names:
            all_names[serial_number] = {}
        all_names[serial_number].update(names)

        # Save
        with open(config_path, "w") as f:
            json.dump(all_names, f, indent=4)

        return {"success": True, "names": all_names[serial_number]}
    except Exception as e:
        logger.error(f"Error updating channel names for {serial_number}: {e}")
        return {"success": False, "error": str(e)}


def get_maestro_devices():
    """Get list of all managed Maestro devices."""
    try:
        if maestro_manager is None:
            return {"success": False, "error": "Maestro manager not initialized"}

        devices = maestro_manager.list_devices()
        return {"success": True, "devices": devices}

    except Exception as e:
        logger.error(f"Error getting Maestro devices: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def get_maestro_device_status(port: str):
    """Get status of a specific Maestro device."""
    try:
        if maestro_manager is None:
            return {"success": False, "error": "Maestro manager not initialized"}

        state = maestro_manager.get_state(port)
        if state is None:
            return {"success": False, "error": f"Device not found: {port}"}

        return {"success": True, "state": state}

    except Exception as e:
        logger.error(
            f"Error getting Maestro device status for {port}: {e}", exc_info=True
        )
        return {"success": False, "error": str(e)}


def get_maestro_servos(port: str):
    """Get all servo positions for a device."""
    try:
        if maestro_manager is None:
            return {"success": False, "error": "Maestro manager not initialized"}

        state = maestro_manager.get_state(port)
        if state is None:
            return {"success": False, "error": f"Device not found: {port}"}

        return {"success": True, "servos": state.get("servos", {})}

    except Exception as e:
        logger.error(f"Error getting Maestro servos for {port}: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def get_maestro_config(port: str):
    """Get device configuration."""
    try:
        if maestro_manager is None:
            return {"success": False, "error": "Maestro manager not initialized"}

        device = maestro_manager.get_device(port)
        if device is None:
            return {"success": False, "error": f"Device not found: {port}"}

        config = {
            "port": device.port,
            "serial_number": device.serial_number,
            "model": device.model_info["name"],
            "channels": device.model_info["channels"],
            "is_mini": device.model_info.get("mini", False),
        }

        # Get channel settings if configurator is available
        if device.configurator:
            try:
                channel_settings = device.configurator.get_all_channel_settings()
                config["channel_settings"] = {
                    ch: {
                        "mode": s.mode.name,
                        "home_mode": s.home_mode.name,
                        "home": s.home_position,
                        "home_us": s.home_position / 4.0,
                        "min": s.minimum,
                        "min_us": s.minimum / 4.0,
                        "max": s.maximum,
                        "max_us": s.maximum / 4.0,
                        "neutral": s.neutral,
                        "neutral_us": s.neutral / 4.0,
                        "range": s.range,
                        "speed": s.speed,
                        "acceleration": s.acceleration,
                    }
                    for ch, s in channel_settings.items()
                }
            except Exception as e:
                logger.warning(f"Could not get channel settings: {e}")

        return {"success": True, "config": config}

    except Exception as e:
        logger.error(f"Error getting Maestro config for {port}: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def get_maestro_channels(port: str):
    """Get all channel settings from device via USB."""
    try:
        if maestro_manager is None:
            return {"success": False, "error": "Maestro manager not initialized"}

        device = maestro_manager.get_device(port)
        if device is None:
            return {"success": False, "error": f"Device not found: {port}"}

        if not device.configurator:
            return {"success": False, "error": "USB configurator not available"}

        channels = {}
        for ch in range(device.model_info["channels"]):
            settings = device.configurator.get_channel_settings(ch)
            if settings:
                channels[ch] = {
                    "mode": settings.mode.name,
                    "home_mode": settings.home_mode.name,
                    "home": settings.home_position,
                    "home_us": settings.home_position / 4.0,
                    "min": settings.minimum,
                    "min_us": settings.minimum / 4.0,
                    "max": settings.maximum,
                    "max_us": settings.maximum / 4.0,
                    "neutral": settings.neutral,
                    "neutral_us": settings.neutral / 4.0,
                    "range": settings.range,
                    "speed": settings.speed,
                    "acceleration": settings.acceleration,
                }

        return {"success": True, "channels": channels}

    except Exception as e:
        logger.error(f"Error getting channel settings for {port}: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def set_maestro_channel_settings(port: str, channel: int, data: dict):
    """Write settings for a single channel via USB."""
    try:
        if maestro_manager is None:
            return {"success": False, "error": "Maestro manager not initialized"}

        device = maestro_manager.get_device(port)
        if device is None:
            return {"success": False, "error": f"Device not found: {port}"}

        if not device.configurator:
            return {"success": False, "error": "USB configurator not available"}

        # Always force a fresh USB connection for write operations
        # USB control transfers can become stale between operations
        logger.info(f"Refreshing USB configurator for {port}")
        device.configurator.disconnect()
        time.sleep(0.1)  # Brief delay for USB to release
        if not device.configurator.connect():
            return {"success": False, "error": "Failed to connect USB configurator"}
        time.sleep(0.1)  # Brief delay for USB to stabilize

        # Build settings object from data
        if not MAESTRO_AVAILABLE:
            return {"success": False, "error": "Maestro configurator not available"}
        # Normalize mode/home_mode to uppercase (MCC uses "Servo", enum uses "SERVO")
        mode_str = data.get("mode", "SERVO").upper()
        home_mode_str = data.get("home_mode", "GOTO").upper()
        settings = ChannelSettings(
            mode=ChannelMode[mode_str],
            home_mode=HomeMode[home_mode_str],
            home_position=int(data.get("home", 6000)),
            minimum=int(data.get("min", 3968)),
            maximum=int(data.get("max", 8000)),
            neutral=int(data.get("neutral", 6000)),
            range=int(data.get("range", 1905)),
            speed=int(data.get("speed", 0)),
            acceleration=int(data.get("acceleration", 0)),
        )

        success = device.configurator.set_channel_settings(channel, settings)
        if not success:
            # Try once more with longer delays
            logger.warning(f"First write attempt failed, retrying for {port}")
            device.configurator.disconnect()
            time.sleep(0.2)
            if device.configurator.connect():
                time.sleep(0.2)
                success = device.configurator.set_channel_settings(channel, settings)
        return {"success": success}

    except Exception as e:
        logger.error(
            f"Error setting channel {channel} settings for {port}: {e}", exc_info=True
        )
        return {"success": False, "error": str(e)}


def maestro_export_config(port: str):
    """Export complete device configuration as JSON."""
    try:
        if maestro_manager is None:
            return {"success": False, "error": "Maestro manager not initialized"}

        device = maestro_manager.get_device(port)
        if device is None:
            return {"success": False, "error": f"Device not found: {port}"}

        if not device.configurator:
            return {"success": False, "error": "USB configurator not available"}

        config = device.configurator.export_settings()
        return {"success": True, "config": config}

    except Exception as e:
        logger.error(f"Error exporting Maestro config for {port}: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def maestro_import_config(port: str, data: dict):
    """Import device configuration from JSON."""
    try:
        if maestro_manager is None:
            return {"success": False, "error": "Maestro manager not initialized"}

        device = maestro_manager.get_device(port)
        if device is None:
            return {"success": False, "error": f"Device not found: {port}"}

        if not device.configurator:
            return {"success": False, "error": "USB configurator not available"}

        # Accept either {config: {...}} or direct config object
        config = data.get("config", data)
        success = device.configurator.import_settings(config)
        return {"success": success}

    except Exception as e:
        logger.error(f"Error importing Maestro config for {port}: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def check_maestro_serial_mode(serial_number: str):
    """
    Check if Maestro serial mode is correctly configured for USB control.

    Args:
        serial_number: Device serial number (e.g., "00489369")

    Returns:
        Dict with mode info, ok status, and message
    """
    try:
        if maestro_manager is None:
            return {"success": False, "error": "Maestro manager not initialized"}

        # Find device by serial number
        device = None
        for port, dev in maestro_manager.devices.items():
            if dev.serial_number == serial_number:
                device = dev
                break

        if device is None:
            # Try to connect directly via USB for devices not yet managed
            if not MAESTRO_AVAILABLE:
                return {"success": False, "error": "Maestro configurator not available"}

            configurator = MaestroConfigurator(serial_number)
            if not configurator.connect():
                return {
                    "success": False,
                    "error": f"Device not found: {serial_number}",
                }

            result = configurator.check_serial_mode()
            configurator.disconnect()
            return {"success": True, **result}

        if not device.configurator:
            return {"success": False, "error": "USB configurator not available"}

        result = device.configurator.check_serial_mode()
        return {"success": True, **result}

    except Exception as e:
        logger.error(
            f"Error checking serial mode for {serial_number}: {e}", exc_info=True
        )
        return {"success": False, "error": str(e)}


def fix_maestro_serial_mode(serial_number: str):
    """
    Fix Maestro serial mode if not USB_DUAL_PORT.

    Writes the correct setting to EEPROM. Device requires power cycle
    for the change to take effect.

    Args:
        serial_number: Device serial number

    Returns:
        Dict with success, changed, needs_power_cycle, and message
    """
    try:
        if maestro_manager is None:
            return {"success": False, "error": "Maestro manager not initialized"}

        # Find device by serial number
        device = None
        for port, dev in maestro_manager.devices.items():
            if dev.serial_number == serial_number:
                device = dev
                break

        if device is None:
            # Try to connect directly via USB
            if not MAESTRO_AVAILABLE:
                return {"success": False, "error": "Maestro configurator not available"}

            configurator = MaestroConfigurator(serial_number)
            if not configurator.connect():
                return {
                    "success": False,
                    "error": f"Device not found: {serial_number}",
                }

            result = configurator.fix_serial_mode()
            configurator.disconnect()
            return result

        if not device.configurator:
            return {"success": False, "error": "USB configurator not available"}

        return device.configurator.fix_serial_mode()

    except Exception as e:
        logger.error(
            f"Error fixing serial mode for {serial_number}: {e}", exc_info=True
        )
        return {"success": False, "error": str(e)}


def set_maestro_target(port: str, channel: int, target: int):
    """Set servo target position."""
    try:
        if maestro_manager is None:
            return {"success": False, "error": "Maestro manager not initialized"}

        result = maestro_manager.set_target(port, channel, target)
        return {"success": result}

    except Exception as e:
        logger.error(
            f"Error setting Maestro target for {port} ch{channel}: {e}", exc_info=True
        )
        return {"success": False, "error": str(e)}


def maestro_go_home(port: str):
    """Send all servos to home position."""
    try:
        if maestro_manager is None:
            return {"success": False, "error": "Maestro manager not initialized"}

        result = maestro_manager.go_home(port)
        return {"success": result}

    except Exception as e:
        logger.error(f"Error sending Maestro home for {port}: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def maestro_run_script(port: str, subroutine: Optional[int] = None):
    """Run or restart script."""
    try:
        if maestro_manager is None:
            return {"success": False, "error": "Maestro manager not initialized"}

        if subroutine is not None:
            result = maestro_manager.run_subroutine(port, subroutine)
        else:
            result = maestro_manager.restart_script(port)

        return {"success": result}

    except Exception as e:
        logger.error(f"Error running Maestro script for {port}: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def maestro_stop_script(port: str):
    """Stop running script."""
    try:
        if maestro_manager is None:
            return {"success": False, "error": "Maestro manager not initialized"}

        result = maestro_manager.stop_script(port)
        return {"success": result}

    except Exception as e:
        logger.error(f"Error stopping Maestro script for {port}: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def maestro_detect_devices():
    """Detect all connected Maestro devices."""
    try:
        if maestro_manager is None:
            return {"success": False, "error": "Maestro manager not initialized"}

        devices = maestro_manager.detect_devices()
        return {"success": True, "devices": devices}

    except Exception as e:
        logger.error(f"Error detecting Maestro devices: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def maestro_add_device(
    port: str, serial_number: Optional[str] = None, start_listener: bool = True
):
    """Add a Maestro device to the manager."""
    try:
        if maestro_manager is None:
            return {"success": False, "error": "Maestro manager not initialized"}

        result = maestro_manager.add_device(port, serial_number, start_listener)

        # Start listener if requested and event loop is available
        if result and start_listener and event_loop_thread:
            device = maestro_manager.get_device(port)
            if device and device.listener:
                # Start listener in async context
                event_loop_thread.run_coroutine(device.listener.start())

        return {"success": result}

    except Exception as e:
        logger.error(f"Error adding Maestro device {port}: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def maestro_remove_device(port: str):
    """Remove a Maestro device from the manager."""
    try:
        if maestro_manager is None:
            return {"success": False, "error": "Maestro manager not initialized"}

        # Stop listener first if it exists
        device = maestro_manager.get_device(port)
        if device and device.listener and event_loop_thread:
            event_loop_thread.run_coroutine(device.listener.stop())

        maestro_manager.remove_device(port)
        return {"success": True}

    except Exception as e:
        logger.error(f"Error removing Maestro device {port}: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


# ========== Maestro WebSocket Handler ==========


async def maestro_websocket_handler(websocket, path):
    """
    WebSocket handler for real-time Maestro servo control.

    Protocol:
    - Client sends: {"cmd": "set_target", "channel": 0, "target": 6000}
    - Server broadcasts: {"type": "position", "channel": 0, "position": 6000}
    """
    logger.info("Maestro WebSocket connection received")

    # Parse query parameters
    parsed = urlparse(path)
    params = parse_qs(parsed.query)
    port = params.get("port", [None])[0]

    if not port:
        await websocket.send(
            json.dumps({"type": "error", "message": "Missing 'port' parameter"})
        )
        return

    # Get Maestro manager
    if maestro_manager is None:
        await websocket.send(
            json.dumps({"type": "error", "message": "Maestro manager not initialized"})
        )
        return

    if not maestro_manager.has_device(port):
        await websocket.send(
            json.dumps({"type": "error", "message": f"No Maestro device on {port}"})
        )
        return

    # Activate listener on-demand
    if maestro_listener_activator:
        if not maestro_listener_activator.on_connect(port):
            await websocket.send(
                json.dumps(
                    {"type": "error", "message": f"Failed to start listener for {port}"}
                )
            )
            return

    # Register for state updates
    async def send_update(data):
        try:
            data["type"] = data.get("type", "update")
            await websocket.send(json.dumps(data))
        except Exception:
            pass

    listener = maestro_manager.get_listener(port)
    if listener:
        listener.register_handler("position", send_update)
        listener.register_handler("error", send_update)
        listener.register_handler("script_status", send_update)

    # Send initial state
    state = maestro_manager.get_state(port)
    await websocket.send(json.dumps({"type": "state", "data": state}))

    try:
        async for message in websocket:
            try:
                data = json.loads(message)
                cmd = data.get("cmd")

                if cmd == "set_target":
                    channel = data["channel"]
                    target = data["target"]
                    maestro_manager.set_target(port, channel, target)

                elif cmd == "set_speed":
                    channel = data["channel"]
                    speed = data["speed"]
                    maestro_manager.set_speed(port, channel, speed)

                elif cmd == "set_acceleration":
                    channel = data["channel"]
                    acceleration = data["acceleration"]
                    maestro_manager.set_acceleration(port, channel, acceleration)

                elif cmd == "go_home":
                    maestro_manager.go_home(port)

                elif cmd == "stop_script":
                    maestro_manager.stop_script(port)

                elif cmd == "run_script":
                    subroutine = data.get("subroutine")
                    if subroutine is not None:
                        maestro_manager.run_subroutine(port, subroutine)
                    else:
                        maestro_manager.restart_script(port)

                elif cmd == "get_state":
                    state = maestro_manager.get_state(port)
                    await websocket.send(json.dumps({"type": "state", "data": state}))

            except json.JSONDecodeError:
                await websocket.send(
                    json.dumps({"type": "error", "message": "Invalid JSON"})
                )
            except KeyError as e:
                await websocket.send(
                    json.dumps({"type": "error", "message": f"Missing field: {e}"})
                )
            except Exception as e:
                logger.error(f"Maestro WS error: {e}")
                await websocket.send(json.dumps({"type": "error", "message": str(e)}))

    finally:
        # Cleanup
        if listener:
            listener.unregister_handler("position", send_update)
            listener.unregister_handler("error", send_update)
            listener.unregister_handler("script_status", send_update)

        # Notify activator of disconnect (may trigger idle timeout)
        if maestro_listener_activator:
            maestro_listener_activator.on_disconnect(port)

        logger.debug("Maestro WebSocket handler exiting")


# ============================================================================
# IMAGE DISPLAY FUNCTIONS
# ============================================================================


def get_image_status():
    """Get status of image display feature including available images"""
    try:
        image_dir = "/opt/droidnet/images"
        images = []

        # Create image directory if it doesn't exist
        if not os.path.exists(image_dir):
            os.makedirs(image_dir, mode=0o755, exist_ok=True)

        # List all image files
        if os.path.exists(image_dir):
            for filename in os.listdir(image_dir):
                file_path = os.path.join(image_dir, filename)
                if os.path.isfile(file_path):
                    # Check if it's a supported image format
                    ext = os.path.splitext(filename)[1].lower()
                    if ext in [".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp"]:
                        stat_info = os.stat(file_path)
                        images.append(
                            {
                                "name": filename,
                                "size": stat_info.st_size,
                                "modified": int(stat_info.st_mtime),
                            }
                        )

        # Sort by modification time (newest first)
        images.sort(key=lambda x: x["modified"], reverse=True)

        # Get current display status
        control_script = "/opt/droidnet/scripts/image-control.sh"
        current_image = None
        display_active = False

        if os.path.exists(control_script):
            try:
                result = subprocess.run(
                    [control_script, "status"],
                    capture_output=True,
                    text=True,
                    timeout=5,
                )
                if result.returncode == 0:
                    status_data = json.loads(result.stdout)
                    if status_data.get("status") == "displaying":
                        current_image = status_data.get("image")
                        display_active = True
            except Exception:
                pass

        # Get HDMI power status
        hdmi_power = "unknown"
        try:
            result = subprocess.run(
                ["vcgencmd", "display_power"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                output = result.stdout.strip()
                if "=1" in output:
                    hdmi_power = "on"
                elif "=0" in output:
                    hdmi_power = "off"
        except Exception:
            pass

        return {
            "success": True,
            "supported": is_display_supported(),
            "image_count": len(images),
            "images": images,
            "current_image": current_image,
            "display_active": display_active,
            "hdmi_power": hdmi_power,
        }

    except Exception as e:
        logger.error(f"Error getting image status: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def show_image(image_name):
    """Display an image on the HDMI output"""
    try:
        if not is_display_supported():
            return {
                "success": False,
                "error": "Display feature not supported on this Pi model",
            }

        # Validate image name
        if not image_name:
            return {"success": False, "error": "No image name provided"}

        # Security check: prevent directory traversal
        if ".." in image_name or image_name.startswith("/"):
            return {"success": False, "error": "Invalid image name"}

        # Check if image exists
        image_dir = "/opt/droidnet/images"
        image_path = os.path.join(image_dir, image_name)

        if not os.path.exists(image_path):
            return {"success": False, "error": f"Image not found: {image_name}"}

        # Stop any currently displaying image
        stop_image()
        time.sleep(0.5)

        # Stop any playing video
        stop_display_video()
        time.sleep(0.5)

        # Start image display
        script_path = "/opt/droidnet/scripts/image-display.sh"
        if not os.path.exists(script_path):
            return {"success": False, "error": "Image display script not found"}

        # Run script in background
        process = subprocess.Popen(
            [script_path, image_name],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

        # Give it a moment to start
        time.sleep(0.5)

        # Check if process is still running
        if process.poll() is not None:
            # Process already exited, something went wrong
            _, stderr = process.communicate()
            error_msg = stderr.decode("utf-8") if stderr else "Unknown error"
            return {"success": False, "error": f"Failed to display image: {error_msg}"}

        return {
            "success": True,
            "message": f"Image displayed: {image_name}",
            "image": image_name,
        }

    except Exception as e:
        logger.error(f"Error showing image: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def stop_image():
    """Stop/hide currently displayed image"""
    try:
        control_script = "/opt/droidnet/scripts/image-control.sh"

        if not os.path.exists(control_script):
            return {"success": False, "error": "Image control script not found"}

        result = subprocess.run(
            [control_script, "stop"],
            capture_output=True,
            text=True,
            timeout=10,
        )

        if result.returncode == 0:
            try:
                response = json.loads(result.stdout)
                return response
            except json.JSONDecodeError:
                return {"success": True, "message": "Image display stopped"}
        else:
            return {"success": False, "error": result.stderr or "Failed to stop image"}

    except Exception as e:
        logger.error(f"Error stopping image: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def upload_image(filename, file_data):
    """Upload an image file to the images directory"""
    try:
        if not is_display_supported():
            return {
                "success": False,
                "error": "Display feature not supported on this Pi model",
            }

        # Validate file extension
        ext = os.path.splitext(filename)[1].lower()
        if ext not in [".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp"]:
            return {
                "success": False,
                "error": f"Unsupported image format: {ext}. "
                "Supported: jpg, jpeg, png, gif, bmp, webp",
            }

        # Sanitize filename
        safe_filename = sanitize_video_filename(
            filename
        )  # Reuse video sanitization function

        image_dir = "/opt/droidnet/images"
        if not os.path.exists(image_dir):
            os.makedirs(image_dir, mode=0o755, exist_ok=True)

        # Handle duplicate filenames
        base_name = os.path.splitext(safe_filename)[0]
        extension = os.path.splitext(safe_filename)[1]
        final_path = os.path.join(image_dir, safe_filename)
        counter = 1

        while os.path.exists(final_path):
            safe_filename = f"{base_name}-{counter}{extension}"
            final_path = os.path.join(image_dir, safe_filename)
            counter += 1

        # Write file
        with open(final_path, "wb") as f:
            f.write(file_data)

        # Set proper permissions
        os.chmod(final_path, 0o644)

        file_size = os.path.getsize(final_path)

        return {
            "success": True,
            "message": f"Image uploaded: {safe_filename}",
            "filename": safe_filename,
            "size": file_size,
        }

    except Exception as e:
        logger.error(f"Error uploading image: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def delete_image(image_name):
    """Delete an image from the images directory"""
    try:
        if not is_display_supported():
            return {
                "success": False,
                "error": "Display feature not supported on this Pi model",
            }

        # Security check: prevent directory traversal
        if ".." in image_name or image_name.startswith("/"):
            return {"success": False, "error": "Invalid image name"}

        image_dir = "/opt/droidnet/images"
        image_path = os.path.join(image_dir, image_name)

        # Verify path is within image directory
        real_image_path = os.path.realpath(image_path)
        real_image_dir = os.path.realpath(image_dir)
        if not real_image_path.startswith(real_image_dir):
            return {"success": False, "error": "Invalid image path"}

        # Check if file exists
        if not os.path.exists(image_path):
            return {"success": False, "error": f"Image not found: {image_name}"}

        # Stop image if it's currently being displayed
        control_script = "/opt/droidnet/scripts/image-control.sh"
        if os.path.exists(control_script):
            try:
                result = subprocess.run(
                    [control_script, "status"],
                    capture_output=True,
                    text=True,
                    timeout=5,
                )
                if result.returncode == 0:
                    status_data = json.loads(result.stdout)
                    if status_data.get("image") == image_name:
                        stop_image()
                        time.sleep(0.5)
            except Exception:
                pass

        # Delete the file
        os.remove(image_path)

        return {"success": True, "message": f"Image deleted: {image_name}"}

    except Exception as e:
        logger.error(f"Error deleting image: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def get_image_diagnostics():
    """Get diagnostic information for image display feature"""
    try:
        diagnostics = {}

        # Check Pi model
        diagnostics["pi_model"] = "unknown"
        try:
            with open("/proc/cpuinfo", "r") as f:
                cpuinfo = f.read()
                if "Pi Zero 2" in cpuinfo:
                    diagnostics["pi_model"] = "pi_zero_2w"
                elif "Pi 3" in cpuinfo:
                    diagnostics["pi_model"] = "pi_3"
                elif "Pi 4" in cpuinfo:
                    diagnostics["pi_model"] = "pi_4"
        except Exception:
            pass

        diagnostics["supported"] = is_display_supported()

        # Check for ffmpeg
        diagnostics["ffmpeg_available"] = shutil.which("ffmpeg") is not None

        # Check for vcgencmd
        diagnostics["vcgencmd_available"] = shutil.which("vcgencmd") is not None

        # Check HDMI status
        try:
            result = subprocess.run(
                ["vcgencmd", "display_power"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            diagnostics["hdmi_status"] = result.stdout.strip()
            diagnostics["hdmi_available"] = result.returncode == 0
        except Exception as e:
            diagnostics["hdmi_status"] = f"Error: {e}"
            diagnostics["hdmi_available"] = False

        # Check image directory
        image_dir = "/opt/droidnet/images"
        diagnostics["image_dir"] = image_dir
        diagnostics["image_dir_exists"] = os.path.exists(image_dir)
        diagnostics["image_dir_writable"] = (
            os.access(image_dir, os.W_OK) if os.path.exists(image_dir) else False
        )

        # Check disk space
        if os.path.exists(image_dir):
            stat = os.statvfs(image_dir)
            free_space = stat.f_bavail * stat.f_frsize
            diagnostics["disk_space_free_mb"] = free_space / (1024 * 1024)

        # Check image display script
        script_path = "/opt/droidnet/scripts/image-display.sh"
        diagnostics["image_display_script_exists"] = os.path.exists(script_path)
        diagnostics["image_display_script_executable"] = (
            os.access(script_path, os.X_OK) if os.path.exists(script_path) else False
        )

        # Check image control script
        control_script = "/opt/droidnet/scripts/image-control.sh"
        diagnostics["image_control_script_exists"] = os.path.exists(control_script)
        diagnostics["image_control_script_executable"] = (
            os.access(control_script, os.X_OK)
            if os.path.exists(control_script)
            else False
        )

        # Check recent logs
        log_file = "/var/log/droidnet/image-display.log"
        if os.path.exists(log_file):
            try:
                with open(log_file, "r") as f:
                    lines = f.readlines()
                    diagnostics["recent_log_entries"] = lines[-10:]
            except Exception:
                diagnostics["recent_log_entries"] = []

        return {"success": True, "diagnostics": diagnostics}

    except Exception as e:
        logger.error(f"Error getting image diagnostics: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


# ========== WCB Listeners Initialization ==========


async def _initialize_wcb_listeners_async():
    """
    Initialize WCB always-on listeners for configured devices (internal async version).
    Must be called from the event loop thread.
    """
    try:
        # Load always-on configuration
        config_path = "/opt/droidnet/config/wcb_alwayson.json"

        if not os.path.exists(config_path):
            logger.info("No WCB always-on configuration found")
            return

        with open(config_path, "r") as f:
            alwayson_config = json.load(f)

        if not alwayson_config:
            logger.info("WCB always-on configuration is empty")
            return

        # Filter to only enabled devices
        enabled_devices = {
            port: cfg
            for port, cfg in alwayson_config.items()
            if cfg.get("enabled", False)
        }

        if not enabled_devices:
            logger.info("No WCB devices enabled for always-on monitoring")
            return

        logger.info(f"Initializing WCB listeners for {len(enabled_devices)} device(s)")

        for port, cfg in enabled_devices.items():
            baud = cfg.get("baud", 115200)

            try:
                await serial_port_manager._start_wcb_listener(port, baud)
                logger.info(f"WCB listener started: {port} @ {baud} baud")
            except Exception as e:
                logger.error(f"Failed to start WCB listener for {port}: {e}")

    except Exception as e:
        logger.error(f"Error initializing WCB listeners: {e}", exc_info=True)


def _sync_bluetooth_with_victron(enabled: bool) -> bool:
    """
    Synchronize Bluetooth service state with Victron feature state.

    Bluetooth is only needed for Victron BLE communication, so it should
    be disabled when Victron is disabled to save CPU resources.

    Args:
        enabled: True if Victron feature is enabled, False otherwise

    Returns:
        True if successful, False otherwise
    """
    try:
        if enabled:
            # Enable and start Bluetooth
            subprocess.run(
                ["systemctl", "enable", "bluetooth"],
                capture_output=True,
                timeout=10,
            )
            result = subprocess.run(
                ["systemctl", "start", "bluetooth"],
                capture_output=True,
                timeout=10,
            )
            logger.info("Bluetooth service enabled and started (Victron enabled)")
        else:
            # Stop and disable Bluetooth
            subprocess.run(
                ["systemctl", "stop", "bluetooth"],
                capture_output=True,
                timeout=10,
            )
            result = subprocess.run(
                ["systemctl", "disable", "bluetooth"],
                capture_output=True,
                timeout=10,
            )
            logger.info("Bluetooth service stopped and disabled (Victron disabled)")

        return result.returncode == 0
    except subprocess.TimeoutExpired:
        logger.error("Timeout while controlling Bluetooth service")
        return False
    except Exception as e:
        logger.error(f"Error controlling Bluetooth service: {e}")
        return False


async def _initialize_victron_monitoring_async():
    """
    Initialize Victron BLE monitoring if auto-start is enabled.
    Also synchronizes Bluetooth service state with Victron config.
    Must be called from the event loop thread.
    """
    try:
        if not VICTRON_CONFIG_AVAILABLE:
            logger.warning("Victron config not available")
            return

        sys.path.insert(0, str(SCRIPTS_DIR))
        config = load_victron_config()

        # Check if feature is enabled (top-level toggle that hides the tab)
        victron_enabled = config.get("enabled", False)

        # Synchronize Bluetooth service state with Victron config
        # This ensures Bluetooth is disabled when Victron is disabled (saves CPU)
        _sync_bluetooth_with_victron(victron_enabled)

        if not victron_enabled:
            logger.info("Victron feature disabled, skipping auto-start")
            return

        # Check if auto-start is enabled
        if not config.get("auto_start", True):
            logger.info("Victron auto-start disabled")
            return

        # Check if device is configured
        device = config.get("device")
        if not device:
            logger.info("No Victron device configured")
            return

        if not device.get("enabled", False):
            logger.info("Victron device is disabled")
            return

        logger.info(
            f"Auto-starting Victron monitoring for {device.get('name', 'device')}"
        )

        # Start monitoring
        manager = get_victron_manager()
        success = await manager.start_monitoring(
            device["mac"], device["encryption_key"]
        )

        if success:
            logger.info(
                f"Victron monitoring started successfully for {device['mac'][:8]}..."
            )
        else:
            logger.error("Failed to auto-start Victron monitoring")

    except Exception as e:
        logger.error(f"Error initializing Victron monitoring: {e}", exc_info=True)


def main():
    """Main server entry point"""
    global thread_limit, event_loop_thread, serial_port_manager, maestro_manager

    logger.info("=" * 60)
    logger.info("DroidNet Signal Booster Web Server Starting")
    logger.info(f"Log file: {os.path.join(LOG_DIR, LOG_FILE)}")
    logger.info("=" * 60)

    # Get thread configuration based on Pi model
    thread_config, pi_model = get_thread_config()

    # Initialize thread limiter
    thread_limit = threading.BoundedSemaphore(thread_config["max_threads"])

    # Log system information
    logger.info(f"System: Raspberry Pi model={pi_model}")
    max_t = thread_config["max_threads"]
    q_size = thread_config["queue_size"]
    logger.info(f"Thread pool: max_threads={max_t}, queue_size={q_size}")

    # Log initial memory usage
    if PSUTIL_AVAILABLE:
        try:
            process = psutil.Process()
            memory_mb = process.memory_info().rss / 1024 / 1024
            logger.info(f"Initial memory usage: {memory_mb:.1f}MB")
        except Exception:
            logger.debug("Error getting memory usage")
    else:
        logger.debug("psutil not available for memory monitoring")

    # START PERSISTENT EVENT LOOP THREAD
    if not ASYNCIO_LOOP_THREAD_AVAILABLE:
        logger.error("AsyncioEventLoopThread is not available")
        sys.exit(1)

    event_loop_thread = AsyncioEventLoopThread()
    event_loop_thread.start()
    logger.info("Background asyncio event loop started")

    # Initialize SerialPortManager with event loop thread
    serial_port_manager = SerialPortManager(event_loop_thread)
    logger.info("SerialPortManager initialized")

    # Set dependencies for handler modules
    comlink_handlers.serial_port_manager = serial_port_manager
    comlink_handlers.get_serial_devices = get_serial_devices
    wcb_handlers.serial_port_manager = serial_port_manager
    victron_handlers.serial_port_manager = serial_port_manager
    firmware_handlers.serial_port_manager = serial_port_manager
    wcb_backup_handlers.serial_port_manager = serial_port_manager
    logger.info("Handler module dependencies initialized")

    # Initialize WCB Backup Manager
    wcb_backup_manager = None
    if WCB_BACKUP_MANAGER_AVAILABLE:
        try:
            wcb_backup_manager = get_backup_manager()
            wcb_backup_manager.serial_port_manager = serial_port_manager
            wcb_backup_handlers.backup_manager = wcb_backup_manager
            logger.info("WCB Backup Manager initialized")
        except Exception as e:
            logger.warning(f"Failed to initialize WCB Backup Manager: {e}")
    else:
        logger.warning("WCB Backup Manager not available")

    # Initialize MaestroManager
    if MAESTRO_MANAGER_AVAILABLE:
        try:
            sys.path.insert(0, str(SCRIPTS_DIR))
            maestro_manager = get_maestro_manager()
            logger.info("MaestroManager initialized")
        except Exception as e:
            logger.warning(f"Failed to initialize MaestroManager: {e}")
            maestro_manager = None
    else:
        logger.warning("MaestroManager not available")
        maestro_manager = None

    # Change to web directory
    if os.path.exists(WEB_ROOT):
        os.chdir(WEB_ROOT)
    else:
        os.chdir(os.path.dirname(__file__))

    # Start WebSocket server in background thread
    ws_thread = threading.Thread(target=start_websocket_server, daemon=True)
    ws_thread.start()

    # Initialize WCB listeners (runs in persistent event loop)
    try:
        event_loop_thread.run_coroutine(_initialize_wcb_listeners_async())
        logger.info("WCB listeners initialized successfully")
    except Exception as e:
        logger.error(f"Failed to initialize WCB listeners: {e}", exc_info=True)

    # Start WCB Backup scheduler (after WCB listeners are initialized)
    if wcb_backup_manager:
        try:
            event_loop_thread.run_coroutine(wcb_backup_manager.start_scheduler())
            logger.info("WCB Backup scheduler started")
        except Exception as e:
            logger.warning(f"Failed to start WCB Backup scheduler: {e}")

    # Initialize MaestroListenerActivator for on-demand listener activation
    # (replaces auto-start - listeners now start when WebSocket connects)
    global maestro_listener_activator
    if maestro_manager and event_loop_thread:
        maestro_listener_activator = MaestroListenerActivator(
            maestro_manager, event_loop_thread
        )
        logger.info(
            "MaestroListenerActivator initialized (on-demand listener activation)"
        )

    # Initialize Victron BLE monitoring (runs in persistent event loop)
    try:
        event_loop_thread.run_coroutine(_initialize_victron_monitoring_async())
        logger.info("Victron monitoring initialized successfully")
    except Exception as e:
        logger.error(f"Failed to initialize Victron monitoring: {e}", exc_info=True)

    # Start HTTP server with threading support
    try:
        # Use ThreadingHTTPServer for concurrent request handling
        server = ThreadingHTTPServer(("0.0.0.0", WEB_PORT), DroidNetHandler)
        server.request_queue_size = thread_config["queue_size"]

        logger.info(
            f"DroidNet Signal Booster ThreadingHTTPServer starting on port {WEB_PORT}"
        )
        logger.info(f"WebSocket server running on port {WS_PORT}")
        logger.info(f"Request queue size: {server.request_queue_size}")
    except PermissionError:
        logger.error(
            f"Permission denied binding to port {WEB_PORT}. "
            "Run as root or use a port > 1024"
        )
        sys.exit(1)
    except OSError as e:
        logger.error(f"Failed to start server on port {WEB_PORT}: {e}")
        sys.exit(1)

    try:
        logger.info("Server ready and accepting connections")
        server.serve_forever()
    except KeyboardInterrupt:
        logger.info("Shutting down server...")
    except Exception as e:
        logger.error(f"Server error: {e}", exc_info=True)
    finally:
        logger.info("Stopping HTTP server...")
        server.shutdown()

        # Stop event loop thread
        logger.info("Stopping background event loop...")
        if event_loop_thread:
            event_loop_thread.stop()

        logger.info("Server stopped")


if __name__ == "__main__":
    main()
