"""
DroidNet Signal Booster - WCB (Wireless Control Board) Handlers
Functions for WCB configuration, device management, and listener control
"""

import os
import sys
import json
import logging
from typing import Dict, Any, Optional

from config.constants import PROJECT_ROOT, SCRIPTS_DIR, CONFIG_DIR

# Add parent directory to path for imports
sys.path.insert(0, str(PROJECT_ROOT))
sys.path.insert(0, str(SCRIPTS_DIR))

# Get logger
logger = logging.getLogger(__name__)

# Import wcb_config functions at module level with error handling
try:
    from wcb_config import (
        load_wcb_config,
        save_wcb_config,
        get_wcb_devices as get_wcb_list,
        toggle_wcb_device as toggle_device,
        update_wcb_enabled,
        update_wcb_delay,
    )
    from usb_manager import USBManager

    WCB_CONFIG_AVAILABLE = True
except ImportError:
    WCB_CONFIG_AVAILABLE = False
    logger.warning("wcb_config or usb_manager modules not available")

# Module-level variable (set by server.py after import)
serial_port_manager = None


def _require_serial_port_manager():
    """
    Validate serial_port_manager is available.

    Raises:
        RuntimeError: If serial_port_manager is not initialized
    """
    if serial_port_manager is None:
        raise RuntimeError("SerialPortManager not initialized")
    return serial_port_manager


# Standard baud rates for validation
ALLOWED_BAUD_RATES = [
    300,
    1200,
    2400,
    4800,
    9600,
    19200,
    38400,
    57600,
    115200,
    230400,
    460800,
    921600,
]

# Maximum command length to prevent abuse
MAX_COMMAND_LENGTH = 256


def _validate_port(port: str) -> Optional[str]:
    """
    Validate port parameter.

    Args:
        port: Serial port path to validate

    Returns:
        Error message if invalid, None if valid
    """
    if not port:
        return "Port is required"
    if not port.startswith("/dev/"):
        return "Invalid port path: must start with /dev/"
    # Prevent path traversal
    if ".." in port:
        return "Invalid port path: path traversal not allowed"
    return None


def _validate_baud(baud: int) -> Optional[str]:
    """
    Validate baud rate parameter.

    Args:
        baud: Baud rate to validate

    Returns:
        Error message if invalid, None if valid
    """
    if not isinstance(baud, int):
        return "Baud rate must be an integer"
    if baud not in ALLOWED_BAUD_RATES:
        return f"Invalid baud rate: {baud}. Allowed: {ALLOWED_BAUD_RATES}"
    return None


def _validate_command(command: str) -> Optional[str]:
    """
    Validate WCB command parameter.

    Args:
        command: WCB command string to validate

    Returns:
        Error message if invalid, None if valid
    """
    if not command:
        return "Command is required"
    if len(command) > MAX_COMMAND_LENGTH:
        return f"Command too long (max {MAX_COMMAND_LENGTH} characters)"
    # WCB commands should start with ?, !, or be alphanumeric (for C<node> messages)
    # ? = query commands, ! = write commands
    if not (command.startswith("?") or command.startswith("!") or command[0].isalnum()):
        return "Invalid command format: must start with ?, !, or alphanumeric"
    return None


def get_wcb_config() -> Dict[str, Any]:
    """Get WCB configuration"""
    try:
        if not WCB_CONFIG_AVAILABLE:
            raise ImportError("wcb_config module not available")

        config = load_wcb_config()
        return {"success": True, "config": config}
    except Exception as e:
        return {"success": False, "error": str(e)}


def get_wcb_devices() -> Dict[str, Any]:
    """Get list of devices marked as WCB"""
    try:
        if not WCB_CONFIG_AVAILABLE:
            raise ImportError("wcb_config module not available")

        # Get WCB device IDs
        wcb_ids = get_wcb_list()

        # Get all USB devices (not just serial devices)
        manager = USBManager()
        all_devices = manager.get_usb_devices()

        # Filter to only WCB devices that have serial ports
        wcb_devices = []
        for device in all_devices:
            if device.unique_id in wcb_ids and device.get_serial_port():
                wcb_devices.append(
                    {
                        "port": device.get_serial_port(),
                        "name": device.get_display_name(),
                        "unique_id": device.unique_id,
                        "vendor_id": device.vendor_id,
                        "product_id": device.product_id,
                        "serial_number": device.serial_number or "",
                    }
                )

        return {"success": True, "devices": wcb_devices}
    except Exception as e:
        return {"success": False, "error": str(e), "devices": []}


def update_wcb_config(data: Dict[str, Any]) -> Dict[str, Any]:
    """Update WCB configuration"""
    try:
        if not WCB_CONFIG_AVAILABLE:
            raise ImportError("wcb_config module not available")

        success = True

        # Update enabled state
        if "enabled" in data:
            if not update_wcb_enabled(data["enabled"]):
                success = False

        # Update delay
        if "update_delay_ms" in data:
            if not update_wcb_delay(data["update_delay_ms"]):
                success = False

        # If other config items, update directly
        if success and any(key not in ["enabled", "update_delay_ms"] for key in data):
            config = load_wcb_config()
            for key, value in data.items():
                if key not in ["enabled", "update_delay_ms"]:
                    config[key] = value
            success = save_wcb_config(config)

        if success:
            return {"success": True, "message": "WCB configuration updated"}
        else:
            return {"success": False, "error": "Failed to update configuration"}

    except Exception as e:
        return {"success": False, "error": str(e)}


def toggle_wcb_device(device_id: str, enabled: bool) -> Dict[str, Any]:
    """Mark or unmark a device as WCB"""
    try:
        if not WCB_CONFIG_AVAILABLE:
            raise ImportError("wcb_config module not available")

        if toggle_device(device_id, enabled):
            action = "marked" if enabled else "unmarked"
            return {"success": True, "message": f"Device {device_id} {action} as WCB"}
        else:
            return {"success": False, "error": f"Failed to update device {device_id}"}
    except Exception as e:
        return {"success": False, "error": str(e)}


def get_wcb_alwayson_config() -> Dict[str, Any]:
    """Get WCB always-on monitoring configuration"""
    try:
        config_path = str(CONFIG_DIR / "wcb_alwayson.json")
        if os.path.exists(config_path):
            with open(config_path, "r") as f:
                config = json.load(f)
        else:
            config = {}
        return {"success": True, "config": config}
    except Exception as e:
        logger.error(f"Error loading always-on config: {e}")
        return {"success": False, "error": str(e), "config": {}}


def save_wcb_alwayson_config(config: Dict[str, Any]) -> Dict[str, Any]:
    """Save WCB always-on monitoring configuration"""
    try:
        config_path = str(CONFIG_DIR / "wcb_alwayson.json")

        # Ensure config directory exists
        os.makedirs(os.path.dirname(config_path), exist_ok=True)

        # Write configuration
        with open(config_path, "w") as f:
            json.dump(config, f, indent=2)

        logger.info(f"Saved always-on config: {config}")
        return {"success": True, "message": "Configuration saved"}
    except Exception as e:
        logger.error(f"Error saving always-on config: {e}")
        return {"success": False, "error": str(e)}


def get_wcb_listeners_status() -> Dict[str, Any]:
    """Get status of all active WCB listeners"""
    try:
        manager = _require_serial_port_manager()
        listeners = manager.get_all_wcb_listeners()
        handlers = manager.get_all_handlers()

        listener_status = []
        for port, listener in listeners.items():
            handler = handlers.get(port)
            if handler:
                stats = handler.get_stats()
                listener_status.append(
                    {
                        "port": port,
                        "baud": handler.baud,
                        "connected": stats.get("connected", False),
                        "uptime_seconds": stats.get("uptime_seconds", 0),
                        "bytes_received": stats.get("bytes_received", 0),
                        "bytes_sent": stats.get("bytes_sent", 0),
                        "lines_received": stats.get("lines_received", 0),
                        "error_count": stats.get("error_count", 0),
                    }
                )

        return {"success": True, "listeners": listener_status}
    except Exception as e:
        logger.error(f"Error getting WCB listeners status: {e}", exc_info=True)
        return {"success": False, "error": str(e), "listeners": []}


def get_wcb_listener_status(port: str) -> Dict[str, Any]:
    """Get status of a specific WCB listener"""
    try:
        manager = _require_serial_port_manager()
        listener = manager.get_wcb_listener(port)
        if not listener:
            return {"success": False, "error": f"No listener found for {port}"}

        handler = manager.get_handler(port)
        if not handler:
            return {"success": False, "error": f"No handler found for {port}"}

        stats = handler.get_stats()
        return {
            "success": True,
            "port": port,
            "baud": handler.baud,
            "connected": stats.get("connected", False),
            "uptime_seconds": stats.get("uptime_seconds", 0),
            "bytes_received": stats.get("bytes_received", 0),
            "bytes_sent": stats.get("bytes_sent", 0),
            "lines_received": stats.get("lines_received", 0),
            "lines_sent": stats.get("lines_sent", 0),
            "error_count": stats.get("error_count", 0),
            "reconnect_count": stats.get("reconnect_count", 0),
        }
    except Exception as e:
        logger.error(
            f"Error getting WCB listener status for {port}: {e}", exc_info=True
        )
        return {"success": False, "error": str(e)}


def start_wcb_listener(port: str, baud: int) -> Dict[str, Any]:
    """
    Start WCB listener for a port (synchronous wrapper).
    Called from HTTP request threads.
    """
    # Validate inputs first
    if error := _validate_port(port):
        return {"success": False, "error": error}
    if error := _validate_baud(baud):
        return {"success": False, "error": error}

    try:
        manager = _require_serial_port_manager()
        manager.start_wcb_listener_sync(port, baud)
        return {
            "success": True,
            "message": f"WCB listener started for {port} @ {baud} baud",
            "port": port,
            "baud": baud,
        }
    except Exception as e:
        logger.error(f"Error starting WCB listener for {port}: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def stop_wcb_listener(port: str) -> Dict[str, Any]:
    """
    Stop WCB listener for a port (synchronous wrapper).
    Called from HTTP request threads.
    """
    # Validate input first
    if error := _validate_port(port):
        return {"success": False, "error": error}

    try:
        manager = _require_serial_port_manager()
        manager.stop_wcb_listener_sync(port)
        return {
            "success": True,
            "message": f"WCB listener stopped for {port}",
            "port": port,
        }
    except Exception as e:
        logger.error(f"Error stopping WCB listener for {port}: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def get_serial_history(port: str, limit: Optional[int] = None) -> Dict[str, Any]:
    """
    Get serial output history for a port.
    Called from HTTP request threads.
    """
    # Validate input first
    if error := _validate_port(port):
        return {"success": False, "error": error}

    try:
        manager = _require_serial_port_manager()
        handler = manager.get_handler(port)
        if not handler:
            return {"success": False, "error": f"No handler found for {port}"}

        history = handler.get_history(limit)
        return {"success": True, "port": port, "history": history}
    except Exception as e:
        logger.error(f"Error getting serial history for {port}: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


def send_wcb_command(port: str, command: str, timeout: float = 5.0) -> Dict[str, Any]:
    """
    Send WCB command and wait for response (synchronous wrapper).
    Called from HTTP request threads.
    """
    # Validate inputs first
    if error := _validate_port(port):
        return {"success": False, "error": error}
    if error := _validate_command(command):
        return {"success": False, "error": error}
    # Validate timeout range
    if timeout < 0.1 or timeout > 60.0:
        return {"success": False, "error": "Timeout must be between 0.1 and 60 seconds"}

    try:
        manager = _require_serial_port_manager()
        listener = manager.get_wcb_listener(port)
        if not listener:
            return {
                "success": False,
                "error": f"No WCB listener active for {port}",
            }

        try:
            # Run the async send_command in the event loop thread
            async def _send():
                return await listener.send_command(command, timeout=timeout)

            response = manager.event_loop_thread.run_coroutine(_send())

            return {
                "success": True,
                "command": command,
                "response": {
                    "success": response.success,
                    "data": response.data,
                    "commands": [
                        {"key": cmd.key, "value": cmd.value}
                        for cmd in response.commands
                    ],
                    "timestamp": response.timestamp,
                },
            }
        except TimeoutError as e:
            return {"success": False, "error": str(e)}

    except Exception as e:
        logger.error(f"Error sending WCB command to {port}: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


# ========== WCB Preset Commands ==========

# Default preset commands for new devices
# Increment DEFAULTS_VERSION when adding new defaults - this triggers migration
# Version 2: Added BACKUP preset (BACKUP includes all CONFIG data plus more)
DEFAULTS_VERSION = 2
DEFAULT_PRESET_COMMANDS = [
    {"name": "BACKUP", "command": "?BACKUP"},
    {"name": "CONFIG", "command": "?CONFIG"},
    {"name": "DON", "command": "?DON"},
    {"name": "DOFF", "command": "?DOFF"},
    {"name": "DIAG", "command": "?CDIAG"},
]

# Config file for preset commands
PRESET_COMMANDS_FILE = CONFIG_DIR / "wcb-preset-commands.json"


def _load_preset_config() -> Dict[str, Any]:
    """Load preset commands configuration from disk, migrating if needed."""
    config = {"devices": {}, "version": 0}
    try:
        if PRESET_COMMANDS_FILE.exists():
            with open(PRESET_COMMANDS_FILE, "r") as f:
                config = json.load(f)
                if "version" not in config:
                    config["version"] = 0
    except Exception as e:
        logger.error(f"Error loading preset commands config: {e}")

    # Migrate if defaults version changed
    if config.get("version", 0) < DEFAULTS_VERSION:
        config = _migrate_preset_defaults(config)

    return config


def _migrate_preset_defaults(config: Dict[str, Any]) -> Dict[str, Any]:
    """
    Migrate preset config when defaults change.

    Adds any new default presets to all existing device configs while
    preserving user additions and edits.
    """
    old_version = config.get("version", 0)
    logger.info(f"Migrating WCB presets from version {old_version} to {DEFAULTS_VERSION}")

    # Get the set of default command names for quick lookup
    default_names = {p["name"] for p in DEFAULT_PRESET_COMMANDS}

    # For each device, add any missing defaults
    devices = config.get("devices", {})
    for device_id, presets in devices.items():
        existing_names = {p["name"] for p in presets}

        # Add any defaults that don't exist in this device's presets
        for default in DEFAULT_PRESET_COMMANDS:
            if default["name"] not in existing_names:
                presets.append(default.copy())
                logger.debug(f"Added default '{default['name']}' to device {device_id}")

        devices[device_id] = presets

    config["devices"] = devices
    config["version"] = DEFAULTS_VERSION

    # Save migrated config
    _save_preset_config(config)
    logger.info(f"WCB preset migration complete for {len(devices)} device(s)")

    return config


def _save_preset_config(config: Dict[str, Any]) -> bool:
    """Save preset commands configuration to disk."""
    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        with open(PRESET_COMMANDS_FILE, "w") as f:
            json.dump(config, f, indent=2)
        return True
    except Exception as e:
        logger.error(f"Error saving preset commands config: {e}")
        return False


def get_wcb_preset_commands(device_id: Optional[str] = None) -> Dict[str, Any]:
    """
    Get preset commands for a WCB device.

    Args:
        device_id: Unique device identifier, or None for defaults

    Returns:
        Dict with 'presets' list and 'is_default' flag
    """
    try:
        config = _load_preset_config()
        devices = config.get("devices", {})

        if device_id and device_id in devices:
            return {
                "success": True,
                "presets": devices[device_id],
                "is_default": False,
                "device_id": device_id,
            }

        # Return defaults
        return {
            "success": True,
            "presets": DEFAULT_PRESET_COMMANDS.copy(),
            "is_default": True,
            "device_id": device_id,
        }
    except Exception as e:
        logger.error(f"Error getting preset commands: {e}")
        return {
            "success": False,
            "error": str(e),
            "presets": DEFAULT_PRESET_COMMANDS.copy(),
            "is_default": True,
        }


def save_wcb_preset_commands(
    device_id: str, presets: list
) -> Dict[str, Any]:
    """
    Save preset commands for a WCB device.

    Args:
        device_id: Unique device identifier
        presets: List of {name, command} dicts

    Returns:
        Dict with success status
    """
    if not device_id:
        return {"success": False, "error": "Device ID is required"}

    # Validate presets
    if not isinstance(presets, list):
        return {"success": False, "error": "Presets must be a list"}

    validated_presets = []
    for i, preset in enumerate(presets):
        if not isinstance(preset, dict):
            return {"success": False, "error": f"Preset {i} must be an object"}
        name = preset.get("name", "").strip()
        command = preset.get("command", "").strip()
        if not name:
            return {"success": False, "error": f"Preset {i} name is required"}
        if not command:
            return {"success": False, "error": f"Preset {i} command is required"}
        if len(name) > 20:
            return {"success": False, "error": f"Preset name '{name}' too long (max 20)"}
        if len(command) > 100:
            return {"success": False, "error": f"Command too long (max 100)"}
        validated_presets.append({"name": name, "command": command})

    try:
        config = _load_preset_config()
        if "devices" not in config:
            config["devices"] = {}

        config["devices"][device_id] = validated_presets

        if _save_preset_config(config):
            logger.info(f"Saved {len(validated_presets)} preset commands for {device_id}")
            return {
                "success": True,
                "presets": validated_presets,
                "device_id": device_id,
            }
        else:
            return {"success": False, "error": "Failed to save configuration"}

    except Exception as e:
        logger.error(f"Error saving preset commands: {e}")
        return {"success": False, "error": str(e)}


def reset_wcb_preset_commands(device_id: str) -> Dict[str, Any]:
    """
    Reset preset commands to defaults for a device.

    Args:
        device_id: Unique device identifier

    Returns:
        Dict with success status and default presets
    """
    if not device_id:
        return {"success": False, "error": "Device ID is required"}

    try:
        config = _load_preset_config()
        if "devices" in config and device_id in config["devices"]:
            del config["devices"][device_id]
            _save_preset_config(config)
            logger.info(f"Reset preset commands to defaults for {device_id}")

        return {
            "success": True,
            "presets": DEFAULT_PRESET_COMMANDS.copy(),
            "is_default": True,
            "device_id": device_id,
        }
    except Exception as e:
        logger.error(f"Error resetting preset commands: {e}")
        return {"success": False, "error": str(e)}
