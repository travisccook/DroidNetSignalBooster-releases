"""
DroidNet Signal Booster - Firmware Handlers
Functions for flashing firmware to Arduino and ESP32 devices
"""

import os
import sys
import subprocess
import logging
import tempfile
import time
from typing import Dict, Any, Optional

from config.constants import PROJECT_ROOT, SCRIPTS_DIR, AVRDUDE_CONFIG_PATH, LOG_DIR

# Add parent directory to path for imports
sys.path.insert(0, str(PROJECT_ROOT))
sys.path.insert(0, str(SCRIPTS_DIR))

# Get logger for general web logging
logger = logging.getLogger(__name__)

# Create dedicated flash logger (separate from web.log)
flash_logger = logging.getLogger("droidnet.flash")
flash_logger.setLevel(logging.INFO)
# Ensure log directory exists (skip if not running on device)
try:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    _flash_handler = logging.FileHandler(str(LOG_DIR / "flash.log"))
    _flash_handler.setFormatter(
        logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
    )
    flash_logger.addHandler(_flash_handler)
except (PermissionError, OSError):
    # Running in dev/test environment without /var/log/droidnet access
    pass
# Prevent propagation to root logger (avoid duplicate logs)
flash_logger.propagate = False

# Module-level variable (set by server.py after import)
serial_port_manager = None


def _get_active_wcb_listener_baud(port: str) -> Optional[int]:
    """
    Check if there's an active WCB listener on the port and return its baud rate.

    Args:
        port: Serial port path

    Returns:
        Baud rate if listener is active, None otherwise
    """
    if serial_port_manager is None:
        return None

    try:
        handler = serial_port_manager.get_handler(port)
        if handler:
            return handler.baud
    except Exception as e:
        logger.debug(f"Error checking WCB listener for {port}: {e}")

    return None


def _force_release_port(port: str) -> bool:
    """
    Forcibly release a serial port by killing any processes using it.

    Uses fuser to identify and kill processes holding the port.
    This is necessary because sometimes processes don't release ports cleanly.

    Args:
        port: Serial port path

    Returns:
        True if port was released (or was already free), False on error
    """
    try:
        # First check what's using the port
        result = subprocess.run(
            ["fuser", port], capture_output=True, text=True, timeout=5
        )

        if result.returncode == 0 and result.stdout.strip():
            # Something is using the port - log it and kill
            pids = result.stdout.strip()
            flash_logger.info(f"Processes using {port}: {pids}")
            logger.info(f"Found processes using {port}: {pids}, killing them")

            # Kill processes using the port
            kill_result = subprocess.run(
                ["fuser", "-k", port], capture_output=True, text=True, timeout=10
            )

            if kill_result.returncode == 0:
                flash_logger.info(f"Killed processes holding {port}")
                logger.info(f"Successfully killed processes holding {port}")
            else:
                flash_logger.warning(f"fuser -k returned {kill_result.returncode}")
                logger.warning(f"fuser -k may not have killed all processes")

            # Give kernel time to clean up after killing
            time.sleep(0.5)
            return True
        else:
            # No processes using the port
            logger.debug(f"No processes found using {port}")
            return True

    except subprocess.TimeoutExpired:
        logger.warning(f"Timeout checking port {port} usage")
        return False
    except FileNotFoundError:
        # fuser not available, skip this step
        logger.debug("fuser command not available")
        return True
    except Exception as e:
        logger.warning(f"Error checking port {port} usage: {e}")
        return False


def _verify_port_available(
    port: str, max_attempts: int = 5, delay: float = 0.5
) -> bool:
    """
    Verify that a serial port is available by attempting to open it.

    Args:
        port: Serial port path
        max_attempts: Maximum number of attempts
        delay: Delay between attempts in seconds

    Returns:
        True if port is available, False otherwise
    """
    import serial

    for attempt in range(max_attempts):
        try:
            # Try to open the port briefly
            ser = serial.Serial(port, 115200, timeout=0.1)
            ser.close()
            logger.debug(f"Port {port} verified available on attempt {attempt + 1}")
            return True
        except serial.SerialException as e:
            if attempt < max_attempts - 1:
                logger.debug(
                    f"Port {port} not yet available (attempt {attempt + 1}): {e}"
                )
                # Try to force release if port is busy
                if "busy" in str(e).lower() or "in use" in str(e).lower():
                    _force_release_port(port)
                time.sleep(delay)
            else:
                logger.warning(
                    f"Port {port} still not available after {max_attempts} attempts: {e}"
                )
        except Exception as e:
            logger.warning(f"Unexpected error checking port {port}: {e}")
            return False

    return False


def _stop_wcb_listener_for_flash(port: str) -> bool:
    """
    Stop WCB listener on a port before flashing.

    Args:
        port: Serial port path

    Returns:
        True if a listener was stopped, False otherwise
    """
    if serial_port_manager is None:
        return False

    try:
        listener = serial_port_manager.get_wcb_listener(port)
        if listener:
            logger.info(f"Stopping WCB listener on {port} for firmware flash")
            flash_logger.info(f"Stopping WCB listener on {port}")
            serial_port_manager.stop_wcb_listener_sync(port)

            # Give time for port to be fully released by OS/USB subsystem
            # Pi Zero W needs extra time for USB cleanup
            time.sleep(1.0)

            # Forcibly release any processes still holding the port
            _force_release_port(port)

            # Additional delay after force release
            time.sleep(0.5)

            # Verify the port is actually available (with retries)
            if not _verify_port_available(port, max_attempts=10, delay=0.3):
                flash_logger.warning(f"Port {port} may not be fully released")
                logger.warning(f"Port {port} may not be fully released after cleanup")
                # One more aggressive attempt
                _force_release_port(port)
                time.sleep(1.0)

            return True
    except Exception as e:
        flash_logger.warning(f"Error stopping WCB listener for {port}: {e}")
        logger.warning(f"Error stopping WCB listener for {port}: {e}")

    return False


def _restart_wcb_listener(port: str, baud: int):
    """
    Restart WCB listener on a port after flashing.

    Args:
        port: Serial port path
        baud: Baud rate to use
    """
    if serial_port_manager is None:
        return

    try:
        logger.info(f"Restarting WCB listener on {port} @ {baud} baud after flash")
        # Give time for device to boot after flash
        time.sleep(2.0)
        serial_port_manager.start_wcb_listener_sync(port, baud)
    except Exception as e:
        logger.warning(f"Error restarting WCB listener for {port}: {e}")


# Import firmware flasher at module level with error handling
try:
    from firmware_flasher import flash_firmware as enhanced_flash

    ENHANCED_FLASHER_AVAILABLE = True
except ImportError:
    ENHANCED_FLASHER_AVAILABLE = False
    logger.warning("Enhanced firmware flasher not available")


def flash_firmware(
    firmware_data: bytes,
    device_port: str,
    board_type: Optional[str] = None,
    additional_files: Optional[Dict[str, str]] = None,
    flash_address: Optional[str] = None,
) -> Dict[str, Any]:
    """Flash firmware to Arduino or ESP32 using enhanced flasher"""
    start_time = time.time()
    wcb_listener_baud = None
    result = None

    # Log flash operation start to dedicated flash log
    flash_logger.info("=" * 60)
    flash_logger.info("FLASH OPERATION STARTED")
    flash_logger.info(f"Port: {device_port}")
    flash_logger.info(f"Board type: {board_type or 'auto-detect'}")
    flash_logger.info(f"Flash address: {flash_address or 'auto'}")
    flash_logger.info(f"Firmware size: {len(firmware_data)} bytes")
    if additional_files:
        flash_logger.info(f"Additional files: {list(additional_files.keys())}")

    try:
        logger.info(
            f"Starting firmware flash to {device_port}, board_type={board_type}"
        )

        # Check for active WCB listener and stop it before flashing
        wcb_listener_baud = _get_active_wcb_listener_baud(device_port)
        if wcb_listener_baud:
            flash_logger.info(f"Stopping WCB listener @ {wcb_listener_baud} baud")
            logger.info(
                f"Found active WCB listener on {device_port} @ {wcb_listener_baud} baud"
            )
            _stop_wcb_listener_for_flash(device_port)
        else:
            # Even without a WCB listener, ensure port is free from any other processes
            flash_logger.info("Ensuring port is available for flashing")
            _force_release_port(device_port)
            time.sleep(0.3)

        # Final port availability check before proceeding
        if not _verify_port_available(device_port, max_attempts=5, delay=0.2):
            flash_logger.warning(
                f"Port {device_port} may still be in use, attempting flash anyway"
            )

        # Check if enhanced flasher is available
        if not ENHANCED_FLASHER_AVAILABLE:
            raise ImportError("Enhanced flasher not available")

        # Detect file type from data
        file_ext = ".hex" if firmware_data.startswith(b":") else ".bin"
        flash_logger.info(f"Detected file type: {file_ext}")
        logger.debug(f"Detected firmware file type: {file_ext}")

        # Save firmware file temporarily
        with tempfile.NamedTemporaryFile(suffix=file_ext, delete=False) as f:
            f.write(firmware_data)
            firmware_file = f.name

        logger.debug(f"Saved firmware to temporary file: {firmware_file}")

        try:
            # Use enhanced flasher with auto-detection
            flash_logger.info("Calling enhanced firmware flasher")
            logger.info("Calling enhanced firmware flasher")
            result = enhanced_flash(
                firmware_file, device_port, board_type, additional_files, flash_address
            )

            # Log flash map for ESP32
            if result.get("flash_map"):
                flash_logger.info(f"Flash map: {result['flash_map']}")

            # Log the full tool output
            if result.get("output"):
                flash_logger.info("--- Tool Output ---")
                for line in result["output"].strip().split("\n"):
                    flash_logger.info(f"  {line}")
                flash_logger.info("--- End Tool Output ---")

            if result.get("success"):
                flash_logger.info(f"Flash successful: {result.get('message', 'OK')}")
                logger.info(f"Firmware flash successful: {result.get('message', 'OK')}")
            else:
                flash_logger.error(
                    f"Flash failed: {result.get('message', 'Unknown error')}"
                )
                logger.error(
                    f"Firmware flash failed: {result.get('message', 'Unknown error')}"
                )

            return result
        finally:
            # Clean up temp file
            if os.path.exists(firmware_file):
                os.unlink(firmware_file)
                logger.debug(f"Cleaned up temporary file: {firmware_file}")

    except ImportError as e:
        flash_logger.warning(f"Enhanced flasher not available, using legacy: {e}")
        logger.warning(f"Enhanced flasher not available, using legacy method: {e}")
        # Fallback to legacy method if enhanced flasher not available
        return flash_firmware_legacy(firmware_data, device_port, board_type)
    except (OSError, subprocess.CalledProcessError) as e:
        flash_logger.error(f"Flash operation failed: {e}")
        logger.error(f"Flash operation failed: {e}", exc_info=True)
        return {"success": False, "message": f"Flash operation failed: {str(e)}"}
    finally:
        # Calculate and log duration
        duration = time.time() - start_time
        if result:
            flash_logger.info(
                f"Result: {'SUCCESS' if result.get('success') else 'FAILED'}"
            )
        flash_logger.info(f"Duration: {duration:.2f}s")
        flash_logger.info("=" * 60)

        # Restart WCB listener if it was running before flash
        if wcb_listener_baud:
            _restart_wcb_listener(device_port, wcb_listener_baud)


def flash_firmware_legacy(
    hex_data: bytes, device_port: str, board_type: Optional[str]
) -> Dict[str, Any]:
    """Legacy flash firmware method for Arduino only"""
    start_time = time.time()

    # Log to dedicated flash log
    flash_logger.info("=" * 60)
    flash_logger.info("LEGACY FLASH OPERATION STARTED")
    flash_logger.info(f"Port: {device_port}")
    flash_logger.info(f"Board type: {board_type or 'uno (default)'}")
    flash_logger.info(f"Firmware size: {len(hex_data)} bytes")

    try:
        logger.info(
            f"Using legacy flash method for {device_port}, board_type={board_type}"
        )

        # Save hex file temporarily
        with tempfile.NamedTemporaryFile(suffix=".hex", delete=False) as f:
            f.write(hex_data)
            hex_file = f.name

        flash_logger.info("Detected file type: .hex")
        logger.debug(f"Saved firmware to {hex_file}")

        # Board type to avrdude parameters mapping
        board_configs = {
            "uno": {"mcu": "atmega328p", "programmer": "arduino", "baud": "115200"},
            "nano": {"mcu": "atmega328p", "programmer": "arduino", "baud": "57600"},
            "mega": {"mcu": "atmega2560", "programmer": "wiring", "baud": "115200"},
            "leonardo": {"mcu": "atmega32u4", "programmer": "avr109", "baud": "57600"},
        }

        config = board_configs.get(board_type, board_configs["uno"])
        flash_logger.info(
            f"Board config: MCU={config['mcu']}, programmer={config['programmer']}, baud={config['baud']}"
        )
        logger.debug(f"Using board config: {config}")

        # Run avrdude
        cmd = [
            "avrdude",
            "-C",
            str(AVRDUDE_CONFIG_PATH),
            "-v",
            "-p",
            config["mcu"],
            "-c",
            config["programmer"],
            "-P",
            device_port,
            "-b",
            config["baud"],
            "-D",
            "-U",
            f"flash:w:{hex_file}:i",
        ]

        flash_logger.info(f"Command: {' '.join(cmd)}")
        logger.info(f"Running avrdude command: {' '.join(cmd)}")
        result = subprocess.run(cmd, capture_output=True, text=True)

        # Clean up
        os.unlink(hex_file)
        logger.debug("Cleaned up temporary hex file")

        # Log full tool output
        output = result.stdout + result.stderr
        flash_logger.info("--- Tool Output (avrdude) ---")
        for line in output.strip().split("\n"):
            flash_logger.info(f"  {line}")
        flash_logger.info("--- End Tool Output ---")

        duration = time.time() - start_time

        if result.returncode == 0:
            flash_logger.info("Flash successful: Firmware flashed successfully")
            flash_logger.info("Result: SUCCESS")
            flash_logger.info(f"Duration: {duration:.2f}s")
            flash_logger.info("=" * 60)
            logger.info("Legacy firmware flash successful")
            return {
                "success": True,
                "message": "Firmware flashed successfully",
                "output": output,
            }
        else:
            flash_logger.error(f"Flash failed: {result.stderr}")
            flash_logger.info("Result: FAILED")
            flash_logger.info(f"Duration: {duration:.2f}s")
            flash_logger.info("=" * 60)
            logger.error(f"Legacy firmware flash failed: {result.stderr}")
            return {
                "success": False,
                "message": f"Flash failed: {result.stderr}",
                "output": output,
            }

    except (OSError, subprocess.CalledProcessError) as e:
        duration = time.time() - start_time
        flash_logger.error(f"Flash operation failed: {e}")
        flash_logger.info("Result: FAILED")
        flash_logger.info(f"Duration: {duration:.2f}s")
        flash_logger.info("=" * 60)
        logger.error(f"Legacy flash operation failed: {e}", exc_info=True)
        return {"success": False, "message": f"Flash operation failed: {str(e)}"}
