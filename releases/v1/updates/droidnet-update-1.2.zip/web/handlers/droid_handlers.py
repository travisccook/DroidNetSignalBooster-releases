"""
DroidNet Signal Booster - Droid Fleet Handlers
Functions for multi-device discovery, updates, and firmware flashing
"""

import json
import logging
import os
import re
import socket
import threading
import time
import urllib.request
import urllib.error
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from config.constants import CONFIG_DIR, RUNTIME_DIR, PROJECT_ROOT
from handlers.network_handlers import discover_droidnet_devices

# Get logger
logger = logging.getLogger(__name__)

# Known devices configuration file
KNOWN_DEVICES_FILE = CONFIG_DIR / "known-devices.json"

# Batch operation state files
BATCH_UPDATE_STATE_FILE = RUNTIME_DIR / "batch-update.json"
BATCH_FLASH_STATE_FILE = RUNTIME_DIR / "batch-flash.json"

# Thread lock for known devices file access
known_devices_lock = threading.Lock()

# Lock for batch state file access
batch_state_lock = threading.Lock()

# Configuration constants
MAX_FIRMWARE_SIZE = 16 * 1024 * 1024  # 16MB max firmware size
MAX_BATCH_DEVICES = 50  # Max devices per batch operation
VALID_BOARD_TYPES = ["auto", "arduino", "esp32", "esp8266"]

# Validation patterns
HOSTNAME_PATTERN = re.compile(r"^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?$")
SERIAL_PORT_PATTERN = re.compile(r"^(/dev/tty[A-Za-z]+\d+|COM\d+)$")
IP_PATTERN = re.compile(r"^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$")


def is_valid_hostname(hostname: str) -> bool:
    """Validate hostname format (alphanumeric with hyphens, max 63 chars per label)"""
    if not hostname or len(hostname) > 253:
        return False
    # Split by dots for FQDN support
    labels = hostname.split(".")
    return all(HOSTNAME_PATTERN.match(label) for label in labels)


def is_valid_ip(ip: str) -> bool:
    """Validate IPv4 address format and block dangerous addresses"""
    match = IP_PATTERN.match(ip)
    if not match:
        return False
    octets = [int(g) for g in match.groups()]
    # Check octet ranges
    if not all(0 <= o <= 255 for o in octets):
        return False
    # Block loopback (127.x.x.x)
    if octets[0] == 127:
        return False
    # Block meta-address (0.0.0.0)
    if all(o == 0 for o in octets):
        return False
    # Block link-local (169.254.x.x) - typically not DroidNet devices
    if octets[0] == 169 and octets[1] == 254:
        return False
    # Block multicast (224.0.0.0 - 239.255.255.255)
    if 224 <= octets[0] <= 239:
        return False
    # Block broadcast (255.255.255.255)
    if all(o == 255 for o in octets):
        return False
    # Block reserved/experimental (240.0.0.0 - 255.255.255.254)
    if octets[0] >= 240:
        return False
    return True


def validate_target(hostname: str, ip: str) -> Tuple[bool, str]:
    """Validate a target hostname and IP address for SSRF prevention"""
    if not is_valid_hostname(hostname):
        return False, f"Invalid hostname format: {hostname}"
    if not is_valid_ip(ip):
        return False, f"Invalid or blocked IP address: {ip}"
    return True, ""


def is_valid_board_type(board_type: str) -> bool:
    """Validate board type parameter"""
    return board_type in VALID_BOARD_TYPES


def is_valid_serial_port(port: str) -> bool:
    """Validate serial port format"""
    return bool(SERIAL_PORT_PATTERN.match(port))


def _load_known_devices_unlocked() -> Dict[str, Any]:
    """Load known devices from config file (must hold lock)"""
    if KNOWN_DEVICES_FILE.exists():
        try:
            with open(KNOWN_DEVICES_FILE, "r") as f:
                data = json.load(f)
                return data.get("devices", {})
        except (json.JSONDecodeError, IOError) as e:
            logger.error(f"Error loading known devices: {e}")
            return {}
    return {}


def _save_known_devices_unlocked(devices: Dict[str, Any]) -> bool:
    """Save known devices to config file (must hold lock)"""
    try:
        # Ensure config directory exists
        KNOWN_DEVICES_FILE.parent.mkdir(parents=True, exist_ok=True)

        data = {"version": 1, "devices": devices}
        with open(KNOWN_DEVICES_FILE, "w") as f:
            json.dump(data, f, indent=2)
        return True
    except IOError as e:
        logger.error(f"Error saving known devices: {e}")
        return False


def load_known_devices() -> Dict[str, Any]:
    """Load known devices from config file"""
    with known_devices_lock:
        return _load_known_devices_unlocked()


def save_known_devices(devices: Dict[str, Any]) -> bool:
    """Save known devices to config file"""
    with known_devices_lock:
        return _save_known_devices_unlocked(devices)


def save_known_device(hostname: str, ip: str, version: str, ap_mode: bool) -> bool:
    """Add or update a known device (atomic read-modify-write)"""
    with known_devices_lock:
        devices = _load_known_devices_unlocked()
        devices[hostname] = {
            "hostname": hostname,
            "last_seen": datetime.now(timezone.utc).isoformat(),
            "last_ip": ip,
            "last_version": version,
            "last_ap_mode": ap_mode,
        }
        return _save_known_devices_unlocked(devices)


def remove_known_device(hostname: str) -> bool:
    """Remove a device from known devices (atomic read-modify-write)"""
    with known_devices_lock:
        devices = _load_known_devices_unlocked()
        if hostname in devices:
            del devices[hostname]
            return _save_known_devices_unlocked(devices)
        return True


def query_device_status(ip: str, timeout: float = 3.0) -> Optional[Dict[str, Any]]:
    """Query a device's status endpoint"""
    try:
        url = f"http://{ip}/api/status"
        req = urllib.request.Request(url, method="GET")
        req.add_header("User-Agent", "DroidNet-Fleet/1.0")

        with urllib.request.urlopen(req, timeout=timeout) as response:
            if response.status == 200:
                return json.loads(response.read().decode())
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as e:
        logger.debug(f"Could not reach device at {ip}: {e}")
    except Exception as e:
        logger.debug(f"Error querying device at {ip}: {e}")
    return None


def query_device_info(ip: str, timeout: float = 3.0) -> Optional[Dict[str, Any]]:
    """Query a device's system-info endpoint for version"""
    try:
        url = f"http://{ip}/api/system-info"
        req = urllib.request.Request(url, method="GET")
        req.add_header("User-Agent", "DroidNet-Fleet/1.0")

        with urllib.request.urlopen(req, timeout=timeout) as response:
            if response.status == 200:
                data = json.loads(response.read().decode())
                # Version is nested at info.version in the response
                if "info" in data and "version" in data["info"]:
                    return {"version": data["info"]["version"]}
                return data
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as e:
        logger.debug(f"Could not get system info from {ip}: {e}")
    except Exception as e:
        logger.debug(f"Error getting system info from {ip}: {e}")
    return None


def query_device_usb(ip: str, timeout: float = 3.0) -> List[Dict[str, Any]]:
    """Query a device's USB devices"""
    try:
        url = f"http://{ip}/api/devices"
        req = urllib.request.Request(url, method="GET")
        req.add_header("User-Agent", "DroidNet-Fleet/1.0")

        with urllib.request.urlopen(req, timeout=timeout) as response:
            if response.status == 200:
                return json.loads(response.read().decode())
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as e:
        logger.debug(f"Could not get USB devices from {ip}: {e}")
    except Exception as e:
        logger.debug(f"Error getting USB devices from {ip}: {e}")
    return []


def query_device_update_available(ip: str, timeout: float = 5.0) -> Optional[bool]:
    """Check if a device has an update available"""
    try:
        url = f"http://{ip}/api/system/update-available"
        req = urllib.request.Request(url, method="GET")
        req.add_header("User-Agent", "DroidNet-Fleet/1.0")

        with urllib.request.urlopen(req, timeout=timeout) as response:
            if response.status == 200:
                data = json.loads(response.read().decode())
                return data.get("update_available", False)
    except Exception as e:
        logger.debug(f"Could not check update availability from {ip}: {e}")
    return None


def query_device_extended_status(ip: str, timeout: float = 3.0) -> Optional[Dict[str, Any]]:
    """Query a device's status endpoint for uptime, load, etc.

    Returns normalized data with:
    - uptime: seconds
    - cpu_load: load average (0-100 scale based on cores)
    """
    # The /api/status endpoint returns: uptime (seconds), load (load average), pi_model
    # We already call this in query_device_status, so we can reuse that data
    # This function is kept for explicit extended status queries if needed
    try:
        url = f"http://{ip}/api/status"
        req = urllib.request.Request(url, method="GET")
        req.add_header("User-Agent", "DroidNet-Fleet/1.0")

        with urllib.request.urlopen(req, timeout=timeout) as response:
            if response.status == 200:
                return json.loads(response.read().decode())
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as e:
        logger.debug(f"Could not get extended status from {ip}: {e}")
    except Exception as e:
        logger.debug(f"Error getting extended status from {ip}: {e}")
    return None


def query_device_services(ip: str, timeout: float = 3.0) -> Dict[str, bool]:
    """Query a device's enabled services via the lightweight services endpoint.

    Returns dict with victron, comlink, virtualhere keys indicating if enabled.
    """
    try:
        url = f"http://{ip}/api/services/status"
        req = urllib.request.Request(url, method="GET")
        req.add_header("User-Agent", "DroidNet-Fleet/1.0")

        with urllib.request.urlopen(req, timeout=timeout) as response:
            if response.status == 200:
                return json.loads(response.read().decode())
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as e:
        logger.debug(f"Could not get services from {ip}: {e}")
    except Exception as e:
        logger.debug(f"Error getting services from {ip}: {e}")
    return {}


def query_single_device(hostname: str, ip: str, is_current: bool) -> Dict[str, Any]:
    """Query all relevant info for a single device"""
    device_data = {
        "hostname": hostname,
        "ip": ip,
        "is_current": is_current,
        "online": False,
        "network_mode": None,
        "version": None,
        "usb_devices": [],
        "update_available": None,
        "last_seen": None,
        # Extended info
        "cpu_usage": 0,
        "uptime": 0,
        "services": {},
    }

    # Get status - this returns uptime, load, ap_mode, pi_model
    status = query_device_status(ip)
    if status:
        device_data["online"] = True
        device_data["network_mode"] = "ap" if status.get("ap_mode", False) else "client"
        # Extract uptime (in seconds) and load from status
        device_data["uptime"] = status.get("uptime", 0)
        # Convert load average to approximate CPU percentage
        # Load of 1.0 on a 4-core Pi = 25% per core, we'll cap at 100%
        load = status.get("load", 0)
        device_data["cpu_usage"] = min(100, int(load * 25))  # Rough approximation

    # Get version from system-info
    if device_data["online"]:
        info = query_device_info(ip)
        if info:
            device_data["version"] = info.get("version")

    # Get USB devices
    if device_data["online"]:
        usb = query_device_usb(ip)
        # Simplify USB data for display
        device_data["usb_devices"] = [
            {
                "port": d.get("port"),
                "type": d.get("type", "unknown"),
                "name": d.get("name", d.get("product_name", "Unknown")),
                "vendor_id": d.get("vendor_id", ""),
                "product_id": d.get("product_id", ""),
            }
            for d in usb
            if d.get("port")
        ]

    # Check for updates
    if device_data["online"]:
        device_data["update_available"] = query_device_update_available(ip)

    # Services status - query which services are enabled
    if device_data["online"]:
        device_data["services"] = query_device_services(ip)

    return device_data


def get_aggregate_status() -> Dict[str, Any]:
    """
    Get aggregated status of all DroidNet devices.
    Merges mDNS discovery with known devices.
    """
    current_hostname = socket.gethostname()

    # Step 1: Load known devices
    known = load_known_devices()

    # Step 2: Run mDNS discovery
    discovery_result = discover_droidnet_devices()
    discovered = {d["hostname"]: d for d in discovery_result.get("devices", [])}

    # Step 3: Merge discovered with known
    # - Update known devices that were discovered
    # - Add newly discovered devices
    # - Keep offline known devices
    all_hostnames = set(known.keys()) | set(discovered.keys())

    # Step 4: Query each device in parallel (with IP validation)
    devices_to_query = []
    for hostname in all_hostnames:
        if hostname in discovered:
            ip = discovered[hostname]["ip"]
            # Validate discovered IP to prevent SSRF
            if is_valid_ip(ip) and is_valid_hostname(hostname):
                devices_to_query.append(
                    (hostname, ip, discovered[hostname]["is_current"])
                )
            else:
                logger.warning(f"Skipping device with invalid hostname/IP: {hostname}/{ip}")
        elif hostname in known:
            # Try last known IP for offline devices (with validation)
            last_ip = known[hostname].get("last_ip", "")
            if last_ip and is_valid_ip(last_ip) and is_valid_hostname(hostname):
                devices_to_query.append((hostname, last_ip, False))

    results = []
    with ThreadPoolExecutor(max_workers=5) as executor:
        future_to_host = {
            executor.submit(query_single_device, h, ip, is_curr): h
            for h, ip, is_curr in devices_to_query
        }
        for future in as_completed(future_to_host):
            hostname = future_to_host[future]
            try:
                device_data = future.result()

                # Add last_seen from known devices if offline
                if not device_data["online"] and hostname in known:
                    device_data["last_seen"] = known[hostname].get("last_seen")

                # Update known devices with online devices
                if device_data["online"]:
                    save_known_device(
                        hostname,
                        device_data["ip"],
                        device_data.get("version", "unknown"),
                        device_data.get("network_mode") == "ap",
                    )

                results.append(device_data)
            except Exception as e:
                logger.error(f"Error querying {hostname}: {e}")
                results.append(
                    {
                        "hostname": hostname,
                        "ip": known.get(hostname, {}).get("last_ip", ""),
                        "online": False,
                        "is_current": False,
                        "last_seen": known.get(hostname, {}).get("last_seen"),
                    }
                )

    # Sort: current first, then online before offline, then alphabetically
    results.sort(
        key=lambda d: (
            not d.get("is_current", False),
            not d.get("online", False),
            d["hostname"].lower(),
        )
    )

    return {
        "success": True,
        "devices": results,
        "current_hostname": current_hostname,
        "timestamp": time.time(),
    }


def query_update_info(hostname: str, ip: str) -> Optional[Dict[str, Any]]:
    """Query just the update-related info for a device (lightweight)"""
    # Check if device is online
    status = query_device_status(ip)
    if not status:
        return None

    # Get version
    info = query_device_info(ip)
    version = info.get("version") if info else None

    # Check update availability
    update_available = query_device_update_available(ip)

    return {
        "hostname": hostname,
        "ip": ip,
        "online": True,
        "version": version,
        "update_available": update_available or False,
    }


def get_updates_summary() -> Dict[str, Any]:
    """Get update availability summary for all known devices.

    Independent of full device status - lightweight for Updates section.
    Returns only online devices with their update status.
    """
    known = load_known_devices()

    # Also check discovered devices
    discovery_result = discover_droidnet_devices()
    discovered = {d["hostname"]: d for d in discovery_result.get("devices", [])}

    all_hostnames = set(known.keys()) | set(discovered.keys())

    results = []
    with ThreadPoolExecutor(max_workers=5) as executor:
        futures = {}
        for hostname in all_hostnames:
            ip = None
            if hostname in discovered:
                ip = discovered[hostname]["ip"]
            elif hostname in known:
                ip = known[hostname].get("last_ip")

            if ip and is_valid_ip(ip) and is_valid_hostname(hostname):
                futures[executor.submit(query_update_info, hostname, ip)] = hostname

        for future in as_completed(futures):
            hostname = futures[future]
            try:
                result = future.result()
                if result:
                    results.append(result)
            except Exception as e:
                logger.debug(f"Error checking updates for {hostname}: {e}")

    # Sort alphabetically by hostname
    results.sort(key=lambda d: d["hostname"].lower())

    return {
        "success": True,
        "devices": results,
        "timestamp": time.time(),
    }


def trigger_remote_update(hostname: str, ip: str) -> Dict[str, Any]:
    """Trigger an update check/download on a remote device"""
    # Validate inputs to prevent SSRF
    valid, error = validate_target(hostname, ip)
    if not valid:
        return {"success": False, "hostname": hostname, "error": error}

    try:
        url = f"http://{ip}/api/system/update"
        data = json.dumps({"action": "check_and_update"}).encode("utf-8")
        req = urllib.request.Request(url, data=data, method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("User-Agent", "DroidNet-Fleet/1.0")

        with urllib.request.urlopen(req, timeout=30) as response:
            if response.status == 200:
                result = json.loads(response.read().decode())
                return {"success": True, "hostname": hostname, "result": result}
    except urllib.error.URLError as e:
        return {
            "success": False,
            "hostname": hostname,
            "error": f"Connection failed: {e}",
        }
    except TimeoutError:
        return {"success": False, "hostname": hostname, "error": "Request timed out"}
    except Exception as e:
        return {"success": False, "hostname": hostname, "error": str(e)}
    return {"success": False, "hostname": hostname, "error": "Unknown error"}


def get_remote_update_status(ip: str) -> Optional[Dict[str, Any]]:
    """Get update status from a remote device"""
    try:
        url = f"http://{ip}/api/system/update-status"
        req = urllib.request.Request(url, method="GET")
        req.add_header("User-Agent", "DroidNet-Fleet/1.0")

        with urllib.request.urlopen(req, timeout=5) as response:
            if response.status == 200:
                return json.loads(response.read().decode())
    except Exception as e:
        logger.debug(f"Could not get update status from {ip}: {e}")
    return None


def start_batch_update(devices: List[Dict[str, str]]) -> Dict[str, Any]:
    """
    Start a batch update across multiple devices.
    UI host device updates last to maintain connection.
    """
    # Validate devices list
    if not devices:
        return {"success": False, "error": "No devices specified"}
    if len(devices) > MAX_BATCH_DEVICES:
        return {"success": False, "error": f"Too many devices (max {MAX_BATCH_DEVICES})"}

    # Validate all devices before starting
    for device in devices:
        valid, error = validate_target(device.get("hostname", ""), device.get("ip", ""))
        if not valid:
            return {"success": False, "error": error}

    current_hostname = socket.gethostname()

    # Sort devices: UI host last
    update_order = sorted(
        devices,
        key=lambda d: (1 if d["hostname"] == current_hostname else 0, d["hostname"]),
    )

    batch_id = f"batch-{int(time.time())}"
    batch_state = {
        "batch_id": batch_id,
        "devices": {
            d["hostname"]: {"status": "pending", "progress": 0, "ip": d["ip"]}
            for d in update_order
        },
        "order": [d["hostname"] for d in update_order],
        "current_index": 0,
        "started_at": time.time(),
        "ui_host": current_hostname,
    }

    # Save initial state
    try:
        RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
        with open(BATCH_UPDATE_STATE_FILE, "w") as f:
            json.dump(batch_state, f)
    except IOError as e:
        return {"success": False, "error": f"Could not save batch state: {e}"}

    # Start background thread for batch updates
    thread = threading.Thread(
        target=_execute_batch_update, args=(batch_state,), daemon=True
    )
    thread.start()

    return {
        "success": True,
        "batch_id": batch_id,
        "order": [d["hostname"] for d in update_order],
        "ui_host_last": update_order[-1]["hostname"] == current_hostname
        if update_order
        else False,
    }


def _execute_batch_update(batch_state: Dict[str, Any]) -> None:
    """Execute batch update in background thread"""
    for i, hostname in enumerate(batch_state["order"]):
        device_info = batch_state["devices"][hostname]
        ip = device_info["ip"]

        # Update state to in_progress
        batch_state["current_index"] = i
        batch_state["devices"][hostname]["status"] = "in_progress"
        _save_batch_state(batch_state, BATCH_UPDATE_STATE_FILE)

        # Trigger update
        result = trigger_remote_update(hostname, ip)

        if result.get("success"):
            # Poll for completion
            max_wait = 300  # 5 minutes max
            start_time = time.time()
            while time.time() - start_time < max_wait:
                status = get_remote_update_status(ip)
                if status:
                    progress = status.get("progress", 0)
                    batch_state["devices"][hostname]["progress"] = progress
                    _save_batch_state(batch_state, BATCH_UPDATE_STATE_FILE)

                    if status.get("completed"):
                        batch_state["devices"][hostname]["status"] = "complete"
                        batch_state["devices"][hostname]["progress"] = 100
                        break
                    elif status.get("error"):
                        batch_state["devices"][hostname]["status"] = "failed"
                        batch_state["devices"][hostname]["error"] = status.get("error")
                        break
                time.sleep(2)
            else:
                # Timeout
                batch_state["devices"][hostname]["status"] = "timeout"
        else:
            batch_state["devices"][hostname]["status"] = "failed"
            batch_state["devices"][hostname]["error"] = result.get(
                "error", "Unknown error"
            )

        _save_batch_state(batch_state, BATCH_UPDATE_STATE_FILE)

    # Mark batch as complete
    batch_state["completed_at"] = time.time()
    _save_batch_state(batch_state, BATCH_UPDATE_STATE_FILE)


def _save_batch_state(state: Dict[str, Any], filepath: Path) -> None:
    """Save batch operation state atomically with locking"""
    with batch_state_lock:
        try:
            filepath.parent.mkdir(parents=True, exist_ok=True)
            # Write to temp file first, then atomic rename
            temp_path = filepath.with_suffix(".tmp")
            with open(temp_path, "w") as f:
                json.dump(state, f)
            temp_path.replace(filepath)  # Atomic on POSIX
        except IOError as e:
            logger.error(f"Could not save batch state: {e}")


def get_batch_update_status() -> Dict[str, Any]:
    """Get current batch update status"""
    try:
        if BATCH_UPDATE_STATE_FILE.exists():
            with open(BATCH_UPDATE_STATE_FILE, "r") as f:
                return json.load(f)
    except (IOError, json.JSONDecodeError) as e:
        logger.error(f"Error reading batch update status: {e}")
    return {}


def trigger_remote_flash(
    hostname: str, ip: str, port: str, firmware_data: bytes, board_type: str = "auto"
) -> Dict[str, Any]:
    """Trigger a firmware flash on a remote device"""
    # Validate inputs to prevent SSRF
    valid, error = validate_target(hostname, ip)
    if not valid:
        return {"success": False, "hostname": hostname, "error": error}

    # Validate board type and port
    if not is_valid_board_type(board_type):
        return {"success": False, "hostname": hostname, "error": "Invalid board type"}
    if not is_valid_serial_port(port):
        return {"success": False, "hostname": hostname, "error": "Invalid serial port"}

    try:
        url = f"http://{ip}/api/flash"

        # Build multipart form data
        boundary = "----DroidNetFlashBoundary"
        body = []

        # Add device_port field
        body.append(f"--{boundary}".encode())
        body.append(b'Content-Disposition: form-data; name="device_port"')
        body.append(b"")
        body.append(port.encode())

        # Add board_type field
        body.append(f"--{boundary}".encode())
        body.append(b'Content-Disposition: form-data; name="board_type"')
        body.append(b"")
        body.append(board_type.encode())

        # Add firmware file
        body.append(f"--{boundary}".encode())
        body.append(
            b'Content-Disposition: form-data; name="firmware_file"; filename="firmware.bin"'
        )
        body.append(b"Content-Type: application/octet-stream")
        body.append(b"")
        body.append(firmware_data)

        body.append(f"--{boundary}--".encode())

        body_bytes = b"\r\n".join(body)

        req = urllib.request.Request(url, data=body_bytes, method="POST")
        req.add_header("Content-Type", f"multipart/form-data; boundary={boundary}")
        req.add_header("User-Agent", "DroidNet-Fleet/1.0")

        with urllib.request.urlopen(req, timeout=120) as response:
            if response.status == 200:
                result = json.loads(response.read().decode())
                return {"success": True, "hostname": hostname, "result": result}
    except urllib.error.URLError as e:
        return {
            "success": False,
            "hostname": hostname,
            "error": f"Connection failed: {e}",
        }
    except TimeoutError:
        return {"success": False, "hostname": hostname, "error": "Flash timed out"}
    except Exception as e:
        return {"success": False, "hostname": hostname, "error": str(e)}
    return {"success": False, "hostname": hostname, "error": "Unknown error"}


def start_batch_flash(
    targets: List[Dict[str, Any]], firmware_data: bytes, board_type: str = "auto"
) -> Dict[str, Any]:
    """
    Start a batch firmware flash across multiple devices.
    Flashes in parallel.
    """
    # Validate targets list
    if not targets:
        return {"success": False, "error": "No targets specified"}
    if len(targets) > MAX_BATCH_DEVICES:
        return {"success": False, "error": f"Too many targets (max {MAX_BATCH_DEVICES})"}

    # Validate firmware size
    if not firmware_data:
        return {"success": False, "error": "Firmware data is empty"}
    if len(firmware_data) > MAX_FIRMWARE_SIZE:
        return {"success": False, "error": f"Firmware too large (max {MAX_FIRMWARE_SIZE // (1024*1024)}MB)"}

    # Validate board type
    if not is_valid_board_type(board_type):
        return {"success": False, "error": f"Invalid board type: {board_type}"}

    # Validate all targets before starting
    for target in targets:
        valid, error = validate_target(target.get("hostname", ""), target.get("ip", ""))
        if not valid:
            return {"success": False, "error": error}
        # Validate serial port
        port = target.get("port", "")
        if not is_valid_serial_port(port):
            return {"success": False, "error": f"Invalid serial port: {port}"}

    batch_id = f"flash-{int(time.time())}"
    batch_state = {
        "batch_id": batch_id,
        "devices": {
            f"{t['hostname']}:{t['port']}": {
                "status": "pending",
                "progress": 0,
                "hostname": t["hostname"],
                "ip": t["ip"],
                "port": t["port"],
            }
            for t in targets
        },
        "started_at": time.time(),
        "board_type": board_type,
    }

    # Save initial state
    try:
        RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
        with open(BATCH_FLASH_STATE_FILE, "w") as f:
            json.dump(batch_state, f)
    except IOError as e:
        return {"success": False, "error": f"Could not save batch state: {e}"}

    # Start background thread for parallel flashing
    thread = threading.Thread(
        target=_execute_batch_flash,
        args=(batch_state, firmware_data, board_type),
        daemon=True,
    )
    thread.start()

    return {
        "success": True,
        "batch_id": batch_id,
        "targets": [f"{t['hostname']}:{t['port']}" for t in targets],
    }


def _execute_batch_flash(
    batch_state: Dict[str, Any], firmware_data: bytes, board_type: str
) -> None:
    """Execute batch flash in parallel"""
    targets = list(batch_state["devices"].values())

    # Cap workers to prevent resource exhaustion (max 10 concurrent flashes)
    with ThreadPoolExecutor(max_workers=min(len(targets), 10)) as executor:
        future_to_target = {
            executor.submit(
                trigger_remote_flash,
                t["hostname"],
                t["ip"],
                t["port"],
                firmware_data,
                board_type,
            ): f"{t['hostname']}:{t['port']}"
            for t in targets
        }

        for future in as_completed(future_to_target):
            target_key = future_to_target[future]
            try:
                result = future.result()
                if result.get("success"):
                    flash_result = result.get("result", {})
                    if flash_result.get("success"):
                        batch_state["devices"][target_key]["status"] = "complete"
                        batch_state["devices"][target_key]["progress"] = 100
                    else:
                        batch_state["devices"][target_key]["status"] = "failed"
                        batch_state["devices"][target_key]["error"] = flash_result.get(
                            "message", "Flash failed"
                        )
                else:
                    batch_state["devices"][target_key]["status"] = "failed"
                    batch_state["devices"][target_key]["error"] = result.get(
                        "error", "Unknown error"
                    )
            except Exception as e:
                batch_state["devices"][target_key]["status"] = "failed"
                batch_state["devices"][target_key]["error"] = str(e)

            _save_batch_state(batch_state, BATCH_FLASH_STATE_FILE)

    # Mark batch as complete
    batch_state["completed_at"] = time.time()
    _save_batch_state(batch_state, BATCH_FLASH_STATE_FILE)


def get_batch_flash_status() -> Dict[str, Any]:
    """Get current batch flash status"""
    try:
        if BATCH_FLASH_STATE_FILE.exists():
            with open(BATCH_FLASH_STATE_FILE, "r") as f:
                return json.load(f)
    except (IOError, json.JSONDecodeError) as e:
        logger.error(f"Error reading batch flash status: {e}")
    return {}
