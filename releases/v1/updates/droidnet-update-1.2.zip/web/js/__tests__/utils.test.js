/**
 * Unit tests for JavaScript utility functions.
 *
 * Tests pure utility functions from utils.js that don't require DOM or network access.
 */

const fs = require('fs');
const path = require('path');
const vm = require('vm');

// Load utils.js into the test environment
const utilsPath = path.join(__dirname, '..', 'utils.js');
const utilsCode = fs.readFileSync(utilsPath, 'utf8');

// Create a sandboxed context with window object
const context = {
    window: { DroidNet: {} },
    console: console,
    setTimeout: setTimeout,
    clearTimeout: clearTimeout,
    Math: Math,
    Date: Date,
    String: String,
    JSON: JSON,
    parseInt: parseInt,
    parseFloat: parseFloat,
    isNaN: isNaN
};
vm.createContext(context);

// Execute utils.js in the sandboxed context
vm.runInContext(utilsCode, context);

// Get references to the utility functions from the context
const {
    escapeHtml,
    formatBytes,
    formatUptime,
    parseSerialPort,
    isValidIPAddress,
    debounce,
    clamp,
    getDeviceDisplayName,
    throttle,
    formatRelativeTime,
    deepClone,
    generateId
} = context.window.DroidNet.utils;

// ============================================================
// TESTS
// ============================================================

describe('getDeviceDisplayName', () => {
    test('returns custom name when available', () => {
        const device = { unique_id: 'arduino-123', name: 'Arduino Uno' };
        const customNames = { 'arduino-123': 'My Arduino' };

        expect(getDeviceDisplayName(device, customNames)).toBe('My Arduino');
    });

    test('returns device name when no custom name', () => {
        const device = { unique_id: 'arduino-123', name: 'Arduino Uno' };
        const customNames = {};

        expect(getDeviceDisplayName(device, customNames)).toBe('Arduino Uno');
    });

    test('returns Unknown Device when no name available', () => {
        const device = { vendor_id: '2341', product_id: '0043' };
        const customNames = {};

        expect(getDeviceDisplayName(device, customNames)).toBe('Unknown Device');
    });

    test('uses vendor:product as fallback ID', () => {
        const device = { vendor_id: '2341', product_id: '0043', name: 'Test' };
        const customNames = { '2341:0043': 'Custom Name' };

        expect(getDeviceDisplayName(device, customNames)).toBe('Custom Name');
    });

    test('handles null customNames', () => {
        const device = { name: 'Test Device' };

        expect(getDeviceDisplayName(device, null)).toBe('Test Device');
    });
});

describe('formatBytes', () => {
    test('formats 0 bytes', () => {
        expect(formatBytes(0)).toBe('0 Bytes');
    });

    test('formats bytes', () => {
        expect(formatBytes(500)).toBe('500 Bytes');
    });

    test('formats kilobytes', () => {
        expect(formatBytes(1024)).toBe('1 KB');
        expect(formatBytes(2048)).toBe('2 KB');
    });

    test('formats megabytes', () => {
        expect(formatBytes(1048576)).toBe('1 MB');
    });

    test('formats gigabytes', () => {
        expect(formatBytes(1073741824)).toBe('1 GB');
    });

    test('respects decimals parameter', () => {
        expect(formatBytes(1536, 1)).toBe('1.5 KB');
        expect(formatBytes(1536, 0)).toBe('2 KB');
    });

    test('handles null/undefined', () => {
        expect(formatBytes(null)).toBe('N/A');
        expect(formatBytes(undefined)).toBe('N/A');
    });
});

describe('formatUptime', () => {
    test('formats seconds only', () => {
        expect(formatUptime(45)).toBe('45s');
    });

    test('formats minutes and seconds', () => {
        expect(formatUptime(125)).toBe('2m 5s');
    });

    test('formats hours', () => {
        expect(formatUptime(3665)).toBe('1h 1m 5s');
    });

    test('formats days', () => {
        expect(formatUptime(90061)).toBe('1d 1h 1m 1s');
    });

    test('handles zero', () => {
        expect(formatUptime(0)).toBe('0s');
    });

    test('handles exact hours', () => {
        expect(formatUptime(3600)).toBe('1h');
    });

    test('handles null/undefined', () => {
        expect(formatUptime(null)).toBe('N/A');
        expect(formatUptime(undefined)).toBe('N/A');
    });
});

describe('parseSerialPort', () => {
    test('parses ttyACM devices', () => {
        expect(parseSerialPort('/dev/ttyACM0')).toBe('ttyACM0');
        expect(parseSerialPort('/dev/ttyACM1')).toBe('ttyACM1');
    });

    test('parses ttyUSB devices', () => {
        expect(parseSerialPort('/dev/ttyUSB0')).toBe('ttyUSB0');
    });

    test('parses ttyS devices', () => {
        expect(parseSerialPort('/dev/ttyS0')).toBe('ttyS0');
    });

    test('returns null for invalid paths', () => {
        expect(parseSerialPort('/dev/sda1')).toBeNull();
        expect(parseSerialPort('COM1')).toBeNull();
    });

    test('handles null/undefined', () => {
        expect(parseSerialPort(null)).toBeNull();
        expect(parseSerialPort(undefined)).toBeNull();
    });
});

describe('isValidIPAddress', () => {
    test('validates correct IP addresses', () => {
        expect(isValidIPAddress('192.168.1.1')).toBe(true);
        expect(isValidIPAddress('10.0.0.1')).toBe(true);
        expect(isValidIPAddress('255.255.255.255')).toBe(true);
        expect(isValidIPAddress('0.0.0.0')).toBe(true);
    });

    test('rejects invalid IP addresses', () => {
        expect(isValidIPAddress('256.1.1.1')).toBe(false);
        expect(isValidIPAddress('192.168.1')).toBe(false);
        expect(isValidIPAddress('192.168.1.1.1')).toBe(false);
        expect(isValidIPAddress('abc.def.ghi.jkl')).toBe(false);
        expect(isValidIPAddress('')).toBe(false);
    });

    test('handles null/undefined', () => {
        expect(isValidIPAddress(null)).toBe(false);
        expect(isValidIPAddress(undefined)).toBe(false);
    });
});

describe('escapeHtml', () => {
    test('escapes HTML special characters', () => {
        expect(escapeHtml('<script>')).toBe('&lt;script&gt;');
        expect(escapeHtml('"quoted"')).toBe('&quot;quoted&quot;');
        expect(escapeHtml("it's")).toBe("it&#039;s");
        expect(escapeHtml('a & b')).toBe('a &amp; b');
    });

    test('leaves safe text unchanged', () => {
        expect(escapeHtml('Hello World')).toBe('Hello World');
        expect(escapeHtml('123')).toBe('123');
    });

    test('handles empty string', () => {
        expect(escapeHtml('')).toBe('');
    });

    test('handles null/undefined', () => {
        expect(escapeHtml(null)).toBe('');
        expect(escapeHtml(undefined)).toBe('');
    });
});

describe('clamp', () => {
    test('clamps value below min', () => {
        expect(clamp(-5, 0, 100)).toBe(0);
    });

    test('clamps value above max', () => {
        expect(clamp(150, 0, 100)).toBe(100);
    });

    test('returns value within range', () => {
        expect(clamp(50, 0, 100)).toBe(50);
    });

    test('handles edge cases', () => {
        expect(clamp(0, 0, 100)).toBe(0);
        expect(clamp(100, 0, 100)).toBe(100);
    });
});

describe('debounce', () => {
    // Note: These tests use real timers because the debounce function
    // runs in a VM context with its own setTimeout reference.
    // The function is tested with short delays for fast execution.

    test('delays function execution', (done) => {
        const func = jest.fn();
        const debouncedFunc = debounce(func, 10);

        debouncedFunc();
        expect(func).not.toBeCalled();

        setTimeout(() => {
            expect(func).toBeCalled();
            done();
        }, 20);
    });

    test('only calls function once for rapid calls', (done) => {
        const func = jest.fn();
        const debouncedFunc = debounce(func, 10);

        debouncedFunc();
        debouncedFunc();
        debouncedFunc();

        setTimeout(() => {
            expect(func).toBeCalledTimes(1);
            done();
        }, 20);
    });
});

describe('throttle', () => {
    test('calls function immediately on first call', () => {
        const func = jest.fn();
        const throttledFunc = throttle(func, 100);

        throttledFunc();
        expect(func).toBeCalledTimes(1);
    });

    test('ignores calls within throttle period', () => {
        const func = jest.fn();
        const throttledFunc = throttle(func, 100);

        throttledFunc();
        throttledFunc();
        throttledFunc();

        expect(func).toBeCalledTimes(1);
    });

    test('allows call after throttle period', (done) => {
        const func = jest.fn();
        const throttledFunc = throttle(func, 10);

        throttledFunc();
        setTimeout(() => {
            throttledFunc();
            expect(func).toBeCalledTimes(2);
            done();
        }, 20);
    });
});

describe('deepClone', () => {
    test('clones nested objects', () => {
        const original = { a: { b: { c: 1 } } };
        const cloned = deepClone(original);

        expect(cloned).toEqual(original);
        expect(cloned).not.toBe(original);
        expect(cloned.a).not.toBe(original.a);
    });

    test('clones arrays', () => {
        const original = [1, [2, 3], { a: 4 }];
        const cloned = deepClone(original);

        expect(cloned).toEqual(original);
        expect(cloned).not.toBe(original);
    });

    test('handles primitives', () => {
        expect(deepClone(42)).toBe(42);
        expect(deepClone('string')).toBe('string');
        expect(deepClone(null)).toBe(null);
    });
});

describe('generateId', () => {
    test('generates unique IDs', () => {
        const id1 = generateId();
        const id2 = generateId();

        expect(id1).not.toBe(id2);
    });

    test('includes prefix when provided', () => {
        const id = generateId('test');

        expect(id.startsWith('test-')).toBe(true);
    });

    test('works without prefix', () => {
        const id = generateId();

        expect(typeof id).toBe('string');
        expect(id.length).toBeGreaterThan(0);
    });
});
