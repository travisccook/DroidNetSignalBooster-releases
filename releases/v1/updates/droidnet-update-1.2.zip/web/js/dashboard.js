/**
 * Dashboard Component
 * Handles fetching and displaying real-time system status
 */

(function() {
    'use strict';

    // Configuration - hardware-adaptive polling intervals
    const POLL_INTERVALS = {
        'pi_zero_w': 15000,  // 15 seconds - very constrained CPU
        'pi_zero_2': 10000,  // 10 seconds - moderate CPU
        'pi_3': 5000,        // 5 seconds - capable
        'pi_4': 5000,        // 5 seconds - powerful
        'unknown': 10000     // 10 seconds - safe default
    };
    let dashboardPollInterval = POLL_INTERVALS['unknown'];  // Will be updated on first fetch
    let dashboardPollTimer = null;
    let isPolling = false;
    let piModelDetected = false;

    // Mini charts for system metrics
    let miniCharts = {
        cpu: null,
        memory: null,
        disk: null,
        temperature: null
    };

    // Expanded chart for modal view
    let expandedChart = null;

    // Current history data for expanded chart
    let currentHistory = null;

    // Expanded process panels state
    let expandedPanels = new Set();

    // Track if chart click handlers have been initialized
    let chartClickHandlersInitialized = false;

    // Track if tab button listeners have been initialized
    let tabButtonListenersInitialized = false;

    // Service name mapping for display
    const SERVICE_MAPPING = {
        web_server: { id: 'web', name: 'Web Server' },
        virtualhere: { id: 'vh', name: 'VirtualHere' },
        comlink: { id: 'comlink', name: 'Comlink' },
        network_controller: { id: 'network', name: 'Network Controller' },
        hostapd: { id: 'hostapd', name: 'Access Point' },
        dnsmasq: { id: 'dnsmasq', name: 'DNS/DHCP' },
        monitor: { id: 'monitor', name: 'Monitor' },
        avahi: { id: 'avahi', name: 'mDNS (Avahi)' },
        rfkill: { id: 'rfkill', name: 'RF Unblock' },
        bluetooth: { id: 'bluetooth', name: 'Bluetooth' },
        victron: { id: 'victron', name: 'Victron BLE' },
        display: { id: 'display', name: 'Display (HDMI)' }
    };

    /**
     * Initialize the dashboard
     */
    function initDashboard() {
        console.log('Dashboard: Initializing...');

        // Start polling when dashboard tab is visible
        if (isDashboardVisible()) {
            startDashboardPolling();
        }

        // Listen for tab changes (support both old and new class names)
        // Only add listeners once to prevent memory leaks
        if (!tabButtonListenersInitialized) {
            document.querySelectorAll('.nav-tab, .tab-button').forEach(btn => {
                btn.addEventListener('click', function() {
                    if (this.textContent.trim() === 'Dashboard') {
                        startDashboardPolling();
                    } else {
                        stopDashboardPolling();
                    }
                });
            });
            tabButtonListenersInitialized = true;
        }

        // Initial fetch
        fetchDashboardStatus();
    }

    /**
     * Check if dashboard tab is currently visible
     */
    function isDashboardVisible() {
        const dashboardTab = document.getElementById('dashboard-tab');
        return dashboardTab && dashboardTab.classList.contains('active');
    }

    /**
     * Start polling for dashboard updates
     */
    function startDashboardPolling() {
        if (isPolling) return;

        console.log('Dashboard: Starting polling at ' + dashboardPollInterval + 'ms interval');
        isPolling = true;
        fetchDashboardStatus();

        dashboardPollTimer = setInterval(function() {
            if (isDashboardVisible()) {
                fetchDashboardStatus();
            }
        }, dashboardPollInterval);
    }

    /**
     * Stop polling for dashboard updates
     */
    function stopDashboardPolling() {
        if (!isPolling) return;

        console.log('Dashboard: Stopping polling');
        isPolling = false;

        if (dashboardPollTimer) {
            clearInterval(dashboardPollTimer);
            dashboardPollTimer = null;
        }
    }

    /**
     * Fetch dashboard status from API
     */
    function fetchDashboardStatus() {
        fetch('/api/dashboard/status')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                if (data.error) {
                    console.error('Dashboard API error:', data.error);
                    return;
                }

                // Detect Pi model and adjust polling interval on first fetch
                if (!piModelDetected && data.system && data.system.pi_model) {
                    const model = data.system.pi_model;
                    const newInterval = POLL_INTERVALS[model] || POLL_INTERVALS['unknown'];
                    if (newInterval !== dashboardPollInterval) {
                        console.log('Dashboard: Detected ' + model + ', adjusting poll interval to ' + newInterval + 'ms');
                        dashboardPollInterval = newInterval;
                        // Restart polling with new interval
                        if (isPolling) {
                            stopDashboardPolling();
                            startDashboardPolling();
                        }
                    }
                    piModelDetected = true;
                    // Expose pi_model globally for other components
                    window.droidnetPiModel = model;
                }

                updateDashboard(data);
            })
            .catch(error => {
                console.error('Dashboard fetch error:', error);
            });
    }

    /**
     * Update all dashboard elements with new data
     */
    function updateDashboard(data) {
        updateSystemHealth(data.system);
        updateUptime(data.system);
        updateNetwork(data.network);
        updateServices(data.services);
        updateDevices(data.devices);
    }

    /**
     * Update system health metrics
     */
    function updateSystemHealth(system) {
        if (!system) return;

        // CPU
        const cpuBar = document.getElementById('cpu-bar');
        const cpuValue = document.getElementById('cpu-value');
        if (cpuBar && cpuValue) {
            const cpu = system.cpu_usage || 0;
            cpuBar.style.width = cpu + '%';
            cpuValue.textContent = cpu + '%';
            cpuBar.className = 'metric-bar-fill ' + getBarClass(cpu, 60, 80);
        }

        // Memory
        const memBar = document.getElementById('memory-bar');
        const memValue = document.getElementById('memory-value');
        if (memBar && memValue && system.memory) {
            const mem = system.memory.percentage || 0;
            memBar.style.width = mem + '%';
            memValue.textContent = mem + '%';
            memBar.className = 'metric-bar-fill ' + getBarClass(mem, 70, 85);
        }

        // Disk
        const diskBar = document.getElementById('disk-bar');
        const diskValue = document.getElementById('disk-value');
        if (diskBar && diskValue && system.disk) {
            const disk = system.disk.percentage || 0;
            diskBar.style.width = disk + '%';
            diskValue.textContent = disk + '%';
            diskBar.className = 'metric-bar-fill ' + getBarClass(disk, 70, 85);
        }

        // Temperature
        const tempBar = document.getElementById('temp-bar');
        const tempValue = document.getElementById('temp-value');
        if (tempBar && tempValue) {
            const temp = system.temperature || 0;
            // Temperature bar: 0-85C range, so percentage = (temp/85)*100
            const tempPercent = Math.min(100, (temp / 85) * 100);
            tempBar.style.width = tempPercent + '%';
            tempValue.textContent = temp.toFixed(1) + '\u00B0C';
            tempBar.className = 'metric-bar-fill ' + getBarClass(temp, 60, 70);
        }

        // Health badge
        const healthBadge = document.getElementById('health-badge');
        if (healthBadge && system.health_status) {
            healthBadge.textContent = capitalizeFirst(system.health_status);
            healthBadge.className = 'badge badge-' + getHealthBadgeClass(system.health_status);
        }

        // Update mini charts with history data
        if (system.history) {
            updateMiniCharts(system.history);
        }
    }

    /**
     * Initialize mini charts for system metrics
     */
    function initMiniCharts() {
        // Check if Chart.js is available
        if (typeof Chart === 'undefined') {
            console.warn('Dashboard: Chart.js not loaded, mini charts disabled');
            return;
        }

        const chartConfig = {
            type: 'line',
            options: {
                responsive: false,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: { enabled: true, mode: 'index', intersect: false }
                },
                scales: {
                    x: { display: false, type: 'linear' },
                    y: {
                        display: true,
                        position: 'right',
                        min: 0,
                        max: 100,
                        ticks: {
                            font: { size: 9 },
                            color: '#9ca3af',
                            maxTicksLimit: 3,
                            callback: function(value) {
                                return value + '%';
                            }
                        },
                        grid: {
                            color: 'rgba(156, 163, 175, 0.15)',
                            drawBorder: false
                        }
                    }
                },
                elements: {
                    point: { radius: 0 },
                    line: { tension: 0.3, borderWidth: 2 }
                },
                animation: false
            }
        };

        const metrics = ['cpu', 'memory', 'disk', 'temperature'];
        const colors = {
            cpu: '#10b981',      // green
            memory: '#3b82f6',   // blue
            disk: '#8b5cf6',     // purple
            temperature: '#f59e0b' // amber
        };

        metrics.forEach(function(metric) {
            const canvas = document.getElementById(metric + '-mini-chart');
            if (canvas && canvas.getContext) {
                try {
                    const config = JSON.parse(JSON.stringify(chartConfig));
                    config.data = {
                        datasets: [{
                            data: [],
                            borderColor: colors[metric],
                            backgroundColor: colors[metric] + '20',
                            fill: true
                        }]
                    };

                    // Temperature has different scale (0-85C) and unit
                    if (metric === 'temperature') {
                        config.options.scales.y.max = 85;
                        config.options.scales.y.ticks.callback = function(value) {
                            return value + '°C';
                        };
                    }

                    miniCharts[metric] = new Chart(canvas.getContext('2d'), config);
                } catch (e) {
                    console.error('Dashboard: Failed to create chart for ' + metric, e);
                }
            }
        });
    }

    /**
     * Update mini charts with history data
     */
    function updateMiniCharts(history) {
        // Store history for expanded chart
        currentHistory = history;

        // Initialize charts if not already done
        if (!miniCharts.cpu && typeof Chart !== 'undefined') {
            initMiniCharts();
            setupChartClickHandlers();
        }

        const metrics = ['cpu', 'memory', 'disk', 'temperature'];
        const units = {
            cpu: '%',
            memory: '%',
            disk: '%',
            temperature: '°C'
        };

        metrics.forEach(function(metric) {
            if (miniCharts[metric] && history[metric] && history[metric].length > 0) {
                const data = history[metric];
                miniCharts[metric].data.datasets[0].data = data.map(function(p) {
                    return { x: p.x, y: p.y };
                });
                miniCharts[metric].update('none');

                // Update tooltip metadata
                const latestValue = data[data.length - 1].y;
                const valueEl = document.getElementById(metric + '-tooltip-value');
                if (valueEl) {
                    valueEl.textContent = latestValue.toFixed(1) + units[metric];
                }

                // Update time range
                const startTime = new Date(data[0].x);
                const endTime = new Date(data[data.length - 1].x);
                const startEl = document.getElementById(metric + '-range-start');
                const endEl = document.getElementById(metric + '-range-end');
                if (startEl) {
                    startEl.textContent = startTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                }
                if (endEl) {
                    endEl.textContent = endTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                }
            }
        });
    }

    /**
     * Setup click handlers for mini chart tooltips
     * Only runs once to prevent duplicate event listeners
     */
    function setupChartClickHandlers() {
        // Prevent adding handlers multiple times
        if (chartClickHandlersInitialized) {
            return;
        }

        const metrics = ['cpu', 'memory', 'disk', 'temperature'];
        const titles = {
            cpu: 'CPU Usage History',
            memory: 'Memory Usage History',
            disk: 'Disk Usage History',
            temperature: 'Temperature History'
        };

        metrics.forEach(function(metric) {
            const tooltip = document.getElementById(metric + '-chart-tooltip');
            if (tooltip) {
                tooltip.addEventListener('click', function(e) {
                    e.stopPropagation();
                    openChartModal(metric, titles[metric]);
                });
            }
        });

        chartClickHandlersInitialized = true;
    }

    /**
     * Open the expanded chart modal
     */
    function openChartModal(metric, title) {
        if (!currentHistory || !currentHistory[metric]) {
            console.warn('No history data for', metric);
            return;
        }

        const modal = document.getElementById('chart-modal');
        const titleEl = document.getElementById('chart-modal-title');
        const canvas = document.getElementById('expanded-chart');

        if (!modal || !canvas) return;

        // Set title
        if (titleEl) titleEl.textContent = title;

        // Destroy existing chart
        if (expandedChart) {
            expandedChart.destroy();
            expandedChart = null;
        }

        // Color mapping
        const colors = {
            cpu: '#10b981',
            memory: '#3b82f6',
            disk: '#8b5cf6',
            temperature: '#f59e0b'
        };

        // Unit mapping
        const units = {
            cpu: '%',
            memory: '%',
            disk: '%',
            temperature: '°C'
        };

        // Show modal first so we can measure container size
        modal.style.display = 'flex';

        // Use requestAnimationFrame to ensure CSS has been applied
        requestAnimationFrame(function() {
            // Destroy any existing chart on this canvas (safety check)
            if (expandedChart) {
                expandedChart.destroy();
                expandedChart = null;
            }

            // Also check for Victron chart if it exists on the same canvas
            if (window.expandedVictronChart) {
                window.expandedVictronChart.destroy();
                window.expandedVictronChart = null;
            }

            // Get modal body dimensions for responsive sizing
            const modalBody = modal.querySelector('.modal-body');
            const containerWidth = modalBody ? Math.max(modalBody.clientWidth - 48, 600) : 800;
            const containerHeight = Math.min(window.innerHeight * 0.6, 450);

            // Set canvas dimensions
            canvas.width = containerWidth;
            canvas.height = containerHeight;

            createExpandedChart();
        });

        function createExpandedChart() {
        // Create expanded chart with more detail
        const ctx = canvas.getContext('2d');
        expandedChart = new Chart(ctx, {
            type: 'line',
            data: {
                datasets: [{
                    label: title,
                    data: currentHistory[metric].map(function(p) {
                        return { x: p.x, y: p.y };
                    }),
                    borderColor: colors[metric],
                    backgroundColor: colors[metric] + '30',
                    fill: true,
                    tension: 0.3,
                    pointRadius: 3,
                    pointHoverRadius: 6,
                    borderWidth: 2.5
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        enabled: true,
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleFont: { size: 14 },
                        bodyFont: { size: 14 },
                        padding: 12,
                        callbacks: {
                            label: function(context) {
                                return context.parsed.y.toFixed(1) + units[metric];
                            },
                            title: function(context) {
                                const timestamp = context[0].parsed.x;
                                const date = new Date(timestamp);
                                return date.toLocaleTimeString();
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        type: 'linear',
                        display: true,
                        title: {
                            display: true,
                            text: 'Time',
                            color: '#9ca3af',
                            font: { size: 14 }
                        },
                        ticks: {
                            callback: function(value) {
                                const date = new Date(value);
                                return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                            },
                            color: '#9ca3af',
                            font: { size: 12 },
                            maxTicksLimit: 8
                        },
                        grid: {
                            color: 'rgba(156, 163, 175, 0.2)'
                        }
                    },
                    y: {
                        display: true,
                        min: 0,
                        max: metric === 'temperature' ? 85 : 100,
                        title: {
                            display: true,
                            text: units[metric],
                            color: '#9ca3af',
                            font: { size: 14 }
                        },
                        ticks: {
                            color: '#9ca3af',
                            font: { size: 12 }
                        },
                        grid: {
                            color: 'rgba(156, 163, 175, 0.2)'
                        }
                    }
                }
            }
        });
        }
    }

    /**
     * Close the expanded chart modal
     */
    function closeChartModal() {
        const modal = document.getElementById('chart-modal');
        if (modal) {
            modal.style.display = 'none';
        }

        // Destroy chart to free memory
        if (expandedChart) {
            expandedChart.destroy();
            expandedChart = null;
        }
    }

    /**
     * Update uptime display
     */
    function updateUptime(system) {
        const uptimeValue = document.getElementById('uptime-value');
        if (uptimeValue && system) {
            uptimeValue.textContent = system.uptime_formatted || '--';
        }
    }

    /**
     * Update network information
     */
    function updateNetwork(network) {
        if (!network) return;

        // Mode badge
        const modeBadge = document.getElementById('network-mode-badge');
        if (modeBadge) {
            const mode = network.mode || 'Unknown';
            modeBadge.textContent = mode;
            modeBadge.className = 'badge ' + (mode.includes('Client') ? 'badge-primary' : 'badge-info');
        }

        // SSID
        const ssidEl = document.getElementById('network-ssid');
        if (ssidEl) {
            ssidEl.textContent = network.ssid || '--';
        }

        // IP
        const ipEl = document.getElementById('network-ip');
        if (ipEl) {
            ipEl.textContent = network.ip || '--';
        }

        // Signal strength
        updateSignalStrength(network.signal_dbm);

        const signalDbm = document.getElementById('signal-dbm');
        if (signalDbm) {
            if (network.signal_dbm !== null && network.signal_dbm !== undefined) {
                signalDbm.textContent = network.signal_dbm + ' dBm';
            } else {
                signalDbm.textContent = '-- dBm';
            }
        }

        // Latency
        const latencyEl = document.getElementById('network-latency');
        if (latencyEl) {
            if (network.latency_ms !== null && network.latency_ms !== undefined) {
                latencyEl.textContent = network.latency_ms + ' ms';
                latencyEl.className = 'info-value ' + (network.latency_ms < 50 ? 'text-success' :
                                                        network.latency_ms < 100 ? '' : 'text-warning');
            } else {
                latencyEl.textContent = '-- ms';
                latencyEl.className = 'info-value';
            }
        }
    }

    /**
     * Update signal strength bars
     */
    function updateSignalStrength(dbm) {
        const signalDisplay = document.getElementById('signal-display');
        if (!signalDisplay) return;

        const bars = signalDisplay.querySelectorAll('.signal-bar');

        // Calculate active bars based on signal strength
        // -30 to -50 = excellent (5 bars)
        // -50 to -60 = good (4 bars)
        // -60 to -70 = fair (3 bars)
        // -70 to -80 = weak (2 bars)
        // -80 to -90 = very weak (1 bar)
        // below -90 = none
        let activeBars = 0;
        if (dbm !== null && dbm !== undefined) {
            if (dbm >= -50) activeBars = 5;
            else if (dbm >= -60) activeBars = 4;
            else if (dbm >= -70) activeBars = 3;
            else if (dbm >= -80) activeBars = 2;
            else if (dbm >= -90) activeBars = 1;
        }

        bars.forEach((bar, index) => {
            if (index < activeBars) {
                bar.classList.add('active');
            } else {
                bar.classList.remove('active');
            }
        });
    }

    /**
     * Update services status
     */
    function updateServices(services) {
        if (!services) return;

        // Update all services using mapping
        Object.keys(SERVICE_MAPPING).forEach(function(serviceKey) {
            const mapping = SERVICE_MAPPING[serviceKey];
            const isRunning = services[serviceKey];
            updateServiceStatus(mapping.id, isRunning);
        });
    }

    /**
     * Update a single service status
     */
    function updateServiceStatus(name, isRunning) {
        const dot = document.getElementById('service-' + name + '-dot');
        const badge = document.getElementById('service-' + name + '-badge');

        if (dot) {
            dot.className = 'status-dot ' + (isRunning ? 'status-dot-connected' : 'status-dot-error');
        }

        if (badge) {
            badge.textContent = isRunning ? 'Running' : 'Stopped';
            badge.className = 'badge badge-sm ' + (isRunning ? 'badge-success' : 'badge-danger');
        }
    }

    /**
     * Update USB devices list
     */
    function updateDevices(devices) {
        if (!devices) return;

        // Update count badge
        const countBadge = document.getElementById('usb-count-badge');
        if (countBadge) {
            const count = devices.count || 0;
            countBadge.textContent = count + ' Connected';
        }

        // Update device list
        const deviceList = document.getElementById('dashboard-device-list');
        if (!deviceList) return;

        const usbDevices = devices.usb || [];

        if (usbDevices.length === 0) {
            deviceList.innerHTML = '<div class="device-row">' +
                '<span class="status-dot status-dot-unknown"></span>' +
                '<div class="device-details">' +
                '<span class="device-friendly-name">No USB devices connected</span>' +
                '</div></div>';
            return;
        }

        deviceList.innerHTML = usbDevices.map(device => createDeviceRow(device)).join('');
    }

    /**
     * Create HTML for a device row
     */
    function createDeviceRow(device) {
        const friendlyName = device.name || device.product_name || 'Unknown Device';
        const port = device.port || device.serial_port || '';
        const vendor = device.vendor_name || '';
        const product = device.product_name || '';
        const baudRate = device.baud_rate || '115200';
        const isShared = device.shared || false;

        let meta = [];
        if (port) meta.push('<code>' + escapeHtml(port) + '</code>');
        if (vendor) meta.push('<span class="device-vendor">' + escapeHtml(vendor) + '</span>');
        if (product && product !== friendlyName) meta.push('<span class="device-product">' + escapeHtml(product) + '</span>');
        meta.push('<span>' + baudRate + ' baud</span>');

        if (isShared) {
            meta.push('<span class="badge badge-success badge-sm">VH Shared</span>');
        }

        return '<div class="device-row">' +
            '<span class="status-dot status-dot-connected"></span>' +
            '<div class="device-details">' +
                '<div class="device-name-row">' +
                    '<span class="device-friendly-name">' + escapeHtml(friendlyName) + '</span>' +
                    '<button class="device-edit-btn" title="Edit name" onclick="editDeviceName(\'' + escapeHtml(device.unique_id || '') + '\')">&#9998;</button>' +
                '</div>' +
                '<div class="device-meta">' +
                    meta.join('<span class="meta-sep">&bull;</span>') +
                '</div>' +
            '</div>' +
        '</div>';
    }

    /**
     * Get appropriate bar color class based on value and thresholds
     */
    function getBarClass(value, warningThreshold, dangerThreshold) {
        if (value >= dangerThreshold) return 'metric-bar-fill--danger';
        if (value >= warningThreshold) return 'metric-bar-fill--warning';
        return 'metric-bar-fill--success';
    }

    /**
     * Get badge class for health status
     */
    function getHealthBadgeClass(status) {
        switch (status) {
            case 'healthy': return 'success';
            case 'warning': return 'warning';
            case 'critical': return 'danger';
            default: return 'secondary';
        }
    }

    /**
     * Capitalize first letter of a string
     */
    function capitalizeFirst(str) {
        return str.charAt(0).toUpperCase() + str.slice(1);
    }

    /**
     * Manual refresh function (called from button)
     */
    window.refreshDashboard = function() {
        console.log('Dashboard: Manual refresh');
        fetchDashboardStatus();
    };

    /**
     * Toggle process panel expansion
     */
    window.toggleProcessPanel = function(type) {
        const panel = document.getElementById(type + '-processes-panel');
        const row = document.getElementById(type + '-metric-row');

        if (!panel || !row) return;

        if (expandedPanels.has(type)) {
            // Collapse
            panel.style.display = 'none';
            row.classList.remove('expanded');
            expandedPanels.delete(type);
        } else {
            // Expand
            panel.style.display = 'block';
            row.classList.add('expanded');
            expandedPanels.add(type);
            fetchTopProcesses();
        }
    };

    /**
     * Global chart modal close function
     */
    window.closeChartModal = closeChartModal;

    /**
     * Global chart modal open function (for inline onclick handlers)
     */
    window.openDashboardChartModal = function(metric, title) {
        openChartModal(metric, title);
    };

    /**
     * Fetch top processes for expanded panels
     */
    function fetchTopProcesses() {
        fetch('/api/dashboard/processes')
            .then(function(response) {
                return response.json();
            })
            .then(function(data) {
                if (data.error) {
                    console.error('Process API error:', data.error);
                    showProcessError();
                    return;
                }
                updateProcessPanels(data);
            })
            .catch(function(error) {
                console.error('Process fetch error:', error);
                showProcessError();
            });
    }

    /**
     * Show error message in process panels
     */
    function showProcessError() {
        ['cpu', 'memory'].forEach(function(type) {
            if (expandedPanels.has(type)) {
                var list = document.getElementById(type + '-processes-list');
                if (list) {
                    list.innerHTML = '<div class="error-text">Failed to load processes</div>';
                }
            }
        });
    }

    /**
     * Update process panel displays
     */
    function updateProcessPanels(data) {
        // CPU processes
        if (expandedPanels.has('cpu') && data.cpu_processes) {
            const list = document.getElementById('cpu-processes-list');
            if (list) {
                list.innerHTML = data.cpu_processes.map(function(p) {
                    return '<div class="process-item">' +
                        '<div>' +
                            '<span class="process-name">' + escapeHtml(p.name) + '</span>' +
                            '<span class="process-pid">PID: ' + p.pid + '</span>' +
                        '</div>' +
                        '<span class="process-usage">' + p.cpu.toFixed(1) + '%</span>' +
                    '</div>';
                }).join('');
            }
        }

        // Memory processes
        if (expandedPanels.has('memory') && data.memory_processes) {
            const list = document.getElementById('memory-processes-list');
            if (list) {
                list.innerHTML = data.memory_processes.map(function(p) {
                    return '<div class="process-item">' +
                        '<div>' +
                            '<span class="process-name">' + escapeHtml(p.name) + '</span>' +
                            '<span class="process-pid">PID: ' + p.pid + '</span>' +
                        '</div>' +
                        '<span class="process-usage">' + p.memory.toFixed(1) + '%</span>' +
                    '</div>';
                }).join('');
            }
        }
    }

    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initDashboard);
    } else {
        initDashboard();
    }

})();
