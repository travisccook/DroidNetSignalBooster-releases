#!/usr/bin/env python3
"""
Thread-safe Comlink history manager with file locking
Prevents race conditions and JSON corruption
"""

import json
import os
import time
import fcntl
import tempfile
import shutil
import logging

from config.constants import (
    TIMEOUT_HISTORY_HOUR_SECONDS,
    TIMEOUT_HISTORY_DAY_SECONDS,
    DATA_DIR,
)

logger = logging.getLogger(__name__)

HISTORY_FILE = str(DATA_DIR / "comlink_history.json")
HISTORY_LOCK = "/var/lock/comlink_history.lock"


class ComlinkHistoryManager:
    """Thread-safe manager for Comlink command history"""

    def __init__(self, history_file=HISTORY_FILE):
        self.history_file = history_file
        self.lock_file = HISTORY_LOCK

        # Ensure directories exist
        os.makedirs(os.path.dirname(history_file), exist_ok=True)
        os.makedirs(os.path.dirname(self.lock_file), exist_ok=True)

    def _acquire_lock(self, lock_fd):
        """Acquire exclusive lock on history file"""
        try:
            fcntl.flock(lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            return True
        except BlockingIOError:
            # Lock held by another process, wait for it
            fcntl.flock(lock_fd, fcntl.LOCK_EX)
            return True

    def _release_lock(self, lock_fd):
        """Release lock on history file"""
        try:
            fcntl.flock(lock_fd, fcntl.LOCK_UN)
        except OSError as e:
            logger.warning(f"OS error releasing lock: {e}")

    def _read_history(self):
        """Read history file with error recovery"""
        if not os.path.exists(self.history_file):
            return {"commands": []}

        try:
            with open(self.history_file, "r") as f:
                data = json.load(f)
                # Ensure correct structure
                if not isinstance(data, dict) or "commands" not in data:
                    logger.warning("Invalid history structure, resetting")
                    return {"commands": []}
                return data
        except json.JSONDecodeError as e:
            logger.error(f"Corrupted history JSON: {e}")
            # Backup corrupted file
            backup_path = f"{self.history_file}.corrupt.{int(time.time())}"
            try:
                shutil.copy2(self.history_file, backup_path)
                logger.info(f"Backed up corrupted file to {backup_path}")
            except Exception as backup_err:
                logger.error(f"Failed to backup corrupted file: {backup_err}")
            # Return empty history
            return {"commands": []}
        except (OSError, IOError) as e:
            logger.error(f"File error reading history: {e}")
            return {"commands": []}

    def _write_history_atomic(self, data):
        """Write history file atomically to prevent corruption"""
        # Write to temporary file first
        temp_fd, temp_path = tempfile.mkstemp(
            dir=os.path.dirname(self.history_file),
            prefix=".comlink_history_",
            suffix=".tmp",
        )

        try:
            with os.fdopen(temp_fd, "w") as f:
                json.dump(data, f, indent=2)
                f.flush()
                os.fsync(f.fileno())

            # Atomic rename
            os.rename(temp_path, self.history_file)
            return True
        except (OSError, IOError) as e:
            logger.error(f"File error writing history: {e}")
            # Clean up temp file
            try:
                os.unlink(temp_path)
            except OSError:
                pass
            return False
        except (TypeError, ValueError) as e:
            logger.error(f"Data serialization error writing history: {e}")
            # Clean up temp file
            try:
                os.unlink(temp_path)
            except OSError:
                pass
            return False

    def add_command(
        self, command, source, target, status, timestamp=None, max_history=1000
    ):
        """
        Add a command to history with proper locking

        Args:
            command: Command string
            source: Source of command (e.g., "comlink_app (192.168.1.1)")
            target: Target type (e.g., "usb", "gpio")
            status: Status string (e.g., "success", "error")
            timestamp: Optional timestamp (defaults to current time)
            max_history: Maximum number of commands to keep

        Returns:
            bool: True if successful, False otherwise
        """
        if timestamp is None:
            timestamp = time.time()

        # Open lock file
        lock_fd = None
        try:
            lock_fd = open(self.lock_file, "w")
            self._acquire_lock(lock_fd)

            # Read current history
            history = self._read_history()

            # Add new command
            history["commands"].append(
                {
                    "timestamp": timestamp,
                    "command": command,
                    "source": source,
                    "target": target,
                    "status": status,
                }
            )

            # Trim to max size
            if len(history["commands"]) > max_history:
                history["commands"] = history["commands"][-max_history:]

            # Write atomically
            success = self._write_history_atomic(history)

            return success

        except (OSError, IOError) as e:
            logger.error(f"File error adding command to history: {e}")
            return False
        finally:
            if lock_fd:
                self._release_lock(lock_fd)
                lock_fd.close()

    def get_history(self, filter_type="all", max_results=100):
        """
        Get command history with optional filtering

        Args:
            filter_type: "all", "hour", "day", or "week"
            max_results: Maximum number of results to return

        Returns:
            list: List of command dictionaries
        """
        lock_fd = None
        try:
            lock_fd = open(self.lock_file, "w")
            self._acquire_lock(lock_fd)

            history = self._read_history()
            all_commands = history.get("commands", [])

            # Filter by time
            current_time = time.time()
            filtered_commands = []

            time_filters = {
                "hour": TIMEOUT_HISTORY_HOUR_SECONDS,
                "day": TIMEOUT_HISTORY_DAY_SECONDS,
                "week": 604800,
                "all": float("inf"),
            }

            time_limit = time_filters.get(filter_type, float("inf"))

            for cmd in all_commands:
                cmd_time = cmd.get("timestamp", 0)
                if current_time - cmd_time <= time_limit:
                    filtered_commands.append(cmd)

            # Sort by timestamp, newest first
            filtered_commands.sort(key=lambda x: x.get("timestamp", 0), reverse=True)

            # Return limited results
            return filtered_commands[:max_results]

        except (OSError, IOError) as e:
            logger.error(f"File error getting history: {e}")
            return []
        finally:
            if lock_fd:
                self._release_lock(lock_fd)
                lock_fd.close()

    def clear_history(self):
        """Clear all history"""
        lock_fd = None
        try:
            lock_fd = open(self.lock_file, "w")
            self._acquire_lock(lock_fd)

            empty_history = {"commands": [], "cleared_at": time.time()}

            success = self._write_history_atomic(empty_history)
            return success

        except (OSError, IOError) as e:
            logger.error(f"File error clearing history: {e}")
            return False
        finally:
            if lock_fd:
                self._release_lock(lock_fd)
                lock_fd.close()

    def get_statistics(self):
        """Get statistics about command history"""
        lock_fd = None
        try:
            lock_fd = open(self.lock_file, "w")
            self._acquire_lock(lock_fd)

            history = self._read_history()
            commands = history.get("commands", [])

            if not commands:
                return {
                    "total_commands": 0,
                    "commands_today": 0,
                    "last_command_time": None,
                    "unique_commands": 0,
                    "top_commands": [],
                }

            total = len(commands)

            # Commands today
            today_start = time.time() - (time.time() % 86400)
            commands_today = sum(
                1 for cmd in commands if cmd.get("timestamp", 0) >= today_start
            )

            # Last command time
            last_command_time = None
            if commands:
                most_recent = max(commands, key=lambda x: x.get("timestamp", 0))
                last_command_time = most_recent.get("timestamp", 0)

            # Unique commands and counts
            unique_commands_set = set()
            command_counts = {}
            for cmd in commands:
                command_text = cmd.get("command", "")
                if command_text:
                    unique_commands_set.add(command_text)
                    command_counts[command_text] = (
                        command_counts.get(command_text, 0) + 1
                    )

            # Top commands
            top_commands = sorted(
                command_counts.items(), key=lambda x: x[1], reverse=True
            )[:10]
            top_commands = [
                {"command": cmd, "count": count} for cmd, count in top_commands
            ]

            return {
                "total_commands": total,
                "commands_today": commands_today,
                "last_command_time": last_command_time,
                "unique_commands": len(unique_commands_set),
                "top_commands": top_commands,
            }

        except (OSError, IOError) as e:
            logger.error(f"File error getting statistics: {e}")
            return {
                "total_commands": 0,
                "commands_today": 0,
                "last_command_time": None,
                "unique_commands": 0,
                "top_commands": [],
            }
        finally:
            if lock_fd:
                self._release_lock(lock_fd)
                lock_fd.close()


# Global instance for easy import
history_manager = ComlinkHistoryManager()
