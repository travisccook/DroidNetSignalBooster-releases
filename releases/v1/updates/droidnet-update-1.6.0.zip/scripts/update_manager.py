#!/usr/bin/env python3
"""
DroidNet Update Manager
Handles system updates uploaded via web interface
"""

import os
import sys
import json
import shutil
import zipfile
import hashlib
import subprocess
import tempfile
import logging
from datetime import datetime
from pathlib import Path

# Configuration
UPDATE_DIR = "/opt/droidnet"
BACKUP_DIR = "/opt/droidnet-backup"
TEMP_DIR = "/tmp/droidnet-update"
LOG_DIR = "/var/log/droidnet"
UPDATE_LOG = "update.log"

# Services to restart after update
SERVICES = [
    "droidnet-web",
    "droidnet-controller",
    "droidnet-comlink",
    "droidnet-monitor",
]


# Setup logging
def setup_logging():
    """Configure logging for update manager"""
    Path(LOG_DIR).mkdir(parents=True, exist_ok=True)

    log_file = os.path.join(LOG_DIR, UPDATE_LOG)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
        handlers=[logging.FileHandler(log_file), logging.StreamHandler(sys.stdout)],
    )
    return logging.getLogger(__name__)


logger = setup_logging()


class UpdateManager:
    def __init__(self):
        self.temp_dir = None
        self.backup_dir = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.cleanup()

    def cleanup(self):
        """Clean up temporary files"""
        if self.temp_dir and os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)

    def calculate_checksum(self, filepath):
        """Calculate SHA256 checksum of a file"""
        sha256_hash = hashlib.sha256()
        with open(filepath, "rb") as f:
            for byte_block in iter(lambda: f.read(4096), b""):
                sha256_hash.update(byte_block)
        return sha256_hash.hexdigest()

    def verify_manifest(self, manifest_path):
        """Verify update package manifest"""
        try:
            with open(manifest_path, "r") as f:
                manifest = json.load(f)

            # Check required fields
            required = ["version", "timestamp", "files"]
            for field in required:
                if field not in manifest:
                    raise ValueError(f"Missing required field: {field}")

            # Verify file checksums
            update_dir = os.path.dirname(manifest_path)
            for file_info in manifest.get("files", []):
                file_path = os.path.join(update_dir, file_info["path"])
                if not os.path.exists(file_path):
                    raise ValueError(f"Missing file: {file_info['path']}")

                # Verify checksum
                actual_checksum = self.calculate_checksum(file_path)
                if actual_checksum != file_info["checksum"]:
                    raise ValueError(f"Checksum mismatch for {file_info['path']}")

            return manifest

        except Exception as e:
            logger.error(f"Manifest verification failed: {e}")
            raise

    def extract_update(self, update_file):
        """Extract update package to temporary directory"""
        try:
            # Log update file details
            logger.info(f"Update file path: {update_file}")
            logger.info(f"Update file exists: {os.path.exists(update_file)}")
            logger.info(
                f"Update file size: {os.path.getsize(update_file) if os.path.exists(update_file) else 'N/A'}"  # noqa: E501
            )

            # Create temporary directory
            self.temp_dir = tempfile.mkdtemp(prefix="droidnet-update-")
            logger.info(f"Extracting update to {self.temp_dir}")

            # List ZIP contents before extraction
            try:
                with zipfile.ZipFile(update_file, "r") as zip_ref:
                    logger.info(
                        f"ZIP file contents: {zip_ref.namelist()[:10]}..."
                    )  # First 10 files
                    logger.info(f"Total files in ZIP: {len(zip_ref.namelist())}")

                    # Check if manifest.json is in the ZIP
                    if "manifest.json" in zip_ref.namelist():
                        logger.info("manifest.json found in ZIP file listing")
                    else:
                        logger.error("manifest.json NOT found in ZIP file listing!")
                        logger.error(
                            f"Files starting with 'manifest': {[f for f in zip_ref.namelist() if 'manifest' in f.lower()]}"  # noqa: E501
                        )
            except Exception as e:
                logger.error(f"Failed to list ZIP contents: {e}")

            # Extract ZIP file
            with zipfile.ZipFile(update_file, "r") as zip_ref:
                zip_ref.extractall(self.temp_dir)
                logger.info("ZIP extraction completed")

            # List extracted files
            extracted_files = os.listdir(self.temp_dir)
            logger.info(
                f"Extracted files in temp dir: {extracted_files[:10]}..."
            )  # First 10 files

            # Verify manifest
            manifest_path = os.path.join(self.temp_dir, "manifest.json")
            logger.info(f"Looking for manifest at: {manifest_path}")
            logger.info(f"Manifest exists: {os.path.exists(manifest_path)}")

            if not os.path.exists(manifest_path):
                # Try to find manifest.json anywhere in temp dir
                for root, dirs, files in os.walk(self.temp_dir):
                    logger.info(f"Checking directory: {root}")
                    logger.info(f"Files: {files[:5]}...")  # First 5 files
                    if "manifest.json" in files:
                        logger.info(
                            f"Found manifest.json at: {os.path.join(root, 'manifest.json')}"  # noqa: E501
                        )

                raise ValueError("No manifest.json found in update package")

            manifest = self.verify_manifest(manifest_path)
            logger.info(f"Update package verified: version {manifest['version']}")

            return manifest

        except Exception as e:
            logger.error(f"Failed to extract update: {e}")
            raise

    def create_backup(self):
        """Create backup of current installation"""
        try:
            timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            self.backup_dir = f"{BACKUP_DIR}-{timestamp}"

            logger.info(f"Creating backup at {self.backup_dir}")

            if os.path.exists(UPDATE_DIR):
                shutil.copytree(
                    UPDATE_DIR,
                    self.backup_dir,
                    ignore=shutil.ignore_patterns("__pycache__", "*.pyc"),
                )
                logger.info("Backup completed successfully")
            else:
                logger.warning(f"Update directory {UPDATE_DIR} does not exist")

        except Exception as e:
            logger.error(f"Backup failed: {e}")
            raise

    def apply_update(self, manifest):  # noqa: C901
        """Apply update files to system"""
        try:
            logger.info("Applying update files...")

            # Create directories as needed
            os.makedirs(UPDATE_DIR, exist_ok=True)

            # Copy files according to manifest
            for file_info in manifest.get("files", []):
                if self.temp_dir is None:
                    raise RuntimeError("temp_dir not initialized")
                src_path = os.path.join(self.temp_dir, file_info["path"])
                dest_path = os.path.join(UPDATE_DIR, file_info["path"])

                # Create parent directory if needed
                os.makedirs(os.path.dirname(dest_path), exist_ok=True)

                # Copy file
                shutil.copy2(src_path, dest_path)

                # Set executable permissions for scripts
                if file_info["path"].endswith((".sh", ".py")):
                    os.chmod(dest_path, 0o755)

                logger.debug(f"Updated: {file_info['path']}")

            # Update version file
            version_file = os.path.join(UPDATE_DIR, "VERSION")
            with open(version_file, "w") as f:
                f.write(manifest["version"])

            # Execute change script if present
            if self.temp_dir is None:
                raise RuntimeError("temp_dir not initialized")
            change_script = os.path.join(self.temp_dir, "change.sh")
            if os.path.exists(change_script):
                logger.info("Executing change script...")
                try:
                    # Make script executable
                    os.chmod(change_script, 0o755)
                    # Execute with full environment
                    result = subprocess.run(
                        ["/bin/bash", change_script],
                        capture_output=True,
                        text=True,
                        cwd=UPDATE_DIR,
                        env={
                            **os.environ,
                            "UPDATE_DIR": UPDATE_DIR,
                            "VERSION": manifest["version"],
                        },
                    )
                    if result.returncode == 0:
                        logger.info("Change script executed successfully")
                        if result.stdout:
                            logger.info(f"Change script output:\n{result.stdout}")
                    else:
                        logger.error(f"Change script failed: {result.stderr}")
                        raise RuntimeError(f"Change script failed: {result.stderr}")
                except Exception as e:
                    logger.error(f"Failed to execute change script: {e}")
                    raise

            # Copy systemd service files if present
            if self.temp_dir is None:
                raise RuntimeError("temp_dir not initialized")
            systemd_src = os.path.join(self.temp_dir, "config/systemd")
            if os.path.exists(systemd_src):
                for service_file in os.listdir(systemd_src):
                    if service_file.endswith(".service"):
                        src = os.path.join(systemd_src, service_file)
                        dst = f"/etc/systemd/system/{service_file}"
                        shutil.copy2(src, dst)
                        logger.info(f"Updated service file: {service_file}")

                # Reload systemd daemon
                subprocess.run(["systemctl", "daemon-reload"], check=True)

            logger.info("Update files applied successfully")

        except Exception as e:
            logger.error(f"Failed to apply update: {e}")
            self.rollback()
            raise

    def restart_services(self):
        """Restart affected services"""
        logger.info("Restarting services...")

        # Update status to indicate restart phase
        self.update_status("Services are restarting - connection may be interrupted...")

        for service in SERVICES:
            try:
                # Check if service exists
                result = subprocess.run(
                    ["systemctl", "list-unit-files", f"{service}.service"],
                    capture_output=True,
                    text=True,
                )

                if service in result.stdout:
                    subprocess.run(["systemctl", "restart", service], check=True)
                    logger.info(f"Restarted {service}")
                else:
                    logger.debug(f"Service {service} not found, skipping")

            except subprocess.CalledProcessError as e:
                logger.warning(f"Failed to restart {service}: {e}")

    def verify_services(self):
        """Verify services are running after update"""
        logger.info("Verifying services...")

        all_healthy = True
        for service in SERVICES:
            try:
                result = subprocess.run(
                    ["systemctl", "is-active", service], capture_output=True, text=True
                )

                if result.stdout.strip() == "active":
                    logger.info(f"{service} is running")
                else:
                    logger.warning(f"{service} is not active")
                    all_healthy = False

            except Exception as e:
                logger.warning(f"Could not check {service}: {e}")

        return all_healthy

    def rollback(self):
        """Rollback to backup if update fails"""
        if not self.backup_dir or not os.path.exists(self.backup_dir):
            logger.error("No backup available for rollback")
            return False

        try:
            logger.warning("Rolling back update...")

            # Remove failed update
            if os.path.exists(UPDATE_DIR):
                shutil.rmtree(UPDATE_DIR)

            # Restore backup
            shutil.copytree(self.backup_dir, UPDATE_DIR)

            # Restart services
            self.restart_services()

            logger.info("Rollback completed")
            return True

        except Exception as e:
            logger.error(f"Rollback failed: {e}")
            return False

    def cleanup_old_backups(self, keep=3):
        """Remove old backup directories, keeping the most recent ones"""
        try:
            backup_pattern = f"{BACKUP_DIR}-*"
            backups = sorted(Path("/opt").glob(backup_pattern.split("/")[-1]))

            if len(backups) > keep:
                for backup in backups[:-keep]:
                    shutil.rmtree(backup)
                    logger.info(f"Removed old backup: {backup}")

        except Exception as e:
            logger.warning(f"Failed to cleanup old backups: {e}")

    def update_status(self, message):
        """Update the status file with current progress"""
        try:
            status_file = "/var/lib/droidnet/update-status.json"
            if os.path.exists(status_file):
                with open(status_file, "r") as f:
                    status = json.load(f)

                status["progress"] = message

                with open(status_file, "w") as f:
                    json.dump(status, f)
        except Exception as e:
            logger.warning(f"Failed to update status: {e}")

    def apply_update_package(self, update_file):
        """Main update process"""
        try:
            logger.info(f"Starting update from {update_file}")

            # Update status with progress
            self.update_status("Extracting and verifying update package...")

            # Extract and verify update
            manifest = self.extract_update(update_file)

            # Create backup
            self.update_status("Creating backup of current installation...")
            self.create_backup()

            # Apply update
            self.update_status("Applying update files...")
            self.apply_update(manifest)

            # Update status before restarting services
            logger.info("Update files applied, preparing to restart services...")
            self.update_status("Update applied successfully, restarting services...")

            # Restart services
            self.restart_services()

            # Verify services
            self.update_status("Verifying services...")
            if not self.verify_services():
                logger.warning("Some services failed to start properly")

            # Cleanup old backups
            self.cleanup_old_backups()

            # Update status after restart
            self.update_status(
                f"Update completed successfully! New version: {manifest['version']}"
            )

            logger.info(
                f"Update completed successfully to version {manifest['version']}"
            )

            return {
                "success": True,
                "version": manifest["version"],
                "backup_dir": self.backup_dir,
            }

        except Exception as e:
            logger.error(f"Update failed: {e}")
            return {"success": False, "error": str(e)}
        finally:
            self.cleanup()


def main():
    """Command line interface for update manager"""
    if len(sys.argv) < 2:
        print("Usage: update_manager.py <update_package.zip>")
        sys.exit(1)

    update_file = sys.argv[1]

    if not os.path.exists(update_file):
        print(f"Update file not found: {update_file}")
        sys.exit(1)

    with UpdateManager() as manager:
        result = manager.apply_update_package(update_file)

    if result["success"]:
        print(f"Update successful! Version: {result['version']}")
        print(f"Backup saved to: {result['backup_dir']}")
    else:
        print(f"Update failed: {result['error']}")
        sys.exit(1)


if __name__ == "__main__":
    main()
