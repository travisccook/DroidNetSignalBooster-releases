#!/usr/bin/env python3
"""
Maestro Script Generator

Generates MCC-compatible Maestro scripts from sequences.
Uses helper subroutines for efficient code generation like
Maestro Control Center does.
"""

from typing import List, Dict, Set, Optional
import re

# Reserved keywords that cannot be used as subroutine names
RESERVED_KEYWORDS = {
    'return', 'delay', 'servo', 'speed', 'acceleration', 'get_position', 'get_ms',
    'begin', 'repeat', 'while', 'if', 'else', 'endif', 'quit',
    'drop', 'dup', 'swap', 'over',
    'plus', 'minus', 'times', 'divide', 'mod',
    'positive', 'negative', 'not', 'and', 'or',
    'equals', 'not_equals', 'less_than', 'greater_than',
    'less_or_equal', 'greater_or_equal',
}

# Safe neutral position for servos (center of typical 4000-8000 range)
DEFAULT_NEUTRAL_POSITION = 6000


def sanitize_name(name: str) -> str:
    """
    Convert a sequence name to a valid subroutine name.

    Rules:
    - Replace spaces with underscores
    - Remove non-alphanumeric characters (except underscore)
    - Must start with letter or underscore
    - Cannot be a reserved keyword
    """
    # Replace spaces with underscores
    name = name.replace(" ", "_")
    # Remove invalid characters
    name = re.sub(r'[^a-zA-Z0-9_]', '', name)
    # Ensure starts with letter or underscore
    if name and name[0].isdigit():
        name = "_" + name
    name = name or "unnamed"
    # Avoid reserved keywords
    if name.lower() in RESERVED_KEYWORDS:
        name = f"seq_{name}"
    return name


def analyze_channel_usage(sequences: List[Dict]) -> Dict[str, Set[int]]:
    """
    Analyze which channels are used in each sequence and across all sequences.

    Returns:
        Dictionary with:
        - 'all': set of all channels used
        - 'per_sequence': list of sets, one per sequence
    """
    all_channels: Set[int] = set()
    per_sequence: List[Set[int]] = []

    for seq in sequences:
        seq_channels: Set[int] = set()
        for frame in seq.get("frames", []):
            positions = frame.get("positions", {})
            for ch_str in positions.keys():
                try:
                    ch = int(ch_str)
                    seq_channels.add(ch)
                    all_channels.add(ch)
                except ValueError:
                    # Skip invalid channel keys (non-numeric)
                    continue
        per_sequence.append(seq_channels)

    return {
        'all': all_channels,
        'per_sequence': per_sequence
    }


def generate_frame_helper(channels: Set[int]) -> str:
    """
    Generate a helper subroutine for setting servo positions.

    MCC generates helpers like:
      sub frame_0..4
        4 servo
        3 servo
        2 servo
        1 servo
        0 servo
        delay
        return

    The stack is expected to have: delay, pos_n, pos_n-1, ..., pos_0
    (delay is deepest, positions are in reverse channel order)
    """
    if not channels:
        return ""

    sorted_channels = sorted(channels, reverse=True)
    min_ch = min(channels)
    max_ch = max(channels)

    # Name the helper based on channel range
    if min_ch == max_ch:
        helper_name = f"frame_{min_ch}"
    else:
        helper_name = f"frame_{min_ch}..{max_ch}"

    lines = [f"sub {helper_name}"]

    # Pop positions from stack and set servos (reverse order of channels)
    for ch in sorted_channels:
        lines.append(f"  {ch} servo")

    # Delay
    lines.append("  delay")
    lines.append("  return")

    return "\n".join(lines)


def generate_sequence_subroutine(
    sequence: Dict,
    helper_name: str,
    channels: Set[int]
) -> str:
    """
    Generate a subroutine for a sequence.

    Format:
      sub SequenceName
        duration pos_n pos_n-1 ... pos_0 frame_helper
        duration pos_n pos_n-1 ... pos_0 frame_helper
        return
    """
    name = sanitize_name(sequence.get("name", "unnamed"))
    frames = sequence.get("frames", [])

    if not frames:
        return f"sub {name}\n  return"

    sorted_channels = sorted(channels, reverse=True)
    lines = [f"sub {name}"]

    for i, frame in enumerate(frames):
        duration = frame.get("duration", 500)
        # Validate duration (1-65535ms range)
        if not isinstance(duration, (int, float)):
            duration = 500
        duration = max(1, min(int(duration), 65535))

        positions = frame.get("positions", {})

        # Build frame line: duration pos_n pos_n-1 ... pos_0 helper
        values = [str(duration)]
        for ch in sorted_channels:
            # Use safe neutral position as default instead of 0
            pos = positions.get(str(ch), DEFAULT_NEUTRAL_POSITION)
            # Validate position is numeric
            if not isinstance(pos, (int, float)):
                pos = DEFAULT_NEUTRAL_POSITION
            values.append(str(int(pos)))
        values.append(helper_name)

        lines.append("  " + " ".join(values))

    lines.append("  return")
    return "\n".join(lines)


def generate_mcc_style_script(
    sequences: List[Dict],
    channel_count: int = 18
) -> str:
    """
    Generate an MCC-compatible script from sequences.

    This generates:
    1. A helper subroutine for setting servo positions and delay
    2. One subroutine per sequence that calls the helper

    Args:
        sequences: List of sequence dictionaries with 'name' and 'frames'
        channel_count: Total number of channels on the device

    Returns:
        Complete script source code
    """
    if not sequences:
        return "# No sequences to generate"

    # Analyze channel usage
    usage = analyze_channel_usage(sequences)
    all_channels = usage['all']

    if not all_channels:
        return "# No channel positions in sequences"

    # Generate helper subroutine name
    min_ch = min(all_channels)
    max_ch = max(all_channels)
    if min_ch == max_ch:
        helper_name = f"frame_{min_ch}"
    else:
        helper_name = f"frame_{min_ch}..{max_ch}"

    # Build script
    lines = []
    lines.append("# Auto-generated Maestro script")
    lines.append(f"# Generated for channels {min_ch}-{max_ch}")
    lines.append("")

    # Generate helper subroutine
    lines.append(generate_frame_helper(all_channels))
    lines.append("")

    # Generate sequence subroutines
    for seq in sequences:
        lines.append(generate_sequence_subroutine(seq, helper_name, all_channels))
        lines.append("")

    return "\n".join(lines)


def generate_simple_script(
    sequence: Dict,
    loop: bool = False
) -> str:
    """
    Generate a simple script for a single sequence.

    This generates direct servo commands without helper subroutines,
    useful for quick testing or simple sequences.

    Args:
        sequence: Sequence dictionary with 'name' and 'frames'
        loop: Whether to loop the sequence

    Returns:
        Script source code
    """
    name = sanitize_name(sequence.get("name", "sequence"))
    frames = sequence.get("frames", [])

    lines = []
    lines.append(f"# Sequence: {sequence.get('name', 'Unnamed')}")
    lines.append("")

    if loop:
        lines.append("begin")

    for i, frame in enumerate(frames):
        duration = frame.get("duration", 500)
        # Validate duration
        if not isinstance(duration, (int, float)):
            duration = 500
        duration = max(1, min(int(duration), 65535))

        positions = frame.get("positions", {})

        lines.append(f"  # Frame {i + 1} ({duration}ms)")
        for ch_str, pos in sorted(positions.items(), key=lambda x: int(x[0]) if x[0].isdigit() else 0):
            try:
                ch = int(ch_str)
                # Validate position
                if not isinstance(pos, (int, float)):
                    pos = DEFAULT_NEUTRAL_POSITION
                lines.append(f"  {int(pos)} {ch} servo")
            except ValueError:
                continue  # Skip invalid channel keys
        lines.append(f"  {duration} delay")
        lines.append("")

    if loop:
        lines.append("repeat")
    else:
        lines.append("quit")

    return "\n".join(lines)


if __name__ == "__main__":
    # Example usage
    sequences = [
        {
            "name": "00Scream",
            "frames": [
                {"duration": 100, "positions": {"0": 4032, "1": 4416, "2": 4416}},
                {"duration": 2000, "positions": {"0": 6848, "1": 7232, "2": 7232}},
            ]
        },
        {
            "name": "01Short Circuit",
            "frames": [
                {"duration": 500, "positions": {"0": 6000, "1": 6000, "2": 6000}},
                {"duration": 100, "positions": {"0": 4000, "1": 4000, "2": 4000}},
            ]
        }
    ]

    print("=== MCC-Style Script ===")
    print(generate_mcc_style_script(sequences))
    print()
    print("=== Simple Script (with loop) ===")
    print(generate_simple_script(sequences[0], loop=True))
