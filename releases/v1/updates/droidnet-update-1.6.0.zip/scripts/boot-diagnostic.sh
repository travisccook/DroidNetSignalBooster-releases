#!/bin/bash

LOG="/boot/firmware/latest-boot-diagnostic.log"
exec > "$LOG" 2>&1

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1"
}

log "=== DroidNet Boot Diagnostic Report ==="

# System info
log "=== System Information ==="
log "Hostname: $(hostname)"
log "Kernel: $(uname -r)"
log "Boot time: $(systemd-analyze time | head -1)"

# Service status
log "=== Systemd Service Status ==="
systemctl status --no-pager | head -20

# Failed services
log "=== Failed Services ==="
systemctl --failed --no-pager

# NetworkManager deep dive
log "=== NetworkManager Diagnostics ==="
log "Service status:"
systemctl status NetworkManager --no-pager | head -20

log "Process check:"
if pgrep -x NetworkManager >/dev/null; then
    log "NetworkManager process is running"
    ps aux | grep -E "NetworkManager|PID" | grep -v grep
else
    log "ERROR: NetworkManager process NOT running"
fi

log "D-Bus status:"
systemctl is-active dbus || log "ERROR: D-Bus is not active!"

log "NetworkManager on D-Bus:"
if dbus-send --system --print-reply --dest=org.freedesktop.DBus \
   /org/freedesktop/DBus org.freedesktop.DBus.ListNames 2>/dev/null | \
   grep -q org.freedesktop.NetworkManager; then
    log "NetworkManager is registered on D-Bus"
else
    log "ERROR: NetworkManager NOT registered on D-Bus!"
fi

log "nmcli test:"
nmcli general status 2>&1 || log "nmcli failed - D-Bus issue confirmed"

log "NetworkManager logs (last 50 lines):"
journalctl -u NetworkManager -n 50 --no-pager

# D-Bus diagnostics
log "=== D-Bus Diagnostics ==="
log "D-Bus services:"
dbus-send --system --print-reply --dest=org.freedesktop.DBus \
    /org/freedesktop/DBus org.freedesktop.DBus.ListNames 2>&1 | \
    grep -E "(NetworkManager|wpa_supplicant)" || log "No network services on D-Bus"

# Network interfaces
log "=== Network Interfaces ==="
ip addr show

# WiFi status
log "=== WiFi Status ==="
/usr/sbin/iw dev 2>/dev/null || log "iw command failed"
rfkill list 2>/dev/null || log "rfkill command failed"

# DroidNet services
log "=== DroidNet Service Status ==="
for service in droidnet-{nm-wait,network-init,wifi-setup,web,monitor,led}; do
    log "$service: $(systemctl is-active $service 2>/dev/null || echo 'not-found') / $(systemctl is-enabled $service 2>/dev/null || echo 'not-found')"
done

log "=== Boot Diagnostic Complete ==="