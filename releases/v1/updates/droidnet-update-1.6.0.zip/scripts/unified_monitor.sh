#!/bin/bash
# DroidNet Unified Monitor - Combines diagnostic, watchdog, and log sync functionality
# Replaces three separate monitoring services with one efficient service
#
# Power optimization: Uses model-aware polling intervals
# - Pi 4/3: Longer intervals (more headroom, save power)
# - Pi Zero 2/W: Shorter intervals (less headroom, need quicker response)

# Run directly for Type=simple (no forking)
# Ensure we can write to boot partition
mount -o remount,rw /boot/firmware 2>/dev/null || true

LOG_DIR="/boot/firmware/droidnet-logs"
mkdir -p "$LOG_DIR"

# Detect Pi model for power-aware intervals
detect_pi_model() {
    local cpuinfo
    cpuinfo=$(cat /proc/cpuinfo 2>/dev/null)

    if echo "$cpuinfo" | grep -q "Pi Zero W" && echo "$cpuinfo" | grep -q "BCM2835"; then
        echo "pi_zero_w"
    elif echo "$cpuinfo" | grep -q "Pi Zero 2"; then
        echo "pi_zero_2"
    elif echo "$cpuinfo" | grep -q "Pi 3"; then
        echo "pi_3"
    elif echo "$cpuinfo" | grep -q "Pi 4"; then
        echo "pi_4"
    elif echo "$cpuinfo" | grep -q "Pi 5"; then
        echo "pi_5"
    else
        echo "unknown"
    fi
}

# Set model-aware polling intervals
# More powerful Pis get longer intervals (power saving)
# Less powerful Pis keep shorter intervals (need quick response)
PI_MODEL=$(detect_pi_model)

case "$PI_MODEL" in
    pi_4|pi_5)
        # Pi 4/5: Aggressive power saving - plenty of headroom
        BASE_INTERVAL=10          # Base loop sleep (was 1s)
        DIAGNOSTIC_INTERVAL=12    # Every 120s (was 30s) - 12 * 10 = 120
        RECOVERY_INTERVAL=12      # Every 120s (was 60s)
        NM_SYNC_INTERVAL=6        # Every 60s (was 10s)
        ;;
    pi_3)
        # Pi 3: Moderate power saving
        BASE_INTERVAL=5           # Base loop sleep
        DIAGNOSTIC_INTERVAL=12    # Every 60s (was 30s)
        RECOVERY_INTERVAL=12      # Every 60s
        NM_SYNC_INTERVAL=6        # Every 30s (was 10s)
        ;;
    pi_zero_2)
        # Pi Zero 2: Slight power saving, maintain responsiveness
        BASE_INTERVAL=5           # Base loop sleep
        DIAGNOSTIC_INTERVAL=10    # Every 50s (was 30s)
        RECOVERY_INTERVAL=12      # Every 60s
        NM_SYNC_INTERVAL=4        # Every 20s (was 10s)
        ;;
    pi_zero_w|*)
        # Pi Zero W or unknown: Keep responsive, minimal changes
        BASE_INTERVAL=5           # Base loop sleep (was 1s)
        DIAGNOSTIC_INTERVAL=8     # Every 40s (was 30s)
        RECOVERY_INTERVAL=12      # Every 60s
        NM_SYNC_INTERVAL=4        # Every 20s (was 10s)
        ;;
esac

# Mark monitor start
echo "[$(TZ='America/Kentucky/Louisville' date '+%Y-%m-%d %H:%M:%S EST/EDT')] Unified monitor started (model: $PI_MODEL, base_interval: ${BASE_INTERVAL}s)" >> "$LOG_DIR/monitor-starts.log"
sync
touch "$LOG_DIR/MONITOR_STARTED_$(date +%s)"

# Create marker file to indicate we're running
touch /var/run/droidnet-monitor.active

# Initialize counters
DIAGNOSTIC_COUNTER=0
RECOVERY_COUNTER=0
DNSMASQ_COUNTER=0

# Main monitoring loop
while true; do
        TIMESTAMP=$(date +%Y%m%d-%H%M%S)
        
        # Increment counters
        ((DIAGNOSTIC_COUNTER++))
        ((RECOVERY_COUNTER++))
        ((DNSMASQ_COUNTER++))
        
        # Diagnostic logging (interval varies by Pi model)
        if [ $DIAGNOSTIC_COUNTER -ge $DIAGNOSTIC_INTERVAL ]; then
            DIAGNOSTIC_COUNTER=0
            {
                echo "=== System Status - $(date) ==="
                echo "Uptime: $(uptime)"
                echo ""
                echo "=== Memory Status ==="
                free -h
                echo ""
                echo "=== Service Status ==="
                # Fix-Plan-34: Update service list to only check active services
                for service in NetworkManager droidnet-network-controller droidnet-web droidnet-led; do
                    status=$(systemctl is-active $service 2>/dev/null || echo "unknown")
                    echo "$service: $status"
                done
                echo ""
                echo "=== Network Status ==="
                ip addr show wlan0 2>/dev/null || echo "wlan0 not found"
                echo ""
                echo "=== Performance Metrics ==="
                echo "Load Average: $(cat /proc/loadavg)"
                echo "Memory: $(free -m | awk 'NR==2{printf "Used: %sMB (%.1f%%)", $3, $3*100/$2}')"
                echo "CPU: $(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | cut -d'%' -f1)% user"
                echo "Processes: $(ps aux | wc -l) total"
                echo ""
                echo "=== Recent Errors (last 2 min) ==="
                journalctl -p err --since "2 minutes ago" --no-pager 2>/dev/null | tail -20
                echo ""
                echo "=== Failed Services ==="
                systemctl list-units --failed --no-pager 2>/dev/null || echo "Could not list failed services"
            } > "$LOG_DIR/status-$TIMESTAMP.log" 2>&1
            sync  # Force write to disk
            
            # Rotate logs (keep last 5)
            ls -t "$LOG_DIR"/status-*.log 2>/dev/null | tail -n +6 | xargs -r rm
        fi
        
        # Service recovery (interval varies by Pi model)
        if [ $RECOVERY_COUNTER -ge $RECOVERY_INTERVAL ]; then
            RECOVERY_COUNTER=0
            
            # Check network mode before attempting NetworkManager operations
            NETWORK_MODE=$(cat /var/lib/droidnet/network-state 2>/dev/null || echo "unknown")
            
            # Only check NetworkManager if not in AP mode
            if [ "$NETWORK_MODE" != "ap_active" ] && [ "$NETWORK_MODE" != "starting_ap" ]; then
                # Check critical services (but be smart about droidnet-ap)
                for service in NetworkManager; do
                    if ! systemctl is-active --quiet $service 2>/dev/null; then
                        echo "[$(date)] WARNING: $service is not active, attempting restart" >> "$LOG_DIR/recovery.log"
                        systemctl restart $service 2>&1 >> "$LOG_DIR/recovery.log"
                        if systemctl is-active --quiet $service 2>/dev/null; then
                            echo "[$(date)] SUCCESS: $service restarted successfully" >> "$LOG_DIR/recovery.log"
                        else
                            echo "[$(date)] ERROR: Failed to restart $service" >> "$LOG_DIR/recovery.log"
                        fi
                    fi
                done
            else
                # Log that we're skipping NetworkManager check in AP mode
                echo "[$(date)] INFO: Skipping NetworkManager check - network mode is $NETWORK_MODE" >> "$LOG_DIR/recovery.log"
            fi
            
            # Fix-Plan-34: Remove check for deprecated droidnet-ap service
            # AP mode is now handled by droidnet-network-controller which manages hostapd directly
            
            # Check if we're in AP mode before enforcing AP IP
            # Use network-state file instead of nmcli to avoid hangs
            if [ "$NETWORK_MODE" = "ap_active" ]; then
                # Only ensure AP IP if we're actually in AP mode
                if ! ip addr show wlan0 2>/dev/null | grep -q "inet 192.168.4.1"; then
                    echo "[$(date)] WARNING: AP mode active but IP missing, attempting to restore" >> "$LOG_DIR/recovery.log"
                    # First flush any existing IPs
                    ip addr flush dev wlan0 2>&1 >> "$LOG_DIR/recovery.log"
                    # Bring interface up
                    ip link set wlan0 up 2>&1 >> "$LOG_DIR/recovery.log"
                    # Add IP
                    ip addr add 192.168.4.1/24 dev wlan0 2>&1 >> "$LOG_DIR/recovery.log"
                    # Log result
                    echo "[$(date)] wlan0 status after IP assignment:" >> "$LOG_DIR/recovery.log"
                    ip addr show wlan0 >> "$LOG_DIR/recovery.log" 2>&1
                fi
            elif [ "$NETWORK_MODE" = "client" ] || [ "$NETWORK_MODE" = "starting_client" ]; then
                echo "[$(date)] Client mode active (not enforcing AP IP)" >> "$LOG_DIR/recovery.log"
            fi
            
            # Force write recovery log
            sync
            
            # Rotate recovery log if too large (>1MB)
            if [ -f "$LOG_DIR/recovery.log" ]; then
                size=$(stat -c%s "$LOG_DIR/recovery.log" 2>/dev/null || echo 0)
                if [ "$size" -gt 1048576 ]; then
                    mv "$LOG_DIR/recovery.log" "$LOG_DIR/recovery-old.log"
                    echo "[$(date)] Log rotated" > "$LOG_DIR/recovery.log"
                fi
            fi
        fi
        
        # Sync NetworkManager logs (interval varies by Pi model)
        if [ $DNSMASQ_COUNTER -ge $NM_SYNC_INTERVAL ]; then
            DNSMASQ_COUNTER=0
            
            # Only sync NetworkManager logs if it's running
            if systemctl is-active --quiet NetworkManager 2>/dev/null; then
                # Get NetworkManager logs from journal
                journalctl -u NetworkManager -n 200 --no-pager > "$LOG_DIR/networkmanager-latest.log" 2>/dev/null
                
                # Also check for AP connection status
                nmcli con show --active | grep -E "DroidNet-AP|wifi" >> "$LOG_DIR/networkmanager-latest.log" 2>/dev/null
            else
                echo "[$(date)] NetworkManager not active - skipping log sync" > "$LOG_DIR/networkmanager-latest.log"
            fi
        fi
        
        sleep $BASE_INTERVAL
    done
