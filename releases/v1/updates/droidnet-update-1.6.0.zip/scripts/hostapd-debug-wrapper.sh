#!/bin/bash
# hostapd debug wrapper for enhanced error capture
# Part of Fix-Plan-03

LOG_FILE="/var/log/hostapd-debug.log"
BOOT_LOG="/boot/firmware/droidnet-logs/hostapd-debug.log"

# Ensure log directories exist
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$BOOT_LOG")"

# Log start
echo "[$(date '+%Y-%m-%d %H:%M:%S')] Starting hostapd with args: $@" | tee -a "$LOG_FILE"

# Capture system state
echo "[$(date '+%Y-%m-%d %H:%M:%S')] System state before hostapd:" | tee -a "$LOG_FILE"
echo "-- Interface status --" | tee -a "$LOG_FILE"
ip link show wlan0 2>&1 | tee -a "$LOG_FILE"
echo "-- WiFi device info --" | tee -a "$LOG_FILE"
/usr/sbin/iw dev wlan0 info 2>&1 | tee -a "$LOG_FILE"
echo "-- RFKill status --" | tee -a "$LOG_FILE"
/usr/sbin/rfkill list 2>&1 | tee -a "$LOG_FILE"
echo "-- Regulatory domain --" | tee -a "$LOG_FILE"
/usr/sbin/iw reg get 2>&1 | tee -a "$LOG_FILE"

# Run hostapd with full output capture
echo "[$(date '+%Y-%m-%d %H:%M:%S')] Executing: /usr/sbin/hostapd $@" | tee -a "$LOG_FILE"
/usr/sbin/hostapd "$@" 2>&1 | while IFS= read -r line; do
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $line" | tee -a "$LOG_FILE"
done

# Capture exit code
EXIT_CODE=${PIPESTATUS[0]}
echo "[$(date '+%Y-%m-%d %H:%M:%S')] hostapd exited with code: $EXIT_CODE" | tee -a "$LOG_FILE"

# Capture system state after
echo "[$(date '+%Y-%m-%d %H:%M:%S')] System state after hostapd exit:" | tee -a "$LOG_FILE"
ip link show wlan0 2>&1 | tee -a "$LOG_FILE"
/usr/sbin/iw dev wlan0 info 2>&1 | tee -a "$LOG_FILE"

# Copy to boot partition if debug enabled
if [ -f /opt/droidnet/config/debug.conf ]; then
    source /opt/droidnet/config/debug.conf
    if [ "$DEBUG_MODE" = "1" ]; then
        cp "$LOG_FILE" "$BOOT_LOG"
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] Debug log copied to boot partition" | tee -a "$LOG_FILE"
    fi
fi

exit $EXIT_CODE