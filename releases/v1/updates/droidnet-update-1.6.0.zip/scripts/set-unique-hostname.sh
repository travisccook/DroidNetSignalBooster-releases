#!/bin/bash
# Set unique hostname with collision detection and user preference support
# This prevents conflicts when multiple DroidNet devices are on the same network

LOG="/var/log/droidnet-hostname.log"
CONFIG_FILE="/opt/droidnet/config/device-name.conf"
ASSIGNED_NAME_FILE="/opt/droidnet/config/assigned-name.conf"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | tee -a "$LOG"
}

# Get MAC address suffix (last 4 hex digits without colons)
get_mac_suffix() {
    local mac=$(cat /sys/class/net/wlan0/address 2>/dev/null || cat /sys/class/net/eth0/address 2>/dev/null)
    if [ -n "$mac" ]; then
        # Get last 2 octets and remove colons, convert to uppercase for SSID
        echo "$mac" | cut -d: -f5-6 | tr -d : | tr '[:lower:]' '[:upper:]'
    else
        # Fallback to random 4-digit hex
        printf "%04X" $RANDOM
    fi
}

# Read user-configured name if exists
get_user_configured_name() {
    if [ -f "$CONFIG_FILE" ] && [ -s "$CONFIG_FILE" ]; then
        # Read first line, remove any whitespace
        local name=$(head -n1 "$CONFIG_FILE" | tr -d '[:space:]')
        if [ -n "$name" ]; then
            echo "$name"
            return 0
        fi
    fi
    return 1
}

# Read previously assigned name if exists
get_assigned_name() {
    if [ -f "$ASSIGNED_NAME_FILE" ] && [ -s "$ASSIGNED_NAME_FILE" ]; then
        local name=$(head -n1 "$ASSIGNED_NAME_FILE" | tr -d '[:space:]')
        if [ -n "$name" ]; then
            echo "$name"
            return 0
        fi
    fi
    return 1
}

# Save assigned name for consistency
save_assigned_name() {
    local name="$1"
    mkdir -p "$(dirname "$ASSIGNED_NAME_FILE")"
    echo "$name" > "$ASSIGNED_NAME_FILE"
}

log "Setting unique hostname for DroidNet device..."

# Get MAC suffix for SSID (always use this for AP SSID)
MAC_SUFFIX=$(get_mac_suffix)
log "MAC suffix for SSID: $MAC_SUFFIX"

# Determine hostname based on priority:
# 1. User-configured name
# 2. Previously assigned name (for consistency)
# 3. Check for collisions and assign new name

NEW_HOSTNAME=""

# Check for user-configured name
if USER_NAME=$(get_user_configured_name); then
    log "User-configured name found: $USER_NAME"
    # Still check for collisions with user name
    if [ -x /opt/droidnet/scripts/check-hostname-collision.sh ]; then
        NEW_HOSTNAME=$(/opt/droidnet/scripts/check-hostname-collision.sh "$USER_NAME")
    else
        NEW_HOSTNAME="$USER_NAME"
    fi
elif ASSIGNED_NAME=$(get_assigned_name); then
    # Use previously assigned name for consistency
    log "Using previously assigned name: $ASSIGNED_NAME"
    NEW_HOSTNAME="$ASSIGNED_NAME"
else
    # No user preference or previous assignment, check for collisions
    log "No user preference found, checking for hostname collisions..."
    if [ -x /opt/droidnet/scripts/check-hostname-collision.sh ]; then
        NEW_HOSTNAME=$(/opt/droidnet/scripts/check-hostname-collision.sh "droidnet")
        # Save the assigned name for future boots
        save_assigned_name "$NEW_HOSTNAME"
    else
        # Fallback to simple droidnet
        NEW_HOSTNAME="droidnet"
    fi
fi

log "Selected hostname: $NEW_HOSTNAME"

# Check if hostname is already set correctly
CURRENT_HOSTNAME=$(hostname)
if [ "$CURRENT_HOSTNAME" = "$NEW_HOSTNAME" ]; then
    log "Hostname already set correctly to $NEW_HOSTNAME"
else
    # Set the new hostname
    log "Changing hostname from $CURRENT_HOSTNAME to $NEW_HOSTNAME"
    
    # Update /etc/hostname
    echo "$NEW_HOSTNAME" > /etc/hostname
    
    # Update /etc/hosts
    if grep -q "127.0.1.1" /etc/hosts; then
        # Replace existing 127.0.1.1 entry
        sed -i "s/127\.0\.1\.1.*/127.0.1.1\t$NEW_HOSTNAME/" /etc/hosts
    else
        # Add new entry
        echo "127.0.1.1	$NEW_HOSTNAME" >> /etc/hosts
    fi
    
    # Ensure localhost entries exist
    if ! grep -q "127.0.0.1\s*localhost" /etc/hosts; then
        echo "127.0.0.1	localhost" >> /etc/hosts
    fi
    
    # Set hostname immediately
    hostname "$NEW_HOSTNAME"
    
    # If systemd-hostnamed is available, use it
    if command -v hostnamectl >/dev/null 2>&1; then
        hostnamectl set-hostname "$NEW_HOSTNAME" || log "hostnamectl failed, but hostname was set manually"
    fi
    
    # Update avahi configuration if it exists
    if [ -f /etc/avahi/avahi-daemon.conf ]; then
        log "Updating avahi configuration..."
        # Comment out or update the host-name line
        sed -i "s/^host-name=.*/host-name=$NEW_HOSTNAME/" /etc/avahi/avahi-daemon.conf || \
        sed -i "s/^#*host-name=.*/host-name=$NEW_HOSTNAME/" /etc/avahi/avahi-daemon.conf
    fi
    
    # Restart avahi-daemon if it's running to pick up new hostname
    if systemctl is-active --quiet avahi-daemon; then
        log "Restarting avahi-daemon for mDNS update..."
        systemctl restart avahi-daemon
    fi
fi

log "Hostname configured as: $NEW_HOSTNAME"
log "Device will be accessible as ${NEW_HOSTNAME}.local"

# Always update the SSID to use MAC suffix (for physical identification)
if nmcli con show "DroidNet-AP" >/dev/null 2>&1; then
    log "Updating AP SSID with MAC suffix..."
    nmcli con modify "DroidNet-AP" wifi.ssid "DroidNet-${MAC_SUFFIX}"
    log "AP SSID set to DroidNet-${MAC_SUFFIX}"
fi

exit 0