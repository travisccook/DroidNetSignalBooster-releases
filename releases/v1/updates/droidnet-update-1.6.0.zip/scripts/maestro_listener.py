#!/usr/bin/env python3
"""
Maestro Always-On Listener
Monitors Maestro state and provides real-time position feedback
Follows the WCBListener pattern for consistency with existing DroidNet architecture
"""

import asyncio
import logging
from typing import Dict, Callable, Optional, List
from dataclasses import dataclass, field
from datetime import datetime

logger = logging.getLogger(__name__)


@dataclass
class ServoState:
    """Current state of a servo channel."""

    channel: int
    target: int = 6000  # Quarter-microseconds
    position: int = 6000
    speed: int = 0
    acceleration: int = 0
    last_updated: datetime = field(default_factory=datetime.now)


@dataclass
class MaestroState:
    """Complete Maestro device state."""

    port: str
    model: str
    channels: int
    connected: bool = False
    script_running: bool = False
    errors: int = 0
    servos: Dict[int, ServoState] = field(default_factory=dict)

    def __post_init__(self):
        # Initialize servo states for all channels
        for i in range(self.channels):
            self.servos[i] = ServoState(channel=i)


class MaestroListener:
    """
    Always-on listener for Maestro servo controller.

    Periodically polls servo positions and errors, broadcasting
    state updates to registered handlers.

    Follows the same pattern as WCBListener for consistency.
    """

    def __init__(
        self,
        controller,  # MaestroController instance
        model_info: Dict,
        poll_interval: float = 0.1,  # 10Hz default
        position_poll_channels: Optional[List[int]] = None,
    ):
        """
        Initialize Maestro listener.

        Args:
            controller: MaestroController instance
            model_info: Dict with 'name' and 'channels' keys
            poll_interval: Polling interval in seconds (default 0.1 = 10Hz)
            position_poll_channels: List of channels to poll, or None for all
        """
        self.controller = controller
        self.model_info = model_info
        self.poll_interval = poll_interval
        self.position_poll_channels = position_poll_channels

        self.state = MaestroState(
            port=controller.port,
            model=model_info["name"],
            channels=model_info["channels"],
        )

        self._running = False
        self._initialized = False  # True after first position poll completes
        self._init_event: Optional[asyncio.Event] = None
        self._poll_task: Optional[asyncio.Task] = None
        self._event_handlers: Dict[str, List[Callable]] = {
            "position": [],
            "error": [],
            "script_status": [],
            "connection": [],
        }

    def register_handler(self, event_type: str, handler: Callable):
        """
        Register callback for state events.

        Args:
            event_type: 'position', 'error', 'script_status', or 'connection'
            handler: Callback function (can be async or sync)
        """
        if event_type in self._event_handlers:
            self._event_handlers[event_type].append(handler)
            logger.debug(f"Registered {event_type} handler for {self.state.port}")

    def unregister_handler(self, event_type: str, handler: Callable):
        """
        Remove callback for state events.

        Args:
            event_type: Type of event
            handler: Callback function to remove
        """
        if event_type in self._event_handlers:
            try:
                self._event_handlers[event_type].remove(handler)
                logger.debug(f"Unregistered {event_type} handler for {self.state.port}")
            except ValueError:
                pass

    async def _emit(self, event_type: str, data: dict):
        """
        Emit event to all registered handlers.

        Args:
            event_type: Type of event
            data: Event data dictionary
        """
        for handler in self._event_handlers.get(event_type, []):
            try:
                if asyncio.iscoroutinefunction(handler):
                    await handler(data)
                else:
                    handler(data)
            except Exception as e:
                logger.error(f"Handler error for {event_type}: {e}")

    async def _read_initial_positions(self):
        """Read initial positions from device before serving clients."""
        loop = asyncio.get_running_loop()
        channels = self.position_poll_channels or range(self.state.channels)

        for channel in channels:
            try:
                position = await loop.run_in_executor(
                    None, self.controller.get_position, channel
                )
                if position is not None:
                    self.state.servos[channel].position = position
                    self.state.servos[channel].target = position
                    self.state.servos[channel].last_updated = datetime.now()
            except Exception as e:
                logger.warning(f"Failed to read initial position for ch {channel}: {e}")

        logger.debug(f"Initial positions read for {self.state.port}")

    async def start(self):
        """Start the polling loop."""
        if self._running:
            logger.warning(f"Listener already running for {self.state.port}")
            return

        self._running = True
        self._initialized = False
        self._init_event = asyncio.Event()
        self.state.connected = True
        await self._emit("connection", {"connected": True, "port": self.state.port})

        # Read initial positions before starting poll loop
        # This ensures get_state() returns accurate data immediately
        await self._read_initial_positions()
        self._initialized = True
        self._init_event.set()

        self._poll_task = asyncio.create_task(self._poll_loop())
        logger.info(f"MaestroListener started for {self.state.port}")

    async def stop(self):
        """Stop the polling loop."""
        self._running = False
        self._initialized = False

        if self._poll_task:
            self._poll_task.cancel()
            try:
                await self._poll_task
            except asyncio.CancelledError:
                pass

        self.state.connected = False
        await self._emit("connection", {"connected": False, "port": self.state.port})
        logger.info(f"MaestroListener stopped for {self.state.port}")

    async def _poll_errors_and_scripts(self, loop):
        """Poll error and script status (called at 1Hz)."""
        errors = await loop.run_in_executor(None, self.controller.get_errors)
        if errors is not None and errors != self.state.errors:
            self.state.errors = errors
            error_list = await loop.run_in_executor(
                None, self.controller.get_error_list
            )
            await self._emit(
                "error",
                {
                    "type": "error",
                    "errors": errors,
                    "error_names": error_list,
                    "port": self.state.port,
                },
            )

        script_running = await loop.run_in_executor(
            None, self.controller.get_script_status
        )
        if script_running is not None and script_running != self.state.script_running:
            self.state.script_running = script_running
            await self._emit(
                "script_status",
                {
                    "type": "script_status",
                    "running": script_running,
                    "port": self.state.port,
                },
            )

    async def _poll_loop(self):
        """
        Main polling loop.

        Polls servo positions at 10Hz and errors/script status at 1Hz.
        """
        error_poll_counter = 0
        loop = asyncio.get_running_loop()

        while self._running:
            try:
                channels = self.position_poll_channels or range(self.state.channels)

                for channel in channels:
                    position = await loop.run_in_executor(
                        None,
                        self.controller.get_position,
                        channel,
                    )
                    if position is not None:
                        old = self.state.servos[channel].position
                        self.state.servos[channel].position = position
                        self.state.servos[channel].last_updated = datetime.now()

                        if abs(position - old) > 10:
                            await self._emit(
                                "position",
                                {
                                    "type": "position",
                                    "channel": channel,
                                    "position": position,
                                    "position_us": position / 4.0,
                                    "port": self.state.port,
                                },
                            )

                error_poll_counter += 1
                if error_poll_counter >= 10:
                    error_poll_counter = 0
                    await self._poll_errors_and_scripts(loop)

                await asyncio.sleep(self.poll_interval)

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Poll error for {self.state.port}: {e}")
                await asyncio.sleep(1.0)

    def get_state(self) -> dict:
        """
        Get current complete state as dictionary.

        Returns:
            Dict with port, model, channels, connected, servos
        """
        return {
            "port": self.state.port,
            "model": self.state.model,
            "channels": self.state.channels,
            "connected": self.state.connected,
            "script_running": self.state.script_running,
            "errors": self.state.errors,
            "servos": {
                ch: {
                    "target": s.target,
                    "position": s.position,
                    "position_us": s.position / 4.0,
                    "speed": s.speed,
                    "acceleration": s.acceleration,
                    "last_updated": s.last_updated.isoformat(),
                }
                for ch, s in self.state.servos.items()
            },
        }

    def update_target(self, channel: int, target: int):
        """
        Update the stored target value for a channel.

        Called by the manager when a set_target command is sent.

        Args:
            channel: Channel number
            target: Target in quarter-microseconds
        """
        if channel in self.state.servos:
            self.state.servos[channel].target = target

    def update_speed(self, channel: int, speed: int):
        """
        Update the stored speed value for a channel.

        Args:
            channel: Channel number
            speed: Speed limit
        """
        if channel in self.state.servos:
            self.state.servos[channel].speed = speed

    def update_acceleration(self, channel: int, acceleration: int):
        """
        Update the stored acceleration value for a channel.

        Args:
            channel: Channel number
            acceleration: Acceleration limit
        """
        if channel in self.state.servos:
            self.state.servos[channel].acceleration = acceleration
