#!/usr/bin/env python3
"""
WCB (Wireless Communication Board) Configuration Manager

Manages WCB device configuration and persistence.
Thread-safe with file locking and atomic writes.
"""

import json
import os
import fcntl
import tempfile
import shutil
import time
import logging
from pathlib import Path
from typing import Dict, List, Any

logger = logging.getLogger(__name__)

CONFIG_DIR = Path("/opt/droidnet/config")
WCB_CONFIG_FILE = CONFIG_DIR / "wcb-config.json"
WCB_CONFIG_LOCK = "/var/lock/wcb_config.lock"

# Default configuration
DEFAULT_WCB_CONFIG = {"enabled": False, "wcb_devices": [], "update_delay_ms": 250}


def ensure_config_dir() -> None:
    """Ensure the configuration directory exists."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def _ensure_lock_dir() -> None:
    """Ensure the lock file directory exists."""
    os.makedirs(os.path.dirname(WCB_CONFIG_LOCK), exist_ok=True)


def _acquire_lock(lock_fd) -> bool:
    """Acquire exclusive lock on config file."""
    try:
        fcntl.flock(lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return True
    except BlockingIOError:
        # Lock held by another process, wait for it
        fcntl.flock(lock_fd, fcntl.LOCK_EX)
        return True


def _release_lock(lock_fd) -> None:
    """Release lock on config file."""
    try:
        fcntl.flock(lock_fd, fcntl.LOCK_UN)
    except OSError as e:
        logger.warning(f"OS error releasing WCB config lock: {e}")


def _read_config_file() -> Dict[str, Any]:
    """
    Read config file with error recovery.
    Should be called while holding the lock.
    """
    if not WCB_CONFIG_FILE.exists():
        return DEFAULT_WCB_CONFIG.copy()

    try:
        with open(WCB_CONFIG_FILE, "r") as f:
            config: Dict[str, Any] = json.load(f)
            # Ensure correct structure
            if not isinstance(config, dict):
                logger.warning("Invalid WCB config structure, resetting")
                return DEFAULT_WCB_CONFIG.copy()
            # Ensure all required fields exist
            for key, default_value in DEFAULT_WCB_CONFIG.items():
                if key not in config:
                    config[key] = default_value
            return config
    except json.JSONDecodeError as e:
        logger.error(f"Corrupted WCB config JSON: {e}")
        # Backup corrupted file
        backup_path = f"{WCB_CONFIG_FILE}.corrupt.{int(time.time())}"
        try:
            shutil.copy2(WCB_CONFIG_FILE, backup_path)
            logger.info(f"Backed up corrupted WCB config to {backup_path}")
        except Exception as backup_err:
            logger.error(f"Failed to backup corrupted WCB config: {backup_err}")
        return DEFAULT_WCB_CONFIG.copy()
    except (OSError, IOError) as e:
        logger.error(f"File error reading WCB config: {e}")
        return DEFAULT_WCB_CONFIG.copy()


def _write_config_atomic(config: Dict[str, Any]) -> bool:
    """
    Write config file atomically to prevent corruption.
    Should be called while holding the lock.
    """
    # Validate config has required fields
    for key in DEFAULT_WCB_CONFIG:
        if key not in config:
            config[key] = DEFAULT_WCB_CONFIG[key]

    # Write to temporary file first
    temp_fd, temp_path = tempfile.mkstemp(
        dir=str(CONFIG_DIR),
        prefix=".wcb_config_",
        suffix=".tmp",
    )

    try:
        with os.fdopen(temp_fd, "w") as f:
            json.dump(config, f, indent=2)
            f.flush()
            os.fsync(f.fileno())

        # Atomic rename
        os.rename(temp_path, WCB_CONFIG_FILE)
        return True
    except (OSError, IOError) as e:
        logger.error(f"File error writing WCB config: {e}")
        # Clean up temp file
        try:
            os.unlink(temp_path)
        except OSError:
            pass
        return False
    except (TypeError, ValueError) as e:
        logger.error(f"Data serialization error writing WCB config: {e}")
        # Clean up temp file
        try:
            os.unlink(temp_path)
        except OSError:
            pass
        return False


def load_wcb_config() -> Dict[str, Any]:
    """
    Load WCB configuration from file with proper locking.

    Returns:
        Dict containing WCB configuration
    """
    ensure_config_dir()
    _ensure_lock_dir()

    if not WCB_CONFIG_FILE.exists():
        # Create default config if it doesn't exist
        save_wcb_config(DEFAULT_WCB_CONFIG)
        return DEFAULT_WCB_CONFIG.copy()

    lock_fd = None
    try:
        lock_fd = open(WCB_CONFIG_LOCK, "w")
        _acquire_lock(lock_fd)

        return _read_config_file()

    except (OSError, IOError) as e:
        logger.error(f"Error loading WCB config: {e}")
        return DEFAULT_WCB_CONFIG.copy()
    finally:
        if lock_fd:
            _release_lock(lock_fd)
            lock_fd.close()


def save_wcb_config(config: Dict[str, Any]) -> bool:
    """
    Save WCB configuration to file atomically with proper locking.

    Args:
        config: Configuration dictionary to save

    Returns:
        True if successful, False otherwise
    """
    ensure_config_dir()
    _ensure_lock_dir()

    lock_fd = None
    try:
        lock_fd = open(WCB_CONFIG_LOCK, "w")
        _acquire_lock(lock_fd)

        return _write_config_atomic(config)

    except (OSError, IOError) as e:
        logger.error(f"Error saving WCB config: {e}")
        return False
    finally:
        if lock_fd:
            _release_lock(lock_fd)
            lock_fd.close()


def is_wcb_device(device_id: str) -> bool:
    """
    Check if a device is marked as a WCB device.

    Args:
        device_id: Unique identifier for the device

    Returns:
        True if device is marked as WCB, False otherwise
    """
    config = load_wcb_config()
    return device_id in config.get("wcb_devices", [])


def toggle_wcb_device(device_id: str, enabled: bool) -> bool:
    """
    Mark or unmark a device as WCB.

    Args:
        device_id: Unique identifier for the device
        enabled: True to mark as WCB, False to unmark

    Returns:
        True if successful, False otherwise
    """
    config = load_wcb_config()
    wcb_devices = config.get("wcb_devices", [])

    if enabled and device_id not in wcb_devices:
        wcb_devices.append(device_id)
    elif not enabled and device_id in wcb_devices:
        wcb_devices.remove(device_id)
    else:
        # No change needed
        return True

    config["wcb_devices"] = wcb_devices
    return save_wcb_config(config)


def get_wcb_devices() -> List[str]:
    """
    Get list of devices marked as WCB.

    Returns:
        List of device IDs marked as WCB
    """
    config = load_wcb_config()
    wcb_devices: List[str] = config.get("wcb_devices", [])
    return wcb_devices


def update_wcb_enabled(enabled: bool) -> bool:
    """
    Enable or disable the WCB feature.

    Args:
        enabled: True to enable WCB feature, False to disable

    Returns:
        True if successful, False otherwise
    """
    config = load_wcb_config()
    config["enabled"] = enabled
    return save_wcb_config(config)


def update_wcb_delay(delay_ms: int) -> bool:
    """
    Update the WCB update delay in milliseconds.

    Args:
        delay_ms: Delay in milliseconds (100-1000)

    Returns:
        True if successful, False otherwise
    """
    # Validate delay range
    if delay_ms < 100 or delay_ms > 1000:
        return False

    config = load_wcb_config()
    config["update_delay_ms"] = delay_ms
    return save_wcb_config(config)


def _handle_command(command: str, args: List[str]) -> None:
    """Handle command line interface."""
    if command == "status":
        config = load_wcb_config()
        print(json.dumps(config, indent=2))

    elif command == "enable" and len(args) > 0:
        enabled = args[0].lower() == "true"
        if update_wcb_enabled(enabled):
            print(f"WCB feature {'enabled' if enabled else 'disabled'}")
        else:
            print("Failed to update WCB enabled status")

    elif command == "device" and len(args) > 1:
        device_id = args[0]
        enabled = args[1].lower() == "true"
        if toggle_wcb_device(device_id, enabled):
            action = "marked" if enabled else "unmarked"
            print(f"Device {device_id} {action} as WCB")
        else:
            print(f"Failed to update device {device_id}")

    elif command == "list":
        devices = get_wcb_devices()
        if devices:
            print("WCB Devices:")
            for device in devices:
                print(f"  - {device}")
        else:
            print("No devices marked as WCB")

    else:
        print("Usage:")
        print("  wcb_config.py status                    - Show current config")
        print("  wcb_config.py enable true|false         - Enable/disable WCB")
        print("  wcb_config.py device <id> true|false    - Mark/unmark as WCB")
        print("  wcb_config.py list                      - List WCB devices")


if __name__ == "__main__":
    # Test/debug functionality
    import sys

    if len(sys.argv) > 1:
        _handle_command(sys.argv[1], sys.argv[2:])
    else:
        # Default: show status
        config = load_wcb_config()
        print(json.dumps(config, indent=2))
