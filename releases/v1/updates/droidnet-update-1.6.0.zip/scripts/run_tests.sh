#!/bin/bash
#
# DroidNet Signal Booster - Test Runner
#
# Quick test runner optimized for AI-assisted development with Claude Code.
# Provides fast feedback loops and comprehensive validation modes.
#
# Usage:
#   ./scripts/run_tests.sh [mode]
#
# Modes:
#   fast     - Quick unit tests only (default, ~5 seconds)
#   full     - All tests except hardware-dependent (~30 seconds)
#   coverage - Full tests with coverage report
#   lint     - Code style and type checking only
#   all      - Complete validation (lint + coverage)
#   single   - Run a specific test file or pattern
#
# Examples:
#   ./scripts/run_tests.sh fast
#   ./scripts/run_tests.sh coverage
#   ./scripts/run_tests.sh single tests/test_event_bus.py
#   ./scripts/run_tests.sh single -k "test_subscribe"
#

set -e

MODE="${1:-fast}"
EXTRA_ARGS="${@:2}"
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$PROJECT_ROOT"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Print header
echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}DroidNet Test Runner${NC}"
echo -e "${BLUE}Mode: ${YELLOW}$MODE${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# Check if pytest is installed
if ! python -c "import pytest" 2>/dev/null; then
    echo -e "${RED}Error: pytest not installed${NC}"
    echo -e "Run: ${YELLOW}pip install -r requirements-dev.txt${NC}"
    exit 1
fi

run_tests() {
    local start_time=$(date +%s)

    case $MODE in
        fast)
            # Fast tests only - for quick feedback during development
            # Excludes slow and hardware tests, stops on first failure
            echo -e "${YELLOW}Running fast tests (unit tests, no hardware)...${NC}"
            echo ""
            python -m pytest tests/ \
                -m "not slow and not hardware" \
                -x \
                -q \
                --tb=line \
                --no-header \
                $EXTRA_ARGS
            ;;

        full)
            # All tests except hardware-dependent
            echo -e "${YELLOW}Running full test suite...${NC}"
            echo ""
            python -m pytest tests/ \
                -m "not hardware" \
                -v \
                --tb=short \
                $EXTRA_ARGS
            ;;

        coverage)
            # Full tests with coverage report
            echo -e "${YELLOW}Running tests with coverage analysis...${NC}"
            echo ""
            python -m pytest tests/ \
                -m "not hardware" \
                --cov=web \
                --cov=scripts \
                --cov-report=term-missing \
                --cov-report=html:htmlcov \
                --cov-report=xml:coverage.xml \
                -v \
                $EXTRA_ARGS
            echo ""
            echo -e "${GREEN}Coverage report generated:${NC}"
            echo -e "  HTML: ${BLUE}htmlcov/index.html${NC}"
            echo -e "  XML:  ${BLUE}coverage.xml${NC}"
            ;;

        lint)
            # Linting and type checking only
            echo -e "${YELLOW}Running code quality checks...${NC}"
            echo ""

            echo -e "${BLUE}[1/3] Black (formatting)...${NC}"
            python -m black --check --diff web/ scripts/ tests/ 2>&1 || {
                echo -e "${RED}Black found formatting issues. Run: black web/ scripts/ tests/${NC}"
                exit 1
            }
            echo -e "${GREEN}  Passed${NC}"

            echo -e "${BLUE}[2/3] Flake8 (linting)...${NC}"
            python -m flake8 web/ scripts/ tests/ --count --show-source --statistics || {
                echo -e "${RED}Flake8 found issues${NC}"
                exit 1
            }
            echo -e "${GREEN}  Passed${NC}"

            echo -e "${BLUE}[3/3] Mypy (type checking)...${NC}"
            python -m mypy web/ scripts/ --config-file pyproject.toml 2>&1 || {
                echo -e "${YELLOW}Mypy found type issues (non-blocking)${NC}"
            }
            echo -e "${GREEN}  Completed${NC}"
            ;;

        all)
            # Everything: lint + full tests + coverage
            echo -e "${YELLOW}Running complete validation suite...${NC}"
            echo ""
            $0 lint
            echo ""
            $0 coverage
            ;;

        single)
            # Run specific test file or pattern
            if [ -z "$EXTRA_ARGS" ]; then
                echo -e "${RED}Error: Please specify a test file or pattern${NC}"
                echo "Usage: $0 single tests/test_file.py"
                echo "       $0 single -k 'test_pattern'"
                exit 1
            fi
            echo -e "${YELLOW}Running: pytest $EXTRA_ARGS${NC}"
            echo ""
            python -m pytest $EXTRA_ARGS -v --tb=short
            ;;

        watch)
            # Watch mode - requires pytest-watch
            if ! python -c "import pytest_watch" 2>/dev/null; then
                echo -e "${RED}Error: pytest-watch not installed${NC}"
                echo -e "Run: ${YELLOW}pip install pytest-watch${NC}"
                exit 1
            fi
            echo -e "${YELLOW}Starting watch mode (Ctrl+C to stop)...${NC}"
            python -m pytest_watch -- tests/ -m "not slow and not hardware" -x -q
            ;;

        help|--help|-h)
            echo "Usage: $0 [mode] [extra_args]"
            echo ""
            echo "Modes:"
            echo "  fast      Quick unit tests only (default)"
            echo "  full      All tests except hardware-dependent"
            echo "  coverage  Full tests with coverage report"
            echo "  lint      Code style and type checking only"
            echo "  all       Complete validation (lint + coverage)"
            echo "  single    Run specific test file or pattern"
            echo "  watch     Watch mode (requires pytest-watch)"
            echo "  help      Show this help message"
            echo ""
            echo "Examples:"
            echo "  $0 fast"
            echo "  $0 coverage"
            echo "  $0 single tests/test_event_bus.py"
            echo "  $0 single -k 'test_subscribe'"
            exit 0
            ;;

        *)
            echo -e "${RED}Unknown mode: $MODE${NC}"
            echo "Run '$0 help' for usage information"
            exit 1
            ;;
    esac

    local end_time=$(date +%s)
    local duration=$((end_time - start_time))

    echo ""
    echo -e "${GREEN}========================================${NC}"
    echo -e "${GREEN}Completed in ${duration}s${NC}"
    echo -e "${GREEN}========================================${NC}"
}

# Run tests and capture exit code
run_tests
exit_code=$?

# Return appropriate exit code
exit $exit_code
