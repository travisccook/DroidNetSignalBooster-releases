#!/usr/bin/env python3
"""
Maestro Script Compiler

Compiles Maestro script source code to bytecode that can be
uploaded to Pololu Maestro servo controllers.

Based on the Pololu Maestro scripting language specification.
"""

import re
from enum import IntEnum
from typing import List, Dict, Tuple, Optional, Set


class Opcode(IntEnum):
    """Maestro bytecode opcodes."""
    QUIT = 0
    LITERAL = 1
    LITERAL_N = 2
    LITERAL_8 = 3
    # Math ops
    PLUS = 4
    MINUS = 5
    TIMES = 6
    DIVIDE = 7
    MOD = 8
    POSITIVE = 9
    NEGATIVE = 10
    # Logic ops
    LOGICAL_NOT = 11
    LOGICAL_AND = 12
    LOGICAL_OR = 13
    BITWISE_NOT = 14
    BITWISE_AND = 15
    BITWISE_OR = 16
    BITWISE_XOR = 17
    # Comparison
    EQUALS = 18
    NOT_EQUALS = 19
    LESS_THAN = 20
    GREATER_THAN = 21
    LESS_OR_EQUAL = 22
    GREATER_OR_EQUAL = 23
    # Stack ops
    DROP = 24
    DUP = 25
    SWAP = 26
    OVER = 27
    # Servo commands
    SERVO = 28
    SPEED = 29
    ACCELERATION = 30
    GET_POSITION = 31
    # Time
    DELAY = 32
    GET_MS = 33
    # Flow control
    BEGIN = 0x41
    REPEAT = 0x42
    WHILE = 0x43
    IF = 0x44
    ELSE = 0x45
    ENDIF = 0x46
    RETURN = 0x47
    GOTO = 0x48
    # Subroutine calls start at 0x50 (80 decimal)
    # Subroutine N is called with opcode 0x50 + N


class CompileError(Exception):
    """Raised when compilation fails."""
    pass


class MaestroCompiler:
    """
    Compiles Maestro script source to bytecode.

    Supported features:
    - Numeric literals (short form 0-127, long form for larger values)
    - Commands: servo, speed, acceleration, delay, get_position, get_ms
    - Stack ops: drop, dup, swap, over
    - Math: plus, minus, times, divide, mod
    - Logic: not, and, or
    - Bitwise: ~, &, |, ^
    - Comparison: equals, not_equals, less_than, greater_than, etc.
    - Flow control: begin/repeat/while, if/else/endif
    - Subroutines: sub name ... return
    - Comments: # or //

    Note: This is a simplified compiler suitable for basic scripts.
    For complex scripts, use the Pololu SDK compiler.
    """

    # Map of keywords to opcodes
    KEYWORDS = {
        'quit': Opcode.QUIT,
        'servo': Opcode.SERVO,
        'speed': Opcode.SPEED,
        'acceleration': Opcode.ACCELERATION,
        'get_position': Opcode.GET_POSITION,
        'delay': Opcode.DELAY,
        'get_ms': Opcode.GET_MS,
        'drop': Opcode.DROP,
        'dup': Opcode.DUP,
        'swap': Opcode.SWAP,
        'over': Opcode.OVER,
        'plus': Opcode.PLUS,
        'minus': Opcode.MINUS,
        'times': Opcode.TIMES,
        'divide': Opcode.DIVIDE,
        'mod': Opcode.MOD,
        'positive': Opcode.POSITIVE,
        'negative': Opcode.NEGATIVE,
        'not': Opcode.LOGICAL_NOT,
        'and': Opcode.LOGICAL_AND,
        'or': Opcode.LOGICAL_OR,
        'equals': Opcode.EQUALS,
        'not_equals': Opcode.NOT_EQUALS,
        'less_than': Opcode.LESS_THAN,
        'greater_than': Opcode.GREATER_THAN,
        'less_or_equal': Opcode.LESS_OR_EQUAL,
        'greater_or_equal': Opcode.GREATER_OR_EQUAL,
        'begin': Opcode.BEGIN,
        'repeat': Opcode.REPEAT,
        'while': Opcode.WHILE,
        'if': Opcode.IF,
        'else': Opcode.ELSE,
        'endif': Opcode.ENDIF,
        'return': Opcode.RETURN,
    }

    # Alternative keyword names
    KEYWORD_ALIASES = {
        '+': Opcode.PLUS,
        '-': Opcode.MINUS,
        '*': Opcode.TIMES,
        '/': Opcode.DIVIDE,
        '%': Opcode.MOD,
        '=': Opcode.EQUALS,
        '!=': Opcode.NOT_EQUALS,
        '<': Opcode.LESS_THAN,
        '>': Opcode.GREATER_THAN,
        '<=': Opcode.LESS_OR_EQUAL,
        '>=': Opcode.GREATER_OR_EQUAL,
        '&&': Opcode.LOGICAL_AND,
        '||': Opcode.LOGICAL_OR,
        '!': Opcode.LOGICAL_NOT,
        '~': Opcode.BITWISE_NOT,
        '&': Opcode.BITWISE_AND,
        '|': Opcode.BITWISE_OR,
        '^': Opcode.BITWISE_XOR,
    }

    def __init__(self):
        self.reset()

    def reset(self):
        """Reset compiler state."""
        self.bytecode = bytearray()
        self.subroutines: Dict[str, int] = {}  # name (lowercase) -> index
        self.subroutine_names: Dict[str, str] = {}  # lowercase -> original name
        self.subroutine_addresses: Dict[str, int] = {}  # name -> bytecode address
        self.errors: List[str] = []
        self.line_num = 0
        self.in_subroutine = False
        self.current_subroutine = None
        self.flow_stack: List[str] = []  # Track begin/if nesting for validation

    def compile(self, source: str) -> Tuple[bytes, List[str]]:
        """
        Compile script source to bytecode.

        Args:
            source: Script source code

        Returns:
            Tuple of (bytecode, error_list)
        """
        self.reset()

        lines = source.strip().split('\n')

        # First pass: collect subroutine names (case-insensitive)
        for i, line in enumerate(lines):
            clean_line = self._strip_comments(line).strip().lower()
            if clean_line.startswith('sub '):
                original_name = line.strip()[4:].strip()
                name_lower = original_name.lower()
                if name_lower in self.subroutines:
                    self.errors.append(f"Line {i + 1}: Duplicate subroutine name: {original_name}")
                else:
                    sub_index = len(self.subroutines)
                    if sub_index > 127:
                        self.errors.append(f"Line {i + 1}: Too many subroutines (max 128)")
                    else:
                        self.subroutines[name_lower] = sub_index
                        self.subroutine_names[name_lower] = original_name

        if self.errors:
            return bytes(), self.errors

        # Second pass: compile
        for i, line in enumerate(lines):
            self.line_num = i + 1
            try:
                self._compile_line(line)
            except CompileError as e:
                self.errors.append(f"Line {self.line_num}: {e}")
            except Exception as e:
                self.errors.append(f"Line {self.line_num}: Internal error: {e}")

        return bytes(self.bytecode), self.errors

    def _strip_comments(self, line: str) -> str:
        """Remove comments from line."""
        # Handle # comments
        if '#' in line:
            line = line[:line.index('#')]
        # Handle // comments
        if '//' in line:
            line = line[:line.index('//')]
        return line

    def _compile_line(self, line: str):
        """Compile a single line."""
        line = self._strip_comments(line).strip()
        if not line:
            return

        # Check for subroutine definition
        if line.lower().startswith('sub '):
            name = line[4:].strip().lower()  # Normalize to lowercase
            self.in_subroutine = True
            self.current_subroutine = name
            self.subroutine_addresses[name] = len(self.bytecode)
            return

        tokens = self._tokenize(line)

        for token in tokens:
            self._compile_token(token)

    def _tokenize(self, line: str) -> List[str]:
        """
        Split line into tokens.

        Handles multi-character operators and preserves case for subroutine names.
        """
        # Pattern matches: numbers, words (subroutine names), and operators
        pattern = r'(-?\d+)|([a-zA-Z_][a-zA-Z0-9_\.]*)|([!=<>]=|&&|\|\||[+\-*/%=<>!~&|^])'
        tokens = []

        for match in re.finditer(pattern, line):
            token = match.group()
            tokens.append(token)

        return tokens

    def _compile_token(self, token: str):
        """Compile a single token to bytecode."""
        token_lower = token.lower()

        # Check for keyword
        if token_lower in self.KEYWORDS:
            if token_lower == 'return':
                if self.in_subroutine:
                    self.bytecode.append(Opcode.RETURN)
                    self.in_subroutine = False
                    self.current_subroutine = None
                else:
                    raise CompileError("'return' outside of subroutine")
            elif token_lower == 'begin':
                self.flow_stack.append('begin')
                self.bytecode.append(self.KEYWORDS[token_lower])
            elif token_lower == 'repeat':
                if not self.flow_stack or self.flow_stack[-1] != 'begin':
                    raise CompileError("'repeat' without matching 'begin'")
                self.flow_stack.pop()
                self.bytecode.append(self.KEYWORDS[token_lower])
            elif token_lower == 'while':
                if not self.flow_stack or self.flow_stack[-1] != 'begin':
                    raise CompileError("'while' without matching 'begin'")
                self.flow_stack.pop()
                self.bytecode.append(self.KEYWORDS[token_lower])
            elif token_lower == 'if':
                self.flow_stack.append('if')
                self.bytecode.append(self.KEYWORDS[token_lower])
            elif token_lower == 'else':
                if not self.flow_stack or self.flow_stack[-1] != 'if':
                    raise CompileError("'else' without matching 'if'")
                self.flow_stack[-1] = 'else'  # Replace 'if' with 'else'
                self.bytecode.append(self.KEYWORDS[token_lower])
            elif token_lower == 'endif':
                if not self.flow_stack or self.flow_stack[-1] not in ('if', 'else'):
                    raise CompileError("'endif' without matching 'if'")
                self.flow_stack.pop()
                self.bytecode.append(self.KEYWORDS[token_lower])
            else:
                self.bytecode.append(self.KEYWORDS[token_lower])
            return

        # Check for operator alias
        if token in self.KEYWORD_ALIASES:
            self.bytecode.append(self.KEYWORD_ALIASES[token])
            return

        # Check for numeric literal
        if self._is_number(token):
            self._encode_literal(int(token))
            return

        # Check for subroutine call (case-insensitive)
        if token_lower in self.subroutines:
            sub_index = self.subroutines[token_lower]
            self.bytecode.append(0x50 + sub_index)
            return

        # Unknown token
        raise CompileError(f"Unknown token: {token}")

    def _is_number(self, token: str) -> bool:
        """Check if token is a numeric literal."""
        try:
            int(token)
            return True
        except ValueError:
            return False

    def _encode_literal(self, value: int):
        """
        Encode a numeric literal.

        Values 0-127 use short form (value + 128).
        Larger values use LITERAL opcode followed by 2 bytes (little-endian).
        Signed 16-bit range: -32768 to 32767.
        """
        # Validate signed 16-bit range first
        if value < -32768 or value > 32767:
            raise CompileError(f"Literal out of signed 16-bit range: {value}")

        if 0 <= value <= 127:
            # Short literal
            self.bytecode.append(value + 128)
        else:
            # Full 16-bit literal
            if value < 0:
                value = value & 0xFFFF  # Two's complement

            self.bytecode.append(Opcode.LITERAL)
            self.bytecode.append(value & 0xFF)
            self.bytecode.append((value >> 8) & 0xFF)

    def get_subroutine_map(self) -> Dict[int, str]:
        """
        Get mapping of subroutine index to name.

        Returns:
            Dictionary mapping index (0-127) to subroutine name (original case)
        """
        return {idx: self.subroutine_names.get(name_lower, name_lower)
                for name_lower, idx in self.subroutines.items()}


def compile_script(source: str) -> Tuple[bytes, List[str], Dict[int, str]]:
    """
    Convenience function to compile a script.

    Args:
        source: Script source code

    Returns:
        Tuple of (bytecode, errors, subroutine_map)
    """
    compiler = MaestroCompiler()
    bytecode, errors = compiler.compile(source)
    subroutine_map = compiler.get_subroutine_map()
    return bytecode, errors, subroutine_map


if __name__ == "__main__":
    # Example usage
    test_script = """
# Test script
sub test_sequence
  6000 0 servo   # Move channel 0 to center
  500 delay      # Wait 500ms
  4000 0 servo   # Move to low position
  500 delay
  return

sub main
  begin
    test_sequence
  repeat
"""

    print("=== Compiling Test Script ===")
    print(test_script)
    print()

    bytecode, errors, sub_map = compile_script(test_script)

    if errors:
        print("Compilation errors:")
        for err in errors:
            print(f"  {err}")
    else:
        print(f"Bytecode ({len(bytecode)} bytes):")
        print("  " + " ".join(f"{b:02X}" for b in bytecode))
        print()
        print("Subroutine map:")
        for idx, name in sorted(sub_map.items()):
            print(f"  {idx} -> {name}")
