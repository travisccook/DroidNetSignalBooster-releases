#!/usr/bin/env python3
"""
Victron Telemetry Storage

Handles persistence of Victron telemetry data to disk.
"""

import json
import logging
from pathlib import Path
from typing import Optional, List, Dict, Any
from dataclasses import asdict
from datetime import datetime

logger = logging.getLogger(__name__)

DATA_DIR = Path("/opt/droidnet/data")
TELEMETRY_FILE = DATA_DIR / "victron_telemetry.json"


def ensure_data_dir() -> None:
    """Ensure the data directory exists."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)


def save_telemetry_snapshot(
    latest: Optional[Any] = None, history: Optional[List[Any]] = None
) -> bool:
    """
    Save telemetry snapshot to disk.

    Args:
        latest: Latest VictronTelemetry object
        history: List of VictronTelemetry objects

    Returns:
        True if successful, False otherwise
    """
    ensure_data_dir()

    try:
        snapshot = {
            "latest": asdict(latest) if latest else None,
            "history": [asdict(t) for t in (history or [])],
            "saved_at": datetime.now().isoformat(),
        }

        with open(TELEMETRY_FILE, "w") as f:
            json.dump(snapshot, f, indent=2)

        return True

    except Exception as e:
        logger.error(f"Failed to save telemetry snapshot: {e}", exc_info=True)
        return False


def load_telemetry_snapshot() -> Optional[Dict[str, Any]]:
    """
    Load telemetry snapshot from disk.

    Returns:
        Dict with 'latest' and 'history' keys, or None if file doesn't exist
    """
    ensure_data_dir()

    if not TELEMETRY_FILE.exists():
        return None

    try:
        with open(TELEMETRY_FILE, "r") as f:
            snapshot = json.load(f)

        # Convert dicts back to VictronTelemetry objects
        from scripts.victron_listener import VictronTelemetry

        if snapshot.get("latest"):
            # Restore as dict (will be converted by manager if needed)
            pass

        if snapshot.get("history"):
            # Convert history list to VictronTelemetry objects
            history = []
            for item in snapshot["history"]:
                try:
                    telemetry = VictronTelemetry(**item)
                    history.append(telemetry)
                except Exception as e:
                    logger.warning(f"Failed to restore telemetry item: {e}")
                    continue
            snapshot["history"] = history

        logger.info(
            f"Loaded telemetry snapshot with {len(snapshot.get('history', []))} samples"
        )
        return snapshot

    except Exception as e:
        logger.error(f"Failed to load telemetry snapshot: {e}", exc_info=True)
        return None


def prune_old_telemetry(max_age_seconds: int) -> bool:
    """
    Remove telemetry data older than specified age.

    Args:
        max_age_seconds: Maximum age of telemetry to keep

    Returns:
        True if successful, False otherwise
    """
    snapshot = load_telemetry_snapshot()
    if not snapshot:
        return True

    try:
        cutoff_time = datetime.now().timestamp() - max_age_seconds

        # Filter history
        history = snapshot.get("history", [])
        original_count = len(history)

        # Keep only recent data
        pruned_history = [t for t in history if t.timestamp >= cutoff_time]

        pruned_count = original_count - len(pruned_history)

        if pruned_count > 0:
            logger.info(f"Pruned {pruned_count} old telemetry samples")

            # Save updated snapshot
            snapshot["history"] = pruned_history
            save_telemetry_snapshot(
                snapshot.get("latest"), snapshot.get("history", [])
            )

        return True

    except Exception as e:
        logger.error(f"Failed to prune old telemetry: {e}", exc_info=True)
        return False


def clear_telemetry_storage() -> bool:
    """
    Delete all stored telemetry data.

    Returns:
        True if successful, False otherwise
    """
    try:
        if TELEMETRY_FILE.exists():
            TELEMETRY_FILE.unlink()
            logger.info("Telemetry storage cleared")
        return True

    except Exception as e:
        logger.error(f"Failed to clear telemetry storage: {e}", exc_info=True)
        return False


def get_storage_info() -> Dict[str, Any]:
    """
    Get information about telemetry storage.

    Returns:
        Dict with file size, sample count, age, etc.
    """
    info = {
        "exists": TELEMETRY_FILE.exists(),
        "size_bytes": 0,
        "sample_count": 0,
        "oldest_timestamp": None,
        "newest_timestamp": None,
    }

    if TELEMETRY_FILE.exists():
        try:
            info["size_bytes"] = TELEMETRY_FILE.stat().st_size

            snapshot = load_telemetry_snapshot()
            if snapshot:
                history = snapshot.get("history", [])
                info["sample_count"] = len(history)

                if history:
                    info["oldest_timestamp"] = history[0].timestamp
                    info["newest_timestamp"] = history[-1].timestamp

        except Exception as e:
            logger.error(f"Failed to get storage info: {e}")

    return info


if __name__ == "__main__":
    # Test/debug functionality
    import sys

    if len(sys.argv) > 1:
        command = sys.argv[1]

        if command == "info":
            info = get_storage_info()
            print(json.dumps(info, indent=2))

        elif command == "clear":
            if clear_telemetry_storage():
                print("Storage cleared")
            else:
                print("Failed to clear storage")

        elif command == "prune" and len(sys.argv) > 2:
            seconds = int(sys.argv[2])
            if prune_old_telemetry(seconds):
                print(f"Pruned data older than {seconds} seconds")
            else:
                print("Failed to prune")

        else:
            print("Usage:")
            print("  victron_storage.py info          - Show storage info")
            print("  victron_storage.py clear         - Clear all data")
            print("  victron_storage.py prune <sec>   - Remove data older than N seconds")
    else:
        # Default: show info
        info = get_storage_info()
        print(json.dumps(info, indent=2))
