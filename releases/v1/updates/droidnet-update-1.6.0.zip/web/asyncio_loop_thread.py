"""
AsyncioEventLoopThread - Persistent asyncio event loop in dedicated thread

Provides a thread-safe bridge between synchronous HTTP request handlers
and asynchronous serial port operations. Ensures background tasks persist
across HTTP requests.
"""

import asyncio
import threading
import logging
from concurrent.futures import Future
from typing import Optional

logger = logging.getLogger(__name__)


class AsyncioEventLoopThread:
    """
    Dedicated thread running persistent asyncio event loop.
    Provides thread-safe interface for sync code to interact with async components.

    This solves the problem of asyncio.run() creating temporary event loops
    that destroy background tasks when HTTP requests complete.

    Usage:
        # During server startup
        loop_thread = AsyncioEventLoopThread()
        loop_thread.start()

        # From HTTP request handler (any thread)
        result = loop_thread.run_coroutine(some_async_function())

        # During server shutdown
        loop_thread.stop()
    """

    def __init__(self):
        self.loop: Optional[asyncio.AbstractEventLoop] = None
        self.thread: Optional[threading.Thread] = None
        self._started = threading.Event()
        self._shutdown = threading.Event()

    def start(self) -> None:
        """
        Start the background event loop thread.

        Raises:
            RuntimeError: If loop fails to start within 5 seconds
        """
        if self.thread and self.thread.is_alive():
            logger.warning("AsyncioEventLoopThread already running")
            return

        self.thread = threading.Thread(
            target=self._run_event_loop, name="AsyncioEventLoop", daemon=False
        )
        self.thread.start()

        # Wait for loop to be ready
        if not self._started.wait(timeout=5.0):
            raise RuntimeError("Failed to start asyncio event loop within 5 seconds")

        logger.info("AsyncioEventLoopThread started successfully")

    def _run_event_loop(self) -> None:
        """
        Run the event loop in this thread (blocks until shutdown).
        Called in the background thread.
        """
        # Create new event loop for this thread
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)

        # Signal that loop is ready
        self._started.set()

        logger.info("Event loop thread running")

        try:
            # Run forever until shutdown requested
            self.loop.run_forever()
        finally:
            # Cleanup
            self._cleanup_loop()

    def _cleanup_loop(self) -> None:
        """Clean up the event loop and cancel all tasks."""
        try:
            # Cancel all running tasks
            pending = asyncio.all_tasks(self.loop)
            if pending:
                logger.info(f"Cancelling {len(pending)} pending tasks")
                for task in pending:
                    task.cancel()

                # Wait for tasks to complete cancellation
                self.loop.run_until_complete(
                    asyncio.gather(*pending, return_exceptions=True)
                )

            # Close the loop
            self.loop.close()
            logger.info("Event loop closed successfully")

        except Exception as e:
            logger.error(f"Error during event loop cleanup: {e}", exc_info=True)
        finally:
            logger.info("Event loop thread stopped")

    def stop(self) -> None:
        """
        Stop the event loop and thread.
        Waits up to 10 seconds for graceful shutdown.
        """
        if not self.loop or not self.thread:
            logger.debug("Event loop thread not running, nothing to stop")
            return

        logger.info("Stopping event loop thread")

        # Schedule loop stop from within the loop (thread-safe)
        self.loop.call_soon_threadsafe(self.loop.stop)

        # Wait for thread to finish
        self.thread.join(timeout=10.0)

        if self.thread.is_alive():
            logger.warning("Event loop thread did not stop cleanly within 10 seconds")
        else:
            logger.info("Event loop thread stopped successfully")

    def run_coroutine(self, coro):
        """
        Run a coroutine in the background loop and wait for result.
        Thread-safe: Can be called from any thread.

        Args:
            coro: Coroutine to execute

        Returns:
            Result of the coroutine

        Raises:
            RuntimeError: If event loop not running
            Any exception raised by the coroutine
        """
        if not self.loop or not self.loop.is_running():
            raise RuntimeError("Event loop not running")

        # Use concurrent.futures.Future for thread-safe result passing
        future = Future()

        async def execute():
            try:
                result = await coro
                future.set_result(result)
            except Exception as e:
                future.set_exception(e)

        # Schedule coroutine in the background loop
        asyncio.run_coroutine_threadsafe(execute(), self.loop)

        # Wait for result (blocks calling thread)
        return future.result()

    def run_coroutine_async(self, coro):
        """
        Schedule a coroutine in the background loop without waiting.
        Thread-safe: Can be called from any thread.

        Args:
            coro: Coroutine to execute

        Returns:
            concurrent.futures.Future that will contain the result

        Raises:
            RuntimeError: If event loop not running
        """
        if not self.loop or not self.loop.is_running():
            raise RuntimeError("Event loop not running")

        return asyncio.run_coroutine_threadsafe(coro, self.loop)

    def is_running(self) -> bool:
        """Check if the event loop is currently running."""
        return self.loop is not None and self.loop.is_running()
