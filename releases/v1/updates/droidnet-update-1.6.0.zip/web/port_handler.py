"""
PortHandler - Single-owner serial port manager with event distribution

Part of the serial communication architecture refactor.
See docs/SERIAL_ARCHITECTURE_PLAN.md for details.
"""

import asyncio
import logging
import queue
import time
import threading
from typing import Optional
import serial

from web.event_bus import EventBus

logger = logging.getLogger(__name__)

# Diagnostic timing flag - set to True to debug latency issues
DEBUG_TIMING = False


class PortHandler:
    """
    Single owner of a serial port with event distribution.

    Manages all I/O for a single serial port through:
    - Single reader task (publishes to EventBus)
    - Single writer task (processes queue)
    - EventBus for data distribution to multiple subscribers

    Example:
        handler = PortHandler('/dev/ttyUSB0', 115200, always_on=True)
        await handler.start()

        # Subscribe to events
        async def on_data(event):
            print(event['line'])

        handler.subscribe('data', on_data)

        # Write to port
        await handler.write('?CONFIG')
    """

    def __init__(
        self, port: str, baud: int, always_on: bool = False, timeout: float = 0.1
    ):
        """
        Initialize port handler.

        Args:
            port: Serial port path (e.g., '/dev/ttyUSB0')
            baud: Baud rate (e.g., 115200)
            always_on: If True, reconnect forever with backoff
            timeout: Serial read timeout in seconds
        """
        self.port = port
        self.baud = baud
        self.always_on = always_on
        self.timeout = timeout

        # Serial connection
        self.serial: Optional[serial.Serial] = None

        # Event distribution
        self.event_bus = EventBus()

        # Write queue for serialized writes (bounded to prevent memory exhaustion)
        self.write_queue = asyncio.Queue(maxsize=100)
        self.write_lock = asyncio.Lock()
        # Thread-safe queue for cross-thread writes (WebSocket -> serial)
        self._threadsafe_queue: queue.Queue = queue.Queue(maxsize=100)

        # Task management
        self.running = False
        self.main_loop_task: Optional[asyncio.Task] = None
        self.reader_task: Optional[asyncio.Task] = None
        self.writer_task: Optional[asyncio.Task] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None  # For thread-safe writes

        # Statistics
        self.stats = {
            "bytes_sent": 0,
            "bytes_received": 0,
            "lines_sent": 0,
            "lines_received": 0,
            "error_count": 0,
            "reconnect_count": 0,
            "start_time": None,
            "last_activity": None,
            "last_error": None,
        }

        # Reconnection backoff
        self.reconnect_backoff = 1.0
        self.max_backoff = 60.0 if always_on else 2.0
        self.max_retries = None if always_on else 3
        self.retry_count = 0

        # Line buffering
        self.line_buffer = ""

        # Serial output history (for always-on monitoring)
        # Store last 500 lines with timestamps
        self.history_buffer: list = []
        self.max_history: int = 500

        # Event publish queue - decouples serial reading from event delivery
        # This prevents slow subscribers from blocking serial buffer draining
        self._publish_queue: asyncio.Queue = None  # Created in start()
        self._publisher_task: Optional[asyncio.Task] = None

    async def start(self) -> None:
        """Start the port handler and begin I/O tasks."""
        if self.running:
            logger.warning(f"PortHandler for {self.port} already running")
            return

        self.running = True
        self.stats["start_time"] = time.time()

        # Capture event loop for thread-safe write operations
        self._loop = asyncio.get_running_loop()

        # Initialize publish queue - decouples serial reading from event delivery
        # Large but bounded to prevent unlimited memory growth
        self._publish_queue = asyncio.Queue(maxsize=10000)

        logger.info(
            f"Starting PortHandler for {self.port} at {self.baud} baud "
            f"(always_on={self.always_on})"
        )

        # Start publisher task (runs for lifetime of PortHandler)
        self._publisher_task = asyncio.create_task(self._publisher_loop())

        # Start main loop and store task reference to prevent garbage collection
        self.main_loop_task = asyncio.create_task(self._main_loop())

    async def stop(self) -> None:
        """Stop the port handler and close connection."""
        logger.info(f"Stopping PortHandler for {self.port}")
        self.running = False

        # Cancel main loop task first (it owns the serial connection lifecycle)
        if self.main_loop_task:
            self.main_loop_task.cancel()
            try:
                await self.main_loop_task
            except asyncio.CancelledError:
                pass

        # Cancel I/O tasks if they still exist
        if self.reader_task and not self.reader_task.done():
            self.reader_task.cancel()
            try:
                await self.reader_task
            except asyncio.CancelledError:
                pass

        if self.writer_task and not self.writer_task.done():
            self.writer_task.cancel()
            try:
                await self.writer_task
            except asyncio.CancelledError:
                pass

        # Cancel publisher task
        if self._publisher_task and not self._publisher_task.done():
            self._publisher_task.cancel()
            try:
                await self._publisher_task
            except asyncio.CancelledError:
                pass

        # Ensure serial connection is closed (may already be closed by main_loop)
        if self.serial and self.serial.is_open:
            try:
                # Flush any pending writes before closing
                self.serial.flush()
            except Exception:
                pass  # Ignore flush errors on shutdown
            self.serial.close()
            logger.info(f"Serial port {self.port} closed")

        # Small delay to ensure OS releases the port
        await asyncio.sleep(0.1)

    async def _main_loop(self) -> None:
        """Main connection loop with reconnection logic."""
        while self.running:
            try:
                # Attempt connection
                await self._connect()

                # Reset backoff on successful connection
                self.reconnect_backoff = 1.0
                self.retry_count = 0

                # Start I/O tasks
                self.reader_task = asyncio.create_task(self._reader_task())
                self.writer_task = asyncio.create_task(self._writer_task())

                # Wait for tasks to complete (or fail)
                await asyncio.gather(
                    self.reader_task, self.writer_task, return_exceptions=True
                )

            except Exception as e:
                logger.error(f"Error in {self.port} main loop: {e}")
                self.stats["error_count"] += 1
                self.stats["last_error"] = str(e)

                # Publish error event
                await self.event_bus.publish(
                    "error",
                    {"port": self.port, "error": str(e), "timestamp": time.time()},
                )

            finally:
                # Close connection if open
                if self.serial and self.serial.is_open:
                    self.serial.close()

            # Check if we should retry
            if not self.running:
                break

            if self.max_retries is not None and self.retry_count >= self.max_retries:
                logger.error(
                    f"Max retries ({self.max_retries}) exceeded for {self.port}, "
                    "giving up"
                )
                await self.event_bus.publish(
                    "status",
                    {
                        "port": self.port,
                        "status": "failed",
                        "message": "Max retries exceeded",
                        "timestamp": time.time(),
                    },
                )
                break

            # Exponential backoff
            self.retry_count += 1
            self.stats["reconnect_count"] += 1

            await self.event_bus.publish(
                "status",
                {
                    "port": self.port,
                    "status": "reconnecting",
                    "message": f"Reconnection attempt {self.retry_count}",
                    "backoff": self.reconnect_backoff,
                    "timestamp": time.time(),
                },
            )

            logger.info(
                f"Reconnecting to {self.port} in {self.reconnect_backoff}s "
                f"(attempt {self.retry_count})"
            )

            await asyncio.sleep(self.reconnect_backoff)

            # Increase backoff
            self.reconnect_backoff = min(self.reconnect_backoff * 2, self.max_backoff)

    async def _connect(self) -> None:
        """Open serial connection."""
        logger.info(f"Opening serial port {self.port} at {self.baud} baud")

        self.serial = serial.Serial(self.port, self.baud, timeout=self.timeout)

        # Explicitly toggle DTR to force Arduino reset
        # This ensures reset happens even if DTR was already high from a previous session
        try:
            self.serial.dtr = False
            await asyncio.sleep(0.1)
            self.serial.dtr = True
            await asyncio.sleep(0.1)
            logger.debug(f"DTR toggled on {self.port} to trigger Arduino reset")
        except Exception as e:
            # Some serial devices don't support DTR control - that's OK
            logger.debug(f"Could not toggle DTR on {self.port}: {e}")

        logger.info(f"Serial port {self.port} opened successfully")

        await self.event_bus.publish(
            "status",
            {
                "port": self.port,
                "status": "connected",
                "baud": self.baud,
                "timestamp": time.time(),
            },
        )

    async def _publisher_loop(self) -> None:
        """
        Separate task to publish events from queue.

        This decouples serial reading from event delivery, ensuring slow
        subscribers never block the serial buffer from being drained.
        """
        logger.debug(f"Publisher task started for {self.port}")
        try:
            while self.running:
                try:
                    # Wait for event from queue with timeout
                    event = await asyncio.wait_for(
                        self._publish_queue.get(), timeout=1.0
                    )

                    # Publish to event bus (this may take time with slow subscribers)
                    event_type = event.get("_type", "data")
                    # Remove internal _type field before publishing
                    if "_type" in event:
                        del event["_type"]

                    await self.event_bus.publish(event_type, event)

                except asyncio.TimeoutError:
                    # No events - check running flag and continue
                    continue
                except Exception as e:
                    logger.error(f"Error publishing event for {self.port}: {e}")

        except asyncio.CancelledError:
            # Drain remaining events before exiting
            while not self._publish_queue.empty():
                try:
                    event = self._publish_queue.get_nowait()
                    event_type = event.get("_type", "data")
                    if "_type" in event:
                        del event["_type"]
                    await self.event_bus.publish(event_type, event)
                except Exception:
                    break
            raise

        logger.debug(f"Publisher task stopped for {self.port}")

    async def _reader_task(self) -> None:
        """Single reader task - publishes all data to event bus."""
        logger.debug(f"Reader task started for {self.port}")
        _reader_loop_count = 0
        _reader_last_log = time.time()

        while self.running and self.serial and self.serial.is_open:
            try:
                _reader_loop_count += 1
                if DEBUG_TIMING and time.time() - _reader_last_log > 5.0:
                    logger.warning(
                        f"[TIMING] reader loop: {_reader_loop_count} iterations in 5s = {_reader_loop_count/5:.1f}/sec"
                    )
                    _reader_loop_count = 0
                    _reader_last_log = time.time()
                    # Dump all tasks in the event loop to identify blockers
                    try:
                        all_tasks = asyncio.all_tasks()
                        logger.warning(
                            f"[TIMING] Active tasks in event loop: {len(all_tasks)}"
                        )
                        for task in all_tasks:
                            task_name = (
                                task.get_name()
                                if hasattr(task, "get_name")
                                else str(task)
                            )
                            coro = task.get_coro()
                            coro_name = (
                                coro.__qualname__
                                if hasattr(coro, "__qualname__")
                                else str(coro)
                            )
                            logger.warning(
                                f"[TIMING]   Task: {task_name} -> {coro_name} done={task.done()}"
                            )
                    except Exception as e:
                        logger.warning(f"[TIMING] Failed to dump tasks: {e}")

                # Time the in_waiting check
                _t_check = time.time()
                _in_waiting = self.serial.in_waiting
                _check_elapsed = (time.time() - _t_check) * 1000
                if DEBUG_TIMING and _check_elapsed > 50:
                    logger.warning(
                        f"[TIMING] in_waiting check took {_check_elapsed:.0f}ms"
                    )

                if _in_waiting > 0:
                    # BURST READ MODE: Keep reading without yielding while data flows
                    # This prevents buffer overflow on Pi Zero W at high baud rates
                    # by draining the kernel buffer as fast as possible
                    burst_reads = 0
                    burst_start = time.time()

                    while self.serial.in_waiting > 0 and burst_reads < 100:
                        # Read available data (max 4096 bytes per read)
                        bytes_to_read = min(self.serial.in_waiting, 4096)
                        chunk = self.serial.read(bytes_to_read)
                        burst_reads += 1

                        if not chunk:
                            break

                        # Update statistics
                        self.stats["bytes_received"] += len(chunk)
                        self.stats["last_activity"] = time.time()

                        # Decode with error replacement
                        try:
                            text = chunk.decode("utf-8")
                        except UnicodeDecodeError as e:
                            logger.warning(
                                f"UTF-8 decode error on {self.port}: {e}, "
                                "using replacement"
                            )
                            text = chunk.decode("utf-8", errors="replace")

                        # Add to line buffer
                        self.line_buffer += text

                        # Normalize line endings
                        self.line_buffer = self.line_buffer.replace("\r\n", "\n")
                        self.line_buffer = self.line_buffer.replace("\r", "\n")

                        # Process complete lines
                        while "\n" in self.line_buffer:
                            line, self.line_buffer = self.line_buffer.split("\n", 1)
                            line = line.strip()

                            if line:
                                self.stats["lines_received"] += 1
                                timestamp = time.time()

                                # Add to history buffer
                                self.history_buffer.append(
                                    {
                                        "line": line,
                                        "timestamp": timestamp,
                                        "direction": "received",
                                    }
                                )
                                if len(self.history_buffer) > self.max_history:
                                    self.history_buffer.pop(0)

                                # Queue for publishing (non-blocking to prevent serial overflow)
                                # The _publisher_loop task will deliver to subscribers
                                try:
                                    self._publish_queue.put_nowait(
                                        {
                                            "_type": "data",
                                            "port": self.port,
                                            "line": line,
                                            "timestamp": timestamp,
                                        }
                                    )
                                except asyncio.QueueFull:
                                    logger.warning(
                                        f"Publish queue full for {self.port}, dropping line"
                                    )
                                    self.stats["error_count"] += 1

                        # Brief check if more data arrived during processing
                        # Don't sleep, just check and continue if data present

                    if DEBUG_TIMING and burst_reads > 1:
                        burst_elapsed = (time.time() - burst_start) * 1000
                        logger.debug(
                            f"[TIMING] Burst read: {burst_reads} reads in {burst_elapsed:.1f}ms"
                        )

                else:
                    # No data available, yield to other tasks
                    # Use short sleep (1ms) to catch high-speed data bursts
                    # At 115200 baud, 1ms = ~11.5 bytes, so 4096 byte buffer
                    # gives us ~350ms before overflow
                    _t_sleep = time.time()
                    await asyncio.sleep(0.001)
                    _sleep_elapsed = (time.time() - _t_sleep) * 1000
                    if DEBUG_TIMING and _sleep_elapsed > 10:
                        logger.warning(
                            f"[TIMING] reader asyncio.sleep took {_sleep_elapsed:.0f}ms (expected ~1ms)"
                        )

            except serial.SerialException as e:
                logger.error(f"Serial read error on {self.port}: {e}")
                self.stats["error_count"] += 1
                self.stats["last_error"] = str(e)
                raise  # Exit reader task to trigger reconnection

            except Exception as e:
                logger.error(f"Unexpected error in reader task for {self.port}: {e}")
                self.stats["error_count"] += 1
                self.stats["last_error"] = str(e)
                raise

        logger.debug(f"Reader task stopped for {self.port}")

    async def _writer_task(self) -> None:
        """Single writer task - processes queue sequentially."""
        logger.debug(f"Writer task started for {self.port}")

        _loop_count = 0
        _last_log_time = time.time()
        while self.running and self.serial and self.serial.is_open:
            try:
                data = None
                from_asyncio_queue = False
                _loop_count += 1

                # Log loop frequency every 5 seconds
                if DEBUG_TIMING and time.time() - _last_log_time > 5.0:
                    logger.warning(
                        f"[TIMING] writer loop: {_loop_count} iterations in 5s = {_loop_count/5:.1f}/sec"
                    )
                    _loop_count = 0
                    _last_log_time = time.time()

                # First, check thread-safe queue (for cross-thread writes) - non-blocking
                try:
                    data = self._threadsafe_queue.get_nowait()
                    if DEBUG_TIMING:
                        t_dequeue = time.time()
                        logger.warning(
                            f"[TIMING] writer dequeued from THREADSAFE queue at {t_dequeue:.3f} thread={threading.current_thread().name} data={data[:50]!r}"
                        )
                except queue.Empty:
                    pass  # No cross-thread data pending

                # If no cross-thread data, check asyncio queue with short timeout
                if data is None:
                    try:
                        _t_wait = time.time()
                        data = await asyncio.wait_for(
                            self.write_queue.get(), timeout=0.01
                        )
                        from_asyncio_queue = True
                        if DEBUG_TIMING:
                            t_dequeue = time.time()
                            logger.warning(
                                f"[TIMING] writer dequeued from asyncio queue at {t_dequeue:.3f} thread={threading.current_thread().name} data={data[:50]!r}"
                            )
                    except asyncio.TimeoutError:
                        _wait_elapsed = (time.time() - _t_wait) * 1000
                        if DEBUG_TIMING and _wait_elapsed > 50:
                            logger.warning(
                                f"[TIMING] writer wait_for timeout took {_wait_elapsed:.0f}ms (expected ~10ms)"
                            )
                        continue  # No commands pending - loop back to check threadsafe queue

                # Atomic write operation
                async with self.write_lock:
                    # Ensure data ends with newline
                    if not data.endswith("\n"):
                        data += "\n"

                    # Write to serial port
                    if DEBUG_TIMING:
                        t_before_write = time.time()
                    self.serial.write(data.encode("utf-8"))
                    self.serial.flush()
                    if DEBUG_TIMING:
                        logger.warning(
                            f"[TIMING] serial write+flush took {(time.time()-t_before_write)*1000:.1f}ms"
                        )

                    timestamp = time.time()

                    # Update statistics
                    self.stats["bytes_sent"] += len(data)
                    self.stats["lines_sent"] += 1
                    self.stats["last_activity"] = timestamp

                    logger.debug(f"Wrote to {self.port}: {data.strip()}")

                    # Add to history buffer
                    self.history_buffer.append(
                        {
                            "line": data.strip(),
                            "timestamp": timestamp,
                            "direction": "sent",
                        }
                    )
                    # Maintain max history size
                    if len(self.history_buffer) > self.max_history:
                        self.history_buffer.pop(0)

                    # Queue sent command for publishing (non-blocking)
                    if DEBUG_TIMING:
                        t_before_publish = time.time()
                    try:
                        self._publish_queue.put_nowait(
                            {
                                "_type": "data",
                                "port": self.port,
                                "line": data.strip(),
                                "timestamp": timestamp,
                                "direction": "sent",
                            }
                        )
                    except asyncio.QueueFull:
                        logger.warning(f"Publish queue full for {self.port} (sent)")
                    if DEBUG_TIMING:
                        logger.warning(
                            f"[TIMING] publish queue put took {(time.time()-t_before_publish)*1000:.1f}ms"
                        )

                # Only call task_done for asyncio queue
                if from_asyncio_queue:
                    self.write_queue.task_done()

            except serial.SerialException as e:
                logger.error(f"Serial write error on {self.port}: {e}")
                self.stats["error_count"] += 1
                self.stats["last_error"] = str(e)
                raise  # Exit writer task to trigger reconnection

            except Exception as e:
                logger.error(f"Unexpected error in writer task for {self.port}: {e}")
                self.stats["error_count"] += 1
                self.stats["last_error"] = str(e)

        logger.debug(f"Writer task stopped for {self.port}")

    async def write(self, data: str) -> None:
        """
        Queue data to be written to serial port (thread-safe).

        Args:
            data: String data to write (newline added automatically)

        Raises:
            RuntimeError: If write queue is full after waiting 5 seconds

        Note:
            Data is written asynchronously through the write queue.
            Write order is guaranteed (FIFO).
            If the queue is full, applies backpressure by waiting up to 5 seconds.
            This method is thread-safe and can be called from any thread.
        """
        if DEBUG_TIMING:
            t0 = time.time()
            logger.warning(
                f"[TIMING] write() called at {t0:.3f} thread={threading.current_thread().name} data={data[:50]!r}"
            )

        # Check if we're in the correct event loop
        try:
            current_loop = asyncio.get_running_loop()
        except RuntimeError:
            current_loop = None

        if current_loop is not self._loop and self._loop is not None:
            # Called from different thread - use thread-safe queue directly
            if DEBUG_TIMING:
                logger.warning(
                    f"[TIMING] write() cross-thread detected, using thread-safe queue"
                )

            try:
                self._threadsafe_queue.put_nowait(data)
            except queue.Full:
                logger.error(f"Thread-safe write queue full for {self.port}")
                raise RuntimeError(f"Serial port {self.port} write queue full")

            if DEBUG_TIMING:
                logger.warning(
                    f"[TIMING] write() cross-thread queued at {time.time():.3f} (elapsed {(time.time()-t0)*1000:.1f}ms)"
                )
        else:
            # Same event loop - call directly
            await self._write_internal(data)
            if DEBUG_TIMING:
                logger.warning(
                    f"[TIMING] write() same-thread completed at {time.time():.3f} (elapsed {(time.time()-t0)*1000:.1f}ms)"
                )

    async def _write_internal(self, data: str) -> None:
        """Internal write implementation - must be called from the correct event loop."""
        try:
            # Try non-blocking first
            self.write_queue.put_nowait(data)
        except asyncio.QueueFull:
            # Queue is full - apply backpressure by waiting with timeout
            logger.warning(f"Write queue full for {self.port}, applying backpressure")
            try:
                await asyncio.wait_for(self.write_queue.put(data), timeout=5.0)
            except asyncio.TimeoutError:
                logger.error(
                    f"Write queue timeout for {self.port} - device unresponsive"
                )
                raise RuntimeError(
                    f"Serial port {self.port} write queue full - device may be unresponsive"
                )

    def subscribe(self, event: str, callback) -> None:
        """
        Subscribe to events from this port.

        Args:
            event: Event type ('data', 'status', 'error')
            callback: Async callback function

        Example:
            async def on_data(event):
                print(event['line'])

            handler.subscribe('data', on_data)
        """
        self.event_bus.subscribe(event, callback)

    def unsubscribe(self, event: str, callback) -> bool:
        """
        Unsubscribe from events.

        Args:
            event: Event type
            callback: Callback to remove

        Returns:
            True if callback was removed
        """
        return self.event_bus.unsubscribe(event, callback)

    def get_stats(self) -> dict:
        """
        Get port statistics.

        Returns:
            Dictionary with statistics including uptime, bytes/lines sent/received,
            errors, and reconnection count
        """
        stats = self.stats.copy()

        # Calculate uptime
        if stats["start_time"]:
            stats["uptime_seconds"] = time.time() - stats["start_time"]
        else:
            stats["uptime_seconds"] = 0

        # Add connection state
        stats["connected"] = (
            self.serial is not None and self.serial.is_open if self.serial else False
        )

        # Add subscriber count
        stats["subscriber_count"] = self.event_bus.subscriber_count()

        return stats

    def is_connected(self) -> bool:
        """Check if serial port is currently connected."""
        return self.serial is not None and self.serial.is_open

    def get_history(self, limit: int | None = None) -> list:
        """
        Get serial output history.

        Args:
            limit: Maximum number of lines to return (most recent first)

        Returns:
            List of history entries with 'line' and 'timestamp' keys
        """
        if limit:
            return self.history_buffer[-limit:]
        return self.history_buffer.copy()
