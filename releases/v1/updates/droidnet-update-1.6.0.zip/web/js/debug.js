// Debug script to check what's happening
console.log('Debug script loaded');

// Check if app.js loaded
if (typeof showTab === 'undefined') {
    console.error('showTab function is not defined - app.js may have failed to load');
} else {
    console.log('showTab function is defined');
}

// Check window.showTab
if (typeof window.showTab === 'undefined') {
    console.error('window.showTab is not defined');
} else {
    console.log('window.showTab is defined');
}

// Try to find any errors
window.addEventListener('error', function(e) {
    console.error('Global error:', e.message, 'at', e.filename, ':', e.lineno);
});

// Log when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded - checking functions again:');
    console.log('showTab:', typeof showTab);
    console.log('window.showTab:', typeof window.showTab);
    console.log('refreshDevices:', typeof window.refreshDevices);
});