/**
 * DroidNet Signal Booster - Shared Utility Functions
 *
 * This module provides common utility functions used across the application.
 * Load this script before other application scripts.
 */

// Create namespace for utilities
window.DroidNet = window.DroidNet || {};
window.DroidNet.utils = {};

/**
 * Sanitize HTML to prevent XSS attacks.
 * @param {string} text - The text to escape
 * @returns {string} The escaped HTML-safe string
 */
function escapeHtml(text) {
    if (text === null || text === undefined) {
        return '';
    }
    const str = String(text);
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return str.replace(/[&<>"']/g, char => map[char]);
}
window.DroidNet.utils.escapeHtml = escapeHtml;

/**
 * Format bytes to human readable string.
 * @param {number} bytes - The number of bytes
 * @param {number} decimals - Number of decimal places (default: 2)
 * @returns {string} Formatted string like "1.5 MB"
 */
function formatBytes(bytes, decimals = 2) {
    if (bytes === 0) return '0 Bytes';
    if (bytes === null || bytes === undefined || isNaN(bytes)) return 'N/A';

    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    const index = Math.min(i, sizes.length - 1);

    return parseFloat((bytes / Math.pow(k, index)).toFixed(decimals)) + ' ' + sizes[index];
}
window.DroidNet.utils.formatBytes = formatBytes;

/**
 * Format uptime seconds to human readable string.
 * @param {number} seconds - The number of seconds
 * @returns {string} Formatted string like "1d 2h 30m 15s"
 */
function formatUptime(seconds) {
    if (seconds === null || seconds === undefined || isNaN(seconds)) {
        return 'N/A';
    }

    seconds = Math.floor(seconds);
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;

    const parts = [];
    if (days > 0) parts.push(`${days}d`);
    if (hours > 0) parts.push(`${hours}h`);
    if (minutes > 0) parts.push(`${minutes}m`);
    if (secs > 0 || parts.length === 0) parts.push(`${secs}s`);

    return parts.join(' ');
}
window.DroidNet.utils.formatUptime = formatUptime;

/**
 * Debounce function calls.
 * @param {Function} func - The function to debounce
 * @param {number} wait - The debounce delay in milliseconds
 * @returns {Function} The debounced function
 */
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func.apply(this, args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}
window.DroidNet.utils.debounce = debounce;

/**
 * Throttle function calls.
 * @param {Function} func - The function to throttle
 * @param {number} limit - The minimum time between calls in milliseconds
 * @returns {Function} The throttled function
 */
function throttle(func, limit) {
    let inThrottle;
    return function executedFunction(...args) {
        if (!inThrottle) {
            func.apply(this, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}
window.DroidNet.utils.throttle = throttle;

/**
 * Clamp a number between min and max values.
 * @param {number} value - The value to clamp
 * @param {number} min - The minimum value
 * @param {number} max - The maximum value
 * @returns {number} The clamped value
 */
function clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
}
window.DroidNet.utils.clamp = clamp;

/**
 * Get device display name with custom name override.
 * @param {Object} device - The device object
 * @param {Object} customNames - Map of device IDs to custom names
 * @returns {string} The display name for the device
 */
function getDeviceDisplayName(device, customNames) {
    customNames = customNames || {};
    const deviceId = device.unique_id || `${device.vendor_id}:${device.product_id}`;
    return customNames[deviceId] || device.name || 'Unknown Device';
}
window.DroidNet.utils.getDeviceDisplayName = getDeviceDisplayName;

/**
 * Parse serial port from device path.
 * @param {string} path - The device path (e.g., "/dev/ttyACM0")
 * @returns {string|null} The port name or null if not a valid serial path
 */
function parseSerialPort(path) {
    if (!path) return null;
    const match = path.match(/\/dev\/(tty(?:ACM|USB|S)\d+)/);
    return match ? match[1] : null;
}
window.DroidNet.utils.parseSerialPort = parseSerialPort;

/**
 * Validate IP address format.
 * @param {string} ip - The IP address to validate
 * @returns {boolean} True if valid IPv4 address
 */
function isValidIPAddress(ip) {
    if (!ip) return false;
    const pattern = /^(\d{1,3}\.){3}\d{1,3}$/;
    if (!pattern.test(ip)) return false;

    const parts = ip.split('.');
    return parts.every(part => {
        const num = parseInt(part, 10);
        return num >= 0 && num <= 255;
    });
}
window.DroidNet.utils.isValidIPAddress = isValidIPAddress;

/**
 * Format a timestamp as a relative time string.
 * @param {number} timestamp - Unix timestamp in seconds
 * @returns {string} Relative time string like "2 minutes ago"
 */
function formatRelativeTime(timestamp) {
    const now = Math.floor(Date.now() / 1000);
    const diff = now - timestamp;

    if (diff < 60) return 'just now';
    if (diff < 3600) return `${Math.floor(diff / 60)} minutes ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)} hours ago`;
    if (diff < 604800) return `${Math.floor(diff / 86400)} days ago`;

    const date = new Date(timestamp * 1000);
    return date.toLocaleDateString();
}
window.DroidNet.utils.formatRelativeTime = formatRelativeTime;

/**
 * Deep clone an object.
 * @param {Object} obj - The object to clone
 * @returns {Object} A deep copy of the object
 */
function deepClone(obj) {
    if (obj === null || typeof obj !== 'object') return obj;
    return JSON.parse(JSON.stringify(obj));
}
window.DroidNet.utils.deepClone = deepClone;

/**
 * Generate a unique ID.
 * @param {string} prefix - Optional prefix for the ID
 * @returns {string} A unique identifier
 */
function generateId(prefix = '') {
    const timestamp = Date.now().toString(36);
    const random = Math.random().toString(36).substring(2, 8);
    return prefix ? `${prefix}-${timestamp}-${random}` : `${timestamp}-${random}`;
}
window.DroidNet.utils.generateId = generateId;

// Make commonly used functions available globally for backwards compatibility
// These can be removed once all files are updated to use DroidNet.utils namespace
window.escapeHtml = escapeHtml;
window.formatBytes = formatBytes;
window.formatUptime = formatUptime;
window.debounce = debounce;
window.clamp = clamp;
