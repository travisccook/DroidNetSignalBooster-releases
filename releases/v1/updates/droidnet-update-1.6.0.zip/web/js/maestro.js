// Project Maestro - Web-Based Pololu Maestro Control Interface
// Complete JavaScript implementation with WebSocket client

// ============================================================================
// Global State
// ============================================================================

let maestroClient = null;
let maestroDevices = [];
let maestroState = null;
let selectedMaestroPort = null;

// Channel configuration state
let maestroChannelConfig = {};      // Loaded config from device
let maestroOriginalConfig = {};     // Original values for comparison
let expandedChannels = new Set();   // Which channels are expanded
let modifiedChannels = new Set();   // Which channels have unsaved changes

// Channel names (stored locally, not on device)
let maestroChannelNames = {};       // { "0": "Door Servo", "1": "Antenna", ... }
let maestroOriginalNames = {};      // Original values for comparison
let currentDeviceSerial = null;     // Serial number of connected device

// Channel visibility (stored locally per device)
let hiddenChannels = new Set();     // Which channels are hidden by user
let channelFilter = 'all';          // 'all', 'active', 'named'

// ============================================================================
// Utility Functions
// ============================================================================

/**
 * Fetch JSON from a URL with proper HTTP status checking.
 * @param {string} url - The URL to fetch
 * @param {Object} options - Optional fetch options
 * @returns {Promise<Object>} - Parsed JSON response
 * @throws {Error} - On HTTP error or JSON parse failure
 */
async function fetchJson(url, options = {}) {
    const response = await fetch(url, options);
    if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    return await response.json();
}

/**
 * Show a toast notification message.
 * @param {string} message - The message to display
 * @param {string} type - Toast type: 'success', 'warning', 'error', 'info'
 * @param {number} duration - Duration in ms (default 3000)
 */
function showToast(message, type = 'info', duration = 3000) {
    // Create toast container if it doesn't exist
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.style.cssText = 'position:fixed;bottom:20px;right:20px;z-index:9999;display:flex;flex-direction:column;gap:8px;';
        document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `toast toast--${type}`;
    toast.textContent = message;
    toast.style.cssText = 'padding:12px 20px;border-radius:6px;color:#fff;font-size:14px;box-shadow:0 4px 12px rgba(0,0,0,0.15);animation:slideIn 0.3s ease;';

    // Type-specific colors
    const colors = {
        success: '#28a745',
        warning: '#ffc107',
        error: '#dc3545',
        info: '#17a2b8'
    };
    toast.style.backgroundColor = colors[type] || colors.info;
    if (type === 'warning') toast.style.color = '#000';

    container.appendChild(toast);

    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, duration);
}

// ============================================================================
// Modal System
// ============================================================================

let activeModalResolve = null;  // For promise-based modals
let modalEscapeListenerActive = false;  // Prevent duplicate ESC listeners

/**
 * Show the Maestro modal with custom content.
 * @param {Object} options - Modal options
 * @param {string} options.title - Modal title
 * @param {string} options.content - HTML content for the modal body
 * @param {Array<Object>} options.actions - Array of button configs {label, class, onclick}
 * @param {boolean} options.closeable - Whether clicking overlay closes modal (default true)
 */
function showMaestroModal({ title, content, actions = [], closeable = true }) {
    const overlay = document.getElementById('maestro-modal-overlay');
    const titleEl = document.getElementById('maestro-modal-title');
    const contentEl = document.getElementById('maestro-modal-content');
    const actionsEl = document.getElementById('maestro-modal-actions');

    if (!overlay || !titleEl || !contentEl || !actionsEl) {
        console.error('Modal elements not found');
        return;
    }

    titleEl.textContent = title;
    contentEl.innerHTML = content;

    // Build action buttons
    actionsEl.innerHTML = actions.map(action => {
        const btnClass = action.class || 'maestro-modal__btn--secondary';
        const dataAction = action.action ? `data-action="${action.action}"` : '';
        return `<button class="maestro-modal__btn ${btnClass}" ${dataAction} onclick="${action.onclick || ''}">${action.label}</button>`;
    }).join('');

    // Store closeable state
    overlay.dataset.closeable = closeable;

    // Show modal
    overlay.classList.add('active');

    // Handle ESC key - only add if not already active
    if (!modalEscapeListenerActive) {
        document.addEventListener('keydown', handleModalEscape);
        modalEscapeListenerActive = true;
    }
}

/**
 * Close the Maestro modal.
 * @param {string} action - Optional action to resolve the promise with
 */
function closeMaestroModal(action = null) {
    const overlay = document.getElementById('maestro-modal-overlay');
    if (overlay) {
        overlay.classList.remove('active');
    }

    // Remove ESC listener and reset flag
    if (modalEscapeListenerActive) {
        document.removeEventListener('keydown', handleModalEscape);
        modalEscapeListenerActive = false;
    }

    // Resolve promise if this was a promise-based modal
    if (activeModalResolve) {
        activeModalResolve(action);
        activeModalResolve = null;
    }
}

/**
 * Handle clicking on the modal overlay.
 */
function closeMaestroModalOnOverlay(event) {
    const overlay = document.getElementById('maestro-modal-overlay');
    if (event.target === overlay && overlay.dataset.closeable !== 'false') {
        closeMaestroModal('cancel');
    }
}

/**
 * Handle ESC key to close modal.
 */
function handleModalEscape(event) {
    if (event.key === 'Escape') {
        const overlay = document.getElementById('maestro-modal-overlay');
        if (overlay && overlay.classList.contains('active')) {
            if (overlay.dataset.closeable !== 'false') {
                closeMaestroModal('cancel');
            }
        }
    }
}

/**
 * Show a confirmation modal and return a promise.
 * @param {Object} options - Modal options
 * @returns {Promise<string>} - Resolves with the action taken
 */
function showConfirmModal({ title, content, confirmLabel = 'Confirm', confirmClass = 'maestro-modal__btn--primary', cancelLabel = 'Cancel' }) {
    return new Promise((resolve) => {
        activeModalResolve = resolve;
        showMaestroModal({
            title,
            content,
            closeable: true,
            actions: [
                { label: cancelLabel, class: 'maestro-modal__btn--secondary', onclick: "closeMaestroModal('cancel')" },
                { label: confirmLabel, class: confirmClass, onclick: "closeMaestroModal('confirm')" }
            ]
        });
    });
}

/**
 * Show a save collision modal with three choices.
 * @param {string} name - The sequence name that collides
 * @param {number} frameCount - Number of frames in existing sequence
 * @returns {Promise<string>} - 'update', 'copy', or 'cancel'
 */
function showSaveCollisionModal(name, frameCount) {
    return new Promise((resolve) => {
        activeModalResolve = resolve;
        showMaestroModal({
            title: 'Sequence Already Exists',
            content: `
                <p>A sequence named <strong>"${escapeHtml(name)}"</strong> already exists with ${frameCount} frames.</p>
                <p>What would you like to do?</p>
            `,
            closeable: true,
            actions: [
                { label: 'Cancel', class: 'maestro-modal__btn--secondary', onclick: "closeMaestroModal('cancel')" },
                { label: 'Save as Copy', class: 'maestro-modal__btn--secondary', onclick: "closeMaestroModal('copy')" },
                { label: 'Update Existing', class: 'maestro-modal__btn--warning', onclick: "closeMaestroModal('update')" }
            ]
        });
    });
}

/**
 * Show import warning modal.
 * @param {number} existingSequenceCount - Number of existing sequences that will be replaced
 * @param {boolean} hasChannelConfig - Whether import includes channel settings
 * @returns {Promise<boolean>} - true if user confirms, false if cancelled
 */
function showImportWarningModal(existingSequenceCount, hasChannelConfig = true) {
    return new Promise((resolve) => {
        activeModalResolve = (action) => resolve(action === 'confirm');

        let warningItems = [];
        if (existingSequenceCount > 0) {
            warningItems.push(`<strong>${existingSequenceCount}</strong> existing sequence${existingSequenceCount !== 1 ? 's' : ''} will be replaced`);
        }
        if (hasChannelConfig) {
            warningItems.push(`Channel settings (min/max limits, speed, acceleration) will be overwritten`);
        }

        const warningList = warningItems.length > 0
            ? `<ul style="margin: 8px 0; padding-left: 20px; text-align: left;">${warningItems.map(i => `<li style="margin: 4px 0;">${i}</li>`).join('')}</ul>`
            : '';

        showMaestroModal({
            title: 'Import Will Replace Settings',
            content: `
                <div class="maestro-modal__warning">
                    <span class="maestro-modal__warning-icon">&#9888;</span>
                    <span class="maestro-modal__warning-text">
                        Importing this file will overwrite your current configuration:
                        ${warningList}
                        This action cannot be undone.
                    </span>
                </div>
                <p>Are you sure you want to continue?</p>
            `,
            closeable: true,
            actions: [
                { label: 'Cancel', class: 'maestro-modal__btn--secondary', onclick: "closeMaestroModal('cancel')" },
                { label: 'Import & Replace', class: 'maestro-modal__btn--danger', onclick: "closeMaestroModal('confirm')" }
            ]
        });
    });
}

/**
 * Show script preview modal (read-only).
 * @param {string} title - Modal title
 * @param {string} scriptContent - The script to display
 */
function showScriptPreviewModal(title, scriptContent) {
    showMaestroModal({
        title: title,
        content: `<textarea id="maestro-preview-script" class="maestro-modal__script" readonly>${escapeHtml(scriptContent)}</textarea>`,
        closeable: true,
        actions: [
            { label: 'Download', class: 'maestro-modal__btn--secondary', onclick: 'downloadScriptPreview()' },
            { label: 'Copy', class: 'maestro-modal__btn--primary', onclick: 'copyScriptPreview()' },
            { label: 'Close', class: 'maestro-modal__btn--secondary', onclick: "closeMaestroModal()" }
        ]
    });
}

/**
 * Copy script preview content to clipboard.
 */
function copyScriptPreview() {
    const textarea = document.getElementById('maestro-preview-script');
    if (textarea) {
        navigator.clipboard.writeText(textarea.value).then(() => {
            showToast('Script copied to clipboard', 'success');
        }).catch(() => {
            showToast('Failed to copy', 'error');
        });
    }
}

/**
 * Download script preview as a text file.
 */
function downloadScriptPreview() {
    const textarea = document.getElementById('maestro-preview-script');
    if (textarea) {
        const blob = new Blob([textarea.value], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `maestro_script_${new Date().toISOString().slice(0, 10)}.txt`;
        a.click();
        URL.revokeObjectURL(url);
        showToast('Script downloaded', 'success');
    }
}

// ============================================================================
// MaestroWebSocketClient - Rate-limited WebSocket client (50Hz max)
// ============================================================================

class MaestroWebSocketClient {
    constructor(port) {
        this.port = port;
        this.ws = null;
        this.connected = false;
        this.pendingUpdates = new Map(); // channel -> target value
        this.updateInterval = 20; // 50Hz = 20ms interval
        this.sendTimer = null;
        this.reconnectTimer = null;
        this.eventHandlers = {
            position: [],
            error: [],
            state: [],
            connection: [],
            script_status: []
        };
    }

    connect() {
        const wsUrl = `ws://${location.hostname}:8080/api/maestro/ws?port=${encodeURIComponent(this.port)}`;
        console.log('Connecting to Maestro WebSocket:', wsUrl);

        this.ws = new WebSocket(wsUrl);

        this.ws.onopen = () => {
            console.log('Maestro WebSocket connected');
            this.connected = true;
            this._emit('connection', { connected: true, port: this.port });
            this._startSendLoop();
        };

        this.ws.onclose = () => {
            console.log('Maestro WebSocket disconnected');
            this.connected = false;
            this._emit('connection', { connected: false, port: this.port });

            if (this.sendTimer) {
                clearInterval(this.sendTimer);
                this.sendTimer = null;
            }

            // Auto-reconnect after 2 seconds
            this.reconnectTimer = setTimeout(() => {
                if (selectedMaestroPort === this.port) {
                    this.connect();
                }
            }, 2000);
        };

        this.ws.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data);
                this._emit(data.type, data);
            } catch (e) {
                console.error('Failed to parse Maestro message:', e);
            }
        };

        this.ws.onerror = (error) => {
            console.error('Maestro WebSocket error:', error);
        };
    }

    disconnect() {
        if (this.sendTimer) {
            clearInterval(this.sendTimer);
            this.sendTimer = null;
        }

        if (this.reconnectTimer) {
            clearTimeout(this.reconnectTimer);
            this.reconnectTimer = null;
        }

        if (this.ws) {
            this.ws.close();
            this.ws = null;
        }

        this.connected = false;
        this.pendingUpdates.clear();

        // Clear all event handlers to prevent memory leaks
        for (const event in this.eventHandlers) {
            this.eventHandlers[event] = [];
        }
    }

    on(event, handler) {
        if (!this.eventHandlers[event]) {
            this.eventHandlers[event] = [];
        }
        this.eventHandlers[event].push(handler);
    }

    off(event, handler) {
        if (!this.eventHandlers[event]) {
            return;
        }
        if (handler) {
            // Remove specific handler
            const index = this.eventHandlers[event].indexOf(handler);
            if (index > -1) {
                this.eventHandlers[event].splice(index, 1);
            }
        } else {
            // Remove all handlers for this event
            this.eventHandlers[event] = [];
        }
    }

    _emit(type, data) {
        const handlers = this.eventHandlers[type] || [];
        handlers.forEach(h => {
            try {
                h(data);
            } catch (e) {
                console.error(`Error in ${type} handler:`, e);
            }
        });
    }

    _startSendLoop() {
        if (this.sendTimer) return;

        this.sendTimer = setInterval(() => {
            if (!this.connected || this.pendingUpdates.size === 0) return;

            // Send all pending updates in batch
            this.pendingUpdates.forEach((target, channel) => {
                this._send({
                    cmd: 'set_target',
                    channel: channel,
                    target: target
                });
            });

            this.pendingUpdates.clear();
        }, this.updateInterval);
    }

    _send(data) {
        if (!this.connected || !this.ws) return;

        try {
            this.ws.send(JSON.stringify(data));
        } catch (e) {
            console.error('Failed to send Maestro command:', e);
        }
    }

    // Public API methods
    setTarget(channel, target) {
        // Queue update for batch sending
        this.pendingUpdates.set(channel, Math.round(target));
    }

    setSpeed(channel, speed) {
        this._send({
            cmd: 'set_speed',
            channel: channel,
            speed: speed
        });
    }

    setAcceleration(channel, acceleration) {
        this._send({
            cmd: 'set_acceleration',
            channel: channel,
            acceleration: acceleration
        });
    }

    goHome() {
        this._send({ cmd: 'go_home' });
    }

    stopScript() {
        this._send({ cmd: 'stop_script' });
    }

    runSubroutine(index) {
        this._send({
            cmd: 'run_subroutine',
            subroutine: index
        });
    }

    getState() {
        this._send({ cmd: 'get_state' });
    }
}

// ============================================================================
// Initialization and Device Management
// ============================================================================

async function initMaestro() {
    console.log('Initializing Maestro interface');
    await refreshMaestroDevices();
}

async function refreshMaestroDevices() {
    try {
        // First get managed devices
        const managedData = await fetchJson('/api/maestro/devices');
        let managedDevices = managedData.success ? (managedData.devices || []) : [];

        // Also detect available devices
        const detectData = await fetchJson('/api/maestro/detect', { method: 'POST' });
        let detectedDevices = detectData.success ? (detectData.devices || []) : [];

        // Merge: use managed devices, add detected devices that aren't managed
        const managedPorts = new Set(managedDevices.map(d => d.port));
        const unmanaged = detectedDevices.filter(d => d.port && !managedPorts.has(d.port));

        // Show all devices - managed ones first, then detected but unmanaged
        maestroDevices = [...managedDevices, ...unmanaged];
        updateMaestroDeviceSelector();
        // Tab visibility is now controlled by config, not device detection
    } catch (error) {
        console.error('Failed to load Maestro devices:', error);
    }
}

function updateMaestroDeviceSelector() {
    const select = document.getElementById('maestro-device-select');
    if (!select) return;

    select.innerHTML = '<option value="">Select Device...</option>';

    maestroDevices.forEach(device => {
        const option = document.createElement('option');
        option.value = device.port;
        option.textContent = `${device.model} (${device.port})`;
        select.appendChild(option);
    });
}

async function onMaestroDeviceChange() {
    const select = document.getElementById('maestro-device-select');
    const port = select.value;

    if (!port) {
        disconnectMaestro();
        return;
    }

    // Find device info
    const device = maestroDevices.find(d => d.port === port);
    if (!device) {
        console.error('Device not found:', port);
        return;
    }

    // If device is not connected (unmanaged), add it to the manager first
    if (!device.connected) {
        console.log('Adding unmanaged device to manager:', port);
        try {
            const result = await fetchJson('/api/maestro/add', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    port: port,
                    serial_number: device.serial_number
                })
            });
            if (!result.success) {
                console.error('Failed to add device:', result.error);
                alert('Failed to add Maestro device: ' + (result.error || 'Unknown error'));
                return;
            }
        } catch (error) {
            console.error('Error adding device:', error);
            alert('Error adding Maestro device: ' + error.message);
            return;
        }
    }

    connectToMaestro(port);
}

function connectToMaestro(port) {
    // Disconnect existing client
    disconnectMaestro();

    // Set selected port AFTER disconnect (disconnect clears it)
    selectedMaestroPort = port;

    // Find device info
    const device = maestroDevices.find(d => d.port === port);
    if (!device) {
        console.error('Device not found:', port);
        return;
    }

    // Save device serial for channel names storage
    currentDeviceSerial = device.serial_number || null;

    // Check serial mode and show alerts if needed
    if (currentDeviceSerial) {
        checkMaestroSerialMode(currentDeviceSerial);
    }

    // Create new WebSocket client
    maestroClient = new MaestroWebSocketClient(port);

    // Register event handlers
    maestroClient.on('connection', handleMaestroConnection);
    maestroClient.on('state', handleMaestroState);
    maestroClient.on('position', handleMaestroPosition);
    maestroClient.on('error', handleMaestroError);
    maestroClient.on('script_status', handleMaestroScriptStatus);

    // Connect
    maestroClient.connect();

    // Update UI
    updateMaestroDeviceInfo(device);

    // Load library and sync state for this device
    updateLibraryVisibility(true);
    loadMaestroLibrary();
    loadSyncState();
}

function disconnectMaestro() {
    // Stop any running sequence playback
    if (maestroPlaybackState && maestroPlaybackState.playing) {
        maestroStopSequence();
    }

    if (maestroClient) {
        maestroClient.disconnect();
        maestroClient = null;
    }

    // Clear core state
    maestroState = null;
    selectedMaestroPort = null;
    currentDeviceSerial = null;

    // Clear channel configuration state
    maestroChannelConfig = {};
    maestroOriginalConfig = {};
    modifiedChannels.clear();

    // Clear channel names
    maestroChannelNames = {};
    maestroOriginalNames = {};

    // Clear channel UI state
    expandedChannels.clear();
    hiddenChannels.clear();
    channelFilter = 'all';

    // Clear sequence recorder state
    maestroSequenceFrames = [];
    selectedFrameIndex = -1;
    maestroPlaybackState = { playing: false, currentFrame: -1, timeoutId: null };

    // Clear library state
    maestroLibrarySequences = [];
    maestroSyncState = null;
    currentEditingSequenceId = null;
    currentScriptEditorSequenceId = null;

    // Hide sections
    document.getElementById('maestro-servos-section').style.display = 'none';
    document.getElementById('maestro-sequence-section').style.display = 'none';
    document.getElementById('maestro-script-section').style.display = 'none';
    document.getElementById('maestro-device-info').style.display = 'none';

    // Hide library section
    updateLibraryVisibility(false);

    // Clear edit indicators
    updateScriptEditorIndicator(null);
    updateRecorderEditIndicator(null);
    updateUnsavedCount();

    // Hide disconnect button
    const disconnectBtn = document.getElementById('maestro-disconnect-btn');
    if (disconnectBtn) disconnectBtn.style.display = 'none';

    // Update status to disconnected
    const statusDiv = document.getElementById('maestro-status');
    if (statusDiv) {
        statusDiv.innerHTML = '<span class="status-dot status-dot-error"></span>Disconnected';
        statusDiv.className = 'badge badge-danger';
    }
}

function updateMaestroDeviceInfo(device) {
    const infoPanel = document.getElementById('maestro-device-info');
    if (!infoPanel) return;

    document.getElementById('maestro-model').textContent = device.model || 'Unknown';
    document.getElementById('maestro-firmware').textContent = device.firmware_version || 'N/A';
    document.getElementById('maestro-serial').textContent = device.serial_number || 'N/A';

    infoPanel.style.display = 'block';
}

// ============================================================================
// Event Handlers
// ============================================================================

function handleMaestroConnection(data) {
    const statusDiv = document.getElementById('maestro-status');
    if (!statusDiv) return;

    if (data.connected) {
        statusDiv.innerHTML = '<span class="status-indicator connected"></span><span>Connected</span>';
        statusDiv.className = 'status-bar';
    } else {
        statusDiv.innerHTML = '<span class="status-indicator disconnected"></span><span>Disconnected</span>';
        statusDiv.className = 'status-bar error';
    }
}

function handleMaestroState(data) {
    maestroState = data.data;
    console.log('Maestro state received:', maestroState);

    // Render servo controls
    if (maestroState && maestroState.channels) {
        renderServoControls(maestroState);

        // Load channel configuration from device (if not already loaded)
        if (Object.keys(maestroChannelConfig).length === 0) {
            loadMaestroChannelConfig();
        }

        // Show sections
        document.getElementById('maestro-servos-section').style.display = 'block';
        document.getElementById('maestro-sequence-section').style.display = 'block';
        document.getElementById('maestro-script-section').style.display = 'block';

        // Show disconnect button
        const disconnectBtn = document.getElementById('maestro-disconnect-btn');
        if (disconnectBtn) disconnectBtn.style.display = 'inline-block';
    }
}

function handleMaestroPosition(data) {
    updateServoPosition(data.channel, data.position);
}

function handleMaestroError(data) {
    const errorDiv = document.getElementById('maestro-error-display');
    if (!errorDiv) return;

    if (data.errors && data.errors !== 0) {
        errorDiv.textContent = `Errors: ${data.error_names.join(', ')}`;
        errorDiv.style.display = 'block';
    } else {
        errorDiv.style.display = 'none';
    }
}

function handleMaestroScriptStatus(data) {
    const statusSpan = document.getElementById('maestro-script-status');
    if (!statusSpan) return;

    statusSpan.textContent = data.running ? 'Script Running' : 'Script Stopped';
    statusSpan.className = data.running ? 'status-success' : '';
}

// ============================================================================
// Servo Control UI
// ============================================================================

function renderServoControls(state) {
    const container = document.getElementById('maestro-servo-controls');
    if (!container) return;

    container.innerHTML = '';

    // Track visibility counts for summary row
    const counts = getChannelVisibilityCounts(state);

    for (let ch = 0; ch < state.channels; ch++) {
        // Skip hidden channels
        if (!isChannelVisible(ch, state)) {
            continue;
        }

        const servoData = state.servos[ch] || {};
        const isExpanded = expandedChannels.has(ch);
        const isModified = modifiedChannels.has(ch);

        // Get channel config for min/max (use device config if available, else defaults)
        const config = maestroChannelConfig[ch] || {};
        const minQuarterUs = config.min ?? 4000;   // Default 1000µs
        const maxQuarterUs = config.max ?? 8000;   // Default 2000µs
        const minUs = config.min_us ?? Math.round(minQuarterUs / 4);
        const maxUs = config.max_us ?? Math.round(maxQuarterUs / 4);

        // Use nullish coalescing to allow position=0 (servo off), calculate center from config
        const centerQuarterUs = Math.round((minQuarterUs + maxQuarterUs) / 2);
        const position = servoData.position ?? centerQuarterUs;
        const positionUs = Math.round(position / 4);

        // Main servo control row
        const row = document.createElement('tr');
        row.className = `servo-row${isExpanded ? ' expanded' : ''}${isModified ? ' channel-unsaved' : ''}`;
        row.id = `servo-row-${ch}`;
        row.innerHTML = `
            <td class="col-channel" onclick="toggleChannelExpand(${ch})">
                <div class="channel-cell">
                    <span class="expand-arrow">${isExpanded ? '▼' : '▶'}</span>
                    <span class="channel-num">${ch}</span>
                </div>
                ${isModified ? '<span class="unsaved-dot" title="Unsaved changes">●</span>' : ''}
            </td>
            <td class="col-name">
                <span class="servo-name" id="servo-name-${ch}" ondblclick="editChannelName(${ch})"
                      title="Double-click to edit">${escapeHtml(maestroChannelNames[ch]) || `Channel ${ch}`}</span>
                <button class="name-edit-btn" onclick="editChannelName(${ch})" title="Edit name">✎</button>
            </td>
            <td class="col-slider">
                <div class="slider-wrapper">
                    <span class="slider-min" id="servo-min-label-${ch}">${minUs}</span>
                    <div class="slider-track-container">
                        <input type="range" id="servo-slider-${ch}" class="servo-slider"
                               min="${minQuarterUs}" max="${maxQuarterUs}" value="${position}" step="4"
                               oninput="onServoSliderInput(${ch}, this.value)">
                        <div class="actual-position-marker" id="servo-actual-${ch}"
                             title="Actual position reported by device"></div>
                    </div>
                    <span class="slider-max" id="servo-max-label-${ch}">${maxUs}</span>
                </div>
            </td>
            <td class="col-value">
                <span class="position-value" id="servo-value-${ch}">${positionUs}<span class="position-unit">µs</span></span>
            </td>
            <td class="col-speed">
                <input type="number" id="servo-speed-${ch}" class="inline-input"
                       min="0" max="255" value="${servoData.speed || 0}"
                       onchange="onServoSpeedChange(${ch}, this.value)">
            </td>
            <td class="col-accel">
                <input type="number" id="servo-accel-${ch}" class="inline-input"
                       min="0" max="255" value="${servoData.acceleration || 0}"
                       onchange="onServoAccelChange(${ch}, this.value)">
            </td>
            <td class="col-actions">
                <div class="servo-actions">
                    <button onclick="centerServo(${ch})" class="servo-action-btn servo-action-btn--center" title="Center">C</button>
                    <button id="servo-toggle-${ch}" onclick="toggleServoEnabled(${ch})"
                            class="servo-action-btn servo-action-btn--toggle ${position === 0 ? 'disabled' : 'enabled'}"
                            title="${position === 0 ? 'Enable servo' : 'Disable servo'}">
                        <span class="toggle-icon">${position === 0 ? '○' : '●'}</span>
                    </button>
                    <button onclick="toggleChannelHidden(${ch})" class="servo-action-btn servo-action-btn--hide" title="Hide channel">
                        <span class="hide-icon">−</span>
                    </button>
                </div>
            </td>
        `;
        container.appendChild(row);

        // Expanded config row (if expanded)
        if (isExpanded) {
            const configRow = renderExpandedConfigRow(ch);
            container.appendChild(configRow);
        }

        updateServoPosition(ch, position);
    }

    // Add hidden channels summary row if any are hidden
    if (counts.hidden > 0) {
        const summaryRow = document.createElement('tr');
        summaryRow.className = 'hidden-channels-summary';
        summaryRow.innerHTML = `
            <td colspan="7" class="hidden-summary-cell">
                <span class="hidden-count">${counts.hidden} channel${counts.hidden !== 1 ? 's' : ''} hidden</span>
                <button onclick="showAllChannels()" class="show-all-btn">Show All</button>
            </td>
        `;
        container.appendChild(summaryRow);
    }
}

function renderExpandedConfigRow(ch) {
    const config = maestroChannelConfig[ch] || {};
    const isModified = modifiedChannels.has(ch);

    const row = document.createElement('tr');
    row.className = 'channel-config-row';
    row.id = `config-row-${ch}`;
    row.innerHTML = `
        <td colspan="7">
            <div class="config-panel">
                ${isModified ? '<div class="config-warning">⚠ Unsaved changes</div>' : ''}
                <div class="config-grid">
                    <div class="config-field">
                        <label title="Channel operating mode: Servo (PWM output), Servo Multiplied (scaled by multiplier), Output (digital on/off), or Input (read analog/digital)">Mode</label>
                        <select id="ch-${ch}-mode" class="form-control form-control--sm"
                                onchange="onChannelConfigChange(${ch}, 'mode', this.value)">
                            <option value="SERVO" ${config.mode === 'SERVO' ? 'selected' : ''}>Servo</option>
                            <option value="SERVO_MULTIPLIED" ${config.mode === 'SERVO_MULTIPLIED' ? 'selected' : ''}>Servo Multiplied</option>
                            <option value="OUTPUT" ${config.mode === 'OUTPUT' ? 'selected' : ''}>Output</option>
                            <option value="INPUT" ${config.mode === 'INPUT' ? 'selected' : ''}>Input</option>
                        </select>
                    </div>
                    <div class="config-field">
                        <label title="Minimum allowed pulse width. Commands below this are clipped. Use [Set] to capture current servo position.">Min (µs)</label>
                        <div class="input-with-btn">
                            <input type="number" id="ch-${ch}-min" class="form-control form-control--sm"
                                   value="${Math.round(config.min_us || 0)}" min="0" max="3000" step="1"
                                   onchange="onChannelConfigChange(${ch}, 'min', this.value * 4)">
                            <button class="set-btn" onclick="setToCurrentPosition(${ch}, 'min')" title="Set to current servo position">Set</button>
                        </div>
                    </div>
                    <div class="config-field">
                        <label title="Maximum allowed pulse width. Commands above this are clipped. Use [Set] to capture current servo position.">Max (µs)</label>
                        <div class="input-with-btn">
                            <input type="number" id="ch-${ch}-max" class="form-control form-control--sm"
                                   value="${Math.round(config.max_us || 2500)}" min="0" max="3000" step="1"
                                   onchange="onChannelConfigChange(${ch}, 'max', this.value * 4)">
                            <button class="set-btn" onclick="setToCurrentPosition(${ch}, 'max')" title="Set to current servo position">Set</button>
                        </div>
                    </div>
                    <div class="config-field">
                        <label title="Startup behavior: OFF=disabled, IGNORE=maintain position, GOTO=move to home position">Home Mode</label>
                        <select id="ch-${ch}-home-mode" class="form-control form-control--sm"
                                onchange="onChannelConfigChange(${ch}, 'home_mode', this.value); updateHomeInputState(${ch})">
                            <option value="OFF" ${config.home_mode === 'OFF' ? 'selected' : ''}>Off</option>
                            <option value="IGNORE" ${config.home_mode === 'IGNORE' ? 'selected' : ''}>Ignore</option>
                            <option value="GOTO" ${config.home_mode === 'GOTO' || !config.home_mode ? 'selected' : ''}>Goto</option>
                        </select>
                    </div>
                    <div class="config-field">
                        <label title="Position servo moves to on startup (only used when Home Mode is 'Goto')">Home (µs)</label>
                        <div class="input-with-btn">
                            <input type="number" id="ch-${ch}-home" class="form-control form-control--sm"
                                   value="${Math.round(config.home_us || 1500)}" min="0" max="3000" step="1"
                                   ${config.home_mode !== 'GOTO' && config.home_mode ? 'disabled' : ''}
                                   onchange="onChannelConfigChange(${ch}, 'home', this.value * 4)">
                            <button class="set-btn" onclick="setToCurrentPosition(${ch}, 'home')" title="Set to current servo position">Set</button>
                        </div>
                    </div>
                    <div class="config-field">
                        <label title="Center position for 8-bit commands. 127 maps to this value. Typically 1500µs for standard servos.">Neutral (µs)</label>
                        <input type="number" id="ch-${ch}-neutral" class="form-control form-control--sm"
                               value="${Math.round(config.neutral_us || 1500)}" min="0" max="3000" step="1"
                               onchange="onChannelConfigChange(${ch}, 'neutral', this.value * 4)">
                    </div>
                    <div class="config-field">
                        <label title="Half the total range for 8-bit commands. Values 0-254 map to Neutral ± Range. In quarter-microseconds.">Range</label>
                        <input type="number" id="ch-${ch}-range" class="form-control form-control--sm"
                               value="${config.range || 1905}" min="0" max="32000"
                               onchange="onChannelConfigChange(${ch}, 'range', parseInt(this.value))">
                    </div>
                    <div class="config-field">
                        <label title="Maximum speed the servo can move. Units: 0.25µs per 10ms. Example: 1 = 25µs/sec. 0 = unlimited (instant).">Speed Limit</label>
                        <input type="number" id="ch-${ch}-speed-limit" class="form-control form-control--sm"
                               value="${config.speed || 0}" min="0" max="255"
                               onchange="onChannelConfigChange(${ch}, 'speed', parseInt(this.value))">
                        <small class="config-hint">0 = unlimited</small>
                    </div>
                    <div class="config-field">
                        <label title="Maximum acceleration. Units: 0.25µs per 10ms per 80ms. Smooths servo movement. 0 = unlimited (instant speed changes).">Accel Limit</label>
                        <input type="number" id="ch-${ch}-accel-limit" class="form-control form-control--sm"
                               value="${config.acceleration || 0}" min="0" max="255"
                               onchange="onChannelConfigChange(${ch}, 'acceleration', parseInt(this.value))">
                        <small class="config-hint">0 = unlimited</small>
                    </div>
                </div>
                <div class="config-actions">
                    <button class="btn btn-primary btn-sm" onclick="applyChannelConfig(${ch})">Apply to Device</button>
                    <button class="btn btn-secondary btn-sm" onclick="discardChannelConfig(${ch})">Discard</button>
                </div>
            </div>
        </td>
    `;
    return row;
}

function onServoSliderInput(channel, value) {
    const us = Math.round(value / 4);
    const valueSpan = document.getElementById(`servo-value-${channel}`);
    if (valueSpan) {
        valueSpan.innerHTML = `${us}<span class="position-unit">µs</span>`;
    }

    // Rate-limited send via WebSocket client
    if (maestroClient && maestroClient.connected) {
        maestroClient.setTarget(channel, parseInt(value));
    }
}

function updateServoPosition(channel, position) {
    const slider = document.getElementById(`servo-slider-${channel}`);
    const valueSpan = document.getElementById(`servo-value-${channel}`);
    const actualMarker = document.getElementById(`servo-actual-${channel}`);
    const toggleBtn = document.getElementById(`servo-toggle-${channel}`);

    const isDisabled = position === 0;

    // Update value display if slider not being dragged
    if (slider && document.activeElement !== slider) {
        if (!isDisabled) {
            slider.value = position;
        }
        if (valueSpan) {
            if (isDisabled) {
                valueSpan.innerHTML = '<span class="position-off">OFF</span>';
            } else {
                const us = Math.round(position / 4);
                valueSpan.innerHTML = `${us}<span class="position-unit">µs</span>`;
            }
        }
    }

    // Update toggle button state
    if (toggleBtn) {
        toggleBtn.className = `servo-action-btn servo-action-btn--toggle ${isDisabled ? 'disabled' : 'enabled'}`;
        toggleBtn.title = isDisabled ? 'Enable servo' : 'Disable servo';
        toggleBtn.querySelector('.toggle-icon').textContent = isDisabled ? '○' : '●';
    }

    // Always update the actual position marker
    if (actualMarker && slider) {
        if (isDisabled) {
            actualMarker.style.display = 'none';
        } else {
            actualMarker.style.display = '';
            // Calculate percentage position on the track
            const min = parseInt(slider.min);
            const max = parseInt(slider.max);
            const percent = ((position - min) / (max - min)) * 100;
            // Position marker to align with slider thumb center
            // Slider thumb (18px) stays within track bounds, so at P%:
            //   thumb center = 9px + P% * (trackWidth - 18px) / trackWidth
            // For 10px marker to have same center: left = P% - P*0.18px + 4px
            actualMarker.style.left = `calc(${percent}% - ${percent * 0.18}px + 4px)`;
            actualMarker.title = `Actual: ${Math.round(position / 4)}µs`;
        }
    }
}

function onServoSpeedChange(channel, speed) {
    if (maestroClient && maestroClient.connected) {
        maestroClient.setSpeed(channel, parseInt(speed));
    }
}

function onServoAccelChange(channel, acceleration) {
    if (maestroClient && maestroClient.connected) {
        maestroClient.setAcceleration(channel, parseInt(acceleration));
    }
}

function centerServo(channel) {
    // Skip disabled servos
    const toggleBtn = document.getElementById(`servo-toggle-${channel}`);
    const isDisabled = toggleBtn && toggleBtn.classList.contains('disabled');
    if (isDisabled) return;

    const slider = document.getElementById(`servo-slider-${channel}`);
    if (slider) {
        // Calculate center from channel config min/max (in quarter-microseconds)
        const config = maestroChannelConfig[channel] || {};
        const minQuarterUs = config.min || 4000;  // Default 1000µs
        const maxQuarterUs = config.max || 8000;  // Default 2000µs
        const centerQuarterUs = Math.round((minQuarterUs + maxQuarterUs) / 2);

        slider.value = centerQuarterUs;
        onServoSliderInput(channel, centerQuarterUs);
    }
}

function disableServo(channel) {
    if (maestroClient && maestroClient.connected) {
        maestroClient.setTarget(channel, 0);
        // Update UI immediately (don't wait for device feedback)
        updateServoPosition(channel, 0);
    }
}

function enableServo(channel) {
    // Enable by moving to last position or center
    const slider = document.getElementById(`servo-slider-${channel}`);
    const lastPosition = slider ? parseInt(slider.value) : 0;

    // If slider was at 0 (never set or disabled), use calculated center
    let targetPosition = lastPosition;
    if (lastPosition <= 0) {
        const config = maestroChannelConfig[channel] || {};
        const minQuarterUs = config.min || 4000;  // Default 1000µs
        const maxQuarterUs = config.max || 8000;  // Default 2000µs
        targetPosition = Math.round((minQuarterUs + maxQuarterUs) / 2);
    }

    if (maestroClient && maestroClient.connected) {
        maestroClient.setTarget(channel, targetPosition);
        // Update UI immediately (don't wait for device feedback)
        updateServoPosition(channel, targetPosition);
    }
}

function toggleServoEnabled(channel) {
    // Check current state from the toggle button class
    const toggleBtn = document.getElementById(`servo-toggle-${channel}`);
    const isCurrentlyDisabled = toggleBtn && toggleBtn.classList.contains('disabled');

    if (isCurrentlyDisabled) {
        enableServo(channel);
    } else {
        disableServo(channel);
    }
}

// ============================================================================
// Bulk Servo Operations
// ============================================================================

function maestroGoHome() {
    if (maestroClient && maestroClient.connected) {
        maestroClient.goHome();
    }
}

function maestroCenterAll() {
    if (!maestroState) return;

    for (let ch = 0; ch < maestroState.channels; ch++) {
        centerServo(ch);
    }
}

function maestroDisableAll() {
    if (!maestroState) return;

    for (let ch = 0; ch < maestroState.channels; ch++) {
        disableServo(ch);
    }
}

function maestroExpandAll() {
    if (!maestroState) return;

    // Expand all visible (non-hidden) channels
    for (let ch = 0; ch < maestroState.channels; ch++) {
        if (isChannelVisible(ch, maestroState)) {
            expandedChannels.add(ch);
        }
    }
    renderServoControls(maestroState);
}

function maestroCollapseAll() {
    expandedChannels.clear();
    if (maestroState) {
        renderServoControls(maestroState);
    }
}

// ============================================================================
// Script Management
// ============================================================================

function maestroRunScript() {
    // TODO: Implement script compilation and upload
    alert('Script compilation and upload not yet implemented');
}

function maestroStopScript() {
    if (maestroClient && maestroClient.connected) {
        maestroClient.stopScript();
    }
}

function maestroUploadScript() {
    // TODO: Implement script upload to device
    alert('Script upload not yet implemented');
}

// ============================================================================
// Configuration Management
// ============================================================================

function showMaestroConfigTab(tabName) {
    // Hide all config tabs
    document.querySelectorAll('#maestro-config-section .tab-inner-content').forEach(tab => {
        tab.style.display = 'none';
    });

    // Remove active from all buttons
    document.querySelectorAll('#maestro-config-section .tab-inner-btn').forEach(btn => {
        btn.classList.remove('active');
    });

    // Show selected tab
    const selectedTab = document.getElementById(`maestro-config-${tabName}`);
    if (selectedTab) {
        selectedTab.style.display = 'block';
    }

    // Mark button as active
    event.target.classList.add('active');
}

// ============================================================================
// Channel Configuration Functions
// ============================================================================

async function loadMaestroChannelConfig() {
    if (!selectedMaestroPort) return;

    try {
        // Load channel settings from device
        const data = await fetchJson(`/api/maestro/device/${encodeURIComponent(selectedMaestroPort)}/channels`);

        if (data.success) {
            maestroChannelConfig = data.channels;
            // Deep copy for comparison
            maestroOriginalConfig = JSON.parse(JSON.stringify(data.channels));
            modifiedChannels.clear();
            console.log('Loaded channel config:', maestroChannelConfig);
        } else {
            console.error('Failed to load channel config:', data.error);
        }

        // Load channel names (stored locally by serial number)
        if (currentDeviceSerial) {
            const namesData = await fetchJson(`/api/maestro/device/${encodeURIComponent(currentDeviceSerial)}/names`);

            if (namesData.success) {
                maestroChannelNames = namesData.names || {};
                maestroOriginalNames = JSON.parse(JSON.stringify(maestroChannelNames));
                console.log('Loaded channel names:', maestroChannelNames);
            }

            // Load hidden channels from localStorage
            loadHiddenChannels();
        }

        // Re-render to show loaded config and names
        if (maestroState) {
            renderServoControls(maestroState);
        }
    } catch (error) {
        console.error('Error loading channel config:', error);
    }
}

function toggleChannelExpand(channel) {
    if (expandedChannels.has(channel)) {
        expandedChannels.delete(channel);
    } else {
        expandedChannels.add(channel);
    }
    // Re-render to show/hide config row
    if (maestroState) {
        renderServoControls(maestroState);
    }
}

// ============================================================================
// Channel Visibility / Hiding
// ============================================================================

/**
 * Load hidden channels from localStorage for current device.
 */
function loadHiddenChannels() {
    hiddenChannels.clear();
    if (!currentDeviceSerial) return;

    const storageKey = `maestro_hidden_${currentDeviceSerial}`;
    const stored = localStorage.getItem(storageKey);
    if (stored) {
        try {
            const arr = JSON.parse(stored);
            arr.forEach(ch => hiddenChannels.add(ch));
        } catch (e) {
            console.error('Failed to parse hidden channels:', e);
        }
    }
}

/**
 * Save hidden channels to localStorage for current device.
 */
function saveHiddenChannels() {
    if (!currentDeviceSerial) return;

    const storageKey = `maestro_hidden_${currentDeviceSerial}`;
    localStorage.setItem(storageKey, JSON.stringify([...hiddenChannels]));
}

/**
 * Toggle visibility of a single channel.
 */
function toggleChannelHidden(channel) {
    if (hiddenChannels.has(channel)) {
        hiddenChannels.delete(channel);
    } else {
        hiddenChannels.add(channel);
    }
    saveHiddenChannels();

    if (maestroState) {
        renderServoControls(maestroState);
    }
}

/**
 * Show all channels (clear hidden set and filter).
 */
function showAllChannels() {
    hiddenChannels.clear();
    channelFilter = 'all';
    saveHiddenChannels();

    // Update filter dropdown if it exists
    const filterSelect = document.getElementById('channel-filter-select');
    if (filterSelect) filterSelect.value = 'all';

    if (maestroState) {
        renderServoControls(maestroState);
    }
}

/**
 * Set the channel filter mode.
 */
function setChannelFilter(filterMode) {
    channelFilter = filterMode;
    if (maestroState) {
        renderServoControls(maestroState);
    }
}

/**
 * Check if a channel should be visible based on current filter and hidden state.
 */
function isChannelVisible(channel, state) {
    // Always hide if manually hidden
    if (hiddenChannels.has(channel)) {
        return false;
    }

    // Apply filter
    switch (channelFilter) {
        case 'active':
            // Show if position is non-zero (enabled) or has been modified
            const servoData = state.servos[channel] || {};
            const position = servoData.position || 0;
            return position !== 0 || modifiedChannels.has(channel);

        case 'named':
            // Show only channels with custom names (not "Channel N")
            const name = maestroChannelNames[channel];
            return name && name !== `Channel ${channel}`;

        case 'all':
        default:
            return true;
    }
}

/**
 * Get count of visible and hidden channels.
 */
function getChannelVisibilityCounts(state) {
    let visible = 0;
    let hidden = 0;
    let manuallyHidden = hiddenChannels.size;

    for (let ch = 0; ch < state.channels; ch++) {
        if (isChannelVisible(ch, state)) {
            visible++;
        } else {
            hidden++;
        }
    }

    return { visible, hidden, manuallyHidden, total: state.channels };
}

function onChannelConfigChange(channel, field, value) {
    if (!maestroChannelConfig[channel]) {
        maestroChannelConfig[channel] = {};
    }

    // Update the config
    maestroChannelConfig[channel][field] = value;

    // Also update _us versions for position fields
    if (field === 'min' || field === 'max' || field === 'home' || field === 'neutral') {
        maestroChannelConfig[channel][field + '_us'] = value / 4;
    }

    // Update slider bounds when min/max changes
    if (field === 'min' || field === 'max') {
        updateSliderBounds(channel);
    }

    // Check if this channel is now modified
    checkChannelModified(channel);
}

/**
 * Update the slider min/max attributes and labels based on channel config.
 */
function updateSliderBounds(channel) {
    const config = maestroChannelConfig[channel] || {};
    const slider = document.getElementById(`servo-slider-${channel}`);
    const minLabel = document.getElementById(`servo-min-label-${channel}`);
    const maxLabel = document.getElementById(`servo-max-label-${channel}`);

    if (slider) {
        const minQuarterUs = config.min || 2000;
        const maxQuarterUs = config.max || 10000;
        slider.min = minQuarterUs;
        slider.max = maxQuarterUs;

        // Clamp current value if outside new bounds
        const currentValue = parseInt(slider.value);
        if (currentValue < minQuarterUs) {
            slider.value = minQuarterUs;
        } else if (currentValue > maxQuarterUs) {
            slider.value = maxQuarterUs;
        }
    }

    if (minLabel) {
        minLabel.textContent = Math.round(config.min_us || 500);
    }

    if (maxLabel) {
        maxLabel.textContent = Math.round(config.max_us || 2500);
    }
}

/**
 * Update the Home position input enabled state based on home_mode.
 * Only GOTO mode uses the home position value.
 */
function updateHomeInputState(channel) {
    const homeMode = maestroChannelConfig[channel]?.home_mode || 'GOTO';
    const homeInput = document.getElementById(`ch-${channel}-home`);
    if (homeInput) {
        homeInput.disabled = (homeMode !== 'GOTO');
    }
}

function checkChannelModified(channel) {
    const current = maestroChannelConfig[channel];
    const original = maestroOriginalConfig[channel];

    let isModified = false;

    // Check config fields
    if (!original) {
        isModified = true;
    } else {
        // Compare relevant fields
        const fields = ['mode', 'home_mode', 'home', 'min', 'max', 'neutral', 'range', 'speed', 'acceleration'];
        for (const field of fields) {
            if (current[field] !== original[field]) {
                isModified = true;
                break;
            }
        }
    }

    // Also check if name has changed
    const currentName = maestroChannelNames[channel] || '';
    const originalName = maestroOriginalNames[channel] || '';
    if (currentName !== originalName) {
        isModified = true;
    }

    if (isModified) {
        modifiedChannels.add(channel);
    } else {
        modifiedChannels.delete(channel);
    }

    updateChannelModifiedState(channel);
}

function updateChannelModifiedState(channel) {
    const row = document.getElementById(`servo-row-${channel}`);
    const configRow = document.getElementById(`config-row-${channel}`);

    if (row) {
        if (modifiedChannels.has(channel)) {
            row.classList.add('channel-unsaved');
        } else {
            row.classList.remove('channel-unsaved');
        }
    }

    // Update the unsaved dot
    const channelCell = row?.querySelector('.col-channel');
    if (channelCell) {
        let dot = channelCell.querySelector('.unsaved-dot');
        if (modifiedChannels.has(channel)) {
            if (!dot) {
                dot = document.createElement('span');
                dot.className = 'unsaved-dot';
                dot.title = 'Unsaved changes';
                dot.textContent = '●';
                channelCell.appendChild(dot);
            }
        } else if (dot) {
            dot.remove();
        }
    }

    // Update warning in config row
    if (configRow) {
        let warning = configRow.querySelector('.config-warning');
        if (modifiedChannels.has(channel)) {
            if (!warning) {
                warning = document.createElement('div');
                warning.className = 'config-warning';
                warning.textContent = '⚠ Unsaved changes';
                const panel = configRow.querySelector('.config-panel');
                if (panel) panel.insertBefore(warning, panel.firstChild);
            }
        } else if (warning) {
            warning.remove();
        }
    }

    // Update header count
    updateUnsavedCount();
}

function updateUnsavedCount() {
    const countEl = document.getElementById('maestro-unsaved-count');
    if (countEl) {
        if (modifiedChannels.size > 0) {
            countEl.textContent = `${modifiedChannels.size} channel(s) with unsaved changes`;
            countEl.style.display = 'inline';
        } else {
            countEl.style.display = 'none';
        }
    }

    // Show/hide the Apply All button
    const applyAllBtn = document.getElementById('maestro-apply-all-btn');
    if (applyAllBtn) {
        applyAllBtn.style.display = modifiedChannels.size > 0 ? 'inline-block' : 'none';
    }
}

function setToCurrentPosition(channel, field) {
    if (!maestroState || !maestroState.servos[channel]) {
        alert('No servo data available');
        return;
    }

    const currentPos = maestroState.servos[channel].position;
    const currentUs = Math.round(currentPos / 4);

    // Update the input field
    const input = document.getElementById(`ch-${channel}-${field}`);
    if (input) {
        input.value = currentUs;
    }

    // Update the config
    onChannelConfigChange(channel, field, currentPos);

    console.log(`Set channel ${channel} ${field} to ${currentUs}µs (${currentPos} quarter-µs)`);
}

function editChannelName(channel) {
    const nameSpan = document.getElementById(`servo-name-${channel}`);
    if (!nameSpan) return;

    const currentName = maestroChannelNames[channel] || `Channel ${channel}`;
    const cell = nameSpan.parentElement;

    // Replace name span with input
    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'channel-name-input';
    input.value = currentName;
    input.maxLength = 30;

    // Hide name span and edit button
    nameSpan.style.display = 'none';
    const editBtn = cell.querySelector('.name-edit-btn');
    if (editBtn) editBtn.style.display = 'none';

    cell.appendChild(input);
    input.focus();
    input.select();

    // Save on Enter or blur
    const saveName = () => {
        const newName = input.value.trim();
        if (newName && newName !== `Channel ${channel}`) {
            maestroChannelNames[channel] = newName;
        } else {
            delete maestroChannelNames[channel];
        }

        // Update display
        nameSpan.textContent = maestroChannelNames[channel] || `Channel ${channel}`;
        nameSpan.style.display = '';
        if (editBtn) editBtn.style.display = '';
        input.remove();

        // Check if modified
        checkChannelModified(channel);
    };

    input.addEventListener('blur', saveName);
    input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            input.blur();
        } else if (e.key === 'Escape') {
            // Cancel - restore original
            input.value = currentName;
            input.blur();
        }
    });
}

async function saveChannelNames() {
    if (!currentDeviceSerial) {
        console.warn('No device serial, cannot save names');
        return false;
    }

    try {
        const result = await fetchJson(
            `/api/maestro/device/${encodeURIComponent(currentDeviceSerial)}/names`,
            {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(maestroChannelNames)
            }
        );

        if (result.success) {
            maestroOriginalNames = JSON.parse(JSON.stringify(maestroChannelNames));
            console.log('Channel names saved');
            return true;
        } else {
            console.error('Failed to save channel names:', result.error);
            return false;
        }
    } catch (error) {
        console.error('Error saving channel names:', error);
        return false;
    }
}

async function applyChannelConfig(channel) {
    if (!selectedMaestroPort) {
        alert('No device selected');
        return;
    }

    const config = maestroChannelConfig[channel];
    if (!config) {
        alert('No configuration for this channel');
        return;
    }

    try {
        const result = await fetchJson(
            `/api/maestro/device/${encodeURIComponent(selectedMaestroPort)}/channels/${channel}`,
            {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(config)
            }
        );

        if (result.success) {
            // Update original config to match
            maestroOriginalConfig[channel] = JSON.parse(JSON.stringify(config));

            // Also save channel name if changed
            const currentName = maestroChannelNames[channel] || '';
            const originalName = maestroOriginalNames[channel] || '';
            if (currentName !== originalName) {
                await saveChannelNames();
            }

            modifiedChannels.delete(channel);
            updateChannelModifiedState(channel);

            // Flash success
            const row = document.getElementById(`servo-row-${channel}`);
            if (row) {
                row.classList.add('save-success');
                setTimeout(() => row.classList.remove('save-success'), 1000);
            }

            console.log(`Channel ${channel} saved to device`);
        } else {
            alert('Failed to save: ' + (result.error || 'Unknown error'));
        }
    } catch (error) {
        console.error('Error saving channel config:', error);
        alert('Error saving: ' + error.message);
    }
}

async function discardChannelConfig(channel) {
    if (!maestroOriginalConfig[channel]) {
        alert('No original configuration to restore');
        return;
    }

    // Restore config from original
    maestroChannelConfig[channel] = JSON.parse(JSON.stringify(maestroOriginalConfig[channel]));

    // Restore name from original
    if (maestroOriginalNames[channel]) {
        maestroChannelNames[channel] = maestroOriginalNames[channel];
    } else {
        delete maestroChannelNames[channel];
    }

    modifiedChannels.delete(channel);

    // Re-render the config row
    if (maestroState) {
        renderServoControls(maestroState);
    }
}

/**
 * Apply imported channel configs from MCC file.
 * Updates in-memory config and marks channels as modified for review.
 * @param {Array} channels - Array of channel config objects from MCC parser
 */
function applyImportedChannelConfigs(channels) {
    if (!channels || channels.length === 0) return;

    let appliedCount = 0;

    for (const ch of channels) {
        const chIdx = ch.index;
        if (chIdx === undefined || chIdx === null) continue;

        // Convert MCC format to our internal format
        // MCC uses quarter-microseconds for min/max/home/neutral
        const config = {
            mode: ch.mode || 'Servo',
            min: ch.min,
            max: ch.max,
            min_us: ch.min / 4,
            max_us: ch.max / 4,
            home_mode: ch.homemode || 'Off',
            home: ch.home,
            home_us: ch.home / 4,
            neutral: ch.neutral,
            neutral_us: ch.neutral / 4,
            range: ch.range,
            speed: ch.speed,
            acceleration: ch.acceleration
        };

        // Update in-memory config
        maestroChannelConfig[chIdx] = config;

        // Update channel name if provided
        if (ch.name) {
            maestroChannelNames[String(chIdx)] = ch.name;
        }

        // Mark as modified so user can review before applying
        modifiedChannels.add(chIdx);
        appliedCount++;
    }

    // Re-render to show changes
    if (maestroState && appliedCount > 0) {
        renderServoControls(maestroState);
        showToast(`${appliedCount} channel configs loaded. Review and click "Apply to Device" to save.`, 'info', 5000);
    }
}

async function maestroSaveConfig() {
    if (!selectedMaestroPort) {
        alert('No device selected');
        return;
    }

    if (modifiedChannels.size === 0) {
        alert('No changes to save');
        return;
    }

    const channels = Array.from(modifiedChannels);
    if (!confirm(`Save changes to ${channels.length} channel(s)?\n\nChannels: ${channels.join(', ')}`)) {
        return;
    }

    let errors = [];
    for (const ch of channels) {
        try {
            const result = await fetchJson(
                `/api/maestro/device/${encodeURIComponent(selectedMaestroPort)}/channels/${ch}`,
                {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(maestroChannelConfig[ch])
                }
            );

            if (result.success) {
                maestroOriginalConfig[ch] = JSON.parse(JSON.stringify(maestroChannelConfig[ch]));
                modifiedChannels.delete(ch);
                updateChannelModifiedState(ch);
            } else {
                errors.push(`Channel ${ch}: ${result.error}`);
            }
        } catch (error) {
            errors.push(`Channel ${ch}: ${error.message}`);
        }
    }

    if (errors.length > 0) {
        alert('Some channels failed to save:\n' + errors.join('\n'));
    } else {
        alert('All changes saved successfully!');
    }
}

/**
 * Apply all pending channel changes to the device.
 * Uses toast notifications instead of alerts for better UX.
 */
async function maestroApplyAllChannelChanges() {
    if (!selectedMaestroPort) {
        showToast('No device connected', 'error');
        return;
    }

    if (modifiedChannels.size === 0) {
        showToast('No pending changes to apply', 'info');
        return;
    }

    const channels = Array.from(modifiedChannels);
    showToast(`Applying changes to ${channels.length} channel(s)...`, 'info');

    let successCount = 0;
    let errors = [];

    for (const ch of channels) {
        try {
            const result = await fetchJson(
                `/api/maestro/device/${encodeURIComponent(selectedMaestroPort)}/channels/${ch}`,
                {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(maestroChannelConfig[ch])
                }
            );

            if (result.success) {
                maestroOriginalConfig[ch] = JSON.parse(JSON.stringify(maestroChannelConfig[ch]));
                modifiedChannels.delete(ch);
                updateChannelModifiedState(ch);
                successCount++;

                // Flash success on the row
                const row = document.getElementById(`servo-row-${ch}`);
                if (row) {
                    row.classList.add('save-success');
                    setTimeout(() => row.classList.remove('save-success'), 1000);
                }
            } else {
                errors.push(`Ch${ch}: ${result.error}`);
            }
        } catch (error) {
            errors.push(`Ch${ch}: ${error.message}`);
        }
    }

    // Update the Apply All button visibility
    updateUnsavedCount();

    if (errors.length > 0) {
        showToast(`${successCount} saved, ${errors.length} failed`, 'warning', 5000);
        console.error('Channel save errors:', errors);
    } else {
        showToast(`All ${successCount} channel(s) saved successfully`, 'success');
    }
}

/**
 * Reset all channel settings to factory defaults.
 * Clears channel config, channel names, and sequence library.
 * Requires confirmation before applying.
 */
async function maestroResetToDefaults() {
    if (!selectedMaestroPort) {
        showToast('No device connected', 'error');
        return;
    }

    if (!maestroState || !maestroState.channels) {
        showToast('No channel data available', 'error');
        return;
    }

    const sequenceCount = maestroLibrarySequences.length;

    // Show confirmation modal with full scope
    const result = await showConfirmModal({
        title: 'Reset to Factory Defaults',
        content: `
            <p>This will reset <strong>ALL settings</strong> to factory defaults:</p>
            <ul style="margin: 12px 0; padding-left: 20px; color: var(--text-muted, #888);">
                <li><strong>${maestroState.channels} channels</strong> - min, max, home, speed, acceleration</li>
                <li><strong>${sequenceCount} sequence${sequenceCount !== 1 ? 's' : ''}</strong> - entire library will be cleared</li>
                <li><strong>Channel names</strong> - all custom names removed</li>
            </ul>
            <p style="color: var(--accent-danger, #e53935);">⚠️ This cannot be undone. Sequences will be permanently deleted.</p>
        `,
        confirmLabel: 'Reset Everything',
        confirmClass: 'maestro-modal__btn--danger',
        cancelLabel: 'Cancel'
    });

    if (result !== 'confirm') {
        return;
    }

    // Default values (Pololu Maestro factory defaults)
    const defaults = {
        mode: 'SERVO',
        min: 3968,           // 992µs in quarter-µs
        max: 8000,           // 2000µs in quarter-µs
        min_us: 992,
        max_us: 2000,
        home_mode: 'OFF',
        home: 6000,          // 1500µs in quarter-µs
        home_us: 1500,
        neutral: 6000,       // 1500µs in quarter-µs
        neutral_us: 1500,
        range: 1905,
        speed: 0,
        acceleration: 0
    };

    // Apply defaults to all channels
    for (let ch = 0; ch < maestroState.channels; ch++) {
        maestroChannelConfig[ch] = JSON.parse(JSON.stringify(defaults));
        modifiedChannels.add(ch);
    }

    // Clear channel names
    maestroChannelNames = {};

    // Clear sequence library via backend
    if (currentDeviceSerial && sequenceCount > 0) {
        try {
            await fetch(`/api/maestro/library/clear?device_serial=${encodeURIComponent(currentDeviceSerial)}`, {
                method: 'DELETE'
            });
        } catch (e) {
            console.error('Failed to clear library:', e);
        }
    }

    // Clear local sequence state
    maestroLibrarySequences = [];
    renderSequenceLibrary();

    // Clear recorder state
    maestroClearRecorder();

    // Re-render channel controls
    if (maestroState) {
        renderServoControls(maestroState);
    }

    // Update Apply All button visibility
    updateUnsavedCount();

    showToast('Reset to factory defaults. Click "Apply All Changes" to save channel settings.', 'success', 5000);
}

// ============================================================================
// Sequence Recording & Playback
// ============================================================================

let maestroSequenceFrames = [];
let maestroPlaybackState = {
    playing: false,
    currentFrame: -1,
    timeoutId: null
};
let selectedFrameIndex = -1;  // Currently selected frame for editing

function maestroRecordFrame() {
    if (!maestroState || !maestroState.servos) return;

    const frame = {
        positions: {},
        duration: parseInt(document.getElementById('maestro-frame-delay').value) || 500,
        timestamp: Date.now()
    };

    // Record channels that are active (enabled)
    // Use slider value as primary source since it reflects user's intent,
    // device-reported position may be delayed or differ slightly
    for (let ch = 0; ch < maestroState.channels; ch++) {
        const slider = document.getElementById(`servo-slider-${ch}`);
        const toggleBtn = document.getElementById(`servo-toggle-${ch}`);
        const isDisabled = toggleBtn && toggleBtn.classList.contains('disabled');

        // Only record enabled channels
        if (!isDisabled && slider) {
            const sliderValue = parseInt(slider.value);
            const servo = maestroState.servos[ch] || {};

            // Use slider value (what user set) for target
            if (sliderValue > 0) {
                frame.positions[ch] = {
                    target: sliderValue,
                    speed: servo.speed || 0,
                    accel: servo.acceleration || 0
                };
                console.log(`Recording ch${ch}: slider=${sliderValue}, device=${servo.position}`);
            }
        }
    }

    const channelCount = Object.keys(frame.positions).length;
    if (channelCount === 0) {
        showToast('No active channels to record. Enable at least one servo first.', 'warning');
        return;
    }

    maestroSequenceFrames.push(frame);
    updateSequenceDisplay();
    showToast(`Frame ${maestroSequenceFrames.length} recorded (${channelCount} channel${channelCount !== 1 ? 's' : ''})`, 'success');
}

function maestroPlaySequence() {
    if (maestroSequenceFrames.length === 0) {
        showToast('No frames to play', 'warning');
        return;
    }

    if (maestroPlaybackState.playing) {
        // Already playing, do nothing
        return;
    }

    maestroPlaybackState.playing = true;
    maestroPlaybackState.currentFrame = 0;

    // Update UI
    const playBtn = document.getElementById('maestro-play-btn');
    const stopBtn = document.getElementById('maestro-stop-btn');
    if (playBtn) playBtn.style.display = 'none';
    if (stopBtn) stopBtn.style.display = 'inline-block';

    playNextFrame();
}

function playNextFrame() {
    if (!maestroPlaybackState.playing) return;

    const frameIndex = maestroPlaybackState.currentFrame;

    // Check if we've reached the end
    if (frameIndex >= maestroSequenceFrames.length) {
        const loop = document.getElementById('maestro-loop-playback');
        if (loop && loop.checked) {
            // Loop back to start
            maestroPlaybackState.currentFrame = 0;
            playNextFrame();
            return;
        } else {
            // Stop playback
            maestroStopSequence();
            return;
        }
    }

    const frame = maestroSequenceFrames[frameIndex];

    // Apply this frame's positions
    applyFrame(frame);

    // Update display to show current frame
    updateSequenceDisplay();

    // Schedule next frame
    maestroPlaybackState.timeoutId = setTimeout(() => {
        maestroPlaybackState.currentFrame++;
        playNextFrame();
    }, frame.duration);
}

function applyFrame(frame) {
    if (!maestroClient || !maestroClient.connected) {
        showToast('Not connected to Maestro', 'error');
        maestroStopSequence();
        return;
    }

    Object.entries(frame.positions).forEach(([channel, data]) => {
        // Handle both old format (just target) and new format (object with target/speed/accel)
        const target = typeof data === 'object' ? data.target : data;
        maestroClient.setTarget(parseInt(channel), target);
    });
}

function maestroStopSequence() {
    if (maestroPlaybackState.timeoutId) {
        clearTimeout(maestroPlaybackState.timeoutId);
        maestroPlaybackState.timeoutId = null;
    }

    maestroPlaybackState.playing = false;
    maestroPlaybackState.currentFrame = -1;

    // Update UI
    const playBtn = document.getElementById('maestro-play-btn');
    const stopBtn = document.getElementById('maestro-stop-btn');
    if (playBtn) playBtn.style.display = 'inline-block';
    if (stopBtn) stopBtn.style.display = 'none';

    updateSequenceDisplay();
}

/**
 * Clear the sequence recorder state.
 * Consolidated function replacing maestroClearSequence and maestroClearRecorderForNew.
 * @param {Object} options
 * @param {boolean} options.stopPlayback - Stop any playing sequence (default true)
 * @param {boolean} options.notify - Show confirmation toast (default false)
 */
function maestroClearRecorder({ stopPlayback = true, notify = false } = {}) {
    if (stopPlayback && maestroPlaybackState.playing) {
        maestroStopSequence();
    }

    // Clear frames
    maestroSequenceFrames = [];
    selectedFrameIndex = -1;

    // Clear editing state
    currentEditingSequenceId = null;

    // Clear UI
    const nameInput = document.getElementById('maestro-sequence-name');
    if (nameInput) nameInput.value = '';

    const frameEditor = document.getElementById('maestro-frame-editor');
    if (frameEditor) frameEditor.style.display = 'none';

    updateSequenceDisplay();
    updateRecorderEditIndicator(null);

    if (notify) {
        showToast('Ready for new sequence', 'info');
    }
}

// Legacy alias for backwards compatibility
function maestroClearSequence() {
    maestroClearRecorder();
}

function maestroDeleteFrame(index) {
    if (maestroPlaybackState.playing) {
        showToast('Stop playback before deleting frames', 'warning');
        return;
    }

    // Handle selected frame
    if (selectedFrameIndex === index) {
        selectedFrameIndex = -1;
        const editor = document.getElementById('maestro-frame-editor');
        if (editor) editor.style.display = 'none';
    } else if (selectedFrameIndex > index) {
        // Adjust selection if a previous frame was deleted
        selectedFrameIndex--;
    }

    maestroSequenceFrames.splice(index, 1);
    updateSequenceDisplay();
    showToast(`Frame ${index + 1} deleted`, 'info');
}

function maestroPreviewFrame(index) {
    if (maestroPlaybackState.playing) {
        showToast('Stop playback to preview frames', 'warning');
        return;
    }
    if (index < 0 || index >= maestroSequenceFrames.length) return;

    const frame = maestroSequenceFrames[index];

    // Apply frame positions to servos (sends commands to device)
    applyFrame(frame);

    // Also update UI sliders to reflect frame positions immediately
    Object.entries(frame.positions).forEach(([channel, data]) => {
        const target = typeof data === 'object' ? data.target : data;
        const slider = document.getElementById(`servo-slider-${channel}`);
        const valueDisplay = document.getElementById(`servo-value-${channel}`);

        if (slider) {
            const oldValue = slider.value;
            const sliderMin = parseInt(slider.min);
            const sliderMax = parseInt(slider.max);
            slider.value = target;
            console.log(`Preview ch${channel}: target=${target}, slider min=${sliderMin} max=${sliderMax}, old=${oldValue}, new=${slider.value}`);

            // If target is outside slider bounds, warn in console
            if (target < sliderMin || target > sliderMax) {
                console.warn(`Ch${channel}: target ${target} is outside slider bounds [${sliderMin}, ${sliderMax}]`);
            }
        }
        if (valueDisplay) {
            valueDisplay.textContent = `${Math.round(target / 4)}µs`;
        }

        // Update local state to match
        if (maestroState && maestroState.servos && maestroState.servos[channel]) {
            maestroState.servos[channel].position = target;
        }
    });

    // Select frame for editing
    selectedFrameIndex = index;

    // Show frame editor UI
    const editor = document.getElementById('maestro-frame-editor');
    const label = document.getElementById('maestro-selected-frame-label');
    const delayInput = document.getElementById('maestro-edit-delay');

    if (editor && label && delayInput) {
        label.textContent = `Editing Frame ${index + 1}`;
        delayInput.value = frame.duration;
        editor.style.display = 'block';
    }

    // Update display to show selected state
    updateSequenceDisplay();
    showToast(`Loaded frame ${index + 1} positions`, 'success');
}

function maestroConvertToScript() {
    if (maestroSequenceFrames.length === 0) {
        showToast('No frames to convert', 'warning');
        return;
    }

    // Generate Maestro script
    let script = '# Maestro Script - Generated from sequence\n';
    script += '# Frame count: ' + maestroSequenceFrames.length + '\n\n';
    script += 'begin\n';

    maestroSequenceFrames.forEach((frame, index) => {
        script += `  # Frame ${index + 1}\n`;

        Object.entries(frame.positions).forEach(([channel, data]) => {
            const target = typeof data === 'object' ? data.target : data;
            // Maestro script uses target values directly (quarter-microseconds)
            script += `  ${target} ${channel} servo\n`;
        });

        // Delay in milliseconds
        script += `  ${frame.duration} delay\n\n`;
    });

    script += 'repeat\n';

    // Create download
    const blob = new Blob([script], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'maestro_sequence.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    showToast('Script downloaded', 'success');
}

function maestroSendToEditor() {
    if (maestroSequenceFrames.length === 0) {
        showToast('No frames to convert', 'warning');
        return;
    }

    // Generate Maestro script
    let script = '# Maestro Script - Generated from sequence\n';
    script += '# Frame count: ' + maestroSequenceFrames.length + '\n\n';
    script += 'begin\n';

    maestroSequenceFrames.forEach((frame, index) => {
        script += `  # Frame ${index + 1}\n`;

        Object.entries(frame.positions).forEach(([channel, data]) => {
            const target = typeof data === 'object' ? data.target : data;
            // Maestro script uses target values directly (quarter-microseconds)
            script += `  ${target} ${channel} servo\n`;
        });

        // Delay in milliseconds
        script += `  ${frame.duration} delay\n\n`;
    });

    script += 'repeat\n';

    // Put script in the editor textarea
    const editor = document.getElementById('maestro-script-editor');
    if (editor) {
        editor.value = script;
        showToast('Script sent to editor', 'success');
    } else {
        showToast('Script editor not found', 'error');
    }
}

function updateSequenceDisplay() {
    const container = document.getElementById('maestro-sequence-frames');
    if (!container) return;

    container.innerHTML = '';

    if (maestroSequenceFrames.length === 0) {
        container.innerHTML = '<div class="empty-state">No frames recorded. Move servos to desired positions and click "Record Frame".</div>';
        // Hide frame editor when no frames
        selectedFrameIndex = -1;
        const editor = document.getElementById('maestro-frame-editor');
        if (editor) editor.style.display = 'none';
        return;
    }

    maestroSequenceFrames.forEach((frame, index) => {
        const isPlaying = maestroPlaybackState.playing && maestroPlaybackState.currentFrame === index;
        const isSelected = selectedFrameIndex === index;
        const channelList = Object.keys(frame.positions).map(ch => `Ch${ch}`).join(', ');

        const div = document.createElement('div');
        div.className = 'sequence-frame-item' + (isPlaying ? ' playing' : '') + (isSelected ? ' selected' : '');
        div.innerHTML = `
            <div class="frame-header">
                <span class="frame-number">Frame ${index + 1}</span>
                <span class="frame-duration">${frame.duration}ms</span>
                <button class="frame-delete-btn" onclick="event.stopPropagation(); maestroDeleteFrame(${index})" title="Delete frame">✕</button>
            </div>
            <div class="frame-details">
                ${Object.keys(frame.positions).length} channel(s): ${channelList || 'none'}
            </div>
        `;
        div.onclick = () => maestroPreviewFrame(index);
        div.title = 'Click to preview this frame';
        container.appendChild(div);
    });
}

/**
 * Update the selected frame's delay value.
 */
function maestroUpdateSelectedFrame() {
    if (selectedFrameIndex < 0 || selectedFrameIndex >= maestroSequenceFrames.length) {
        showToast('No frame selected', 'warning');
        return;
    }

    const delayInput = document.getElementById('maestro-edit-delay');
    const newDelay = parseInt(delayInput?.value) || 500;

    if (newDelay < 10 || newDelay > 10000) {
        showToast('Delay must be between 10 and 10000 ms', 'warning');
        return;
    }

    maestroSequenceFrames[selectedFrameIndex].duration = newDelay;
    updateSequenceDisplay();
    showToast(`Frame ${selectedFrameIndex + 1} delay updated to ${newDelay}ms`, 'success');
}

/**
 * Overwrite the selected frame's positions with current servo positions.
 */
function maestroOverwriteSelectedFrame() {
    if (selectedFrameIndex < 0 || selectedFrameIndex >= maestroSequenceFrames.length) {
        showToast('No frame selected', 'warning');
        return;
    }

    if (!maestroState || !maestroState.servos) {
        showToast('No servo data available', 'warning');
        return;
    }

    // Capture current positions
    const newPositions = {};
    Object.keys(maestroState.servos).forEach(ch => {
        const servo = maestroState.servos[ch];
        if (servo.position !== 0) {
            newPositions[ch] = {
                target: servo.position,
                speed: servo.speed || 0,
                accel: servo.acceleration || 0
            };
        }
    });

    maestroSequenceFrames[selectedFrameIndex].positions = newPositions;
    updateSequenceDisplay();
    const channelCount = Object.keys(newPositions).length;
    showToast(`Frame ${selectedFrameIndex + 1} updated with ${channelCount} active channel(s)`, 'success');
}

/**
 * Deselect the currently selected frame.
 */
function maestroDeselectFrame() {
    selectedFrameIndex = -1;

    // Hide editor
    const editor = document.getElementById('maestro-frame-editor');
    if (editor) editor.style.display = 'none';

    updateSequenceDisplay();
}

// ============================================================================
// Serial Mode Management
// ============================================================================

/**
 * Check if the Maestro device is in the correct serial mode (USB Dual Port).
 * Called when a device is connected to warn the user if the mode needs fixing.
 * @param {string} serialNumber - The device serial number
 */
async function checkMaestroSerialMode(serialNumber) {
    if (!serialNumber) return;

    // First check if we have a pending power cycle for this device
    const pendingKey = `maestro_power_cycle_pending_${serialNumber}`;
    if (localStorage.getItem(pendingKey) === 'true') {
        showPowerCycleAlert(serialNumber);
        return;
    }

    try {
        const data = await fetchJson(`/api/maestro/device/${encodeURIComponent(serialNumber)}/serial-mode`);

        if (!data.ok) {
            // Serial mode needs fixing
            showSerialModeAlert(serialNumber, data.mode_name, data.message);
        } else {
            // Mode is correct, hide any alerts
            hideSerialModeAlerts();
        }
    } catch (error) {
        console.error('Error checking serial mode:', error);
        // Don't show error to user - this is a non-critical check
    }
}

/**
 * Show the serial mode warning alert.
 */
function showSerialModeAlert(serialNumber, modeName, message) {
    const alert = document.getElementById('maestro-serial-mode-alert');
    const msgEl = document.getElementById('maestro-serial-mode-message');

    if (alert && msgEl) {
        msgEl.innerHTML = `Device is in <strong>${escapeHtml(modeName)}</strong> mode. ` +
            `USB serial commands may not work correctly. Click "Fix Now" to switch to USB Dual Port mode.`;
        alert.style.display = 'flex';
        alert.dataset.serialNumber = serialNumber;
    }

    // Hide power cycle alert if visible
    const powerCycleAlert = document.getElementById('maestro-power-cycle-alert');
    if (powerCycleAlert) powerCycleAlert.style.display = 'none';
}

/**
 * Show the power cycle required alert.
 */
function showPowerCycleAlert(serialNumber) {
    const serialModeAlert = document.getElementById('maestro-serial-mode-alert');
    const powerCycleAlert = document.getElementById('maestro-power-cycle-alert');

    if (serialModeAlert) serialModeAlert.style.display = 'none';
    if (powerCycleAlert) {
        powerCycleAlert.style.display = 'flex';
        powerCycleAlert.dataset.serialNumber = serialNumber;
    }
}

/**
 * Hide all serial mode related alerts.
 */
function hideSerialModeAlerts() {
    const serialModeAlert = document.getElementById('maestro-serial-mode-alert');
    const powerCycleAlert = document.getElementById('maestro-power-cycle-alert');

    if (serialModeAlert) serialModeAlert.style.display = 'none';
    if (powerCycleAlert) powerCycleAlert.style.display = 'none';
}

/**
 * Fix the Maestro serial mode by calling the API.
 * Called when user clicks "Fix Now" button.
 */
async function fixMaestroSerialMode() {
    const alert = document.getElementById('maestro-serial-mode-alert');
    const serialNumber = alert?.dataset.serialNumber || currentDeviceSerial;

    if (!serialNumber) {
        showToast('No device selected', 'error');
        return;
    }

    // Disable the button while processing
    const btn = document.getElementById('maestro-fix-serial-btn');
    if (btn) {
        btn.disabled = true;
        btn.textContent = 'Fixing...';
    }

    try {
        const result = await fetchJson(
            `/api/maestro/device/${encodeURIComponent(serialNumber)}/serial-mode/fix`,
            { method: 'POST' }
        );

        if (result.success) {
            if (result.needs_power_cycle) {
                // Store power cycle pending state
                const pendingKey = `maestro_power_cycle_pending_${serialNumber}`;
                localStorage.setItem(pendingKey, 'true');

                // Show power cycle alert
                showPowerCycleAlert(serialNumber);
                showToast('Serial mode updated. Power cycle the device to apply.', 'info', 5000);
            } else if (result.changed) {
                showToast('Serial mode fixed successfully!', 'success');
                hideSerialModeAlerts();
            } else {
                showToast('Serial mode is already correct.', 'info');
                hideSerialModeAlerts();
            }
        } else {
            showToast('Failed to fix serial mode: ' + (result.error || 'Unknown error'), 'error');
        }
    } catch (error) {
        console.error('Error fixing serial mode:', error);
        showToast('Error fixing serial mode: ' + error.message, 'error');
    } finally {
        // Re-enable button
        if (btn) {
            btn.disabled = false;
            btn.textContent = 'Fix Now';
        }
    }
}

/**
 * Dismiss the serial mode warning alert.
 * Called when user clicks "Dismiss" button.
 */
function dismissSerialModeAlert() {
    const alert = document.getElementById('maestro-serial-mode-alert');
    if (alert) {
        alert.style.display = 'none';
    }
}

/**
 * Confirm that power cycle has been completed and try to reconnect.
 * Called when user clicks "Done - Reconnect" button.
 */
async function confirmPowerCycleComplete() {
    const alert = document.getElementById('maestro-power-cycle-alert');
    const serialNumber = alert?.dataset.serialNumber || currentDeviceSerial;

    // Clear the pending state
    if (serialNumber) {
        const pendingKey = `maestro_power_cycle_pending_${serialNumber}`;
        localStorage.removeItem(pendingKey);
    }

    // Hide the alert
    hideSerialModeAlerts();

    showToast('Reconnecting to device...', 'info');

    // Disconnect current connection
    disconnectMaestro();

    // Wait a moment for device to be ready after power cycle
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Refresh device list and reconnect
    await refreshMaestroDevices();

    // Try to reconnect to the same device by port
    if (selectedMaestroPort) {
        const device = maestroDevices.find(d => d.port === selectedMaestroPort);
        if (device) {
            connectToMaestro(device.port);
        }
    } else if (serialNumber) {
        // Find device by serial number
        const device = maestroDevices.find(d => d.serial_number === serialNumber);
        if (device) {
            connectToMaestro(device.port);
            // Update selector
            const select = document.getElementById('maestro-device-select');
            if (select) select.value = device.port;
        }
    }
}

// ============================================================================
// Maestro Library Management
// ============================================================================

// Library state
let maestroLibrarySequences = [];
let maestroSyncState = null;
let currentEditingSequenceId = null;     // Sequence being edited in recorder
let currentScriptEditorSequenceId = null; // Sequence being edited in script editor

/**
 * Load sequences from the library for the current device.
 */
async function loadMaestroLibrary() {
    if (!currentDeviceSerial) {
        console.log('No device serial, cannot load library');
        return;
    }

    try {
        // Load sequences
        const seqResult = await fetchJson(`/api/maestro/sequences?device_serial=${encodeURIComponent(currentDeviceSerial)}`);
        if (seqResult.success) {
            maestroLibrarySequences = seqResult.sequences || [];
            renderSequenceLibrary();
            updateSyncStatus();
        } else {
            console.error('Failed to load sequences:', seqResult.error);
        }

    } catch (error) {
        console.error('Error loading library:', error);
    }
}

/**
 * Load sync state for the current device.
 */
async function loadSyncState() {
    if (!currentDeviceSerial) return;

    try {
        const result = await fetchJson(`/api/maestro/sync-state/${encodeURIComponent(currentDeviceSerial)}`);
        if (result.success) {
            maestroSyncState = result.state;
            updateSyncStatus();
            updateSubroutineMap();
        }
    } catch (error) {
        console.error('Error loading sync state:', error);
    }
}

/**
 * Update the sync status badge UI.
 */
function updateSyncStatus() {
    const badge = document.getElementById('maestro-sync-status');
    const syncBtn = document.getElementById('maestro-sync-btn');
    if (!badge) return;

    if (!maestroSyncState) {
        // Never synced
        badge.className = 'sync-status sync-status--unknown';
        badge.innerHTML = '<span class="sync-icon">&#9675;</span><span class="sync-text">Not synced</span>';
        if (syncBtn) syncBtn.disabled = maestroLibrarySequences.length === 0;
        return;
    }

    // Check if any sequences have been modified since last sync
    const syncedIds = maestroSyncState.sequence_ids || [];
    const currentIds = maestroLibrarySequences.map(s => s.id);

    const hasChanges =
        currentIds.length !== syncedIds.length ||
        currentIds.some(id => !syncedIds.includes(id)) ||
        maestroLibrarySequences.some(seq => {
            const syncTime = new Date(maestroSyncState.last_sync);
            const modTime = new Date(seq.modified);
            return modTime > syncTime;
        });

    if (hasChanges) {
        badge.className = 'sync-status sync-status--pending';
        const changedCount = maestroLibrarySequences.filter(seq => {
            if (!syncedIds.includes(seq.id)) return true;
            const syncTime = new Date(maestroSyncState.last_sync);
            const modTime = new Date(seq.modified);
            return modTime > syncTime;
        }).length;
        badge.innerHTML = `<span class="sync-icon">&#9888;</span><span class="sync-text">${changedCount} change${changedCount !== 1 ? 's' : ''} pending</span>`;
        if (syncBtn) syncBtn.disabled = false;
    } else {
        badge.className = 'sync-status sync-status--synced';
        const ago = formatTimeAgo(maestroSyncState.last_sync);
        badge.innerHTML = `<span class="sync-icon">&#10003;</span><span class="sync-text">Synced ${ago}</span>`;
        if (syncBtn) syncBtn.disabled = true;
    }
}

/**
 * Format a timestamp as "X ago".
 */
function formatTimeAgo(isoString) {
    const date = new Date(isoString);
    const now = new Date();
    const seconds = Math.floor((now - date) / 1000);

    if (seconds < 60) return 'just now';
    if (seconds < 3600) return `${Math.floor(seconds / 60)} min ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)} hr ago`;
    return `${Math.floor(seconds / 86400)} days ago`;
}

/**
 * Render the sequence library UI.
 */
function renderSequenceLibrary() {
    const container = document.getElementById('maestro-sequence-list');
    if (!container) return;

    if (maestroLibrarySequences.length === 0) {
        container.innerHTML = '<div class="empty-state">No sequences in library. Create a new sequence or import from MCC backup.</div>';
        // Hide the old subroutine map section if it exists
        const subMapEl = document.getElementById('maestro-subroutine-map');
        if (subMapEl) subMapEl.style.display = 'none';
        return;
    }

    const syncedIds = maestroSyncState?.sequence_ids || [];
    const syncTime = maestroSyncState?.last_sync ? new Date(maestroSyncState.last_sync) : null;

    container.innerHTML = maestroLibrarySequences.map((seq, index) => {
        // Determine status
        let statusClass = 'sequence-item__status--new';
        let statusText = 'NEW';

        if (syncedIds.includes(seq.id)) {
            const modTime = new Date(seq.modified);
            if (syncTime && modTime > syncTime) {
                statusClass = 'sequence-item__status--modified';
                statusText = 'MODIFIED';
            } else {
                statusClass = 'sequence-item__status--synced';
                statusText = '&#10003;';
            }
        }

        // Calculate total duration
        const totalDuration = (seq.frames || []).reduce((sum, f) => sum + (f.duration || 0), 0);
        const durationStr = totalDuration >= 1000 ? `${(totalDuration / 1000).toFixed(1)}s` : `${totalDuration}ms`;

        return `
            <div class="sequence-item" draggable="true" data-id="${seq.id}" data-index="${index}">
                <span class="sequence-item__drag-handle" title="Drag to reorder">&#9776;</span>
                <span class="sequence-item__index" title="Subroutine index when synced to device">#${index}</span>
                <div class="sequence-item__info">
                    <div class="sequence-item__name">${escapeHtml(seq.name)}</div>
                    <div class="sequence-item__meta">${seq.frames?.length || 0} frames &bull; ${durationStr}</div>
                </div>
                <span class="sequence-item__status ${statusClass}">${statusText}</span>
                <div class="sequence-item__actions">
                    <button class="btn btn-xs btn-primary" onclick="event.stopPropagation(); maestroRunLibrarySequence('${seq.id}')" title="Run via real-time servo commands">&#9654; Run</button>
                    <button class="btn btn-xs btn-secondary" onclick="event.stopPropagation(); maestroEditSequence('${seq.id}')" title="Edit in recorder and script editor">&#9998; Edit</button>
                    <button class="btn btn-xs btn-danger" onclick="event.stopPropagation(); maestroDeleteLibrarySequence('${seq.id}')" title="Delete sequence">&#10005;</button>
                </div>
            </div>
        `;
    }).join('');

    // Hide the old separate subroutine map section (reordering is now integrated into the list)
    const subMapEl = document.getElementById('maestro-subroutine-map');
    if (subMapEl) subMapEl.style.display = 'none';

    // Setup drag-and-drop reordering directly on the sequence list
    setupLibraryReordering(container);
}

/**
 * Update the subroutine map display.
 * Shows sequence order which determines subroutine index when synced to device.
 */
function updateSubroutineMap() {
    const container = document.getElementById('maestro-subroutine-list');
    if (!container) return;

    if (maestroLibrarySequences.length === 0) {
        container.innerHTML = '<div class="empty-state">No sequences</div>';
        return;
    }

    container.innerHTML = maestroLibrarySequences.map((seq, index) => `
        <div class="subroutine-item" draggable="true" data-index="${index}" data-id="${seq.id}">
            <span class="subroutine-item__index">${index}</span>
            <span class="subroutine-item__name">${escapeHtml(seq.name)}</span>
            <span class="subroutine-item__drag-handle">&#9776;</span>
        </div>
    `).join('');

    // Add drag-and-drop handlers for reordering
    setupSequenceReordering(container);
}

/**
 * Setup drag-and-drop reordering for sequences.
 */
/**
 * Setup sequence reordering with event delegation (prevents listener accumulation).
 * Uses container-level listeners instead of per-item listeners.
 */
function setupSequenceReordering(container) {
    // Remove old delegation listeners if they exist
    if (container._seqDragStartHandler) {
        container.removeEventListener('dragstart', container._seqDragStartHandler);
        container.removeEventListener('dragend', container._seqDragEndHandler);
        container.removeEventListener('dragover', container._seqDragOverHandler);
    }

    let draggedItem = null;

    // Delegated dragstart handler
    container._seqDragStartHandler = (e) => {
        const item = e.target.closest('.subroutine-item');
        if (!item) return;
        draggedItem = item;
        item.classList.add('dragging');
        e.dataTransfer.effectAllowed = 'move';
    };

    // Delegated dragend handler
    container._seqDragEndHandler = () => {
        if (draggedItem) {
            draggedItem.classList.remove('dragging');
            draggedItem = null;
            saveSequenceOrder(container);
        }
    };

    // Delegated dragover handler
    container._seqDragOverHandler = (e) => {
        e.preventDefault();
        const item = e.target.closest('.subroutine-item');
        if (!item || !draggedItem || draggedItem === item) return;

        const rect = item.getBoundingClientRect();
        const midY = rect.top + rect.height / 2;

        if (e.clientY < midY) {
            container.insertBefore(draggedItem, item);
        } else {
            container.insertBefore(draggedItem, item.nextSibling);
        }
    };

    // Attach delegated listeners to container
    container.addEventListener('dragstart', container._seqDragStartHandler);
    container.addEventListener('dragend', container._seqDragEndHandler);
    container.addEventListener('dragover', container._seqDragOverHandler);
}
/**
 * Setup library reordering with event delegation (prevents listener accumulation).
 * Uses container-level listeners instead of per-item listeners.
 */
function setupLibraryReordering(container) {
    // Remove old delegation listeners if they exist
    if (container._dragStartHandler) {
        container.removeEventListener('dragstart', container._dragStartHandler);
        container.removeEventListener('dragend', container._dragEndHandler);
        container.removeEventListener('dragover', container._dragOverHandler);
        container.removeEventListener('dragenter', container._dragEnterHandler);
        container.removeEventListener('dragleave', container._dragLeaveHandler);
        container.removeEventListener('drop', container._dropHandler);
    }

    let draggedItem = null;

    // Delegated dragstart handler
    container._dragStartHandler = (e) => {
        const item = e.target.closest('.sequence-item');
        if (!item) return;
        draggedItem = item;
        item.classList.add('dragging');
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/plain', item.dataset.id);
    };

    // Delegated dragend handler
    container._dragEndHandler = () => {
        if (draggedItem) {
            draggedItem.classList.remove('dragging');
            draggedItem = null;
            saveLibraryOrder(container);
        }
    };

    // Delegated dragover handler
    container._dragOverHandler = (e) => {
        e.preventDefault();
        const item = e.target.closest('.sequence-item');
        if (!item || !draggedItem || draggedItem === item) return;

        const rect = item.getBoundingClientRect();
        const midY = rect.top + rect.height / 2;

        if (e.clientY < midY) {
            container.insertBefore(draggedItem, item);
        } else {
            container.insertBefore(draggedItem, item.nextSibling);
        }
    };

    // Delegated dragenter handler
    container._dragEnterHandler = (e) => {
        e.preventDefault();
        const item = e.target.closest('.sequence-item');
        if (item && draggedItem && draggedItem !== item) {
            item.classList.add('drag-over');
        }
    };

    // Delegated dragleave handler
    container._dragLeaveHandler = (e) => {
        const item = e.target.closest('.sequence-item');
        if (item) {
            item.classList.remove('drag-over');
        }
    };

    // Delegated drop handler
    container._dropHandler = (e) => {
        const item = e.target.closest('.sequence-item');
        if (item) {
            item.classList.remove('drag-over');
        }
    };

    // Attach delegated listeners to container
    container.addEventListener('dragstart', container._dragStartHandler);
    container.addEventListener('dragend', container._dragEndHandler);
    container.addEventListener('dragover', container._dragOverHandler);
    container.addEventListener('dragenter', container._dragEnterHandler);
    container.addEventListener('dragleave', container._dragLeaveHandler);
    container.addEventListener('drop', container._dropHandler);
}

/**
 * Save the new sequence order after drag-and-drop in the library.
 */
async function saveLibraryOrder(container) {
    const items = container.querySelectorAll('.sequence-item');
    const newOrder = Array.from(items).map(item => item.dataset.id);

    // Reorder the local array
    const reordered = newOrder.map(id => maestroLibrarySequences.find(s => s.id === id)).filter(Boolean);
    if (reordered.length !== maestroLibrarySequences.length) return;

    maestroLibrarySequences = reordered;

    // Update indices display in the library list
    items.forEach((item, index) => {
        const indexEl = item.querySelector('.sequence-item__index');
        if (indexEl) indexEl.textContent = `#${index}`;
        item.dataset.index = index;
    });

    // Mark as needing sync
    updateSyncStatus();
    showToast('Sequence order changed. Sync to device to apply.', 'info');
}

/**
 * Save the new sequence order after drag-and-drop (legacy subroutine map).
 */
async function saveSequenceOrder(container) {
    const items = container.querySelectorAll('.subroutine-item');
    const newOrder = Array.from(items).map(item => item.dataset.id);

    // Reorder the local array
    const reordered = newOrder.map(id => maestroLibrarySequences.find(s => s.id === id)).filter(Boolean);
    if (reordered.length !== maestroLibrarySequences.length) return;

    maestroLibrarySequences = reordered;

    // Update indices display
    items.forEach((item, index) => {
        const indexEl = item.querySelector('.subroutine-item__index');
        if (indexEl) indexEl.textContent = index;
    });

    // Mark as needing sync
    updateSyncStatus();
    showToast('Sequence order changed. Sync to device to apply.', 'info');
}

/**
 * Create a new sequence in the library.
 */
async function maestroCreateSequence() {
    const name = prompt('Enter sequence name:', `Sequence ${maestroLibrarySequences.length}`);
    if (!name) return;

    try {
        const result = await fetchJson('/api/maestro/sequences', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                name: name,
                device_serial: currentDeviceSerial,
                frames: []
            })
        });

        if (result.success) {
            showToast('Sequence created', 'success');
            await loadMaestroLibrary();
            // Open editor for new sequence
            maestroEditSequence(result.sequence.id);
        } else {
            showToast('Failed to create sequence: ' + result.error, 'error');
        }
    } catch (error) {
        showToast('Error creating sequence: ' + error.message, 'error');
    }
}

/**
 * Edit a sequence from the library.
 * Loads into BOTH the sequence recorder and the script editor.
 */
async function maestroEditSequence(sequenceId) {
    const seq = maestroLibrarySequences.find(s => s.id === sequenceId);
    if (!seq) {
        showToast('Sequence not found', 'error');
        return;
    }

    // Validate the sequence can be edited in the recorder
    const validation = validateSequenceForRecorder(seq);
    if (!validation.valid) {
        // Show error message and suggest using script editor
        showSequenceParseError(seq, validation.errors);
        return;
    }

    // Track editing in both recorder and script editor
    currentEditingSequenceId = sequenceId;
    currentScriptEditorSequenceId = sequenceId;

    // === Load into Sequence Recorder ===
    // Convert frames from library format to recorder format
    // Use 'duration' property consistently (matches recorder format and updateSequenceDisplay)
    maestroSequenceFrames = (seq.frames || []).map(f => ({
        duration: f.duration,
        positions: f.positions || {}
    }));

    // Update the sequence name input if it exists
    const nameInput = document.getElementById('maestro-sequence-name');
    if (nameInput) {
        nameInput.value = seq.name || '';
    }

    updateSequenceDisplay();

    // Update the recorder edit indicator
    updateRecorderEditIndicator(seq.name);

    // === Load into Script Editor ===
    const script = generateSequenceScript(seq);
    const editor = document.getElementById('maestro-script-editor');
    if (editor) {
        editor.value = script;
    }

    // Update the editing indicator
    updateScriptEditorIndicator(seq.name);

    showToast(`Editing: ${seq.name}`, 'info');

    // Scroll to sequence recorder
    const recorderSection = document.getElementById('maestro-sequence-section');
    if (recorderSection) {
        recorderSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
}

/**
 * Generate script code for a sequence.
 * @param {Object} seq - Sequence object
 * @param {number|null} index - Optional subroutine index to include in header
 * @returns {string} - Maestro script code
 */
function generateSequenceScript(seq, index = null) {
    const subName = sanitizeSubroutineName(seq.name);
    let script = '';

    // Header varies based on whether we have an index
    if (index !== null) {
        script += `# ${index}: ${seq.name}\n`;
    } else {
        script += `# ${seq.name}\n`;
        script += `# ${seq.frames?.length || 0} frames\n\n`;
    }

    script += `sub ${subName}\n`;

    (seq.frames || []).forEach((frame, frameIdx) => {
        script += `  # Frame ${frameIdx + 1}${frame.name ? ` - ${frame.name}` : ''}\n`;

        const positions = frame.positions || {};
        Object.entries(positions).forEach(([channel, pos]) => {
            const target = typeof pos === 'object' ? pos.target : pos;
            script += `  ${target} ${channel} servo\n`;
        });

        script += `  ${frame.duration || 500} delay\n\n`;
    });

    script += `  return\n`;
    return script;
}

/**
 * Update the script editor "Editing:" indicator.
 * @param {string|null} name - Name to display, or null to hide
 */
function updateScriptEditorIndicator(name) {
    const indicator = document.getElementById('maestro-editing-indicator');
    const nameEl = document.getElementById('maestro-editing-name');

    if (indicator && nameEl) {
        if (name) {
            nameEl.textContent = name;
            indicator.style.display = 'inline-flex';
        } else {
            indicator.style.display = 'none';
        }
    }
}

/**
 * Validate a sequence can be edited in the visual recorder.
 * @param {Object} seq - Sequence object from library
 * @returns {Object} - { valid: boolean, errors: string[] }
 */
function validateSequenceForRecorder(seq) {
    const errors = [];

    if (!seq.frames || !Array.isArray(seq.frames)) {
        errors.push('Sequence has no frames array');
        return { valid: false, errors };
    }

    for (let i = 0; i < seq.frames.length; i++) {
        const frame = seq.frames[i];

        // Check for valid duration
        if (typeof frame.duration !== 'number' || frame.duration < 0) {
            errors.push(`Frame ${i + 1}: Invalid duration (${frame.duration})`);
        }

        // Check for valid positions
        if (frame.positions && typeof frame.positions === 'object') {
            for (const [channel, pos] of Object.entries(frame.positions)) {
                // Positions should be numbers (quarter-microseconds)
                if (typeof pos !== 'number' && typeof pos !== 'object') {
                    errors.push(`Frame ${i + 1}, Ch${channel}: Invalid position data`);
                }
                // Handle both simple number and object with target
                const target = typeof pos === 'object' ? pos.target : pos;
                if (typeof target !== 'number') {
                    errors.push(`Frame ${i + 1}, Ch${channel}: Position target is not a number`);
                }
            }
        } else if (frame.positions !== undefined && !frame.positions) {
            // Empty positions is OK
        } else if (typeof frame.positions !== 'object') {
            errors.push(`Frame ${i + 1}: Positions is not an object`);
        }
    }

    return { valid: errors.length === 0, errors };
}

/**
 * Show error dialog when a sequence cannot be edited in the recorder.
 */
function showSequenceParseError(seq, errors) {
    const errorList = errors.slice(0, 5).join('\n  - ');
    const moreErrors = errors.length > 5 ? `\n  ... and ${errors.length - 5} more issues` : '';

    const message = `Cannot edit "${seq.name}" in the visual recorder.\n\n` +
        `Issues found:\n  - ${errorList}${moreErrors}\n\n` +
        `This sequence may have been created with advanced scripting features. ` +
        `Would you like to view it as a script instead?`;

    if (confirm(message)) {
        // Convert sequence to script and show in editor
        maestroViewSequenceAsScript(seq.id);
    }
}

/**
 * View a single sequence as script code (script-editor-only).
 * Used when sequence cannot be edited in visual recorder.
 */
function maestroViewSequenceAsScript(sequenceId) {
    const seq = maestroLibrarySequences.find(s => s.id === sequenceId);
    if (!seq) {
        showToast('Sequence not found', 'error');
        return;
    }

    // Track that we're editing this sequence in script editor
    currentScriptEditorSequenceId = sequenceId;

    // Generate script for this single sequence
    const script = generateSequenceScript(seq);

    // Put script in the editor
    const editor = document.getElementById('maestro-script-editor');
    if (editor) {
        editor.value = script;
        updateScriptEditorIndicator(seq.name);
        showToast(`Loaded "${seq.name}" as script`, 'info');

        // Scroll to script editor
        const scriptSection = document.getElementById('maestro-script-section');
        if (scriptSection) {
            scriptSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    } else {
        showToast('Script editor not found', 'error');
    }
}

/**
 * Save changes from script editor to the current sequence.
 * Parses the script and updates the sequence frames.
 */
async function maestroSaveCurrentScript() {
    if (!currentScriptEditorSequenceId) {
        showToast('No sequence is being edited', 'warning');
        return;
    }

    const editor = document.getElementById('maestro-script-editor');
    if (!editor) return;

    const scriptSource = editor.value.trim();
    if (!scriptSource) {
        showToast('Script is empty', 'error');
        return;
    }

    // Parse the script back into frames
    const parsed = parseScriptToFrames(scriptSource);
    if (parsed.errors.length > 0) {
        showToast(`Parse errors:\n${parsed.errors.join('\n')}`, 'error', 5000);
        return;
    }

    try {
        const result = await fetchJson(`/api/maestro/sequences/${currentScriptEditorSequenceId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ frames: parsed.frames })
        });

        if (result.success) {
            showToast('Sequence saved', 'success');
            await loadMaestroLibrary();

            // Also update recorder if same sequence is loaded there
            if (currentEditingSequenceId === currentScriptEditorSequenceId) {
                maestroSequenceFrames = parsed.frames.map(f => ({
                    duration: f.duration,
                    positions: f.positions || {}
                }));
                updateSequenceDisplay();
            }
        } else {
            showToast('Failed to save: ' + result.error, 'error');
        }
    } catch (error) {
        showToast('Error saving: ' + error.message, 'error');
    }
}

/**
 * Parse script code back into frame objects.
 * @param {string} script - Maestro script code
 * @returns {Object} - { frames: [], errors: [] }
 */
function parseScriptToFrames(script) {
    const frames = [];
    const errors = [];
    let currentFrame = null;

    const lines = script.split('\n');
    for (let lineNum = 0; lineNum < lines.length; lineNum++) {
        const line = lines[lineNum].trim();

        // Skip comments and empty lines
        if (!line || line.startsWith('#')) continue;

        // Skip subroutine definition
        if (line.startsWith('sub ')) continue;

        // Skip return statement
        if (line === 'return') continue;

        // Parse servo command: <value> <channel> servo
        const servoMatch = line.match(/^(\d+)\s+(\d+)\s+servo$/i);
        if (servoMatch) {
            if (!currentFrame) {
                currentFrame = { positions: {}, duration: 500 };
            }
            const value = parseInt(servoMatch[1]);
            const channel = servoMatch[2];
            currentFrame.positions[channel] = value;
            continue;
        }

        // Parse delay command: <ms> delay
        const delayMatch = line.match(/^(\d+)\s+delay$/i);
        if (delayMatch) {
            if (!currentFrame) {
                currentFrame = { positions: {}, duration: 500 };
            }
            currentFrame.duration = parseInt(delayMatch[1]);
            // End of frame
            frames.push(currentFrame);
            currentFrame = null;
            continue;
        }

        // Unknown command - could be advanced scripting
        if (!line.startsWith('begin') && !line.startsWith('repeat') && !line.startsWith('end')) {
            errors.push(`Line ${lineNum + 1}: Unknown command: ${line.substring(0, 30)}...`);
        }
    }

    // If we have an incomplete frame (no delay), add it
    if (currentFrame && Object.keys(currentFrame.positions).length > 0) {
        frames.push(currentFrame);
    }

    return { frames, errors };
}

/**
 * Delete the current sequence from the library (script editor action).
 * Delegates to maestroDeleteLibrarySequence which handles all cleanup.
 */
async function maestroDeleteCurrentScript() {
    if (!currentScriptEditorSequenceId) {
        showToast('No sequence is being edited', 'warning');
        return;
    }

    // Delegate to shared delete function (handles confirmation, cleanup, etc.)
    await maestroDeleteLibrarySequence(currentScriptEditorSequenceId);
}

/**
 * Clear the script editor and stop editing.
 */
function maestroClearScriptEditor() {
    const editor = document.getElementById('maestro-script-editor');
    if (editor) {
        editor.value = '';
    }

    currentScriptEditorSequenceId = null;
    updateScriptEditorIndicator(null);

    // Also clear recorder if editing same sequence
    if (currentEditingSequenceId) {
        // Use consolidated clear function (handles selectedFrameIndex, frame editor, etc.)
        maestroClearRecorder({ stopPlayback: false });
    }
}

/**
 * Sanitize a sequence name for use as a subroutine name.
 */
function sanitizeSubroutineName(name) {
    // Replace spaces and special chars with underscores
    return (name || 'Sequence')
        .replace(/[^a-zA-Z0-9_]/g, '_')
        .replace(/_+/g, '_')
        .replace(/^_|_$/g, '');
}

/**
 * View all library sequences as a compiled script.
 * This generates a full MCC-style script with all sequences as subroutines.
 */
function maestroViewAllAsScript() {
    if (maestroLibrarySequences.length === 0) {
        showToast('No sequences in library', 'warning');
        return;
    }

    // Generate full script with all sequences
    let script = `# Maestro Script - All Sequences\n`;
    script += `# Generated from library (${maestroLibrarySequences.length} sequences)\n`;
    script += `# Subroutine indices match library order\n\n`;

    // Generate each sequence as a subroutine using shared function
    maestroLibrarySequences.forEach((seq, index) => {
        script += generateSequenceScript(seq, index) + '\n';
    });

    // Show in modal preview (read-only, with copy/download)
    showScriptPreviewModal(
        `Full Library Script (${maestroLibrarySequences.length} sequences)`,
        script
    );
}

/**
 * Save current sequence recorder frames back to the library.
 */
async function maestroSaveSequenceToLibrary() {
    if (!currentEditingSequenceId) {
        // Create new sequence
        const name = prompt('Enter sequence name:', `Sequence ${maestroLibrarySequences.length}`);
        if (!name) return;

        try {
            const frames = maestroSequenceFrames.map(f => ({
                duration: f.duration,
                positions: f.positions
            }));

            const result = await fetchJson('/api/maestro/sequences', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    name: name,
                    device_serial: currentDeviceSerial,
                    frames: frames
                })
            });

            if (result.success) {
                showToast('Sequence saved to library', 'success');
                currentEditingSequenceId = result.sequence.id;
                await loadMaestroLibrary();
            } else {
                showToast('Failed to save: ' + result.error, 'error');
            }
        } catch (error) {
            showToast('Error saving: ' + error.message, 'error');
        }
    } else {
        // Update existing sequence
        try {
            const frames = maestroSequenceFrames.map(f => ({
                duration: f.duration,
                positions: f.positions
            }));

            const result = await fetchJson(`/api/maestro/sequences/${currentEditingSequenceId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ frames: frames })
            });

            if (result.success) {
                showToast('Sequence updated', 'success');
                await loadMaestroLibrary();
            } else {
                showToast('Failed to update: ' + result.error, 'error');
            }
        } catch (error) {
            showToast('Error updating: ' + error.message, 'error');
        }
    }
}

/**
 * Delete a sequence from the library.
 */
async function maestroDeleteLibrarySequence(sequenceId) {
    const seq = maestroLibrarySequences.find(s => s.id === sequenceId);
    const seqName = seq?.name || sequenceId;
    const seqIndex = maestroLibrarySequences.findIndex(s => s.id === sequenceId);

    // Build confirmation message with reorder warning if applicable
    let confirmMsg = `Delete sequence "${seqName}"?`;
    if (seqIndex >= 0 && seqIndex < maestroLibrarySequences.length - 1) {
        confirmMsg += `\n\nNote: This will change subroutine indices for sequences after it.`;
    }

    if (!confirm(confirmMsg)) return;

    try {
        const result = await fetchJson(`/api/maestro/sequences/${sequenceId}`, {
            method: 'DELETE'
        });

        if (result.success) {
            showToast('Sequence deleted', 'success');

            // Clear sequence recorder if this sequence was being edited
            if (currentEditingSequenceId === sequenceId) {
                currentEditingSequenceId = null;
                maestroSequenceFrames = [];
                updateSequenceDisplay();
            }

            // Clear script editor if this sequence was being edited there
            if (currentScriptEditorSequenceId === sequenceId) {
                currentScriptEditorSequenceId = null;
                updateScriptEditorIndicator(null);
                const editor = document.getElementById('maestro-script-editor');
                if (editor) editor.value = '';
            }

            await loadMaestroLibrary();
        } else {
            showToast('Failed to delete: ' + result.error, 'error');
        }
    } catch (error) {
        showToast('Error deleting: ' + error.message, 'error');
    }
}

/**
 * Run a library sequence via real-time servo commands.
 */
async function maestroRunLibrarySequence(sequenceId) {
    const seq = maestroLibrarySequences.find(s => s.id === sequenceId);
    if (!seq) {
        showToast('Sequence not found', 'error');
        return;
    }

    // Load into recorder and play
    maestroSequenceFrames = (seq.frames || []).map(f => ({
        duration: f.duration,
        positions: f.positions || {}
    }));

    updateSequenceDisplay();
    maestroPlaySequence();
}

/**
 * Test a subroutine by running it on the device.
 * This requires the script to be synced to the device first.
 */
async function maestroTestSubroutine(index) {
    if (!selectedMaestroPort) {
        showToast('No device connected', 'error');
        return;
    }

    if (!maestroSyncState) {
        showToast('Device not synced. Sync first to run subroutines.', 'warning');
        return;
    }

    try {
        const result = await fetchJson(`/api/maestro/device/${encodeURIComponent(selectedMaestroPort)}/script/run`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ subroutine: index })
        });

        if (result.success) {
            showToast(`Running subroutine ${index}`, 'success');
        } else {
            showToast('Failed to run: ' + result.error, 'error');
        }
    } catch (error) {
        showToast('Error: ' + error.message, 'error');
    }
}

/**
 * Sync library sequences to device.
 *
 * This generates an MCC-style script from all sequences,
 * compiles it to bytecode, and uploads to the device.
 */
async function maestroSyncToDevice() {
    if (!selectedMaestroPort || !currentDeviceSerial) {
        showToast('No device connected', 'error');
        return;
    }

    if (maestroLibrarySequences.length === 0) {
        showToast('No sequences to sync', 'warning');
        return;
    }

    // Confirm sync
    const seqCount = maestroLibrarySequences.length;
    if (!confirm(`Sync ${seqCount} sequence${seqCount !== 1 ? 's' : ''} to device?\n\nThis will replace any existing script on the device.`)) {
        return;
    }

    // Update UI to show syncing
    const syncBtn = document.getElementById('maestro-sync-btn');
    const syncStatus = document.getElementById('maestro-sync-status');
    if (syncBtn) {
        syncBtn.disabled = true;
        syncBtn.innerHTML = '<span>&#8635;</span> Syncing...';
    }
    if (syncStatus) {
        syncStatus.className = 'sync-status sync-status--pending';
        syncStatus.innerHTML = '<span class="sync-icon">&#8635;</span><span class="sync-text">Syncing...</span>';
    }

    try {
        const result = await fetchJson('/api/maestro/sync', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                device_serial: currentDeviceSerial,
                port: selectedMaestroPort
            })
        });

        if (result.success) {
            showToast(`Synced ${seqCount} sequences (${result.bytecode_size} bytes)`, 'success');

            // Reload sync state
            await loadSyncState();
        } else {
            // Show errors
            if (result.errors && result.errors.length > 0) {
                showToast('Compilation errors:\n' + result.errors.join('\n'), 'error', 10000);
            } else {
                showToast('Sync failed: ' + (result.error || 'Unknown error'), 'error');
            }
        }
    } catch (error) {
        showToast('Error syncing: ' + error.message, 'error');
    } finally {
        // Restore button
        if (syncBtn) {
            syncBtn.disabled = false;
            syncBtn.innerHTML = '<span>&#8593;</span> Sync to Device';
        }
        // Update status will be handled by loadSyncState
        updateSyncStatus();
    }
}

// ============================================================================
// MCC Import/Export
// ============================================================================

/**
 * Export device config and library in MCC-compatible format.
 * This creates a file compatible with Maestro Control Center.
 */
async function maestroExportConfig() {
    if (!selectedMaestroPort || !currentDeviceSerial) {
        showToast('No device connected', 'error');
        return;
    }

    try {
        const result = await fetchJson(`/api/maestro/export-mcc/${encodeURIComponent(currentDeviceSerial)}/${encodeURIComponent(selectedMaestroPort)}`);
        if (result.success) {
            const blob = new Blob([result.xml], { type: 'text/xml' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `maestro_settings_${currentDeviceSerial}_${new Date().toISOString().slice(0,10)}.txt`;
            a.click();
            URL.revokeObjectURL(url);
            showToast('Settings exported', 'success');
        } else {
            showToast('Export failed: ' + result.error, 'error');
        }
    } catch (error) {
        showToast('Error exporting: ' + error.message, 'error');
    }
}

// ============================================================================
// Sequence Recorder to Library
// ============================================================================

/**
 * Save current sequence from recorder to the library.
 */
/**
 * Generate a unique copy name by appending (2), (3), etc.
 * @param {string} baseName - The original name
 * @returns {string} - A unique name not in the library
 */
function generateUniqueCopyName(baseName) {
    let counter = 2;
    let candidate = `${baseName} (${counter})`;
    while (maestroLibrarySequences.some(s => s.name === candidate)) {
        counter++;
        candidate = `${baseName} (${counter})`;
    }
    return candidate;
}

/**
 * Update an existing sequence in the library.
 * @param {string} sequenceId - The sequence ID to update
 * @param {Object} updates - Fields to update (name, frames)
 * @returns {Promise<boolean>} - Success status
 */
async function updateSequenceInLibrary(sequenceId, updates) {
    try {
        const result = await fetchJson(`/api/maestro/sequences/${sequenceId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(updates)
        });

        if (result.success) {
            return true;
        } else {
            showToast('Update failed: ' + result.error, 'error');
            return false;
        }
    } catch (error) {
        showToast('Error updating: ' + error.message, 'error');
        return false;
    }
}

/**
 * Create a new sequence in the library.
 * @param {string} name - Sequence name
 * @param {Array} frames - Array of frame objects
 * @returns {Promise<Object|null>} - Created sequence or null on failure
 */
async function createSequenceInLibrary(name, frames) {
    try {
        const result = await fetchJson('/api/maestro/sequences', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                name: name,
                device_serial: currentDeviceSerial,
                frames: frames
            })
        });

        if (result.success) {
            return result.sequence;
        } else {
            showToast('Save failed: ' + result.error, 'error');
            return null;
        }
    } catch (error) {
        showToast('Error saving: ' + error.message, 'error');
        return null;
    }
}

/**
 * Save current sequence from recorder to the library.
 * Smart save logic:
 * - If editing existing sequence: UPDATE it
 * - If new with name collision: PROMPT user
 * - If new with unique name: CREATE it
 */
async function maestroSaveToLibrary() {
    if (!currentDeviceSerial) {
        showToast('Connect to a device first', 'error');
        return;
    }

    if (maestroSequenceFrames.length === 0) {
        showToast('No frames recorded', 'error');
        return;
    }

    const nameInput = document.getElementById('maestro-sequence-name');
    const name = nameInput ? nameInput.value.trim() : '';

    if (!name) {
        showToast('Please enter a sequence name', 'error');
        if (nameInput) nameInput.focus();
        return;
    }

    // Convert recorded frames to library format
    const frames = maestroSequenceFrames.map(frame => ({
        duration: frame.duration,
        positions: frame.positions
    }));

    // CASE 1: Editing an existing sequence - UPDATE it
    if (currentEditingSequenceId) {
        const existingSeq = maestroLibrarySequences.find(s => s.id === currentEditingSequenceId);

        // Check if name changed and collides with ANOTHER sequence
        if (existingSeq && existingSeq.name !== name) {
            const collision = maestroLibrarySequences.find(
                s => s.name === name && s.id !== currentEditingSequenceId
            );
            if (collision) {
                showToast(`Name "${name}" is already used by another sequence`, 'error');
                return;
            }
        }

        // Update the existing sequence
        const success = await updateSequenceInLibrary(currentEditingSequenceId, { name, frames });
        if (success) {
            showToast(`Sequence "${name}" updated`, 'success');
            await loadMaestroLibrary();
            updateRecorderEditIndicator(name);  // Keep edit state

            // Also update script editor if same sequence
            if (currentScriptEditorSequenceId === currentEditingSequenceId) {
                const seq = { name, frames };
                const script = generateSequenceScript(seq);
                const editor = document.getElementById('maestro-script-editor');
                if (editor) editor.value = script;
                updateScriptEditorIndicator(name);
            }
        }
        return;
    }

    // CASE 2: Creating new - check for name collision
    const existingByName = maestroLibrarySequences.find(s => s.name === name);
    if (existingByName) {
        const frameCount = existingByName.frames?.length || 0;
        const choice = await showSaveCollisionModal(name, frameCount);

        if (choice === 'update') {
            // Update the existing sequence
            const success = await updateSequenceInLibrary(existingByName.id, { frames });
            if (success) {
                showToast(`Sequence "${name}" updated`, 'success');
                // Set edit state to this sequence
                currentEditingSequenceId = existingByName.id;
                await loadMaestroLibrary();
                updateRecorderEditIndicator(name);
            }
            return;
        } else if (choice === 'copy') {
            // Create with unique name
            const uniqueName = generateUniqueCopyName(name);
            const created = await createSequenceInLibrary(uniqueName, frames);
            if (created) {
                showToast(`Sequence "${uniqueName}" created`, 'success');
                if (nameInput) nameInput.value = uniqueName;
                // Set edit state to new sequence
                currentEditingSequenceId = created.id;
                await loadMaestroLibrary();
                updateRecorderEditIndicator(uniqueName);
            }
            return;
        } else {
            // Cancelled
            return;
        }
    }

    // CASE 3: New sequence with unique name - CREATE it
    const created = await createSequenceInLibrary(name, frames);
    if (created) {
        showToast(`Sequence "${name}" saved to library`, 'success');
        // Set edit state to new sequence
        currentEditingSequenceId = created.id;
        await loadMaestroLibrary();
        updateRecorderEditIndicator(name);
    }
}

/**
 * Update the recorder edit mode indicator.
 * @param {string|null} name - Sequence name being edited, or null for new
 */
function updateRecorderEditIndicator(name) {
    const indicator = document.getElementById('maestro-recorder-indicator');
    if (!indicator) return;

    if (name) {
        indicator.className = 'maestro-edit-indicator';
        indicator.innerHTML = `
            <span class="maestro-edit-indicator__label">Editing:</span>
            <span class="maestro-edit-indicator__name">${escapeHtml(name)}</span>
        `;
    } else {
        indicator.className = 'maestro-edit-indicator maestro-edit-indicator--new';
        indicator.innerHTML = `
            <span class="maestro-edit-indicator__name">New Sequence</span>
        `;
    }
}

/**
 * Clear the recorder to start a new sequence.
 */
function maestroClearRecorderForNew() {
    maestroClearRecorder({ notify: true });
}

/**
 * Import config from file (JSON or MCC XML).
 */
async function maestroImportConfig(input) {
    const file = input.files[0];
    if (!file) return;

    // Validate file size (max 10MB to prevent DoS)
    const MAX_IMPORT_SIZE = 10 * 1024 * 1024;
    if (file.size > MAX_IMPORT_SIZE) {
        showToast('File too large (max 10MB)', 'error');
        input.value = '';
        return;
    }

    // Reset input so same file can be selected again
    input.value = '';

    if (!currentDeviceSerial) {
        showToast('Connect to a device first', 'error');
        return;
    }

    try {
        const content = await file.text();

        // Detect format by content
        const isMCC = content.trim().startsWith('<') || content.includes('<UscSettings');

        if (isMCC) {
            // Check if there are existing sequences - warn user about overwrite
            const existingCount = maestroLibrarySequences.length;
            if (existingCount > 0) {
                const confirmed = await showImportWarningModal(existingCount);
                if (!confirmed) {
                    showToast('Import cancelled', 'info');
                    return;
                }
            }

            // Import MCC XML (backend will clear existing sequences first)
            const result = await fetchJson('/api/maestro/import-mcc', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    xml: content,
                    device_serial: currentDeviceSerial
                })
            });

            if (result.success) {
                const imp = result.imported;
                let message = `Imported: ${imp.sequences} sequences`;
                if (imp.scripts > 0) {
                    message += `, ${imp.scripts} scripts`;
                }

                // Handle channel configs if present
                if (result.channels && result.channels.length > 0) {
                    const channelCount = result.channels.length;
                    message += `, ${channelCount} channel configs`;

                    // Apply channel configs to in-memory state
                    applyImportedChannelConfigs(result.channels);
                }

                // Clear editing state since library was replaced
                currentEditingSequenceId = null;
                currentScriptEditorSequenceId = null;
                updateRecorderEditIndicator(null);
                updateScriptEditorIndicator(null);
                maestroClearScriptEditor();

                showToast(message, 'success');
                await loadMaestroLibrary();
            } else {
                showToast('Import failed: ' + result.error, 'error');
            }
        } else {
            // Import JSON (existing functionality)
            const config = JSON.parse(content);
            const result = await fetchJson(`/api/maestro/device/${encodeURIComponent(selectedMaestroPort)}/import`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(config)
            });

            if (result.success) {
                showToast('Config imported. Reload servos to see changes.', 'success');
                await loadMaestroChannelConfig();
            } else {
                showToast('Import failed: ' + result.error, 'error');
            }
        }
    } catch (error) {
        showToast('Error importing: ' + error.message, 'error');
    }
}

/**
 * Show/hide library section based on device connection.
 */
function updateLibraryVisibility(show) {
    const section = document.getElementById('maestro-library-section');
    const configActions = document.getElementById('maestro-config-actions');

    if (section) section.style.display = show ? 'block' : 'none';
    if (configActions) configActions.classList.toggle('hidden', !show);
}

// ============================================================================
// Utility Functions
// ============================================================================

// Make functions globally available
window.initMaestro = initMaestro;
window.refreshMaestroDevices = refreshMaestroDevices;
window.onMaestroDeviceChange = onMaestroDeviceChange;
window.onServoSliderInput = onServoSliderInput;
window.onServoSpeedChange = onServoSpeedChange;
window.onServoAccelChange = onServoAccelChange;
window.centerServo = centerServo;
window.disableServo = disableServo;
window.enableServo = enableServo;
window.toggleServoEnabled = toggleServoEnabled;
window.maestroGoHome = maestroGoHome;
window.maestroCenterAll = maestroCenterAll;
window.maestroDisableAll = maestroDisableAll;
window.maestroExpandAll = maestroExpandAll;
window.maestroCollapseAll = maestroCollapseAll;
window.maestroRunScript = maestroRunScript;
window.maestroStopScript = maestroStopScript;
window.maestroUploadScript = maestroUploadScript;
window.showMaestroConfigTab = showMaestroConfigTab;
window.maestroSaveConfig = maestroSaveConfig;
window.maestroExportConfig = maestroExportConfig;
window.maestroImportConfig = maestroImportConfig;
window.maestroRecordFrame = maestroRecordFrame;
window.maestroPlaySequence = maestroPlaySequence;
window.maestroStopSequence = maestroStopSequence;
window.maestroClearSequence = maestroClearSequence;
window.maestroClearRecorder = maestroClearRecorder;
window.maestroConvertToScript = maestroConvertToScript;
window.maestroSendToEditor = maestroSendToEditor;
window.maestroDeleteFrame = maestroDeleteFrame;
window.maestroPreviewFrame = maestroPreviewFrame;
window.maestroUpdateSelectedFrame = maestroUpdateSelectedFrame;
window.maestroOverwriteSelectedFrame = maestroOverwriteSelectedFrame;
window.maestroDeselectFrame = maestroDeselectFrame;
window.disconnectMaestro = disconnectMaestro;
// Channel configuration functions
window.toggleChannelExpand = toggleChannelExpand;
window.onChannelConfigChange = onChannelConfigChange;
window.updateHomeInputState = updateHomeInputState;
window.setToCurrentPosition = setToCurrentPosition;
window.editChannelName = editChannelName;
window.applyChannelConfig = applyChannelConfig;
window.discardChannelConfig = discardChannelConfig;
window.loadMaestroChannelConfig = loadMaestroChannelConfig;
window.maestroApplyAllChannelChanges = maestroApplyAllChannelChanges;
window.maestroResetToDefaults = maestroResetToDefaults;
// Serial mode functions
window.checkMaestroSerialMode = checkMaestroSerialMode;
window.fixMaestroSerialMode = fixMaestroSerialMode;
window.dismissSerialModeAlert = dismissSerialModeAlert;
window.confirmPowerCycleComplete = confirmPowerCycleComplete;
// Library management functions
window.loadMaestroLibrary = loadMaestroLibrary;
window.maestroCreateSequence = maestroCreateSequence;
window.maestroEditSequence = maestroEditSequence;
window.maestroViewSequenceAsScript = maestroViewSequenceAsScript;
window.maestroViewAllAsScript = maestroViewAllAsScript;
window.maestroDeleteLibrarySequence = maestroDeleteLibrarySequence;
window.maestroRunLibrarySequence = maestroRunLibrarySequence;
window.maestroSaveSequenceToLibrary = maestroSaveSequenceToLibrary;
window.maestroTestSubroutine = maestroTestSubroutine;
window.maestroSyncToDevice = maestroSyncToDevice;
// Sequence recorder to library
window.maestroSaveToLibrary = maestroSaveToLibrary;
window.maestroClearRecorderForNew = maestroClearRecorderForNew;
// Script editor functions (edit individual sequences)
window.maestroSaveCurrentScript = maestroSaveCurrentScript;
window.maestroDeleteCurrentScript = maestroDeleteCurrentScript;
window.maestroClearScriptEditor = maestroClearScriptEditor;
// Modal functions
window.closeMaestroModal = closeMaestroModal;
window.closeMaestroModalOnOverlay = closeMaestroModalOnOverlay;
window.copyScriptPreview = copyScriptPreview;
window.downloadScriptPreview = downloadScriptPreview;

console.log('Maestro module loaded');
