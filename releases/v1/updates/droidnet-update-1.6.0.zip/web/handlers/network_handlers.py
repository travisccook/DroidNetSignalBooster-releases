"""
DroidNet Signal Booster - Network Handlers
Network and WiFi management functions
"""

import os
import json
import subprocess
import logging
import socket
import time
import configparser
import re
import urllib.request
import urllib.error
from datetime import datetime
from typing import Dict, List, Any, Optional

from config.constants import (
    CONFIG_DIR,
    SCRIPTS_DIR,
    BIN_DIR,
    RUNTIME_DIR,
    NETWORK_STATE_FILE,
    DROIDNET_MODE_FILE,
    DROIDNET_MODE_FILE_BOOT,
    FALLBACK_FLAG_FILE,
    HOSTAPD_CONF_SYSTEM,
    NETWORKMANAGER_CONNECTIONS_DIR,
    WIFI_CONFIG_FILE,
    NETWORK_SETTINGS_FILE,
    HOSTAPD_TEMPLATE_FILE,
    SWITCH_NETWORK_MODE_SCRIPT,
    DETECT_VHUSBD_SCRIPT,
    VHUSBD_BINARY,
)

# Configure logging
logger = logging.getLogger(__name__)


def get_wifi_status() -> Dict[str, Any]:
    """Get current Wi-Fi status"""
    try:
        # Check network state file to determine actual mode
        current_state = "unknown"
        if NETWORK_STATE_FILE.exists():
            with open(NETWORK_STATE_FILE, "r") as f:
                current_state = f.read().strip()

        # Determine if in AP mode based on state or running services
        is_ap_mode = False
        if current_state == "ap_active":
            is_ap_mode = True
        else:
            # Check if hostapd is running as fallback
            result = subprocess.run(
                ["systemctl", "is-active", "hostapd"], capture_output=True, text=True
            )
            if result.returncode == 0 and result.stdout.strip() == "active":
                is_ap_mode = True

        if is_ap_mode:
            # In AP mode
            ssid = "DroidNet-AP"
            ip = "192.168.4.1"
            mode = "Access Point Mode"

            # Try to get actual SSID from hostapd config
            if HOSTAPD_CONF_SYSTEM.exists():
                try:
                    with open(HOSTAPD_CONF_SYSTEM, "r") as f:
                        for line in f:
                            if line.startswith("ssid="):
                                ssid = line.split("=", 1)[1].strip()
                                break
                except Exception:
                    pass
        else:
            # In client mode or transitioning
            # Get current SSID
            result = subprocess.run(["iwgetid", "-r"], capture_output=True, text=True)
            ssid = result.stdout.strip() if result.returncode == 0 else ""

            # Get IP address
            result = subprocess.run(["hostname", "-I"], capture_output=True, text=True)
            ip = result.stdout.strip().split()[0] if result.stdout.strip() else "No IP"

            mode = "Client Mode" if ssid else "Disconnected"

        return {
            "ssid": ssid or "None",
            "ip": ip,
            "mode": mode,
            "state": current_state,
            "success": True,
        }
    except Exception as e:
        return {"error": str(e), "success": False}


def scan_wifi_networks() -> List[Dict[str, Any]]:
    """Scan for available Wi-Fi networks"""
    try:
        logger.info("Scanning for WiFi networks")
        result = subprocess.run(
            ["iwlist", "wlan0", "scan"], capture_output=True, text=True
        )
        networks = []

        current_network = {}
        for line in result.stdout.split("\n"):
            line = line.strip()
            if "ESSID:" in line:
                ssid = line.split("ESSID:")[1].strip('"')
                if ssid:
                    current_network["ssid"] = ssid
            elif "Signal level=" in line:
                # Extract signal strength
                signal = line.split("Signal level=")[1].split()[0]
                try:
                    signal_pct = int((int(signal) + 100) * 2)  # Rough conversion
                    current_network["signal"] = max(0, min(100, signal_pct))
                except (ValueError, TypeError):
                    current_network["signal"] = 50
            elif "Encryption key:" in line:
                if current_network and "ssid" in current_network:
                    networks.append(current_network)
                    current_network = {}

        return sorted(networks, key=lambda x: x.get("signal", 0), reverse=True)
    except Exception:
        return []


def save_network_to_config(ssid: str, password: str, priority: int = 100) -> bool:
    """Save network to wifi-config.json"""
    try:
        WIFI_CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)

        # Load existing config
        existing_networks = []
        if WIFI_CONFIG_FILE.exists():
            try:
                with open(WIFI_CONFIG_FILE, "r") as f:
                    data = json.load(f)
                    if isinstance(data, dict) and "networks" in data:
                        existing_networks = data.get("networks", [])
            except Exception as e:
                logger.warning(f"Could not read existing config: {e}")

        # Check if network already exists
        network_exists = False
        new_network = {"ssid": ssid, "psk": password, "priority": priority}

        for idx, network in enumerate(existing_networks):
            if network.get("ssid") == ssid:
                # Update existing network
                existing_networks[idx] = new_network
                network_exists = True
                break

        if not network_exists:
            # Add new network
            existing_networks.append(new_network)

        # Save updated config
        with open(WIFI_CONFIG_FILE, "w") as f:
            json.dump({"networks": existing_networks}, f, indent=2)

        logger.info(f"Saved network {ssid} to wifi-config.json")
        return True
    except Exception as e:
        logger.error(f"Failed to save network to config: {e}")
        return False


def create_nm_connection(ssid: str, password: str) -> bool:
    """Create persistent NetworkManager connection profile"""
    try:
        # Delete existing connection if it exists
        result = subprocess.run(
            ["nmcli", "connection", "delete", ssid], capture_output=True, text=True
        )

        # Create new connection
        cmd = [
            "nmcli",
            "connection",
            "add",
            "type",
            "wifi",
            "con-name",
            ssid,
            "ifname",
            "wlan0",
            "ssid",
            ssid,
            "wifi-sec.key-mgmt",
            "wpa-psk",
            "wifi-sec.psk",
            password,
            "connection.autoconnect",
            "yes",
            "connection.autoconnect-priority",
            "100",
        ]

        result = subprocess.run(cmd, capture_output=True, text=True)

        if result.returncode == 0:
            logger.info(f"Created NetworkManager connection for {ssid}")
            return True
        else:
            logger.error(f"Failed to create NM connection: {result.stderr}")
            return False
    except Exception as e:
        logger.error(f"Error creating NM connection: {e}")
        return False


def sync_network_configs() -> Dict[str, Any]:
    """Sync NetworkManager connections with wifi-config.json"""
    try:
        synced = []
        errors = []

        # Load wifi-config.json
        wifi_networks = []

        if WIFI_CONFIG_FILE.exists():
            with open(WIFI_CONFIG_FILE, "r") as f:
                data = json.load(f)
                if isinstance(data, dict) and "networks" in data:
                    wifi_networks = data.get("networks", [])

        # Get NetworkManager WiFi connections
        result = subprocess.run(
            ["nmcli", "-t", "-f", "NAME,TYPE", "connection", "show"],
            capture_output=True,
            text=True,
        )

        nm_wifi_connections = set()
        for line in result.stdout.strip().split("\n"):
            if ":802-11-wireless" in line:
                name = line.split(":")[0]
                nm_wifi_connections.add(name)

        # Sync from wifi-config.json to NetworkManager
        for network in wifi_networks:
            ssid = network.get("ssid")
            password = network.get("psk", "")

            if ssid and ssid not in nm_wifi_connections:
                # Create missing NetworkManager connection
                if create_nm_connection(ssid, password):
                    synced.append(f"Added {ssid} to NetworkManager")
                else:
                    errors.append(f"Failed to add {ssid} to NetworkManager")

        # Find NetworkManager connections not in wifi-config.json
        config_ssids = {net.get("ssid") for net in wifi_networks}
        orphaned = nm_wifi_connections - config_ssids

        if orphaned:
            logger.info(f"Found orphaned NM connections: {orphaned}")
            # We don't auto-add these to wifi-config.json to avoid
            # saving temporary connections

        return {
            "success": True,
            "synced": synced,
            "errors": errors,
            "orphaned": list(orphaned),
        }
    except Exception as e:
        logger.error(f"Failed to sync network configs: {e}")
        return {"success": False, "error": str(e)}


def connect_wifi(ssid: str, password: str) -> Dict[str, Any]:
    """Connect to Wi-Fi network"""
    debug_info = {
        "ssid": ssid,
        "has_password": bool(password),
        "timestamp": datetime.now().isoformat(),
    }

    try:
        logger.info(f"Attempting to connect to WiFi network: {ssid}")

        # Always save network to config first
        if not save_network_to_config(ssid, password):
            logger.warning(
                "Failed to save network to config, but continuing with connection"
            )

        # Step 1: Check current network mode
        current_mode = "unknown"
        current_state = "unknown"

        # Read state file to check current network state
        if NETWORK_STATE_FILE.exists():
            with open(NETWORK_STATE_FILE, "r") as f:
                current_state = f.read().strip()
                logger.debug(f"Current network state: {current_state}")
                debug_info["current_state"] = current_state

        # Check if already switching modes
        if current_state.startswith("switching_to_"):
            logger.warning("Mode switch already in progress")
            return {
                "success": False,
                "message": "Network mode switch already in progress",
                "debug": debug_info,
            }

        # Determine current mode
        if current_state == "ap_active":
            current_mode = "ap"
        elif current_state in ["client_active", "starting_client"]:
            current_mode = "client"
        else:
            # Fallback to mode file
            if DROIDNET_MODE_FILE_BOOT.exists():
                with open(DROIDNET_MODE_FILE_BOOT, "r") as f:
                    current_mode = f.read().strip()
                    debug_info["mode_from_file"] = str(DROIDNET_MODE_FILE_BOOT)
            elif DROIDNET_MODE_FILE.exists():
                with open(DROIDNET_MODE_FILE, "r") as f:
                    current_mode = f.read().strip()
                    debug_info["mode_from_file"] = str(DROIDNET_MODE_FILE)

        logger.info(f"Current mode: {current_mode}, state: {current_state}")
        debug_info["current_mode"] = current_mode

        # Step 2: Handle based on current mode
        if current_mode == "ap" or current_state == "ap_active":
            # We're in AP mode, need to switch to client mode
            logger.info("Currently in AP mode, preparing to switch to client mode")

            # Network already saved to wifi-config.json at the
            # beginning of this function
            logger.info("WiFi credentials saved to config")

            # Use the proper mode switch script
            if SWITCH_NETWORK_MODE_SCRIPT.exists():
                logger.info("Triggering network mode switch to client")

                # Run mode switch and check exit code
                switch_result = subprocess.run(
                    [str(SWITCH_NETWORK_MODE_SCRIPT), "client"],
                    capture_output=True,
                    text=True,
                )

                if switch_result.returncode == 0:
                    # Mode switch initiated successfully
                    logger.info("Mode switch initiated successfully")
                    return {
                        "success": True,
                        "message": (
                            "Switching to client mode and connecting to network..."
                        ),
                        "mode_switch": True,
                        "reconnect_info": {
                            "current_ip": "192.168.4.1",
                            "wait_time": 30,
                            "instruction": (
                                "Device will reconnect to your network shortly. "
                                "You will lose connection to this interface."
                            ),
                        },
                    }
                else:
                    # Process failed
                    error_msg = (
                        switch_result.stderr.strip()
                        if switch_result.stderr
                        else "Mode switch script failed"
                    )
                    logger.error(f"Mode switch failed: {error_msg}")
                    return {
                        "success": False,
                        "message": f"Failed to switch network mode: {error_msg}",
                    }
            else:
                logger.error(f"Mode switch script not found: {SWITCH_NETWORK_MODE_SCRIPT}")
                return {"success": False, "message": "Mode switch script not available"}

        elif current_mode == "client" or current_state in [
            "client_active",
            "starting_client",
        ]:
            # Already in client mode, check if NetworkManager is running
            logger.info("Already in client mode, checking NetworkManager status")

            # Check if NetworkManager is masked
            mask_check = subprocess.run(
                ["systemctl", "is-enabled", "NetworkManager"],
                capture_output=True,
                text=True,
            )
            debug_info["nm_enabled_status"] = mask_check.stdout.strip()

            if "masked" in mask_check.stdout:
                logger.error(
                    "NetworkManager is masked in client mode - system misconfiguration"
                )
                debug_info["nm_masked"] = True
                return {
                    "success": False,
                    "message": "Network service is disabled",
                    "debug": debug_info,
                }

            # Wait for NetworkManager to be active
            max_attempts = 10
            nm_active = False

            for attempt in range(max_attempts):
                nm_status = subprocess.run(
                    ["systemctl", "is-active", "NetworkManager"],
                    capture_output=True,
                    text=True,
                )

                if nm_status.stdout.strip() == "active":
                    nm_active = True
                    break

                logger.debug(
                    f"Waiting for NetworkManager... "
                    f"attempt {attempt + 1}/{max_attempts}"
                )
                time.sleep(1)

            debug_info["nm_active_after_wait"] = nm_active

            if not nm_active:
                logger.error("NetworkManager is not active in client mode")
                # Try to start it
                start_result = subprocess.run(
                    ["systemctl", "start", "NetworkManager"],
                    capture_output=True,
                    text=True,
                )
                debug_info["nm_start_attempted"] = True
                debug_info["nm_start_result"] = start_result.returncode
                time.sleep(3)

                # Check again
                nm_status = subprocess.run(
                    ["systemctl", "is-active", "NetworkManager"],
                    capture_output=True,
                    text=True,
                )
                debug_info["nm_status_after_start"] = nm_status.stdout.strip()

                if nm_status.stdout.strip() != "active":
                    return {
                        "success": False,
                        "message": "Network service not available",
                        "debug": debug_info,
                    }

            # NetworkManager is active, proceed with connection
            logger.info("NetworkManager is active, attempting connection")
            debug_info["networkmanager_active"] = True

            # Get current Wi-Fi state before connection
            wifi_state = subprocess.run(
                ["nmcli", "radio", "wifi"], capture_output=True, text=True
            )
            debug_info["wifi_radio"] = wifi_state.stdout.strip()

            # List available networks for debugging
            scan_result = subprocess.run(
                ["nmcli", "-t", "-f", "SSID,SIGNAL,SECURITY", "dev", "wifi", "list"],
                capture_output=True,
                text=True,
            )
            available_networks = []
            for line in scan_result.stdout.strip().split("\n"):
                if line:
                    parts = line.split(":")
                    if len(parts) >= 3 and parts[0]:  # Skip empty SSIDs
                        available_networks.append(
                            {"ssid": parts[0], "signal": parts[1], "security": parts[2]}
                        )
            debug_info["available_networks"] = available_networks
            debug_info["target_network_found"] = any(
                net["ssid"] == ssid for net in available_networks
            )

            # Create persistent connection profile first
            logger.info(f"Creating NetworkManager connection profile for {ssid}")
            if not create_nm_connection(ssid, password):
                return {
                    "success": False,
                    "message": "Failed to create network profile",
                    "debug": debug_info,
                }

            # Now activate the connection
            logger.info(f"Activating connection to {ssid}")
            result = subprocess.run(
                ["nmcli", "connection", "up", ssid],
                capture_output=True,
                text=True,
                timeout=30,
            )

            debug_info["nmcli_returncode"] = result.returncode
            debug_info["nmcli_stdout"] = result.stdout.strip()
            debug_info["nmcli_stderr"] = result.stderr.strip()

            if result.returncode == 0:
                logger.info(f"Successfully connected to {ssid}")
                return {"success": True, "message": f"Connected to {ssid}"}
            else:
                # Handle nmcli errors
                error_msg = (
                    result.stderr.strip() if result.stderr else result.stdout.strip()
                )
                logger.error(f"Failed to connect to {ssid}: {error_msg}")

                if (
                    "Secrets were required" in error_msg
                    or "Secrets request failed" in error_msg
                ):
                    return {
                        "success": False,
                        "message": "Invalid password",
                        "debug": debug_info,
                    }
                elif "No network with SSID" in error_msg:
                    return {
                        "success": False,
                        "message": "Network not found",
                        "debug": debug_info,
                    }
                elif "Connection activation failed" in error_msg:
                    if "Secrets" in error_msg:
                        return {
                            "success": False,
                            "message": "Invalid password",
                            "debug": debug_info,
                        }
                    else:
                        return {
                            "success": False,
                            "message": "Connection failed - check password",
                            "debug": debug_info,
                        }
                else:
                    return {
                        "success": False,
                        "message": f"Connection failed: {error_msg}",
                        "debug": debug_info,
                    }

        else:
            # Unknown mode
            logger.error(f"Unknown network mode: {current_mode}")
            return {
                "success": False,
                "message": "Network mode unknown",
                "debug": debug_info,
            }

    except subprocess.TimeoutExpired:
        logger.error(f"Connection to {ssid} timed out")
        debug_info["error_type"] = "timeout"
        return {
            "success": False,
            "message": "Connection timed out",
            "debug": debug_info,
        }
    except Exception as e:
        logger.error(f"Connection error: {str(e)}", exc_info=True)
        debug_info["error_type"] = "exception"
        debug_info["error_details"] = str(e)
        return {
            "success": False,
            "message": f"Connection error: {str(e)}",
            "debug": debug_info,
        }


def get_saved_networks() -> List[Dict[str, Any]]:
    """Get saved NetworkManager connections with availability status"""
    try:
        saved_networks = []

        # Try using nmcli first (works in client mode)
        result = subprocess.run(
            ["nmcli", "-t", "-f", "NAME,TYPE,UUID", "connection", "show"],
            capture_output=True,
            text=True,
        )

        if result.returncode == 0:
            # Get available networks for comparison
            scan_result = subprocess.run(
                ["nmcli", "-t", "-f", "SSID,SIGNAL", "device", "wifi"],
                capture_output=True,
                text=True,
            )
            available_ssids = {}
            if scan_result.returncode == 0:
                for line in scan_result.stdout.strip().split("\n"):
                    if line and ":" in line:
                        parts = line.split(":")
                        if len(parts) >= 2:
                            ssid = parts[0]
                            signal = parts[1] if len(parts) > 1 else "0"
                            if ssid:
                                available_ssids[ssid] = (
                                    int(signal) if signal.isdigit() else 0
                                )

            # Process saved connections
            for line in result.stdout.strip().split("\n"):
                if line and ":" in line:
                    parts = line.split(":")
                    if len(parts) >= 3 and parts[1] == "802-11-wireless":
                        name = parts[0]
                        uuid = parts[2]

                        # Skip special connections
                        if name in ["DroidNet-AP", "lo"]:
                            continue

                        # Get priority for this connection
                        priority = 0
                        priority_result = subprocess.run(
                            [
                                "nmcli",
                                "-t",
                                "-f",
                                "connection.autoconnect-priority",
                                "connection",
                                "show",
                                uuid,
                            ],
                            capture_output=True,
                            text=True,
                        )
                        if priority_result.returncode == 0:
                            priority_line = priority_result.stdout.strip()
                            if ":" in priority_line:
                                try:
                                    priority = int(priority_line.split(":")[1])
                                except ValueError:
                                    priority = 0

                        saved_networks.append(
                            {
                                "ssid": name,
                                "uuid": uuid,
                                "available": name in available_ssids,
                                "signal": available_ssids.get(name, 0),
                                "priority": priority,
                            }
                        )
        else:
            # Fallback: Read directly from NetworkManager system-connections (AP mode)
            if NETWORKMANAGER_CONNECTIONS_DIR.exists():
                for filename in os.listdir(NETWORKMANAGER_CONNECTIONS_DIR):
                    if filename.endswith(".nmconnection"):
                        filepath = NETWORKMANAGER_CONNECTIONS_DIR / filename
                        try:
                            config = configparser.ConfigParser()
                            config.read(filepath)

                            # Check if it's a WiFi connection
                            if config.has_section("wifi") and config.has_option(
                                "wifi", "ssid"
                            ):
                                ssid_bytes = config.get("wifi", "ssid")
                                # Remove quotes if present
                                ssid = ssid_bytes.strip('"')

                                # Get UUID if available
                                uuid = ""
                                if config.has_section(
                                    "connection"
                                ) and config.has_option("connection", "uuid"):
                                    uuid = config.get("connection", "uuid")

                                # Skip special connections
                                if ssid in ["DroidNet-AP", "lo"]:
                                    continue

                                # Get priority if available
                                priority = 0
                                if config.has_section(
                                    "connection"
                                ) and config.has_option(
                                    "connection", "autoconnect-priority"
                                ):
                                    try:
                                        priority = int(
                                            config.get(
                                                "connection", "autoconnect-priority"
                                            )
                                        )
                                    except ValueError:
                                        priority = 0

                                saved_networks.append(
                                    {
                                        "ssid": ssid,
                                        "uuid": uuid,
                                        "available": False,  # Can't scan in AP mode
                                        "signal": 0,
                                        "priority": priority,
                                    }
                                )
                        except Exception:
                            # Skip files we can't read
                            pass

        return saved_networks
    except Exception:
        return []


def forget_network(ssid: str) -> Dict[str, Any]:
    """Forget a saved network connection"""
    try:
        # Remove from NetworkManager
        nm_removed = False
        result = subprocess.run(
            ["nmcli", "-t", "-f", "NAME,UUID", "connection", "show"],
            capture_output=True,
            text=True,
        )

        uuid = None
        for line in result.stdout.strip().split("\n"):
            if line.startswith(f"{ssid}:"):
                uuid = line.split(":")[1]
                break

        if uuid:
            # Delete the connection
            result = subprocess.run(
                ["nmcli", "connection", "delete", uuid], capture_output=True, text=True
            )
            if result.returncode == 0:
                nm_removed = True
                logger.info(f"Removed {ssid} from NetworkManager")

        # Remove from wifi-config.json
        config_removed = False

        if WIFI_CONFIG_FILE.exists():
            try:
                with open(WIFI_CONFIG_FILE, "r") as f:
                    data = json.load(f)

                if isinstance(data, dict) and "networks" in data:
                    original_count = len(data["networks"])
                    data["networks"] = [
                        n for n in data["networks"] if n.get("ssid") != ssid
                    ]

                    if len(data["networks"]) < original_count:
                        with open(WIFI_CONFIG_FILE, "w") as f:
                            json.dump(data, f, indent=2)
                        config_removed = True
                        logger.info(f"Removed {ssid} from wifi-config.json")
            except Exception as e:
                logger.error(f"Failed to remove from config: {e}")

        if nm_removed or config_removed:
            return {"success": True, "message": f"Network {ssid} forgotten"}
        else:
            return {"success": False, "error": "Network not found"}
    except Exception as e:
        return {"success": False, "error": str(e)}


def get_wifi_mode() -> Dict[str, Any]:
    """Get current Wi-Fi mode preference and configuration"""
    try:
        # Check web interface config first (has priority)
        if WIFI_CONFIG_FILE.exists():
            with open(WIFI_CONFIG_FILE, "r") as f:
                config = json.load(f)
                mode = config.get("mode")
                if mode:
                    return {"mode": mode, "source": "web_config", "success": True}

        # Check mode file
        if DROIDNET_MODE_FILE_BOOT.exists():
            with open(DROIDNET_MODE_FILE_BOOT, "r") as f:
                mode = f.read().strip()
                return {"mode": mode, "source": "mode_file", "success": True}

        # Check fallback location
        if DROIDNET_MODE_FILE.exists():
            with open(DROIDNET_MODE_FILE, "r") as f:
                mode = f.read().strip()
                return {"mode": mode, "source": "mode_file_fallback", "success": True}

        # Default to AP mode
        return {"mode": "ap", "source": "default", "success": True}
    except Exception as e:
        return {"mode": "ap", "success": False, "error": str(e)}


def set_wifi_mode(mode: str) -> Dict[str, Any]:
    """Set Wi-Fi mode (ap or client)"""
    try:
        # Validate mode
        if mode not in ["ap", "client"]:
            return {"success": False, "error": "Invalid mode. Use 'ap' or 'client'"}

        # Update mode file that network-controller reads
        # Ensure directory exists
        if DROIDNET_MODE_FILE_BOOT.parent.exists():
            with open(DROIDNET_MODE_FILE_BOOT, "w") as f:
                f.write(mode)
        else:
            # Fallback to /var/lib/droidnet if /boot/firmware not available
            DROIDNET_MODE_FILE.parent.mkdir(parents=True, exist_ok=True)
            with open(DROIDNET_MODE_FILE, "w") as f:
                f.write(mode)

        # Also update web interface config for persistence
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)

        # Load existing config or create new
        if WIFI_CONFIG_FILE.exists():
            with open(WIFI_CONFIG_FILE, "r") as f:
                config = json.load(f)
        else:
            config = {}

        # Update mode
        config["mode"] = mode

        # Save updated config
        with open(WIFI_CONFIG_FILE, "w") as f:
            json.dump(config, f, indent=2)

        # Use the safe mode switching script if available
        if SWITCH_NETWORK_MODE_SCRIPT.exists() and os.access(SWITCH_NETWORK_MODE_SCRIPT, os.X_OK):
            try:
                result = subprocess.run(
                    [str(SWITCH_NETWORK_MODE_SCRIPT), mode],
                    capture_output=True,
                    text=True,
                    timeout=60,  # Give it time to verify
                )

                if result.returncode == 0:
                    return {
                        "success": True,
                        "message": (
                            f"Successfully switched to {mode} mode. "
                            "The network has been reconfigured."
                        ),
                    }
                else:
                    # Script failed but mode was saved
                    return {
                        "success": True,
                        "message": (
                            f"Wi-Fi mode set to {mode}. "
                            "Please wait for the network to restart."
                        ),
                        "warning": "Mode switch in progress",
                    }
            except subprocess.TimeoutExpired:
                return {
                    "success": True,
                    "message": (
                        f"Wi-Fi mode set to {mode}. "
                        "Network reconfiguration in progress."
                    ),
                    "warning": "Switch is taking longer than expected",
                }
            except Exception:
                # Fall through to direct restart
                pass

        # Fallback: Direct restart the network controller
        try:
            result = subprocess.run(
                ["systemctl", "restart", "droidnet-network-controller"],
                capture_output=True,
                text=True,
            )

            if result.returncode == 0:
                return {
                    "success": True,
                    "message": (
                        f"Switching to {mode} mode. "
                        "The network will restart momentarily."
                    ),
                }
            else:
                return {
                    "success": True,
                    "message": (
                        f"Wi-Fi mode set to {mode}. "
                        "Please reboot the device to apply changes."
                    ),
                    "warning": "Could not restart network service automatically",
                }
        except Exception:
            return {
                "success": True,
                "message": (
                    f"Wi-Fi mode set to {mode}. "
                    "Please reboot the device to apply changes."
                ),
            }
    except Exception as e:
        return {"success": False, "error": str(e)}


def get_ap_config() -> Dict[str, Any]:
    """Get current AP configuration"""
    try:
        config = {}

        # Always read from template file which stores user preferences
        if HOSTAPD_TEMPLATE_FILE.exists():
            try:
                with open(HOSTAPD_TEMPLATE_FILE, "r") as f:
                    for line in f:
                        line = line.strip()
                        if line.startswith("ssid="):
                            config["ssid"] = line.split("=", 1)[1]
                        elif line.startswith("wpa_passphrase="):
                            config["password"] = line.split("=", 1)[1]
            except Exception as e:
                logger.warning(f"Could not read template config: {e}")

        # Handle MAC suffix placeholder - remove it for display
        if "ssid" in config and "%%MAC_SUFFIX%%" in config["ssid"]:
            # This is a default SSID with placeholder
            config["ssid"] = config["ssid"].replace("-%%MAC_SUFFIX%%", "")

        # Default values if not found
        if "ssid" not in config:
            config["ssid"] = "DroidNet"
        if "password" not in config:
            config["password"] = "droidnet123"

        # Check current mode
        hostapd_status = subprocess.run(
            ["systemctl", "is-active", "hostapd"],
            capture_output=True,
            text=True,
        )
        is_ap_active = hostapd_status.stdout.strip() == "active"

        return {
            "success": True,
            "ssid": config["ssid"],
            "password": config["password"],
            "mode": "ap" if is_ap_active else "client",
        }

    except Exception as e:
        logger.error(f"Error getting AP config: {e}")
        return {"success": False, "error": str(e)}


def set_ap_config(ssid: str, password: str) -> Dict[str, Any]:
    """Update AP configuration"""
    try:
        # Validate inputs
        if not ssid:
            return {"success": False, "error": "SSID cannot be empty"}

        if password and len(password) < 8:
            return {"success": False, "error": "Password must be at least 8 characters"}

        # Check current mode for appropriate message
        # Check if connected to external network
        result = subprocess.run(["iwgetid"], capture_output=True, text=True)
        is_ap_mode = True
        if result.returncode == 0 and result.stdout.strip():
            is_ap_mode = False

        try:
            # Update the template file (this is the persistent configuration)
            if HOSTAPD_TEMPLATE_FILE.exists():
                with open(HOSTAPD_TEMPLATE_FILE, "r") as f:
                    template_lines = f.readlines()

                new_template_lines = []
                for line in template_lines:
                    if line.startswith("ssid="):
                        # Check if user is setting back to default
                        if ssid.lower() == "droidnet":
                            # Use placeholder for default SSID
                            new_template_lines.append("ssid=DroidNet-%%MAC_SUFFIX%%\n")
                        else:
                            # User-defined SSID - no MAC suffix
                            new_template_lines.append(f"ssid={ssid}\n")
                    elif line.startswith("wpa_passphrase=") and password:
                        new_template_lines.append(f"wpa_passphrase={password}\n")
                    else:
                        new_template_lines.append(line)

                with open(HOSTAPD_TEMPLATE_FILE, "w") as f:
                    f.writelines(new_template_lines)
            else:
                # Create template if it doesn't exist
                logger.warning(
                    f"Template file {HOSTAPD_TEMPLATE_FILE} not found, creating new one"
                )
                HOSTAPD_TEMPLATE_FILE.parent.mkdir(parents=True, exist_ok=True)
                with open(HOSTAPD_TEMPLATE_FILE, "w") as f:
                    # Check if user is setting default or custom SSID
                    if ssid.lower() == "droidnet":
                        ssid_line = "ssid=DroidNet-%%MAC_SUFFIX%%"
                    else:
                        ssid_line = f"ssid={ssid}"

                    f.write(
                        f"""interface=wlan0
driver=nl80211
{ssid_line}
hw_mode=g
channel=6
ieee80211n=1
ieee80211d=1
country_code=US
wmm_enabled=1
macaddr_acl=0
auth_algs=1
ignore_broadcast_ssid=0
wpa=2
wpa_passphrase={password if password else 'droidnet123'}
wpa_key_mgmt=WPA-PSK
wpa_pairwise=TKIP
rsn_pairwise=CCMP
ap_isolate=0
"""
                    )

            # If in AP mode, also update the active configuration
            if is_ap_mode and HOSTAPD_CONF_SYSTEM.exists():
                with open(HOSTAPD_CONF_SYSTEM, "r") as f:
                    config_lines = f.readlines()

                new_config_lines = []
                for line in config_lines:
                    if line.startswith("ssid="):
                        new_config_lines.append(f"ssid={ssid}\n")
                    elif line.startswith("wpa_passphrase=") and password:
                        new_config_lines.append(f"wpa_passphrase={password}\n")
                    else:
                        new_config_lines.append(line)

                with open(HOSTAPD_CONF_SYSTEM, "w") as f:
                    f.writelines(new_config_lines)

                return {
                    "success": True,
                    "message": "AP settings updated. Restart device to apply changes.",
                }
            else:
                return {
                    "success": True,
                    "message": "AP settings saved. Will apply in AP mode.",
                }

        except Exception as e:
            logger.error(f"Failed to update AP settings: {e}")
            return {
                "success": False,
                "error": f"Failed to update configuration: {str(e)}",
            }

    except Exception as e:
        logger.error(f"Failed to update AP configuration: {e}")
        return {"success": False, "error": str(e)}


def get_virtualhere_status() -> Dict[str, Any]:
    """Get VirtualHere service status and information"""
    try:
        status = {"running": False, "build_type": "Unknown", "version": "Unknown"}

        # Check if service is running
        result = subprocess.run(
            ["systemctl", "is-active", "droidnet-virtualhere"],
            capture_output=True,
            text=True,
        )
        status["running"] = result.stdout.strip() == "active"

        # Check which binary is being used
        if VHUSBD_BINARY.exists():
            real_path = os.path.realpath(VHUSBD_BINARY)
            if "vhusbdarmpi" in real_path:
                status["build_type"] = "CPU Optimized (Pi Zero)"
            elif "vhusbdpin" in real_path:
                status["build_type"] = "CPU Optimized (Legacy Pi)"
            elif "vhusbdarm" in real_path:
                status["build_type"] = "Generic ARM"
            else:
                status["build_type"] = "Unknown"

        # Get version info from running process if available
        if status["running"]:
            # Check for listening port
            result = subprocess.run(
                ["netstat", "-tlnp"], capture_output=True, text=True
            )
            if "7575" in result.stdout:
                status["port"] = 7575

            # Try to get version from logs
            result = subprocess.run(
                ["journalctl", "-u", "droidnet-virtualhere", "-n", "20", "--no-pager"],
                capture_output=True,
                text=True,
            )
            for line in result.stdout.split("\n"):
                if "Starting VirtualHere USB Server" in line:
                    # Extract version like "v4.7.8"
                    match = re.search(r"v(\d+\.\d+\.\d+)", line)
                    if match:
                        status["version"] = match.group(1)
                        break

            # Count connected clients
            # (simplified - would need vhclient for accurate count)
            result = subprocess.run(["netstat", "-tn"], capture_output=True, text=True)
            connections = [
                line
                for line in result.stdout.split("\n")
                if ":7575" in line and "ESTABLISHED" in line
            ]
            status["clients"] = len(connections)

            # Count shared devices
            result = subprocess.run(["lsusb"], capture_output=True, text=True)
            # Exclude hubs and root hubs
            devices = [
                line
                for line in result.stdout.split("\n")
                if line and "hub" not in line.lower() and "root" not in line.lower()
            ]
            status["devices"] = len(devices)

        return status
    except Exception as e:
        return {"error": str(e), "running": False}


def toggle_virtualhere(enable: bool) -> Dict[str, Any]:
    """Enable or disable VirtualHere service"""
    try:
        if enable:
            # First ensure the symlink exists
            result = subprocess.run(
                [str(DETECT_VHUSBD_SCRIPT)], capture_output=True, text=True
            )
            if result.returncode != 0:
                return {
                    "success": False,
                    "error": "Failed to detect VirtualHere binary",
                }

            # Start and enable the service
            subprocess.run(["systemctl", "enable", "droidnet-virtualhere"], check=True)
            subprocess.run(["systemctl", "start", "droidnet-virtualhere"], check=True)
            return {"success": True, "message": "VirtualHere started"}
        else:
            # Stop and disable the service
            subprocess.run(["systemctl", "stop", "droidnet-virtualhere"], check=True)
            subprocess.run(["systemctl", "disable", "droidnet-virtualhere"], check=True)
            return {"success": True, "message": "VirtualHere stopped"}
    except subprocess.CalledProcessError as e:
        return {"success": False, "error": f"Service control failed: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": str(e)}


def get_network_settings() -> Dict[str, Any]:
    """Get network configuration settings"""
    try:
        default_settings = {"client_connection_timeout": 60, "version": 1}

        if NETWORK_SETTINGS_FILE.exists():
            try:
                with open(NETWORK_SETTINGS_FILE, "r") as f:
                    settings = json.load(f)
                    # Ensure we have all required fields
                    for key, value in default_settings.items():
                        if key not in settings:
                            settings[key] = value
                    return {"success": True, "settings": settings}
            except Exception as e:
                logger.error(f"Error reading network settings: {e}")
                return {"success": True, "settings": default_settings}
        else:
            # Return defaults if file doesn't exist
            return {"success": True, "settings": default_settings}
    except Exception as e:
        logger.error(f"Error getting network settings: {e}")
        return {"success": False, "error": str(e)}


def discover_droidnet_devices() -> Dict[str, Any]:
    """Discover DroidNet devices on the network using mDNS"""
    try:
        logger.info("Scanning for DroidNet devices via mDNS")
        devices = []
        current_hostname = socket.gethostname()

        # Use avahi-browse to find HTTP services on the network
        # -r: resolve, -p: parsable, -t: terminate after scan
        result = subprocess.run(
            ["avahi-browse", "-rpt", "_http._tcp"],
            capture_output=True,
            text=True,
            timeout=10,
        )

        # Parse avahi-browse output
        # Format: =;interface;protocol;name;type;domain;hostname;address;port;txt
        discovered_hosts = {}
        for line in result.stdout.split("\n"):
            if line.startswith("="):
                parts = line.split(";")
                if len(parts) >= 9:
                    hostname = parts[6].rstrip(".local")
                    ip = parts[7]
                    port = parts[8]
                    # Only consider port 80 HTTP services
                    if port == "80" and ip and hostname:
                        discovered_hosts[ip] = hostname

        # Check each discovered host to see if it's a DroidNet device
        for ip, hostname in discovered_hosts.items():
            try:
                # Quick check of /api/status to verify it's a DroidNet device
                url = f"http://{ip}/api/status"
                req = urllib.request.Request(url, method="GET")
                req.add_header("User-Agent", "DroidNet-Discovery/1.0")

                with urllib.request.urlopen(req, timeout=2) as response:
                    if response.status == 200:
                        data = json.loads(response.read().decode())
                        # Check for DroidNet-specific fields in status response
                        if "connected" in data and "ap_mode" in data:
                            is_current = hostname == current_hostname
                            devices.append(
                                {
                                    "hostname": hostname,
                                    "ip": ip,
                                    "is_current": is_current,
                                }
                            )
                            logger.debug(f"Found DroidNet device: {hostname} ({ip})")
            except (urllib.error.URLError, TimeoutError, json.JSONDecodeError):
                # Not a DroidNet device or unreachable
                pass
            except Exception as e:
                logger.debug(f"Error checking {hostname} ({ip}): {e}")

        # Sort devices: current device first, then alphabetically by hostname
        devices.sort(key=lambda d: (not d["is_current"], d["hostname"].lower()))

        logger.info(f"Found {len(devices)} DroidNet device(s)")
        return {"success": True, "devices": devices}

    except subprocess.TimeoutExpired:
        logger.warning("mDNS scan timed out")
        return {"success": False, "error": "Scan timed out", "devices": []}
    except FileNotFoundError:
        logger.error("avahi-browse not found - avahi-utils may not be installed")
        return {
            "success": False,
            "error": "avahi-browse not available",
            "devices": [],
        }
    except Exception as e:
        logger.error(f"Error discovering devices: {e}")
        return {"success": False, "error": str(e), "devices": []}


def set_network_settings(data: Dict[str, Any]) -> Dict[str, Any]:
    """Set network configuration settings"""
    try:
        # Ensure config directory exists
        NETWORK_SETTINGS_FILE.parent.mkdir(parents=True, exist_ok=True)

        # Load existing settings or create new
        if NETWORK_SETTINGS_FILE.exists():
            with open(NETWORK_SETTINGS_FILE, "r") as f:
                settings = json.load(f)
        else:
            settings = {"version": 1}

        # Update client connection timeout if provided
        if "client_connection_timeout" in data:
            timeout = int(data["client_connection_timeout"])
            # Validate timeout range
            if timeout < 10 or timeout > 300:
                return {
                    "success": False,
                    "error": "Timeout must be between 10 and 300 seconds",
                }
            settings["client_connection_timeout"] = timeout

        # Save updated settings
        with open(NETWORK_SETTINGS_FILE, "w") as f:
            json.dump(settings, f, indent=4)

        # Set appropriate permissions
        os.chmod(NETWORK_SETTINGS_FILE, 0o644)

        logger.info(f"Network settings updated: {settings}")
        return {"success": True, "settings": settings}
    except Exception as e:
        logger.error(f"Error setting network settings: {e}")
        return {"success": False, "error": str(e)}


def get_network_priorities() -> Dict[str, int]:
    """Get autoconnect priorities for all saved networks"""
    try:
        priorities = {}

        # Get all saved connections
        result = subprocess.run(
            ["nmcli", "-t", "-f", "NAME,UUID", "connection", "show"],
            capture_output=True,
            text=True,
        )

        for line in result.stdout.strip().split("\n"):
            if ":" in line:
                name, uuid = line.split(":", 1)

                # Skip system connections
                if name in ["lo"]:
                    continue

                # Get priority for this connection
                priority_result = subprocess.run(
                    [
                        "nmcli",
                        "-t",
                        "-f",
                        "connection.autoconnect-priority",
                        "connection",
                        "show",
                        uuid,
                    ],
                    capture_output=True,
                    text=True,
                )

                if priority_result.returncode == 0:
                    priority_line = priority_result.stdout.strip()
                    if ":" in priority_line:
                        priority = int(priority_line.split(":")[1])
                        priorities[name] = priority

        return priorities
    except Exception as e:
        logger.error(f"Error getting network priorities: {e}")
        return {}


def set_network_priority(ssid: str, priority: int) -> Dict[str, Any]:
    """Set autoconnect priority for a network"""
    try:
        # Validate priority
        priority = int(priority)
        if priority < 1 or priority > 999:
            return {"success": False, "error": "Priority must be between 1 and 999"}

        # Find connection UUID
        result = subprocess.run(
            ["nmcli", "-t", "-f", "NAME,UUID", "connection", "show"],
            capture_output=True,
            text=True,
        )

        uuid = None
        for line in result.stdout.strip().split("\n"):
            if line.startswith(f"{ssid}:"):
                uuid = line.split(":")[1]
                break

        if uuid:
            # Set the priority
            result = subprocess.run(
                [
                    "nmcli",
                    "connection",
                    "modify",
                    uuid,
                    "connection.autoconnect-priority",
                    str(priority),
                ],
                capture_output=True,
                text=True,
            )

            if result.returncode == 0:
                return {"success": True, "message": f"Priority set to {priority}"}
            else:
                return {"success": False, "error": result.stderr}
        else:
            return {"success": False, "error": "Network not found"}

    except Exception as e:
        return {"success": False, "error": str(e)}


def make_permanent_ap() -> Dict[str, Any]:
    """Convert temporary AP mode to permanent"""
    try:
        # Remove the fallback flag
        if FALLBACK_FLAG_FILE.exists():
            os.remove(FALLBACK_FLAG_FILE)

        return {
            "success": True,
            "message": (
                "AP mode is now permanent. The device will stay in AP mode "
                "on future boots."
            ),
        }
    except Exception as e:
        return {"success": False, "error": str(e)}


def retry_client_mode() -> Dict[str, Any]:
    """Retry client mode connection"""
    try:
        # Remove fallback flag
        if FALLBACK_FLAG_FILE.exists():
            os.remove(FALLBACK_FLAG_FILE)

        # Set mode to client
        if DROIDNET_MODE_FILE_BOOT.parent.exists():
            with open(DROIDNET_MODE_FILE_BOOT, "w") as f:
                f.write("client")
        else:
            # Fallback location
            DROIDNET_MODE_FILE.parent.mkdir(parents=True, exist_ok=True)
            with open(DROIDNET_MODE_FILE, "w") as f:
                f.write("client")

        # Trigger mode switch
        if SWITCH_NETWORK_MODE_SCRIPT.exists():
            result = subprocess.run(
                ["sudo", str(SWITCH_NETWORK_MODE_SCRIPT), "client"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode == 0:
                return {
                    "success": True,
                    "message": "Retrying WiFi connection. Please wait...",
                }
            else:
                return {
                    "success": True,
                    "message": "WiFi retry initiated. The network is restarting.",
                    "warning": "Mode switch in progress",
                }
        else:
            # Restart network controller
            subprocess.run(
                ["sudo", "systemctl", "restart", "droidnet-network-controller"],
                check=False,
            )
            return {
                "success": True,
                "message": (
                    "WiFi retry initiated. Please wait for the network to restart."
                ),
            }
    except Exception as e:
        return {"success": False, "error": str(e)}


def update_network_config(data: Dict[str, Any]) -> Dict[str, Any]:
    """Update network configuration settings"""
    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)

        config_file = CONFIG_DIR / "network.json"

        # Load existing config
        if config_file.exists():
            with open(config_file, "r") as f:
                config = json.load(f)
        else:
            config = {
                "mode": "auto",
                "ap_timeout": 60,
                "check_interval": 30,
                "ap_ssid_format": "DROIDNET-%MAC%",
                "ap_password": "droidnet123",
                "ap_channel": 6,
            }

        # Update only provided fields
        if "ap_timeout" in data:
            timeout = int(data["ap_timeout"])
            if timeout < 10 or timeout > 600:
                return {
                    "success": False,
                    "error": "AP timeout must be between 10 and 600 seconds",
                }
            config["ap_timeout"] = timeout

        if "check_interval" in data:
            interval = int(data["check_interval"])
            if interval < 10 or interval > 300:
                return {
                    "success": False,
                    "error": "Check interval must be between 10 and 300 seconds",
                }
            config["check_interval"] = interval

        if "ap_channel" in data:
            channel = int(data["ap_channel"])
            if channel < 1 or channel > 11:
                return {
                    "success": False,
                    "error": "AP channel must be between 1 and 11",
                }
            config["ap_channel"] = channel

        # Save updated config
        with open(config_file, "w") as f:
            json.dump(config, f, indent=2)

        # Note: network-controller.sh doesn't use this JSON config
        # It reads mode from /boot/firmware/droidnet-mode directly
        # This config is kept for backwards compatibility

        return {"success": True, "message": "Network configuration updated"}
    except Exception as e:
        return {"success": False, "error": str(e)}
