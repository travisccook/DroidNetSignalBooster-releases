"""
DroidNet Signal Booster - Comlink Handlers
Functions for Comlink configuration, status, and command handling
"""

import os
import sys
import json
import subprocess
import time
import socket
import logging
import re
import serial
from typing import Dict, Any, Optional, List

from config.constants import PROJECT_ROOT, SCRIPTS_DIR, CONFIG_DIR, DATA_DIR

# Add parent directory to path for imports
sys.path.insert(0, str(PROJECT_ROOT))
sys.path.insert(0, str(SCRIPTS_DIR))

# Get logger
logger = logging.getLogger(__name__)

# Import gpio_serial at module level with error handling
try:
    from gpio_serial import send_gpio_serial
    GPIO_SERIAL_AVAILABLE = True
except ImportError:
    GPIO_SERIAL_AVAILABLE = False
    logger.warning("gpio_serial module not available")

# Module-level variables (set by server.py after import)
serial_port_manager = None
get_serial_devices = None


def get_comlink_config() -> Dict[str, Any]:
    """Get Comlink configuration"""
    try:
        config_path = str(CONFIG_DIR / "comlink_config.json")

        # Default configuration
        default_config = {
            "enabled": False,
            "command_port": 8080,
            "discovery_port": 8081,
            "default_target": "usb",
            "default_usb_port": "",
            "default_gpio_pin": 27,
            "default_baud_rate": 9600,
            "history_size": 1000,
            "discovery_interval": 5,
            "command_timeout": 100,
            "add_cr_termination": True,
        }

        if os.path.exists(config_path):
            with open(config_path, "r") as f:
                saved_config = json.load(f)
                # Merge with defaults to ensure all keys exist
                default_config.update(saved_config)

        return {"success": True, "config": default_config}
    except Exception as e:
        logger.error(f"Error getting Comlink config: {e}")
        return {"success": False, "error": str(e)}


def update_comlink_config(data: Dict[str, Any]) -> Dict[str, Any]:
    """Update Comlink configuration"""
    try:
        config_path = str(CONFIG_DIR / "comlink_config.json")
        os.makedirs(os.path.dirname(config_path), exist_ok=True)

        # Get current config
        current_result = get_comlink_config()
        if not current_result["success"]:
            return current_result

        current_config = current_result["config"]

        # Update with new values
        current_config.update(data)

        # Save config
        with open(config_path, "w") as f:
            json.dump(current_config, f, indent=4)

        # If enabling/disabling, start/stop the service
        if "enabled" in data:
            if data["enabled"]:
                # Start and enable Comlink service
                subprocess.run(["systemctl", "enable", "droidnet-comlink"], check=False)
                subprocess.run(["systemctl", "start", "droidnet-comlink"], check=False)

                # Verify service actually started (wait up to 3 seconds)
                for _ in range(6):
                    time.sleep(0.5)
                    result = subprocess.run(
                        ["systemctl", "is-active", "droidnet-comlink"],
                        capture_output=True,
                        text=True,
                    )
                    status = result.stdout.strip()
                    if status == "active":
                        break
                    if status == "failed":
                        # Service failed to start - get error message
                        log_result = subprocess.run(
                            ["journalctl", "-u", "droidnet-comlink", "-n", "5", "--no-pager"],
                            capture_output=True,
                            text=True,
                        )
                        error_log = log_result.stdout.strip()
                        logger.error(f"Comlink service failed to start: {error_log}")
                        return {
                            "success": False,
                            "error": "Service failed to start. Check logs for details.",
                            "log": error_log[-500:] if len(error_log) > 500 else error_log,
                        }
                else:
                    # Service didn't reach "active" state in time
                    result = subprocess.run(
                        ["systemctl", "is-active", "droidnet-comlink"],
                        capture_output=True,
                        text=True,
                    )
                    if result.stdout.strip() != "active":
                        return {
                            "success": False,
                            "error": f"Service not running (status: {result.stdout.strip()})",
                        }
            else:
                # Stop and disable Comlink service
                subprocess.run(["systemctl", "stop", "droidnet-comlink"], check=False)
                subprocess.run(
                    ["systemctl", "disable", "droidnet-comlink"], check=False
                )
        else:
            # If service is enabled and config changed, restart it to pick up
            # new settings
            if current_config.get("enabled", False):
                # Check if service is running
                result = subprocess.run(
                    ["systemctl", "is-active", "droidnet-comlink"],
                    capture_output=True,
                    text=True,
                )
                if result.stdout.strip() == "active":
                    # Restart the service to pick up new configuration
                    subprocess.run(
                        ["systemctl", "restart", "droidnet-comlink"], check=False
                    )
                    logger.info(
                        "Restarted Comlink service to apply configuration changes"
                    )

        return {"success": True}
    except Exception as e:
        logger.error(f"Error updating Comlink config: {e}")
        return {"success": False, "error": str(e)}


def get_comlink_status() -> Dict[str, Any]:
    """Get Comlink service status"""
    try:
        # Check if service is running
        result = subprocess.run(
            ["systemctl", "is-active", "droidnet-comlink"],
            capture_output=True,
            text=True,
        )
        service_running = result.stdout.strip() == "active"

        # Get device name and IP
        hostname = socket.gethostname()
        try:
            ip_address = socket.gethostbyname(hostname + ".local")
        except Exception:
            # Fallback to getting IP from network interface
            ip_address = (
                subprocess.run(["hostname", "-I"], capture_output=True, text=True)
                .stdout.strip()
                .split()[0]
                if subprocess.run(
                    ["hostname", "-I"], capture_output=True, text=True
                ).stdout.strip()
                else "Unknown"
            )

        # Get command count from history
        history_path = str(DATA_DIR / "comlink_history.json")
        commands_received = 0
        if os.path.exists(history_path):
            try:
                with open(history_path, "r") as f:
                    history = json.load(f)
                    commands_received = len(history.get("commands", []))
            except Exception:
                pass

        # Get active devices (this would be populated by the Comlink service)
        active_devices = []
        devices_path = str(DATA_DIR / "comlink_devices.json")
        if os.path.exists(devices_path):
            try:
                with open(devices_path, "r") as f:
                    devices_data = json.load(f)
                    # Filter devices seen in last 5 minutes (300 seconds)
                    current_time = time.time()
                    active_devices = [
                        d
                        for d in devices_data.get("devices", [])
                        if current_time - d.get("last_seen", 0) < 300
                    ]
            except Exception:
                pass

        return {
            "success": True,
            "status": {
                "service_running": service_running,
                "device_name": hostname,
                "ip_address": ip_address,
                "commands_received": commands_received,
                "active_devices": active_devices,
            },
        }
    except Exception as e:
        logger.error(f"Error getting Comlink status: {e}")
        return {"success": False, "error": str(e)}


def get_comlink_devices() -> Dict[str, Any]:
    """Get list of Comlink devices from the tracking file"""
    try:
        devices_path = str(DATA_DIR / "comlink_devices.json")

        if not os.path.exists(devices_path):
            return {"success": True, "devices": []}

        with open(devices_path, "r") as f:
            data = json.load(f)
            devices = data.get("devices", [])

        # Add relative time for last seen
        current_time = time.time()
        for device in devices:
            if "last_seen" in device:
                time_diff = current_time - device["last_seen"]
                if time_diff < 60:
                    device["last_seen_text"] = f"{int(time_diff)}s ago"
                elif time_diff < 3600:
                    device["last_seen_text"] = f"{int(time_diff / 60)}m ago"
                else:
                    device["last_seen_text"] = f"{int(time_diff / 3600)}h ago"

        return {"success": True, "devices": devices}
    except Exception as e:
        logger.error(f"Error getting Comlink devices: {e}")
        return {"success": False, "error": str(e)}


def get_comlink_history(filter_type: str = "all") -> Dict[str, Any]:
    """Get Comlink command history with filtering"""
    try:
        history_path = str(DATA_DIR / "comlink_history.json")

        if not os.path.exists(history_path):
            return {
                "success": True,
                "history": [],
                "statistics": {
                    "total_commands": 0,
                    "commands_today": 0,
                    "last_command_time": None,
                    "unique_commands": 0,
                    "top_commands": [],
                },
            }

        with open(history_path, "r") as f:
            data = json.load(f)
            all_commands = data.get("commands", [])

        # Filter commands based on time
        current_time = time.time()
        filtered_commands = []

        for cmd in all_commands:
            cmd_time = cmd.get("timestamp", 0)
            time_diff = current_time - cmd_time

            if filter_type == "hour" and time_diff <= 3600:
                filtered_commands.append(cmd)
            elif filter_type == "day" and time_diff <= 86400:
                filtered_commands.append(cmd)
            elif filter_type == "week" and time_diff <= 604800:
                filtered_commands.append(cmd)
            elif filter_type == "all":
                filtered_commands.append(cmd)

        # Sort by timestamp, newest first
        filtered_commands.sort(key=lambda x: x.get("timestamp", 0), reverse=True)

        # Calculate statistics
        stats = calculate_comlink_statistics(all_commands)

        return {
            "success": True,
            "history": filtered_commands[:100],  # Return max 100 most recent
            "statistics": stats,
        }
    except Exception as e:
        logger.error(f"Error getting Comlink history: {e}")
        return {"success": False, "error": str(e)}


def calculate_comlink_statistics(commands: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Calculate statistics from command history"""
    if not commands:
        return {
            "total_commands": 0,
            "commands_today": 0,
            "last_command_time": None,
            "unique_commands": 0,
            "top_commands": [],
        }

    total = len(commands)

    # Commands today
    today_start = time.time() - (time.time() % 86400)
    commands_today = sum(
        1 for cmd in commands if cmd.get("timestamp", 0) >= today_start
    )

    # Last command time
    last_command_time = None
    if commands:
        # Commands should already be sorted by timestamp
        most_recent = max(commands, key=lambda x: x.get("timestamp", 0))
        last_command_time = most_recent.get("timestamp", 0)

    # Unique commands
    unique_commands_set = set()
    command_counts = {}
    for cmd in commands:
        command_text = cmd.get("command", "")
        if command_text:
            unique_commands_set.add(command_text)
            command_counts[command_text] = command_counts.get(command_text, 0) + 1

    # Top commands
    top_commands = sorted(command_counts.items(), key=lambda x: x[1], reverse=True)[:10]
    top_commands = [{"command": cmd, "count": count} for cmd, count in top_commands]

    return {
        "total_commands": total,
        "commands_today": commands_today,
        "last_command_time": last_command_time,
        "unique_commands": len(unique_commands_set),
        "top_commands": top_commands,
    }


def clear_comlink_history() -> Dict[str, Any]:
    """Clear all Comlink command history"""
    try:
        history_path = str(DATA_DIR / "comlink_history.json")

        # Create empty history
        empty_history = {"commands": [], "cleared_at": time.time()}

        os.makedirs(os.path.dirname(history_path), exist_ok=True)
        with open(history_path, "w") as f:
            json.dump(empty_history, f, indent=4)

        return {"success": True}
    except Exception as e:
        logger.error(f"Error clearing Comlink history: {e}")
        return {"success": False, "error": str(e)}


def send_comlink_command(data: Dict[str, Any]) -> Dict[str, Any]:
    """Send a command through Comlink (for testing from web interface)"""
    try:
        # Get Comlink config
        config_result = get_comlink_config()
        if not config_result["success"]:
            return config_result

        config = config_result["config"]

        # Determine target
        target = data.get("target") or config["default_target"]
        command = data.get("payload", "")

        if not command:
            return {"success": False, "error": "No command specified"}

        # Add CR termination if needed
        if config["add_cr_termination"] and not command.endswith("\r"):
            command += "\r"

        # Send to appropriate output
        if target == "usb":
            port = data.get("port") or config["default_usb_port"]
            if not port:
                # Auto-detect first available serial port
                devices = get_serial_devices()
                if devices:
                    port = devices[0]["port"]
                else:
                    return {"success": False, "error": "No USB serial device found"}

            # Use SerialPortManager for coordinated access with persistent event loop
            logger.info(f"Sending Comlink command '{command}' to port {port}")

            # Get saved baud rate or use default
            default_baud = config.get("default_baud_rate", 115200)

            # Use synchronous wrapper that runs in persistent event loop
            success, used_baud = serial_port_manager.send_to_port_sync(
                port, command, default_baud
            )

            if success:
                logger.info(f"Comlink command sent successfully at {used_baud} baud")
                result = {"success": True, "baud_rate": used_baud}
            else:
                result = {"success": False, "error": "Failed to send command"}
        else:
            # Send via GPIO
            gpio_pin = data.get("gpio_pin") or config["default_gpio_pin"]
            result = send_gpio_serial_command(
                gpio_pin, command, config["default_baud_rate"]
            )

        # Log to history
        log_comlink_command(
            command, data.get("source", "web_interface"), target, result["success"]
        )

        return result
    except Exception as e:
        logger.error(f"Error sending Comlink command: {e}")
        return {"success": False, "error": str(e)}


def clean_command_string(cmd_str: str) -> str:
    """Clean command string to ensure it's JSON-safe"""
    if not isinstance(cmd_str, str):
        return str(cmd_str)

    # Remove any control characters except common ones (tab, newline, carriage return)
    # Remove ASCII control characters (except \t, \n, \r)
    cleaned = re.sub(r"[\x00-\x08\x0B-\x0C\x0E-\x1F\x7F-\x9F]", "", cmd_str)

    # Remove Unicode control characters and format characters
    # This includes zero-width spaces, directional marks, etc.
    cleaned = re.sub(r"[\u200B-\u200F\u2028-\u202F\u205F-\u206F\uFEFF]", "", cleaned)

    # Strip trailing whitespace
    cleaned = cleaned.rstrip()

    return cleaned


def log_comlink_command(command: str, source: str, target: str, success: bool) -> None:
    """Log a command to Comlink history"""
    try:
        history_path = str(DATA_DIR / "comlink_history.json")

        # Load existing history
        if os.path.exists(history_path):
            with open(history_path, "r") as f:
                data = json.load(f)
        else:
            data = {"commands": []}

        # Add new command
        data["commands"].append(
            {
                "timestamp": time.time(),
                "command": clean_command_string(command),
                "source": source,
                "target": target,
                "status": "success" if success else "error",
            }
        )

        # Keep only last N commands based on config
        config_result = get_comlink_config()
        max_history = (
            config_result["config"]["history_size"]
            if config_result["success"]
            else 1000
        )

        if len(data["commands"]) > max_history:
            data["commands"] = data["commands"][-max_history:]

        # Save updated history
        os.makedirs(os.path.dirname(history_path), exist_ok=True)
        with open(history_path, "w") as f:
            json.dump(data, f, indent=4)

    except Exception as e:
        logger.error(f"Error logging Comlink command: {e}")


def send_serial_command(port: str, command: str, baud_rate: int) -> Dict[str, Any]:
    """Send command to USB serial port"""
    try:
        # Direct serial connection - simpler and more reliable for test commands
        logger.info(f"Sending command to {port}: {repr(command)}")

        with serial.Serial(port, baud_rate, timeout=1) as ser:
            ser.write(command.encode())
            ser.flush()

            # Wait briefly for echo
            time.sleep(0.1)

            # Try to read any echo response
            if ser.in_waiting:
                echo = ser.read(ser.in_waiting)
                logger.info(
                    f"Serial echo from {port}: {echo.decode('utf-8', errors='ignore')}"
                )

        return {"success": True}
    except Exception as e:
        logger.error(f"Error sending serial command to {port}: {e}")
        return {"success": False, "error": str(e)}


def send_gpio_serial_command(gpio_pin: int, command: str, baud_rate: int = 9600) -> Dict[str, Any]:
    """Send command via GPIO software serial"""
    try:
        # Check if GPIO serial is available
        if not GPIO_SERIAL_AVAILABLE:
            return {"success": False, "error": "GPIO serial module not available"}

        # Send command
        success = send_gpio_serial(gpio_pin, command, baud_rate)

        if success:
            return {"success": True}
        else:
            return {"success": False, "error": "Failed to send GPIO serial command"}

    except Exception as e:
        logger.error(f"Error sending GPIO serial command: {e}")
        return {"success": False, "error": str(e)}
