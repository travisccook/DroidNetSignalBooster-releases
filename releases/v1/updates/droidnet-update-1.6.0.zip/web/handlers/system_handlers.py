"""
DroidNet Signal Booster - System Handlers
Functions for system status, monitoring, and information
"""

import os
import sys
import json
import subprocess
import threading
import time
import logging
import re
from typing import Dict, Any, Optional
from collections import deque
from dataclasses import dataclass

from config.constants import PROJECT_ROOT, FALLBACK_FLAG_FILE
from handlers.device_handlers import get_usb_devices
from handlers.network_handlers import get_wifi_status

# Add parent directory to path for imports
sys.path.insert(0, str(PROJECT_ROOT))

# Get logger
logger = logging.getLogger(__name__)

# System metrics history configuration
SYSTEM_HISTORY_MAX_SAMPLES = 180


@dataclass
class SystemMetricsSample:
    """A single sample of system metrics for history tracking"""

    timestamp: float
    cpu_usage: float
    memory_percentage: float
    disk_percentage: float
    temperature: float


# Global state for metrics history
system_metrics_history: deque = deque(maxlen=SYSTEM_HISTORY_MAX_SAMPLES)
last_metrics_update: float = 0
metrics_lock = threading.Lock()  # Thread safety for metrics history

# Module-level manager references (set by server.py after initialization)
# This avoids circular import issues when server.py runs as __main__
serial_port_manager = None
maestro_manager = None


def get_pi_model() -> str:
    """Detect Raspberry Pi model from /proc/cpuinfo"""
    try:
        with open("/proc/cpuinfo", "r") as f:
            cpuinfo = f.read()

        # Check for specific models
        if "Pi Zero W" in cpuinfo and "BCM2835" in cpuinfo:
            return "pi_zero_w"
        elif "Pi Zero 2" in cpuinfo:
            return "pi_zero_2"
        elif "Pi 3" in cpuinfo:
            return "pi_3"
        elif "Pi 4" in cpuinfo:
            return "pi_4"

        # Fallback detection by revision codes
        for line in cpuinfo.split("\n"):
            if line.startswith("Revision"):
                revision = line.split(":")[1].strip()
                # Common revision codes
                if revision in ["9000c1", "900092", "900093"]:  # Pi Zero W
                    return "pi_zero_w"
                elif revision in ["902120"]:  # Pi Zero 2 W
                    return "pi_zero_2"
                elif revision in ["a02082", "a22082", "a32082", "a52082"]:  # Pi 3B/3B+
                    return "pi_3"
                elif revision in [
                    "a03111",
                    "b03111",
                    "c03111",
                    "c03112",
                    "c03114",
                ]:  # Pi 4
                    return "pi_4"

    except (OSError, FileNotFoundError) as e:
        logger.warning(f"Could not read /proc/cpuinfo to detect Pi model: {e}")

    return "unknown"


def get_system_status() -> Dict[str, Any]:
    """Get overall system status"""
    try:
        logger.debug("Getting system status")
        # Check network connectivity
        connected = False
        ap_mode = True

        # Check if connected to external network
        result = subprocess.run(["iwgetid"], capture_output=True, text=True)
        if result.returncode == 0 and result.stdout.strip():
            connected = True
            ap_mode = False

        # Check if AP mode is due to fallback
        is_fallback = FALLBACK_FLAG_FILE.exists()
        fallback_reason = None
        if is_fallback and ap_mode:
            fallback_reason = "No saved networks found"

        return {
            "connected": connected,
            "ap_mode": ap_mode,
            "is_fallback": is_fallback,
            "fallback_reason": fallback_reason,
            "uptime": get_uptime(),
            "load": get_load_average(),
            "pi_model": get_pi_model(),  # For frontend polling adaptation
        }
    except (subprocess.CalledProcessError, OSError, FileNotFoundError) as e:
        logger.error(f"Error reading system status: {e}", exc_info=True)
        return {"error": str(e)}


def get_uptime() -> int:
    """Get system uptime"""
    try:
        with open("/proc/uptime", "r") as f:
            uptime_seconds = float(f.readline().split()[0])
            return int(uptime_seconds)
    except (OSError, IOError, ValueError, IndexError):
        return 0


def get_load_average() -> float:
    """Get system load average"""
    try:
        with open("/proc/loadavg", "r") as f:
            return float(f.readline().split()[0])
    except (OSError, IOError, ValueError, IndexError):
        return 0.0


def get_cpu_usage() -> int:
    """Get CPU usage percentage"""
    try:
        # Read /proc/stat for CPU usage
        with open("/proc/stat", "r") as f:
            line = f.readline()
            if line.startswith("cpu "):
                parts = line.split()
                # user, nice, system, idle, iowait, irq, softirq
                user = int(parts[1])
                nice = int(parts[2])
                system = int(parts[3])
                idle = int(parts[4])
                iowait = int(parts[5]) if len(parts) > 5 else 0

                total = user + nice + system + idle + iowait
                _active = user + nice + system  # noqa: F841

                # Calculate percentage (approximate since we only have one sample)
                if total > 0:
                    # Use load average as a proxy for a single-sample read
                    load = get_load_average()
                    # Approximate: load of 1.0 = 100% on single core
                    # Pi has 4 cores, so divide by 4 for overall percentage
                    return min(100, int(load * 25))
        return 0
    except Exception:
        return 0


def get_memory_usage() -> Dict[str, int]:
    """Get memory usage info"""
    try:
        with open("/proc/meminfo", "r") as f:
            meminfo = {}
            for line in f:
                parts = line.split()
                if len(parts) >= 2:
                    key = parts[0].rstrip(":")
                    value = int(parts[1])  # Value in kB
                    meminfo[key] = value

            total = meminfo.get("MemTotal", 0)
            free = meminfo.get("MemFree", 0)
            buffers = meminfo.get("Buffers", 0)
            cached = meminfo.get("Cached", 0)

            # Available memory = free + buffers + cached
            available = free + buffers + cached
            used = total - available

            if total > 0:
                percentage = int((used / total) * 100)
            else:
                percentage = 0

            return {
                "total_mb": total // 1024,
                "used_mb": used // 1024,
                "available_mb": available // 1024,
                "percentage": percentage,
            }
    except Exception:
        return {"total_mb": 0, "used_mb": 0, "available_mb": 0, "percentage": 0}


def get_cpu_temperature() -> float:
    """Get CPU temperature"""
    try:
        result = subprocess.run(
            ["vcgencmd", "measure_temp"], capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            # Output is like: temp=42.5'C
            temp_str = result.stdout.strip()
            if "=" in temp_str:
                temp_value = temp_str.split("=")[1].replace("'C", "").replace("°C", "")
                return float(temp_value)
    except Exception:
        pass
    return 0.0


def get_disk_usage() -> Dict[str, Any]:
    """Get disk usage for root filesystem"""
    try:
        result = subprocess.run(
            ["df", "-B1", "/"], capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            lines = result.stdout.strip().split("\n")
            if len(lines) >= 2:
                parts = lines[1].split()
                if len(parts) >= 5:
                    total = int(parts[1])
                    used = int(parts[2])
                    available = int(parts[3])
                    percentage = int(parts[4].rstrip("%"))

                    return {
                        "total_gb": round(total / (1024**3), 1),
                        "used_gb": round(used / (1024**3), 1),
                        "available_gb": round(available / (1024**3), 1),
                        "percentage": percentage,
                    }
    except Exception:
        pass
    return {"total_gb": 0, "used_gb": 0, "available_gb": 0, "percentage": 0}


def get_service_status(service_name: str) -> bool:
    """Get status of a systemd service"""
    try:
        result = subprocess.run(
            ["systemctl", "is-active", service_name],
            capture_output=True,
            text=True,
            timeout=5,
        )
        return result.stdout.strip() == "active"
    except Exception:
        return False


def get_services_status_batch(service_names: list) -> Dict[str, bool]:
    """Get status of multiple systemd services in a single call.

    Much more efficient than calling get_service_status() for each service,
    especially on low-powered devices like Pi Zero W where process spawning
    is expensive.
    """
    try:
        # systemctl is-active can check multiple services at once
        result = subprocess.run(
            ["systemctl", "is-active", "--"] + list(service_names),
            capture_output=True,
            text=True,
            timeout=10,
        )
        # Output is one status per line in same order as input
        statuses = result.stdout.strip().split("\n")
        return {
            name: (status == "active") for name, status in zip(service_names, statuses)
        }
    except Exception:
        # Fallback: return all as False
        return {name: False for name in service_names}


def get_services_status_summary() -> Dict[str, bool]:
    """Get lightweight summary of key service states for Droid tab.

    Returns enabled status for Victron, Comlink, and VirtualHere services.
    Optimized for remote device queries.
    """
    # Service name mapping: systemd name -> display name
    service_mapping = {
        "droidnet-virtualhere": "virtualhere",
        "droidnet-comlink": "comlink",
    }

    # Get systemd service statuses in batch
    batch_status = get_services_status_batch(list(service_mapping.keys()))
    services = {
        friendly_name: batch_status.get(service_name, False)
        for service_name, friendly_name in service_mapping.items()
    }

    # Add Victron status - check if monitoring is active via config file
    # (Victron doesn't have a dedicated systemd service, it's in-process)
    try:
        victron_config = "/opt/droidnet/config/victron-config.json"
        if os.path.exists(victron_config):
            with open(victron_config, "r") as f:
                config = json.load(f)
                services["victron"] = config.get("enabled", False)
        else:
            services["victron"] = False
    except Exception as e:
        logger.debug(f"Could not determine Victron status: {e}")
        services["victron"] = False

    # Add Maestro detection - check if any Maestro devices are connected
    # Uses module-level maestro_manager set by server.py
    try:
        if maestro_manager:
            devices = maestro_manager.list_devices()
            services["maestro"] = len(devices) > 0
        else:
            services["maestro"] = False
    except Exception as e:
        logger.debug(f"Could not determine Maestro status: {e}")
        services["maestro"] = False

    # Add WCB detection - check if any WCB listeners are active
    # Uses module-level serial_port_manager set by server.py
    try:
        if serial_port_manager:
            listeners = serial_port_manager.get_all_wcb_listeners()
            services["wcb"] = len(listeners) > 0
        else:
            services["wcb"] = False
    except Exception as e:
        logger.debug(f"Could not determine WCB status: {e}")
        services["wcb"] = False

    return services


def get_wifi_signal_strength() -> Optional[int]:
    """Get WiFi signal strength in dBm"""
    try:
        result = subprocess.run(
            ["iwconfig", "wlan0"], capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            for line in result.stdout.split("\n"):
                if "Signal level" in line:
                    # Parse "Signal level=-45 dBm" or "Signal level=-45"
                    match = re.search(r"Signal level[=:]?\s*(-?\d+)", line)
                    if match:
                        return int(match.group(1))
    except Exception:
        pass
    return None


def get_network_latency() -> Optional[int]:
    """Get network latency to gateway"""
    try:
        # Get default gateway
        result = subprocess.run(
            ["ip", "route", "show", "default"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0 and result.stdout.strip():
            parts = result.stdout.split()
            if "via" in parts:
                gateway_idx = parts.index("via") + 1
                if gateway_idx < len(parts):
                    gateway = parts[gateway_idx]
                    # Ping the gateway
                    ping_result = subprocess.run(
                        ["ping", "-c", "1", "-W", "1", gateway],
                        capture_output=True,
                        text=True,
                        timeout=3,
                    )
                    if ping_result.returncode == 0:
                        # Parse "time=12.3 ms"
                        match = re.search(r"time[=<](\d+\.?\d*)", ping_result.stdout)
                        if match:
                            return round(float(match.group(1)))
    except Exception:
        pass
    return None


def format_uptime(seconds: int) -> str:
    """Format uptime seconds into human-readable string"""
    days = seconds // 86400
    hours = (seconds % 86400) // 3600
    minutes = (seconds % 3600) // 60

    if days > 0:
        return f"{days}d {hours}h {minutes}m"
    elif hours > 0:
        return f"{hours}h {minutes}m"
    else:
        return f"{minutes}m"


def get_dashboard_status() -> Dict[str, Any]:
    """Get comprehensive dashboard status for the new dashboard UI"""
    global last_metrics_update

    try:
        # Get system metrics
        cpu_usage = get_cpu_usage()
        memory = get_memory_usage()
        temperature = get_cpu_temperature()
        disk = get_disk_usage()
        uptime_seconds = get_uptime()

        current_time = time.time()

        # Thread-safe access to metrics history
        with metrics_lock:
            # Record metrics sample for history (throttle to 5-second intervals)
            if current_time - last_metrics_update >= 5:
                sample = SystemMetricsSample(
                    timestamp=current_time,
                    cpu_usage=cpu_usage,
                    memory_percentage=memory["percentage"],
                    disk_percentage=disk["percentage"],
                    temperature=temperature,
                )
                system_metrics_history.append(sample)
                last_metrics_update = current_time

            # Build history arrays for charts (timestamp in milliseconds for JS)
            history = {
                "cpu": [
                    {"x": s.timestamp * 1000, "y": s.cpu_usage}
                    for s in system_metrics_history
                ],
                "memory": [
                    {"x": s.timestamp * 1000, "y": s.memory_percentage}
                    for s in system_metrics_history
                ],
                "disk": [
                    {"x": s.timestamp * 1000, "y": s.disk_percentage}
                    for s in system_metrics_history
                ],
                "temperature": [
                    {"x": s.timestamp * 1000, "y": s.temperature}
                    for s in system_metrics_history
                ],
            }

        wifi_status = get_wifi_status()

        signal_strength = get_wifi_signal_strength()
        latency = get_network_latency()

        # Get USB devices
        usb_devices = get_usb_devices()

        # Get service status - batch call (1 process instead of 9)
        service_mapping = {
            "droidnet-web": "web_server",
            "droidnet-virtualhere": "virtualhere",
            "droidnet-comlink": "comlink",
            "droidnet-network-controller": "network_controller",
            "hostapd": "hostapd",
            "dnsmasq": "dnsmasq",
            "droidnet-monitor": "monitor",
            "avahi-daemon": "avahi",
            "droidnet-rfkill-unblock": "rfkill",
            "bluetooth": "bluetooth",
        }
        batch_status = get_services_status_batch(service_mapping.keys())
        services = {
            friendly_name: batch_status.get(service_name, False)
            for service_name, friendly_name in service_mapping.items()
        }

        # Add Victron monitoring status (not a systemd service - runs in-process)
        try:
            from web.handlers.victron_handlers import get_victron_status

            victron_result = get_victron_status()
            if victron_result.get("success"):
                status = victron_result.get("status", {})
                services["victron"] = status.get("monitoring", False)
            else:
                services["victron"] = False
        except Exception:
            services["victron"] = False

        # Add Display/HDMI status
        try:
            result = subprocess.run(
                ["vcgencmd", "display_power"],
                capture_output=True,
                text=True,
                timeout=2,
            )
            if result.returncode == 0 and "=1" in result.stdout:
                services["display"] = True
            else:
                services["display"] = False
        except Exception:
            services["display"] = False

        # Determine overall health status
        health_status = "healthy"
        if temperature > 70:
            health_status = "warning"
        if temperature > 80 or memory["percentage"] > 90 or disk["percentage"] > 90:
            health_status = "critical"

        return {
            "system": {
                "cpu_usage": cpu_usage,
                "memory": memory,
                "temperature": temperature,
                "disk": disk,
                "uptime_seconds": uptime_seconds,
                "uptime_formatted": format_uptime(uptime_seconds),
                "health_status": health_status,
                "history": history,
                "pi_model": get_pi_model(),  # For frontend polling adaptation
            },
            "network": {
                "mode": wifi_status.get("mode", "Unknown"),
                "ssid": wifi_status.get("ssid", ""),
                "ip": wifi_status.get("ip", ""),
                "state": wifi_status.get("state", "unknown"),
                "signal_dbm": signal_strength,
                "latency_ms": latency,
            },
            "devices": {
                "usb": usb_devices,
                "count": len(usb_devices) if isinstance(usb_devices, list) else 0,
            },
            "services": services,
            "timestamp": time.time(),
        }
    except Exception as e:
        logger.error(f"Error getting dashboard status: {e}", exc_info=True)
        return {"error": str(e)}


def get_top_processes() -> Dict[str, Any]:
    """Get top 5 CPU and memory consuming processes for dashboard"""
    try:
        # Single ps call with both CPU and memory (optimized)
        result = subprocess.run(
            ["ps", "-eo", "pid,comm,%cpu,%mem", "--sort=-%cpu"],
            capture_output=True,
            text=True,
            timeout=5,
        )

        lines = result.stdout.strip().split("\n")[1:11]  # Skip header, get top 10
        all_processes = []

        for line in lines:
            parts = line.split()
            if len(parts) >= 4:
                all_processes.append(
                    {
                        "pid": int(parts[0]),
                        "name": parts[1][:20],  # Truncate long names
                        "cpu": float(parts[2]),
                        "memory": float(parts[3]),
                    }
                )

        # Top 5 by CPU (already sorted)
        cpu_processes = [
            {"pid": p["pid"], "name": p["name"], "cpu": p["cpu"]}
            for p in all_processes[:5]
        ]

        # Top 5 by memory (re-sort)
        by_memory = sorted(all_processes, key=lambda x: x["memory"], reverse=True)[:5]
        memory_processes = [
            {"pid": p["pid"], "name": p["name"], "memory": p["memory"]}
            for p in by_memory
        ]

        return {
            "cpu_processes": cpu_processes,
            "memory_processes": memory_processes,
            "timestamp": time.time(),
        }
    except Exception as e:
        logger.error(f"Error getting top processes: {e}")
        return {"error": str(e), "cpu_processes": [], "memory_processes": []}


def get_current_version() -> str:
    """Get current system version from multiple sources"""
    # Try VERSION file first - check multiple locations
    # (deployed systems use /opt/droidnet, dev uses project root)
    version_paths = [
        str(PROJECT_ROOT / "VERSION"),
        "/opt/droidnet/VERSION",
    ]
    for version_file in version_paths:
        if os.path.exists(version_file):
            try:
                with open(version_file, "r") as f:
                    version = f.read().strip()
                    if version:
                        return version
            except Exception:
                pass

    # Try git hash
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"],
            capture_output=True,
            text=True,
            cwd=str(PROJECT_ROOT),
        )
        if result.returncode == 0 and result.stdout.strip():
            return f"git-{result.stdout.strip()}"
    except Exception:
        pass

    # Check for package.json version
    package_json = str(PROJECT_ROOT / "package.json")
    if os.path.exists(package_json):
        try:
            with open(package_json, "r") as f:
                data = json.load(f)
                if "version" in data:
                    return data["version"]
        except Exception:
            pass

    # Default for development/fresh installs
    return "development"


def get_system_info() -> Dict[str, Any]:
    """Get comprehensive system information"""
    info = {}

    try:
        # Add version info
        info["version"] = get_current_version()

        # Try to get git info
        try:
            git_result = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                capture_output=True,
                text=True,
                cwd=str(PROJECT_ROOT),
            )
            if git_result.returncode == 0:
                info["git_hash"] = git_result.stdout.strip()
        except Exception:
            pass

        # Basic system info
        commands = {
            "hostname": ["hostname"],
            "uptime": ["uptime"],
            "uname": ["uname", "-a"],
            "cpu_info": ["cat", "/proc/cpuinfo"],
            "memory": ["free", "-h"],
            "disk_usage": ["df", "-h"],
            "processes": ["ps", "aux", "--sort=-pcpu"],
            "temperature": ["vcgencmd", "measure_temp"],
            "network_connections": ["netstat", "-tuln"],
            "mounted_filesystems": ["mount"],
            "usb_devices": ["lsusb", "-v"],
            "system_services": [
                "systemctl",
                "list-units",
                "--type=service",
                "--state=running",
            ],
        }

        for key, cmd in commands.items():
            try:
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
                info[key] = {
                    "content": result.stdout
                    if result.returncode == 0
                    else f"Error: {result.stderr}",
                    "status": "success" if result.returncode == 0 else "error",
                }
            except subprocess.TimeoutExpired:
                info[key] = {"content": "Command timed out", "status": "timeout"}
            except Exception as e:
                info[key] = {"content": f"Error: {str(e)}", "status": "error"}

        # DroidNet specific status
        try:
            status_script = str(PROJECT_ROOT / "droidnet-status.sh")
            if os.path.exists(status_script):
                result = subprocess.run(
                    ["bash", status_script], capture_output=True, text=True, timeout=5
                )
                info["droidnet_status"] = {
                    "content": result.stdout,
                    "status": "success" if result.returncode == 0 else "error",
                }
            else:
                info["droidnet_status"] = {
                    "content": "DroidNet status script not found",
                    "status": "error",
                }
        except Exception as e:
            info["droidnet_status"] = {"content": f"Error: {str(e)}", "status": "error"}

        return {
            "info": info,
            "timestamp": subprocess.run(
                ["date", "+%Y-%m-%d %H:%M:%S"], capture_output=True, text=True
            ).stdout.strip(),
        }

    except Exception as e:
        return {"error": f"Failed to get system info: {str(e)}"}
