# DroidNet Signal Booster v1.6 Release Notes

This release improves Maestro servo control accuracy and adds convenience features for managing channel settings.

## Maestro Tab

### Bug Fixes
- **Accurate initial servo positions** - Servo sliders now show the actual device positions immediately when connecting, instead of defaulting to center position until manually adjusted
- **Go Home works on first click** - The Go Home button now correctly moves servos to their home positions without needing to "wiggle" sliders first
- **Center All respects channel configuration** - Center All now moves each servo to the true center of its configured min/max range, rather than assuming 1500µs for all servos
- **Center All skips disabled servos** - Disabled servos are no longer inadvertently enabled when clicking Center All
- **Position indicator alignment** - The green "actual position" dot now properly aligns with the blue slider thumb

### New Features
- **Expand All / Collapse All buttons** - New buttons in the Servo Control header to quickly show or hide the settings panel for all visible channels
