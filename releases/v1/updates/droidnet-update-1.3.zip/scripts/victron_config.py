#!/usr/bin/env python3
"""
Victron Smart Shunt Configuration Manager

Manages Victron device configuration and persistence.
"""

import json
import fcntl
import tempfile
import os
from pathlib import Path
from typing import Dict, Optional, Any

from config.constants import TIMEOUT_HISTORY_HOUR_SECONDS

CONFIG_DIR = Path("/opt/droidnet/config")
VICTRON_CONFIG_FILE = CONFIG_DIR / "victron-config.json"
VICTRON_LOCK_FILE = CONFIG_DIR / ".victron-config.lock"

# Default configuration
DEFAULT_VICTRON_CONFIG = {
    "enabled": False,  # Feature-level enable/disable (hides tab when disabled)
    "device": None,
    "history_retention_seconds": TIMEOUT_HISTORY_HOUR_SECONDS,
    "update_interval": 1.0,  # 1 second
    "auto_start": True,
}


def ensure_config_dir() -> None:
    """Ensure the configuration directory exists."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def load_victron_config() -> Dict[str, Any]:
    """
    Load Victron configuration from file with shared locking.

    Returns:
        Dict containing Victron configuration
    """
    ensure_config_dir()

    if not VICTRON_CONFIG_FILE.exists():
        # Create default config if it doesn't exist
        save_victron_config(DEFAULT_VICTRON_CONFIG)
        return DEFAULT_VICTRON_CONFIG.copy()

    try:
        # Use shared lock for reading (allows multiple readers)
        with open(VICTRON_LOCK_FILE, "w") as lock_file:
            fcntl.flock(lock_file.fileno(), fcntl.LOCK_SH)
            try:
                with open(VICTRON_CONFIG_FILE, "r") as f:
                    config: Dict[str, Any] = json.load(f)
                    # Ensure all required fields exist
                    for key, default_value in DEFAULT_VICTRON_CONFIG.items():
                        if key not in config:
                            config[key] = default_value
                    return config
            finally:
                fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)
    except (json.JSONDecodeError, IOError) as e:
        print(f"Error loading Victron config: {e}")
        return DEFAULT_VICTRON_CONFIG.copy()


def save_victron_config(config: Dict[str, Any]) -> bool:
    """
    Save Victron configuration to file atomically with file locking.

    Uses a lock file to prevent race conditions when multiple requests
    try to save simultaneously. Writes to a temp file first, then
    atomically renames to prevent corruption.

    Args:
        config: Configuration dictionary to save

    Returns:
        True if successful, False otherwise
    """
    ensure_config_dir()

    try:
        # Validate config has required fields
        for key in DEFAULT_VICTRON_CONFIG:
            if key not in config:
                config[key] = DEFAULT_VICTRON_CONFIG[key]

        # Use file locking to prevent race conditions
        with open(VICTRON_LOCK_FILE, "w") as lock_file:
            fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX)
            try:
                # Write to temp file first
                fd, temp_path = tempfile.mkstemp(
                    dir=CONFIG_DIR, prefix=".victron-config-", suffix=".tmp"
                )
                try:
                    with os.fdopen(fd, "w") as f:
                        json.dump(config, f, indent=2)
                    # Atomic rename
                    os.rename(temp_path, VICTRON_CONFIG_FILE)
                except Exception:
                    # Clean up temp file on error
                    if os.path.exists(temp_path):
                        os.unlink(temp_path)
                    raise
            finally:
                fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)
        return True
    except IOError as e:
        print(f"Error saving Victron config: {e}")
        return False


def get_victron_device() -> Optional[Dict[str, Any]]:
    """
    Get configured Victron device.

    Returns:
        Device configuration dict or None if not configured
    """
    config = load_victron_config()
    return config.get("device")


def update_victron_device(
    mac: str, encryption_key: str, name: str = "Smart Shunt", enabled: bool = True
) -> bool:
    """
    Update Victron device configuration.

    Args:
        mac: Device MAC address (AA:BB:CC:DD:EE:FF format)
        encryption_key: 32-character hexadecimal encryption key
        name: Friendly name for the device
        enabled: Whether monitoring is enabled

    Returns:
        True if successful, False otherwise
    """
    # Validate MAC address format
    if not _validate_mac_address(mac):
        print(f"Invalid MAC address format: {mac}")
        return False

    # Validate encryption key (32 hex chars)
    if not _validate_encryption_key(encryption_key):
        print("Invalid encryption key: must be 32 hexadecimal characters")
        return False

    config = load_victron_config()
    config["device"] = {
        "mac": mac.upper(),  # Normalize to uppercase
        "encryption_key": encryption_key.lower(),  # Normalize to lowercase
        "name": name,
        "enabled": enabled,
    }

    return save_victron_config(config)


def delete_victron_device() -> bool:
    """
    Delete Victron device configuration.

    Returns:
        True if successful, False otherwise
    """
    config = load_victron_config()
    config["device"] = None
    return save_victron_config(config)


def is_victron_enabled() -> bool:
    """
    Check if Victron monitoring is enabled.

    Returns:
        True if device is configured and enabled, False otherwise
    """
    device = get_victron_device()
    if device is None:
        return False
    return device.get("enabled", False)


def is_victron_feature_enabled() -> bool:
    """
    Check if the Victron feature is enabled (feature-level toggle).

    This controls whether the Victron tab is shown at all.

    Returns:
        True if feature is enabled, False otherwise
    """
    config = load_victron_config()
    return config.get("enabled", False)


def update_victron_feature_enabled(enabled: bool) -> bool:
    """
    Update the Victron feature enabled state (feature-level toggle).

    Args:
        enabled: True to enable the feature, False to disable

    Returns:
        True if successful, False otherwise
    """
    config = load_victron_config()
    config["enabled"] = enabled
    return save_victron_config(config)


def update_history_retention(seconds: int) -> bool:
    """
    Update the history retention period in seconds.

    Args:
        seconds: Number of seconds to retain history (60-86400)

    Returns:
        True if successful, False otherwise
    """
    # Validate range (1 minute to 24 hours)
    if seconds < 60 or seconds > 86400:
        print(f"Invalid retention period: {seconds} (must be 60-86400)")
        return False

    config = load_victron_config()
    config["history_retention_seconds"] = seconds
    return save_victron_config(config)


def update_auto_start(enabled: bool) -> bool:
    """
    Update auto-start setting.

    Args:
        enabled: True to auto-start monitoring on boot

    Returns:
        True if successful, False otherwise
    """
    config = load_victron_config()
    config["auto_start"] = enabled
    return save_victron_config(config)


def _validate_mac_address(mac: str) -> bool:
    """
    Validate MAC address format.

    Args:
        mac: MAC address string

    Returns:
        True if valid, False otherwise
    """
    import re

    # Accept formats: AA:BB:CC:DD:EE:FF or AA-BB-CC-DD-EE-FF
    pattern = r"^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$"
    return bool(re.match(pattern, mac))


def _validate_encryption_key(key: str) -> bool:
    """
    Validate encryption key format.

    Args:
        key: Encryption key string

    Returns:
        True if valid (32 hex chars), False otherwise
    """
    import re

    # Must be exactly 32 hexadecimal characters
    pattern = r"^[0-9A-Fa-f]{32}$"
    return bool(re.match(pattern, key))


def _handle_command(command: str, args: list) -> None:
    """Handle command line interface."""
    if command == "status":
        config = load_victron_config()
        print(json.dumps(config, indent=2))

    elif command == "device" and len(args) >= 2:
        mac = args[0]
        key = args[1]
        name = args[2] if len(args) > 2 else "Smart Shunt"
        if update_victron_device(mac, key, name):
            print(f"Device configured: {name} ({mac})")
        else:
            print("Failed to configure device")

    elif command == "delete":
        if delete_victron_device():
            print("Device configuration deleted")
        else:
            print("Failed to delete device")

    elif command == "retention" and len(args) > 0:
        seconds = int(args[0])
        if update_history_retention(seconds):
            print(f"History retention set to {seconds} seconds")
        else:
            print("Failed to update retention")

    elif command == "autostart" and len(args) > 0:
        enabled = args[0].lower() == "true"
        if update_auto_start(enabled):
            print(f"Auto-start {'enabled' if enabled else 'disabled'}")
        else:
            print("Failed to update auto-start")

    else:
        print("Usage:")
        print(
            "  victron_config.py status                          - Show current config"
        )
        print("  victron_config.py device <mac> <key> [name]       - Configure device")
        print("  victron_config.py delete                          - Delete device")
        print(
            "  victron_config.py retention <seconds>             - Set history retention"
        )
        print("  victron_config.py autostart true|false            - Set auto-start")


if __name__ == "__main__":
    # Test/debug functionality
    import sys

    if len(sys.argv) > 1:
        _handle_command(sys.argv[1], sys.argv[2:])
    else:
        # Default: show status
        config = load_victron_config()
        print(json.dumps(config, indent=2))
