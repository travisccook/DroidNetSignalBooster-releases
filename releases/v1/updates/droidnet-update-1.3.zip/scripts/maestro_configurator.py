#!/usr/bin/env python3
"""
Pololu Maestro Native USB Configurator
Provides access to device configuration via USB control transfers
"""

import usb.core
import usb.util
import struct
import logging
from typing import Optional, List, Dict, Any
from dataclasses import dataclass
from enum import IntEnum

logger = logging.getLogger(__name__)

POLOLU_VENDOR_ID = 0x1FFB


class UscRequest(IntEnum):
    """USB control transfer request types"""

    GET_PARAMETER = 0x81
    SET_PARAMETER = 0x82
    GET_VARIABLES = 0x83
    SET_SERVO_VARIABLE = 0x84
    SET_TARGET = 0x85
    CLEAR_ERRORS = 0x86
    GET_SERVO_SETTINGS = 0x87
    GET_STACK = 0x88
    GET_CALL_STACK = 0x89
    SET_PWM = 0x8A
    REINITIALIZE = 0x90
    ERASE_SCRIPT = 0xA0
    WRITE_SCRIPT = 0xA1
    SET_SCRIPT_DONE = 0xA2
    RESTART_SCRIPT_AT_SUBROUTINE = 0xA3
    RESTART_SCRIPT_AT_SUBROUTINE_WITH_PARAM = 0xA4
    RESTART_SCRIPT = 0xA5
    START_BOOTLOADER = 0xFF


class UscParameter(IntEnum):
    """
    Device parameter IDs per Pololu SDK (Usc.h / protocol.h).

    IMPORTANT: These must match the Pololu SDK exactly.
    Hardware testing confirmed parameter 3 returns serial mode data
    while parameter 0 returns zeros (it's PARAMETER_INITIALIZED, not for general use).
    """

    # Serial settings (verified against Pololu SDK)
    SERIAL_MODE = 3
    SERIAL_FIXED_BAUD_RATE = 4
    SERIAL_TIMEOUT = 6
    SERIAL_ENABLE_CRC = 8
    SERIAL_NEVER_SUSPEND = 9
    SERIAL_DEVICE_NUMBER = 10
    SERIAL_MINI_SSC_OFFSET = 11

    # Mini Maestro servo period (2 bytes split across two parameters)
    MINI_MAESTRO_SERVO_PERIOD_L = 18  # Low 8 bits
    MINI_MAESTRO_SERVO_PERIOD_H = 19  # High 8 bits
    SERVO_MULTIPLIER = 20

    # Script
    SCRIPT_DONE = 24
    # Servo channel settings base parameters (9-byte stride per channel)
    # Each channel: base = SERVO0_HOME + (channel * 9)
    SERVO0_HOME = 30  # 2 bytes - home position in quarter-µs
    SERVO0_MIN = 32  # 1 byte - minimum / 64
    SERVO0_MAX = 33  # 1 byte - maximum / 64
    SERVO0_NEUTRAL = 34  # 2 bytes - neutral in quarter-µs
    SERVO0_RANGE = 36  # 1 byte - range / 127
    SERVO0_SPEED = 37  # 1 byte - exponential speed
    SERVO0_ACCELERATION = 38  # 1 byte - acceleration
    # Channel mode bytes for Mini Maestro (4 channels per byte)
    CHANNEL_MODES_0_3 = 12
    CHANNEL_MODES_4_7 = 13
    CHANNEL_MODES_8_11 = 14
    CHANNEL_MODES_12_15 = 15
    CHANNEL_MODES_16_19 = 16
    CHANNEL_MODES_20_23 = 17


class ChannelMode(IntEnum):
    """Channel operating modes (stored in bits 0-1 of mode byte)"""

    SERVO = 0
    SERVO_MULTIPLIED = 1
    OUTPUT = 2
    INPUT = 3


class HomeMode(IntEnum):
    """
    Home position behavior on startup/error.

    The Pololu SDK encodes home mode in the HOME parameter value:
    - 0 = Off (channel disabled on startup)
    - 1 = Ignore (don't change position, maintain last state)
    - >1 = Goto (move to this position in quarter-microseconds)
    """

    OFF = 0  # Channel disabled on startup
    IGNORE = 1  # Don't change position on startup/error
    GOTO = 2  # Go to home_position on startup/error


class SerialMode(IntEnum):
    """
    Serial communication mode for Maestro devices.

    Determines how the Maestro handles serial commands:
    - USB_DUAL_PORT: Commands via USB Command Port (ttyACM0), TTL passthrough on ttyACM1
    - USB_CHAINED: Commands via USB, also forwarded to TTL TX/RX for daisy-chaining
    - UART_DETECT: Commands via TTL TX/RX with auto baud rate detection
    - UART_FIXED: Commands via TTL TX/RX with fixed baud rate

    IMPORTANT: For DroidNet's USB serial control, USB_DUAL_PORT mode is required.
    If the Maestro is in UART mode, USB serial commands won't work!
    """

    USB_DUAL_PORT = 0  # Required for USB serial control
    USB_CHAINED = 1  # USB + TTL forwarding
    UART_DETECT = 2  # TTL serial, auto-detect baud
    UART_FIXED = 3  # TTL serial, fixed baud rate


# Mode byte bit masks
MODE_MASK = 0x03  # Bits 0-1: channel mode


@dataclass
class ChannelSettings:
    """Configuration for a single channel"""

    mode: ChannelMode = ChannelMode.SERVO
    home_mode: HomeMode = HomeMode.GOTO  # Behavior on startup/error
    home_position: int = 6000  # Quarter-microseconds (only used when home_mode=GOTO)
    minimum: int = 3968  # ~992µs
    maximum: int = 8000  # 2000µs
    neutral: int = 6000  # 1500µs
    range: int = 1905  # ~476µs
    speed: int = 0  # 0 = unlimited
    acceleration: int = 0  # 0 = unlimited

    def to_bytes(self) -> bytes:
        """Serialize to USB transfer format."""
        # Mode byte only contains channel mode (no home flag)
        mode_byte = self.mode & MODE_MASK

        # Home position encodes home_mode:
        # - 0 = Off, 1 = Ignore, >1 = Goto position
        if self.home_mode == HomeMode.OFF:
            home_value = 0
        elif self.home_mode == HomeMode.IGNORE:
            home_value = 1
        else:  # GOTO
            home_value = self.home_position

        return struct.pack(
            "<BBHHHHHBB",
            mode_byte,
            0,  # Reserved
            home_value,
            self.minimum,
            self.maximum,
            self.neutral,
            self.range,
            self.speed,
            self.acceleration,
        )

    @classmethod
    def from_bytes(cls, data: bytes) -> "ChannelSettings":
        """Deserialize from USB transfer format."""
        (
            mode_byte,
            _,
            home,
            minimum,
            maximum,
            neutral,
            range_,
            speed,
            accel,
        ) = struct.unpack("<BBHHHHHBB", data[:14])
        # Extract mode from bits 0-1
        mode = ChannelMode(mode_byte & MODE_MASK)

        # Decode home_mode from home value:
        # - 0 = Off, 1 = Ignore, >1 = Goto position
        if home == 0:
            home_mode = HomeMode.OFF
            home_position = 6000  # Default
        elif home == 1:
            home_mode = HomeMode.IGNORE
            home_position = 6000  # Default (not used)
        else:
            home_mode = HomeMode.GOTO
            home_position = home

        return cls(
            mode=mode,
            home_mode=home_mode,
            home_position=home_position,
            minimum=minimum,
            maximum=maximum,
            neutral=neutral,
            range=range_,
            speed=speed,
            acceleration=accel,
        )


def _normal_speed_to_exponential(speed: int) -> int:
    """
    Convert normal speed value to Maestro's exponential speed format.

    The Maestro uses a 5-bit mantissa and 3-bit exponent format for speed.
    Format: Bits 0-2 = exponent (0-7), Bits 3-7 = mantissa (0-31)
    Encoded as: exponent | (mantissa << 3)
    Speed 0 means unlimited. Higher values = slower movement.
    """
    if speed <= 0:
        return 0  # Unlimited

    # Find best mantissa/exponent representation
    mantissa = speed
    exponent = 0

    while mantissa > 31 and exponent < 7:
        mantissa = (mantissa + 1) >> 1  # Round up when shifting
        exponent += 1

    # Clamp mantissa to 5 bits
    if mantissa > 31:
        mantissa = 31

    # Pololu SDK format: exponent in low 3 bits, mantissa in upper 5 bits
    return exponent | (mantissa << 3)


def _exponential_speed_to_normal(exp_speed: int) -> int:
    """Convert Maestro's exponential speed format back to normal value."""
    if exp_speed == 0:
        return 0

    # Pololu SDK format: exponent in low 3 bits, mantissa in upper 5 bits
    exponent = exp_speed & 0x07
    mantissa = (exp_speed >> 3) & 0x1F

    return mantissa << exponent


class MaestroConfigurator:
    """
    Native USB configuration interface for Pololu Maestro.

    Provides access to settings that cannot be modified via serial protocol:
    - Channel modes and limits
    - Home positions
    - Script upload/download
    - Firmware version
    - Device parameters
    """

    MAESTRO_MODELS = {
        0x0089: {"name": "Micro Maestro 6", "channels": 6, "mini": False},
        0x008A: {"name": "Mini Maestro 12", "channels": 12, "mini": True},
        0x008B: {"name": "Mini Maestro 18", "channels": 18, "mini": True},
        0x008C: {"name": "Mini Maestro 24", "channels": 24, "mini": True},
    }

    def __init__(self, serial_number: Optional[str] = None):
        """
        Initialize configurator.

        Args:
            serial_number: Specific device serial number, or None for first found
        """
        self.serial_number = serial_number
        self.device: Optional[usb.core.Device] = None
        self.model_info: Optional[Dict] = None

    @classmethod
    def list_devices(cls) -> List[Dict[str, Any]]:
        """
        Find all connected Maestro devices.

        Returns:
            List of device info dictionaries
        """
        devices = []

        for product_id, model in cls.MAESTRO_MODELS.items():
            found = usb.core.find(
                find_all=True, idVendor=POLOLU_VENDOR_ID, idProduct=product_id
            )

            for dev in found:
                try:
                    serial = usb.util.get_string(dev, dev.iSerialNumber)
                except:
                    serial = None

                devices.append(
                    {
                        "serial_number": serial,
                        "product_id": product_id,
                        "model": model["name"],
                        "channels": model["channels"],
                        "is_mini": model["mini"],
                        "bus": dev.bus,
                        "address": dev.address,
                    }
                )

        return devices

    def connect(self) -> bool:
        """
        Connect to Maestro device.

        Returns:
            True if connected successfully
        """
        for product_id, model in self.MAESTRO_MODELS.items():
            dev = usb.core.find(idVendor=POLOLU_VENDOR_ID, idProduct=product_id)

            if dev is not None:
                if self.serial_number:
                    try:
                        serial = usb.util.get_string(dev, dev.iSerialNumber)
                        if serial != self.serial_number:
                            continue
                    except:
                        continue

                self.device = dev
                self.model_info = model

                # IMPORTANT: Do NOT detach kernel drivers or set configuration!
                # The Maestro exposes multiple interfaces:
                #   - Interfaces 0-1: Command Port (CDC ACM) - used by cdc_acm for serial
                #   - Interfaces 2-3: TTL Port (CDC ACM) - used by cdc_acm for serial
                #   - Interface 4+: Native USB for configuration
                #
                # USB control transfers go to endpoint 0 which is always available
                # without claiming interfaces. Detaching cdc_acm would break the
                # serial ports needed for servo control.
                #
                # The previous code was detaching interface 0 which destroyed ttyACM0!

                logger.info(f"Connected to {model['name']}")
                return True

        logger.error("No Maestro device found")
        return False

    def disconnect(self):
        """Release USB device."""
        if self.device:
            usb.util.dispose_resources(self.device)
            self.device = None

    def _control_transfer(
        self,
        request_type: int,
        request: int,
        value: int = 0,
        index: int = 0,
        data_or_length=None,
    ):
        """Execute USB control transfer."""
        if not self.device:
            raise ConnectionError("Not connected to device")

        return self.device.ctrl_transfer(
            request_type, request, value, index, data_or_length
        )

    # ─────────────────────────────────────────────────────────────────
    # Device Information
    # ─────────────────────────────────────────────────────────────────

    def get_firmware_version(self) -> Optional[str]:
        """Get firmware version string."""
        if not self.device:
            return None

        major = (self.device.bcdDevice >> 8) & 0xFF
        minor = self.device.bcdDevice & 0xFF
        return f"{major}.{minor:02d}"

    def get_serial_number(self) -> Optional[str]:
        """Get device serial number."""
        if not self.device:
            return None

        try:
            return usb.util.get_string(self.device, self.device.iSerialNumber)
        except:
            return None

    # ─────────────────────────────────────────────────────────────────
    # Channel Configuration
    # ─────────────────────────────────────────────────────────────────

    def _get_raw_parameter(self, param: int, byte_count: int = 2) -> Optional[int]:
        """
        Read a raw parameter value via USB control transfer.

        Args:
            param: Parameter ID
            byte_count: Number of bytes to read (1 or 2)

        Returns:
            Parameter value or None on error
        """
        try:
            data = self._control_transfer(
                0xC0, UscRequest.GET_PARAMETER, 0, param, byte_count  # Device to host
            )
            if byte_count == 1:
                return data[0]
            else:
                return struct.unpack("<H", bytes(data))[0]
        except usb.core.USBError as e:
            logger.error(f"Failed to get raw parameter {param}: {e}")
            return None

    def get_channel_settings(self, channel: int) -> Optional[ChannelSettings]:
        """
        Read settings for a single channel from EEPROM parameters.

        Uses GET_PARAMETER to read individual settings, not GET_SERVO_SETTINGS
        which returns runtime servo status instead of configuration.

        Args:
            channel: Channel number

        Returns:
            ChannelSettings object or None on error
        """
        try:
            # Calculate parameter offset for this channel (9 bytes per channel)
            base = UscParameter.SERVO0_HOME + (channel * 9)

            # Read each parameter with correct byte count
            home = self._get_raw_parameter(base + 0, 2)
            min_raw = self._get_raw_parameter(base + 2, 1)
            max_raw = self._get_raw_parameter(base + 3, 1)
            neutral = self._get_raw_parameter(base + 4, 2)
            range_raw = self._get_raw_parameter(base + 6, 1)
            speed_raw = self._get_raw_parameter(base + 7, 1)
            accel = self._get_raw_parameter(base + 8, 1)

            if None in [home, min_raw, max_raw, neutral, range_raw, speed_raw, accel]:
                logger.error(f"Failed to read all parameters for channel {channel}")
                return None

            # Decode scaled values
            minimum = min_raw * 64
            maximum = max_raw * 64
            range_val = range_raw * 127
            speed = _exponential_speed_to_normal(speed_raw)

            # Decode home_mode from home value (Pololu SDK format):
            # - 0 = Off (channel disabled on startup)
            # - 1 = Ignore (don't change position on startup/error)
            # - >1 = Goto (move to this position)
            if home == 0:
                home_mode = HomeMode.OFF
                home_position = 6000  # Default
            elif home == 1:
                home_mode = HomeMode.IGNORE
                home_position = 6000  # Default (not used)
            else:
                home_mode = HomeMode.GOTO
                home_position = home

            # Read mode for Mini Maestro (4 channels per byte)
            mode = ChannelMode.SERVO
            if self.model_info and self.model_info.get("mini", False):
                mode_param_index = channel // 4
                mode_params = [
                    UscParameter.CHANNEL_MODES_0_3,
                    UscParameter.CHANNEL_MODES_4_7,
                    UscParameter.CHANNEL_MODES_8_11,
                    UscParameter.CHANNEL_MODES_12_15,
                    UscParameter.CHANNEL_MODES_16_19,
                    UscParameter.CHANNEL_MODES_20_23,
                ]
                if mode_param_index < len(mode_params):
                    mode_byte = self._get_raw_parameter(
                        mode_params[mode_param_index], 1
                    )
                    if mode_byte is not None:
                        bit_pos = (channel % 4) * 2
                        mode = ChannelMode((mode_byte >> bit_pos) & 0x03)

            return ChannelSettings(
                mode=mode,
                home_mode=home_mode,
                home_position=home_position,
                minimum=minimum,
                maximum=maximum,
                neutral=neutral,
                range=range_val,
                speed=speed,
                acceleration=accel,
            )

        except Exception as e:
            logger.error(f"Failed to get channel {channel} settings: {e}")
            return None

    def _set_raw_parameter(self, param: int, value: int, byte_count: int = 2) -> bool:
        """
        Write a raw parameter value via USB control transfer.

        Args:
            param: Parameter ID
            value: Value to write
            byte_count: Number of bytes (1 or 2)

        Returns:
            True if successful
        """
        try:
            # The index encodes the parameter ID and byte count in high byte
            # For Maestro: index = param | (byte_count << 8) but for most params
            # we use index = param directly and encode byte count differently
            self._control_transfer(
                0x40,  # Host to device, vendor, device
                UscRequest.SET_PARAMETER,
                value & 0xFFFF,  # Clamp to 16 bits
                param | ((byte_count & 0x03) << 8),
                None,
            )
            return True
        except usb.core.USBError as e:
            logger.error(f"Failed to set raw parameter {param}: {e}")
            return False

    def set_channel_settings(self, channel: int, settings: ChannelSettings) -> bool:
        """
        Write settings for a single channel.

        Uses SET_PARAMETER to write each setting individually, as per Pololu SDK.
        Settings are written to EEPROM and persist across power cycles.

        Args:
            channel: Channel number
            settings: ChannelSettings object

        Returns:
            True if successful
        """
        try:
            # Calculate parameter offset for this channel (9 bytes per channel)
            base = UscParameter.SERVO0_HOME + (channel * 9)

            # Write each parameter using proper scaling from Pololu SDK:
            # - HOME: encodes home_mode (0=Off, 1=Ignore, >1=Goto position)
            # - MIN: divided by 64 (1 byte)
            # - MAX: divided by 64 (1 byte)
            # - NEUTRAL: raw quarter-µs (2 bytes)
            # - RANGE: divided by 127 (1 byte)
            # - SPEED: exponential format (1 byte)
            # - ACCELERATION: raw value (1 byte)

            # Home value encodes home_mode (2 bytes)
            if settings.home_mode == HomeMode.OFF:
                home_value = 0
            elif settings.home_mode == HomeMode.IGNORE:
                home_value = 1
            else:  # GOTO
                home_value = settings.home_position
            if not self._set_raw_parameter(base + 0, home_value, 2):
                return False

            # Minimum (1 byte, scaled by 64)
            min_scaled = max(0, min(255, settings.minimum // 64))
            if not self._set_raw_parameter(base + 2, min_scaled, 1):
                return False

            # Maximum (1 byte, scaled by 64)
            max_scaled = max(0, min(255, settings.maximum // 64))
            if not self._set_raw_parameter(base + 3, max_scaled, 1):
                return False

            # Neutral (2 bytes)
            if not self._set_raw_parameter(base + 4, settings.neutral, 2):
                return False

            # Range (1 byte, scaled by 127)
            range_scaled = max(0, min(255, settings.range // 127))
            if not self._set_raw_parameter(base + 6, range_scaled, 1):
                return False

            # Speed (1 byte, exponential format)
            speed_exp = _normal_speed_to_exponential(settings.speed)
            if not self._set_raw_parameter(base + 7, speed_exp, 1):
                return False

            # Acceleration (1 byte)
            accel = max(0, min(255, settings.acceleration))
            if not self._set_raw_parameter(base + 8, accel, 1):
                return False

            # Write mode byte for Mini Maestro (4 channels per byte)
            # For Micro Maestro, mode is in IO_MASK_C and OUTPUT_MASK_C
            # Note: home_mode is encoded in the HOME parameter, not the mode byte
            if self.model_info and self.model_info.get("mini", False):
                if not self._set_channel_mode(channel, settings.mode):
                    logger.warning(f"Failed to set mode for channel {channel}")
                    # Continue anyway - mode is less critical

            # Reinitialize device to reload settings from EEPROM to RAM
            # This makes the new settings take effect immediately
            if not self.reinitialize():
                logger.warning("Failed to reinitialize device after settings write")
                # Return True anyway since the EEPROM write succeeded

            logger.info(f"Successfully wrote settings for channel {channel}")
            return True

        except Exception as e:
            logger.error(f"Failed to set channel {channel} settings: {e}")
            return False

    def _set_channel_mode(self, channel: int, mode: ChannelMode) -> bool:
        """
        Set the mode byte for a single channel on Mini Maestro.

        Mini Maestro stores 4 channel modes per byte in CHANNEL_MODES_X_Y parameters.
        Each channel uses 2 bits for mode.

        Note: home_mode is NOT stored in this byte - it's encoded in the HOME parameter.
        """
        try:
            # Determine which mode byte parameter to use
            mode_param_index = channel // 4
            mode_params = [
                UscParameter.CHANNEL_MODES_0_3,
                UscParameter.CHANNEL_MODES_4_7,
                UscParameter.CHANNEL_MODES_8_11,
                UscParameter.CHANNEL_MODES_12_15,
                UscParameter.CHANNEL_MODES_16_19,
                UscParameter.CHANNEL_MODES_20_23,
            ]

            if mode_param_index >= len(mode_params):
                return False

            param = mode_params[mode_param_index]

            # Read current mode byte
            current = self.get_parameter(param)
            if current is None:
                current = 0

            # Calculate bit position within the byte (2 bits per channel)
            bit_pos = (channel % 4) * 2

            # Clear the 2 bits for this channel and set new mode
            mask = ~(0x03 << bit_pos) & 0xFF
            new_value = (current & mask) | ((mode & 0x03) << bit_pos)

            return self._set_raw_parameter(param, new_value, 1)

        except Exception as e:
            logger.error(f"Failed to set channel {channel} mode: {e}")
            return False

    def get_all_channel_settings(self) -> Dict[int, ChannelSettings]:
        """Get settings for all channels."""
        settings = {}
        if not self.model_info:
            return settings

        for ch in range(self.model_info["channels"]):
            s = self.get_channel_settings(ch)
            if s:
                settings[ch] = s
        return settings

    # ─────────────────────────────────────────────────────────────────
    # Device Parameters
    # ─────────────────────────────────────────────────────────────────

    def get_parameter(self, param: UscParameter) -> Optional[int]:
        """Read a device parameter."""
        try:
            data = self._control_transfer(0xC0, UscRequest.GET_PARAMETER, 0, param, 2)
            return struct.unpack("<H", bytes(data))[0]
        except usb.core.USBError as e:
            logger.error(f"Failed to get parameter {param}: {e}")
            return None

    def set_parameter(self, param: UscParameter, value: int) -> bool:
        """Write a device parameter."""
        try:
            self._control_transfer(0x40, UscRequest.SET_PARAMETER, value, param, 0)
            return True
        except usb.core.USBError as e:
            logger.error(f"Failed to set parameter {param}: {e}")
            return False

    # ─────────────────────────────────────────────────────────────────
    # Serial Mode Configuration
    # ─────────────────────────────────────────────────────────────────

    def get_serial_mode(self) -> Optional[SerialMode]:
        """
        Get the current serial communication mode.

        Returns:
            SerialMode enum value, or None on error
        """
        value = self.get_parameter(UscParameter.SERIAL_MODE)
        if value is None:
            return None

        # Serial mode is in bits 0-2
        mode_value = value & 0x07
        try:
            return SerialMode(mode_value)
        except ValueError:
            logger.warning(f"Unknown serial mode value: {mode_value}")
            return None

    def set_serial_mode(self, mode: SerialMode) -> bool:
        """
        Set the serial communication mode.

        IMPORTANT: Changes are written to EEPROM but require a power cycle
        to take effect. The device will continue using the old mode until
        physically power cycled.

        Args:
            mode: Desired SerialMode

        Returns:
            True if EEPROM was written successfully
        """
        # Get current settings to preserve other bits
        current = self.get_parameter(UscParameter.SERIAL_MODE)
        if current is None:
            logger.error("Failed to read current serial mode")
            return False

        # Preserve bits 3-7, set bits 0-2 to new mode
        new_value = (current & ~0x07) | (mode & 0x07)

        if self.set_parameter(UscParameter.SERIAL_MODE, new_value):
            logger.info(f"Serial mode set to {mode.name} (requires power cycle)")
            return True
        return False

    def check_serial_mode(self) -> Dict[str, Any]:
        """
        Check if serial mode is correctly configured for USB serial control.

        Returns a dict with:
            - 'mode': Current SerialMode
            - 'mode_name': Human-readable mode name
            - 'ok': True if USB_DUAL_PORT mode
            - 'message': Status message
        """
        mode = self.get_serial_mode()

        if mode is None:
            return {
                "mode": None,
                "mode_name": "Unknown",
                "ok": False,
                "message": "Failed to read serial mode from device",
            }

        if mode == SerialMode.USB_DUAL_PORT:
            return {
                "mode": mode,
                "mode_name": mode.name,
                "ok": True,
                "message": "Serial mode is correctly configured for USB control",
            }
        else:
            return {
                "mode": mode,
                "mode_name": mode.name,
                "ok": False,
                "message": (
                    f"Device is in {mode.name} mode. "
                    "USB serial commands will not work. "
                    "Change to USB_DUAL_PORT mode and power cycle the device."
                ),
            }

    def fix_serial_mode(self) -> Dict[str, Any]:
        """
        Check serial mode and fix it if not USB_DUAL_PORT.

        If the mode is wrong, this will:
        1. Write USB_DUAL_PORT to EEPROM
        2. Return a message indicating power cycle is needed

        Returns:
            Dict with 'success', 'changed', 'needs_power_cycle', 'message'
        """
        check = self.check_serial_mode()

        if check["ok"]:
            return {
                "success": True,
                "changed": False,
                "needs_power_cycle": False,
                "message": "Serial mode already correct (USB_DUAL_PORT)",
            }

        # Mode needs to be changed
        current_mode = check["mode_name"]

        if self.set_serial_mode(SerialMode.USB_DUAL_PORT):
            return {
                "success": True,
                "changed": True,
                "needs_power_cycle": True,
                "message": (
                    f"Changed serial mode from {current_mode} to USB_DUAL_PORT. "
                    "POWER CYCLE REQUIRED: Unplug the Maestro, wait 5 seconds, "
                    "then plug it back in for the change to take effect."
                ),
            }
        else:
            return {
                "success": False,
                "changed": False,
                "needs_power_cycle": False,
                "message": f"Failed to change serial mode from {current_mode}",
            }

    # ─────────────────────────────────────────────────────────────────
    # Script Management
    # ─────────────────────────────────────────────────────────────────

    def erase_script(self) -> bool:
        """Erase the script stored in device EEPROM."""
        try:
            self._control_transfer(0x40, UscRequest.ERASE_SCRIPT, 0, 0, 0)
            return True
        except usb.core.USBError as e:
            logger.error(f"Failed to erase script: {e}")
            return False

    def write_script(self, bytecode: bytes) -> bool:
        """
        Write compiled script bytecode to device.

        The Maestro requires script data to be written in 16-byte blocks.
        Each block must be exactly 16 bytes (padded with zeros if needed).

        Args:
            bytecode: Compiled script bytecode

        Returns:
            True if successful
        """
        try:
            import time

            # Write in 16-byte blocks (Maestro requirement)
            block_size = 16
            block_num = 0
            offset = 0

            while offset < len(bytecode):
                # Extract block and pad to exactly 16 bytes
                block = bytecode[offset : offset + block_size]
                if len(block) < block_size:
                    block = block + bytes(block_size - len(block))

                self._control_transfer(
                    0x40, UscRequest.WRITE_SCRIPT, block_num, 0, block
                )
                offset += block_size
                block_num += 1

                # Small delay between blocks for EEPROM write
                time.sleep(0.01)

            # Mark script as done
            self._control_transfer(0x40, UscRequest.SET_SCRIPT_DONE, 0, 0, 0)

            logger.info(f"Uploaded script: {len(bytecode)} bytes in {block_num} blocks")
            return True
        except usb.core.USBError as e:
            logger.error(f"Failed to write script: {e}")
            return False

    def restart_script(self) -> bool:
        """Restart script from beginning."""
        try:
            self._control_transfer(0x40, UscRequest.RESTART_SCRIPT, 0, 0, 0)
            return True
        except usb.core.USBError as e:
            logger.error(f"Failed to restart script: {e}")
            return False

    def restart_script_at_subroutine(
        self, subroutine: int, parameter: Optional[int] = None
    ) -> bool:
        """
        Restart script at a specific subroutine.

        Args:
            subroutine: Subroutine number (0-127)
            parameter: Optional parameter to pass to subroutine

        Returns:
            True if successful
        """
        try:
            if parameter is not None:
                self._control_transfer(
                    0x40,
                    UscRequest.RESTART_SCRIPT_AT_SUBROUTINE_WITH_PARAM,
                    parameter,
                    subroutine,
                    0,
                )
            else:
                self._control_transfer(
                    0x40, UscRequest.RESTART_SCRIPT_AT_SUBROUTINE, 0, subroutine, 0
                )
            return True
        except usb.core.USBError as e:
            logger.error(f"Failed to restart script at subroutine: {e}")
            return False

    def clear_errors(self) -> bool:
        """Clear all error flags."""
        try:
            self._control_transfer(0x40, UscRequest.CLEAR_ERRORS, 0, 0, 0)
            return True
        except usb.core.USBError as e:
            logger.error(f"Failed to clear errors: {e}")
            return False

    def reinitialize(self) -> bool:
        """Reinitialize the device (reload settings from EEPROM)."""
        try:
            self._control_transfer(0x40, UscRequest.REINITIALIZE, 0, 0, 0)
            return True
        except usb.core.USBError as e:
            logger.error(f"Failed to reinitialize: {e}")
            return False

    # ─────────────────────────────────────────────────────────────────
    # Settings Export/Import (JSON format for compatibility)
    # ─────────────────────────────────────────────────────────────────

    def export_settings(self) -> Dict[str, Any]:
        """
        Export all device settings as a dictionary.

        Compatible with Maestro Control Center XML format.
        """
        settings = {
            "model": self.model_info["name"] if self.model_info else "Unknown",
            "firmware_version": self.get_firmware_version(),
            "serial_number": self.get_serial_number(),
            "channels": [],
            "parameters": {},
        }

        # Export channel settings
        if self.model_info:
            for ch in range(self.model_info["channels"]):
                ch_settings = self.get_channel_settings(ch)
                if ch_settings:
                    settings["channels"].append(
                        {
                            "channel": ch,
                            "mode": ch_settings.mode.name,
                            "home_mode": ch_settings.home_mode.name,
                            "home": ch_settings.home_position,
                            "min": ch_settings.minimum,
                            "max": ch_settings.maximum,
                            "neutral": ch_settings.neutral,
                            "range": ch_settings.range,
                            "speed": ch_settings.speed,
                            "acceleration": ch_settings.acceleration,
                        }
                    )

        # Export key parameters
        for param in [UscParameter.SERIAL_MODE, UscParameter.SERIAL_DEVICE_NUMBER]:
            value = self.get_parameter(param)
            if value is not None:
                settings["parameters"][param.name] = value

        return settings

    def import_settings(self, settings: Dict[str, Any]) -> bool:
        """
        Import device settings from a dictionary.

        Args:
            settings: Settings dictionary (from export_settings or parsed XML)

        Returns:
            True if all settings applied successfully
        """
        success = True

        # Import channel settings
        for ch_data in settings.get("channels", []):
            ch = ch_data["channel"]
            # Handle both new home_mode and legacy home_enabled format
            home_mode_str = ch_data.get("home_mode")
            if home_mode_str:
                home_mode = HomeMode[home_mode_str]
            elif ch_data.get("home_enabled", False):
                home_mode = HomeMode.GOTO
            else:
                home_mode = HomeMode.IGNORE
            ch_settings = ChannelSettings(
                mode=ChannelMode[ch_data.get("mode", "SERVO")],
                home_mode=home_mode,
                home_position=ch_data.get("home", 6000),
                minimum=ch_data.get("min", 3968),
                maximum=ch_data.get("max", 8000),
                neutral=ch_data.get("neutral", 6000),
                range=ch_data.get("range", 1905),
                speed=ch_data.get("speed", 0),
                acceleration=ch_data.get("acceleration", 0),
            )

            if not self.set_channel_settings(ch, ch_settings):
                success = False

        # Import parameters
        for param_name, value in settings.get("parameters", {}).items():
            try:
                param = UscParameter[param_name]
                if not self.set_parameter(param, value):
                    success = False
            except KeyError:
                logger.warning(f"Unknown parameter: {param_name}")

        return success

    def is_connected(self) -> bool:
        """Check if connected to a device."""
        if self.device is None:
            return False
        # Try a simple USB operation to verify connection is still alive
        try:
            # Read firmware version as a health check
            _ = self.device.bcdDevice
            return True
        except Exception:
            # Connection is stale, clear device reference
            self.device = None
            return False
