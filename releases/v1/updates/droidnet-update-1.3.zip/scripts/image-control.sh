#!/bin/bash
# Image Control Script for DroidNet Display Feature
# Provides control operations for image display

set -e

# Configuration
PID_FILE="/var/run/droidnet-image.pid"
LOG_FILE="/var/log/droidnet/image-display.log"

# Logging function
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

# Get current image display status
get_status() {
    local status="stopped"
    local pid=""
    local image=""

    if [[ -f "$PID_FILE" ]]; then
        pid=$(cat "$PID_FILE")
        if kill -0 "$pid" 2>/dev/null; then
            status="displaying"
            # Try to get image name from process command line
            image=$(ps -p "$pid" -o args= | grep -oP '(?<=/opt/droidnet/images/)[^[:space:]]+' || echo "unknown")
        else
            # PID file exists but process is dead
            rm -f "$PID_FILE"
        fi
    fi

    # Output JSON
    echo "{"
    echo "  \"status\": \"$status\","
    echo "  \"pid\": \"$pid\","
    echo "  \"image\": \"$image\""
    echo "}"
}

# Stop image display
stop_display() {
    if [[ ! -f "$PID_FILE" ]]; then
        echo "{\"success\": false, \"message\": \"No image currently displayed\"}"
        return 1
    fi

    local pid=$(cat "$PID_FILE")

    if ! kill -0 "$pid" 2>/dev/null; then
        # Process already dead
        rm -f "$PID_FILE"
        echo "{\"success\": false, \"message\": \"Image display process not running\"}"
        return 1
    fi

    # Send SIGTERM to gracefully stop
    kill -TERM "$pid" 2>/dev/null

    # Wait for process to exit (up to 3 seconds)
    for i in {1..30}; do
        if ! kill -0 "$pid" 2>/dev/null; then
            break
        fi
        sleep 0.1
    done

    # Force kill if still running
    if kill -0 "$pid" 2>/dev/null; then
        log "Force killing image display process (PID: $pid)"
        kill -9 "$pid" 2>/dev/null || true
    fi

    # Clean up PID file
    rm -f "$PID_FILE"

    # Turn off HDMI
    if command -v vcgencmd &> /dev/null; then
        vcgencmd display_power 0 &>> "$LOG_FILE"
    fi

    log "Image display stopped"
    echo "{\"success\": true, \"message\": \"Image display stopped\"}"
    return 0
}

# Main function
main() {
    local action=$1

    case "$action" in
        status)
            get_status
            ;;
        stop|hide)
            stop_display
            ;;
        *)
            echo "{\"success\": false, \"message\": \"Invalid action: $action\"}"
            echo "Usage: $0 {status|stop|hide}" >&2
            exit 1
            ;;
    esac
}

# Run main function
main "$@"
