#!/bin/bash
# Simplified WiFi setup that handles both hardware init and AP configuration

set -e
LOG="/var/log/droidnet-wifi-setup.log"
exec 1> >(tee -a "$LOG")
exec 2>&1

echo "[$(date)] Starting WiFi setup..."

# 1. Hardware initialization
echo "[$(date)] Initializing WiFi hardware..."
iw reg set US || echo "[$(date)] WARNING: Failed to set regulatory domain"
ip link set wlan0 up || echo "[$(date)] WARNING: Failed to bring up wlan0"

# 2. Wait for NetworkManager
echo "[$(date)] Waiting for NetworkManager..."
for i in {1..30}; do
    if systemctl is-active --quiet NetworkManager; then
        break
    fi
    sleep 1
done

# 3. Reload connection profiles
echo "[$(date)] Reloading NetworkManager connections..."
nmcli connection reload

# 4. Check for active connections first
ACTIVE_WIFI=$(nmcli -t -f TYPE,STATE,CONNECTION device | grep "^wifi:connected:" | cut -d: -f3)

if [ -z "$ACTIVE_WIFI" ]; then
    echo "[$(date)] No active WiFi connection found..."
    
    # Try to connect to saved networks first
    SAVED_NETWORKS=$(nmcli -t -f NAME,TYPE connection show | grep ":802-11-wireless$" | grep -v "DroidNet-AP" | cut -d: -f1)
    
    if [ -n "$SAVED_NETWORKS" ]; then
        echo "[$(date)] Found saved networks, attempting to connect..."
        
        # Give NetworkManager time to auto-connect
        for i in {1..20}; do
            ACTIVE_WIFI=$(nmcli -t -f TYPE,STATE,CONNECTION device | grep "^wifi:connected:" | grep -v "DroidNet-AP" | cut -d: -f3)
            if [ -n "$ACTIVE_WIFI" ]; then
                echo "[$(date)] Successfully connected to: $ACTIVE_WIFI"
                break
            fi
            sleep 1
        done
        
        # If still not connected, try manual connection
        if [ -z "$ACTIVE_WIFI" ]; then
            # Use while read to handle network names with spaces
            echo "$SAVED_NETWORKS" | while IFS= read -r network; do
                [ -z "$network" ] && continue
                echo "[$(date)] Attempting manual connection to: $network"
                if timeout 15 nmcli connection up "$network" 2>&1; then
                    echo "[$(date)] Successfully connected to: $network"
                    # Signal success by creating a marker file
                    touch /tmp/wifi-connected-successfully
                    break
                fi
            done
            # Check if connection succeeded
            if [ -f /tmp/wifi-connected-successfully ]; then
                rm -f /tmp/wifi-connected-successfully
                ACTIVE_WIFI="connected"
            fi
        fi
    fi
    
    # Only activate AP if we couldn't connect to any saved networks
    if [ -z "$ACTIVE_WIFI" ]; then
        echo "[$(date)] No saved networks available or connection failed, activating DroidNet AP..."
        nmcli connection up "DroidNet-AP" || {
            echo "[$(date)] Failed to activate AP, running setup script..."
            /opt/droidnet/scripts/setup_ap.sh
        }
    fi
else
    echo "[$(date)] Already connected to: $ACTIVE_WIFI"
fi

echo "[$(date)] WiFi setup complete"