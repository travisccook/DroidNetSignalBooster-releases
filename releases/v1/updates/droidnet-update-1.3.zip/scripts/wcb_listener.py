"""
WCB Serial Event Listener

Monitors WCB serial port for unsolicited messages and command responses.
Handles single-line responses (store, erase, debug mode).

Note: Multi-line ?BACKUP responses are handled by WCBBackupManager's
passive capture system, not by this listener.
"""

import asyncio
import logging
from typing import Dict, Callable, List, Optional
from dataclasses import dataclass
from datetime import datetime

logger = logging.getLogger(__name__)


@dataclass
class WCBCommand:
    """Parsed WCB command entry."""

    key: str
    value: str


@dataclass
class WCBResponse:
    """Parsed WCB response."""

    command: str
    success: bool
    commands: List[WCBCommand]  # For ?BACKUP responses (via backup manager)
    data: str
    timestamp: float


class WCBListener:
    """Always-on listener for WCB serial events."""

    def __init__(self, port_handler, port: str = "", device_id: str = ""):
        self.handler = port_handler
        self.port = port
        self.device_id = device_id
        self.event_handlers: Dict[str, Callable] = {}
        self._running = False

        # Backup manager for passive capture (set externally)
        self.backup_manager = None

        # Pending commands with lock for thread safety
        self._pending_lock = asyncio.Lock()
        self.pending_commands: Dict[str, asyncio.Future] = {}

    async def start(self):
        """Start listening for WCB events."""
        self._running = True
        self.handler.subscribe("data", self._on_serial_data)
        logger.info("WCB listener started")

    async def stop(self):
        """Stop listening for WCB events."""
        self._running = False
        self.handler.unsubscribe("data", self._on_serial_data)
        # Cancel any pending commands
        async with self._pending_lock:
            for cmd_id, future in self.pending_commands.items():
                if not future.done():
                    future.cancel()
            self.pending_commands.clear()
        logger.info("WCB listener stopped")

    async def _on_serial_data(self, event_data):
        """Process incoming WCB serial line."""
        line = event_data["line"].strip()
        timestamp = event_data["timestamp"]

        if not line:
            return  # Skip empty lines

        # Pass to backup manager for passive capture (if configured)
        # Backup manager handles multi-line ?BACKUP responses internally
        if self.backup_manager and self.port and self.device_id:
            try:
                await self.backup_manager.on_serial_data(
                    self.port, self.device_id, line, timestamp
                )
            except Exception as e:
                logger.debug(f"Backup manager passive capture error: {e}")

        # Process single-line responses and events
        await self._process_single_line(line, timestamp)

    async def _process_single_line(self, line: str, timestamp: float):
        """Process a single-line response or event."""

        # Check for common WCB responses
        # Store command responses (from WCB_Storage.cpp line 377):
        # "Stored: Key='X', Value='Y'"
        if line.startswith("Stored:"):
            # Response to ?CS command
            await self._complete_pending_command(True, [], line, timestamp)

        # Erase command responses (from WCB_Storage.cpp lines 419-422):
        # Success: "Deleted stored command key: 'X'"
        # Not found: "No stored value found for key: 'X', but removed from list if present."
        elif line.startswith("Deleted stored command"):
            # Successful erase - response to ?CE command
            await self._complete_pending_command(True, [], line, timestamp)

        elif line.startswith("No stored value found"):
            # Key not found - response to ?CE command (still considered success in WCB)
            await self._complete_pending_command(True, [], line, timestamp)

        # Debug mode responses (from WCB.ino lines 651, 655):
        # "Debugging enabled" or "Debugging disabled"
        elif line.startswith("Debugging"):
            # Response to ?DON or ?DOFF
            await self._complete_pending_command(True, [], line, timestamp)

        # Invalid command responses (from WCB.ino line 733):
        # "Invalid Local Command"
        elif line.startswith("Invalid"):
            # Response to unrecognized command
            await self._complete_pending_command(False, [], line, timestamp)

        # Checksum verification failure (from main.cpp lines 404-410):
        # "✗ Command checksum FAILED - Configuration may be corrupted!"
        elif "checksum FAILED" in line:
            # Command was corrupted in transmission - WCB aborted execution
            await self._complete_pending_command(
                False, [], "Checksum verification failed - command not executed", timestamp
            )

        # Backup end marker - complete pending ?BACKUP command
        elif "End of Backup" in line:
            # ?BACKUP response complete - backup manager handles the content
            await self._complete_pending_command(True, [], "Backup complete", timestamp)

        # Config end marker - complete pending ?CONFIG command
        elif "End of Configuration Info" in line:
            # ?CONFIG response complete
            await self._complete_pending_command(True, [], "Config complete", timestamp)

        elif (
            line.startswith("Diagnostic")
            or line.startswith("Uptime")
            or line.startswith("Free")
        ):
            # Diagnostic information (from ?CDIAG or unsolicited)
            await self._handle_diagnostic(line, timestamp)

        else:
            # Unknown message - log and dispatch as generic event
            logger.debug(f"WCB unknown message: {line}")
            await self._dispatch_event("unknown", line, timestamp)

    async def _complete_pending_command(
        self, success: bool, commands: List[WCBCommand], data: str, timestamp: float
    ):
        """Complete the oldest pending command."""
        async with self._pending_lock:
            if self.pending_commands:
                cmd_id = next(iter(self.pending_commands))
                future = self.pending_commands.pop(cmd_id)

                response = WCBResponse(
                    command=cmd_id,
                    success=success,
                    commands=commands,
                    data=data,
                    timestamp=timestamp,
                )

                if not future.done():
                    future.set_result(response)

    async def _handle_diagnostic(self, line: str, timestamp: float):
        """Handle diagnostic information."""
        logger.info(f"WCB diagnostic: {line}")
        await self._dispatch_event("diagnostic", line, timestamp)

    async def _dispatch_event(self, event_type: str, data: str, timestamp: float):
        """Dispatch event to registered handlers."""
        if event_type in self.event_handlers:
            try:
                await self.event_handlers[event_type](
                    {"type": event_type, "data": data, "timestamp": timestamp}
                )
            except Exception as e:
                logger.error(f"Error in WCB event handler: {e}")

    async def send_command(self, command: str, timeout: float = 5.0) -> WCBResponse:
        """
        Send WCB command and wait for response.

        Supported commands:
        - ?BACKUP - Get configuration backup (parsed by backup manager)
        - ?CS<key>,<value> - Store command
        - ?CE<key> - Erase command
        - ?DON / ?DOFF - Debug mode
        - ?CDIAG - Diagnostics
        """
        cmd_id = command.strip()
        future = asyncio.Future()

        async with self._pending_lock:
            self.pending_commands[cmd_id] = future

        try:
            # Send through handler's queue (no newline - WCB expects bare command)
            await self.handler.write(command)

            # Wait for response
            response = await asyncio.wait_for(future, timeout=timeout)
            return response

        except asyncio.TimeoutError:
            async with self._pending_lock:
                self.pending_commands.pop(cmd_id, None)
            raise TimeoutError(f"WCB command timeout: {command}")
        except Exception as e:
            # Clean up pending command on any other exception (e.g., write failure)
            async with self._pending_lock:
                self.pending_commands.pop(cmd_id, None)
            logger.error(f"WCB command failed: {command}: {e}")
            raise

    def register_event_handler(self, event_type: str, handler: Callable):
        """
        Register handler for specific WCB event type.

        Event types:
        - 'diagnostic' - Diagnostic info
        - 'unknown' - Unrecognized messages
        """
        self.event_handlers[event_type] = handler
