#!/usr/bin/env python3
"""
WCB Configuration Backup Manager

Provides:
- CRC32 verification (IEEE 802.3 polynomial matching WCB firmware)
- Backup parsing for ?BACKUP output
- Change detection (commands added/removed, settings changed)
- Delta detection (only save when checksum changes)
- Scheduled hourly backups
- Count-based retention (keeps last N backups)
- Passive capture from serial output
"""

import asyncio
import binascii
import logging
import os
import re
import sys
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

# Setup Python paths
sys.path.insert(0, "/opt/droidnet")
from utils.config_helpers import load_json_config, save_json_config
from config.constants import CONFIG_DIR, DATA_DIR

logger = logging.getLogger(__name__)

# CRC32 polynomial (IEEE 802.3) - matches WCB firmware
CRC32_POLYNOMIAL = 0xEDB88320


@dataclass
class BackupConfig:
    """Backup system configuration."""

    backup_interval_hours: float = 1.0
    max_backups: int = 50  # Keep last N backups
    enabled: bool = True
    save_all_backups: bool = False  # If True, save every backup; if False, only on changes


@dataclass
class ParsedBackup:
    """
    Parsed WCB backup data.

    Broadcast Settings (WCB v5.6+):
        broadcast_output: Controls whether data received on a serial port is
            broadcast to other WCBs via ESP-NOW. True = send broadcasts,
            False = don't send. Maps to ?SBOx1/?SBOx0 commands.

        broadcast_input: Controls whether broadcasts received from other WCBs
            are written to a serial port. True = allow incoming broadcasts,
            False = block incoming broadcasts. Maps to ?SBIx1/?SBIx0 commands.
            Note: Firmware internally uses "blockBroadcastFrom" (inverted logic),
            but we store the "allowed" state for clarity.

    Kyber Settings:
        kyber_settings["status"]: "local", "remote", or "clear"

    Serial Monitor Mappings (WCB v5.3+):
        serial_monitor_mappings: List of mappings from input port to output destinations.
        Each mapping: {"input_port": "1", "outputs": ["S2", "W1S3"]}
        - "Sx" = local serial port x
        - "WxSy" = WCB x, serial port y

    PWM Settings:
        pwm_output_port: GPIO pin for PWM output (e.g., "5")
        pwm_port_mappings: List of PWM input to serial output mappings
    """

    hw_version: str = ""
    wcb_number: str = ""
    wcb_quantity: str = ""
    mac_octet2: str = ""
    mac_octet3: str = ""
    esp_now_password: str = ""
    # Command characters (rarely changed from defaults)
    command_delimiter: str = ""  # ?D - delimiter between chained commands (default: ^)
    local_function_id: str = ""  # ?LF - prefix for local commands (default: ?)
    command_character: str = ""  # ?CC - prefix for serial routing (default: ;)
    baud_rates: Dict[str, int] = field(default_factory=dict)
    # Legacy field - kept for backward compatibility with old backups
    broadcast_enabled: Dict[str, bool] = field(default_factory=dict)
    # WCB v5.6+: Separate broadcast OUTPUT (sending) and INPUT (receiving) settings
    # broadcast_output: True = send broadcasts from this port, False = don't send
    broadcast_output: Dict[str, bool] = field(default_factory=dict)  # ?SBOx0/1
    # broadcast_input: True = allow broadcasts TO this port, False = block
    broadcast_input: Dict[str, bool] = field(default_factory=dict)  # ?SBIx0/1
    serial_labels: Dict[str, str] = field(default_factory=dict)
    # Serial monitor mappings (WCB v5.3+ HCR_Port_Mirror)
    serial_monitor_mappings: List[Dict[str, Any]] = field(default_factory=list)
    stored_commands: List[Dict[str, str]] = field(default_factory=list)
    # PWM settings
    pwm_output_port: str = ""  # ?PO - GPIO pin for PWM output
    pwm_port_mappings: List[Dict[str, Any]] = field(default_factory=list)  # ?PMS
    pwm_mappings: List[Dict[str, Any]] = field(default_factory=list)  # Legacy ?PWM
    kyber_settings: Dict[str, Any] = field(default_factory=dict)


@dataclass
class BackupChanges:
    """Changes detected between two backups."""

    commands_added: List[Dict[str, str]] = field(default_factory=list)
    commands_removed: List[Dict[str, str]] = field(default_factory=list)
    config_changes: List[Dict[str, str]] = field(default_factory=list)
    is_initial: bool = False  # True only for the very first backup of a device

    def is_empty(self) -> bool:
        """Check if no changes detected."""
        return (
            not self.commands_added
            and not self.commands_removed
            and not self.config_changes
        )

    def to_dict(self) -> Dict:
        """Convert to dictionary."""
        return {
            "commands_added": self.commands_added,
            "commands_removed": self.commands_removed,
            "config_changes": self.config_changes,
        }

    def generate_summary(self) -> str:
        """Generate human-readable change summary."""
        parts = []
        if self.commands_added:
            count = len(self.commands_added)
            parts.append(f"Added {count} command{'s' if count > 1 else ''}")
        if self.commands_removed:
            count = len(self.commands_removed)
            parts.append(f"Removed {count} command{'s' if count > 1 else ''}")
        if self.config_changes:
            count = len(self.config_changes)
            parts.append(f"{count} setting{'s' if count > 1 else ''} changed")
        if parts:
            return ", ".join(parts)
        # Only show "Initial backup" for the very first backup of a device
        return "Initial backup" if self.is_initial else ""


class WCBBackupManager:
    """
    Manages WCB configuration backups.

    Singleton pattern for centralized backup management.
    """

    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return

        self._initialized = True
        self._scheduler_task: Optional[asyncio.Task] = None
        self._scheduler_running = False

        # External dependencies (set by server.py)
        self.serial_port_manager = None

        # Event handlers for notifications
        self._event_handlers: Dict[str, List[Callable]] = {}

        # Track last checksum per device for delta detection
        self._last_checksums: Dict[str, str] = {}

        # Passive capture buffering
        self._capture_buffers: Dict[str, List[str]] = {}
        self._capture_active: Dict[str, bool] = {}
        self._capture_start_times: Dict[str, float] = {}

        # Paths
        self.config_path = str(CONFIG_DIR / "wcb_backup_config.json")
        self.history_path = str(DATA_DIR / "wcb_backup_history.json")
        self.backup_dir = DATA_DIR / "wcb_backups"

        # Ensure backup directory exists
        self.backup_dir.mkdir(parents=True, exist_ok=True)

        # Load configuration
        self.config = self._load_config()

        # Load last checksums from history
        self._load_last_checksums()

        logger.info("WCBBackupManager initialized")

    def _load_config(self) -> BackupConfig:
        """Load backup configuration from file."""
        data = load_json_config(
            self.config_path,
            defaults={
                "backup_interval_hours": 1.0,
                "max_backups": 50,
                "enabled": True,
                "save_all_backups": False,
            },
        )
        # Migration: if old retention_days exists, ignore it and use default max_backups
        return BackupConfig(
            backup_interval_hours=data.get("backup_interval_hours", 1.0),
            max_backups=data.get("max_backups", 50),
            enabled=data.get("enabled", True),
            save_all_backups=data.get("save_all_backups", False),
        )

    def save_config(self) -> bool:
        """Save backup configuration to file."""
        data = {
            "backup_interval_hours": self.config.backup_interval_hours,
            "max_backups": self.config.max_backups,
            "enabled": self.config.enabled,
            "save_all_backups": self.config.save_all_backups,
        }
        return save_json_config(self.config_path, data)

    def _load_last_checksums(self):
        """Load last checksums from backup history."""
        history = load_json_config(self.history_path, defaults={"entries": []})
        for entry in reversed(history.get("entries", [])):
            device_id = entry.get("device_id")
            checksum = entry.get("checksum")
            if device_id and checksum and device_id not in self._last_checksums:
                if entry.get("status") == "success":
                    self._last_checksums[device_id] = checksum

    # ─────────────────────────────────────────────────────────────────
    # CRC32 Verification
    # ─────────────────────────────────────────────────────────────────

    @staticmethod
    def calculate_crc32(data: bytes) -> str:
        """
        Calculate CRC32 checksum matching WCB firmware.

        Uses IEEE 802.3 polynomial (0xEDB88320).

        Args:
            data: Bytes data to checksum

        Returns:
            8-character uppercase hex string
        """
        crc = 0xFFFFFFFF
        for byte in data:
            crc ^= byte
            for _ in range(8):
                if crc & 1:
                    crc = (crc >> 1) ^ CRC32_POLYNOMIAL
                else:
                    crc = crc >> 1
        return f"{(crc ^ 0xFFFFFFFF) & 0xFFFFFFFF:08X}"

    def verify_checksum(self, raw_backup: str, expected_checksum: str) -> bool:
        """
        Verify backup data against expected CRC32 checksum.

        The checksum is calculated on the command string portion (everything
        before ?CHK on the same line).

        WCB backup outputs a long line with all stored commands concatenated by ^,
        ending with ?CHK<checksum>. The checksum is calculated on everything in
        that line before ?CHK (with trailing ^ removed).

        Args:
            raw_backup: Raw backup data
            expected_checksum: Expected 8-character hex checksum

        Returns:
            True if checksum matches
        """
        # Find the line containing ?CHK followed by the checksum
        # This line contains all stored commands joined by ^ delimiter
        # Format: ?CSname1,value1^*** desc^?CSname2,value2^...^?CHK<checksum>
        checksum_pattern = rf"\?CHK{expected_checksum}"
        match = re.search(checksum_pattern, raw_backup, re.IGNORECASE)
        if not match:
            logger.error(f"Could not find checksum marker ?CHK{expected_checksum}")
            return False

        # Find the start of the line containing the checksum
        # Search backwards from the match position to find the line
        checksum_pos = match.start()
        line_start = raw_backup.rfind("\n", 0, checksum_pos)
        if line_start == -1:
            line_start = 0
        else:
            line_start += 1  # Skip the newline

        # Extract the full line up to ?CHK
        full_line = raw_backup[line_start:checksum_pos]

        # The commands portion is everything before ?CHK
        # Sometimes there's content before it on the same line we need to ignore
        # Look for the first ?CS or other WCB command pattern
        commands_portion = full_line

        if not commands_portion:
            logger.error("Empty commands portion for checksum verification")
            return False

        # Remove trailing ^ if present (checksum is calculated without it)
        if commands_portion.endswith("^"):
            commands_portion = commands_portion[:-1]

        # Encode to bytes for consistent CRC32 calculation (latin-1 preserves byte values)
        try:
            data_bytes = commands_portion.encode("latin-1")
        except UnicodeEncodeError:
            logger.error("Commands contain non-Latin-1 characters, cannot calculate CRC32")
            return False

        calculated = self.calculate_crc32(data_bytes)

        if calculated.upper() == expected_checksum.upper():
            logger.debug(f"Checksum verified: {expected_checksum}")
            return True

        # Also verify with Python's binascii for comparison
        alt_crc = binascii.crc32(data_bytes) & 0xFFFFFFFF
        alt_calculated = f"{alt_crc:08X}"

        logger.warning(
            f"Checksum mismatch: calculated {calculated} (alt: {alt_calculated}), "
            f"expected {expected_checksum}. "
            f"Data length: {len(commands_portion)}, "
            f"First 80 chars: {repr(commands_portion[:80])}"
        )

        # Check if alternative calculation matches
        if alt_calculated.upper() == expected_checksum.upper():
            logger.info("Alternative CRC32 matched - using binascii")
            return True

        return False

    # ─────────────────────────────────────────────────────────────────
    # Backup Parsing
    # ─────────────────────────────────────────────────────────────────

    def parse_backup(self, raw_backup: str) -> Tuple[Optional[ParsedBackup], Dict]:
        """
        Parse ?BACKUP output into structured data.

        Actual format from WCB firmware (main.cpp printBackupConfig):
        *** WCB Configuration Backup
        *** Copy and paste these commands to restore
        *** ========================================
        ?HW24           <- individual config commands
        ?M222
        ?WCB1
        ?D^             <- delimiter command (always printed)
        ...
        ?CSname,value   <- individual stored commands
        ...
        *** === For Configured Boards (Current Delimiter: '^') ===
        [commands joined by CURRENT delimiter, ending with ?CHK<checksum1>]
        *** Checksum: ?CHK<checksum1>
        *** === For Factory Reset/Fresh Boards (Uses Default '^' Delimiter) ===
        [commands joined by DEFAULT '^' delimiter, ending with ?CHK<checksum2>]
        *** Checksum: ?CHK<checksum2>
        --------- End of Backup ---------

        KEY DIFFERENCE between sections:
        - "Configured" uses the board's CURRENT command delimiter (could be custom)
        - "Factory Reset" ALWAYS uses default '^' delimiter
        - The ?D<delimiter> command is only included in factory_reset if non-default

        Use factory_reset when restoring to a fresh/reset board that only understands '^'.
        Use configured when restoring to a board that already has your custom delimiter.

        Args:
            raw_backup: Raw backup output from WCB

        Returns:
            Tuple of (ParsedBackup, restore_commands dict) or (None, {}) on error
        """
        parsed = ParsedBackup()
        restore_commands = {"configured": "", "factory_reset": ""}

        # WCB backup has TWO restore sections with different purposes:
        # 1. "For Configured Boards" - uses current delimiter (could be custom)
        # 2. "For Factory Reset/Fresh Boards" - always uses default '^' delimiter
        #
        # The factory_reset version is needed when restoring to a board that has
        # been factory reset and only understands the default '^' delimiter.
        # The configured version is for boards that already have custom delimiter.

        def extract_line_after_header(header_pattern: str) -> str:
            """Extract the restore line that follows a section header."""
            match = re.search(header_pattern, raw_backup)
            if not match:
                return ""

            # Find the end of the header line
            header_end = raw_backup.find("\n", match.end())
            if header_end == -1:
                return ""

            # Find the next line (the actual restore data)
            line_start = header_end + 1
            line_end = raw_backup.find("\n", line_start)
            if line_end == -1:
                line_end = len(raw_backup)

            line = raw_backup[line_start:line_end].strip()

            # Validate it looks like a restore line (should have commands and end with ?CHK)
            if line and "?CHK" in line and len(line) > 100:
                return line
            return ""

        # Find restore lines by looking AFTER section headers
        # This avoids matching ^?CHK in stored command values
        configured_line = extract_line_after_header(
            r"\*\*\* === For Configured Boards.*==="
        )
        factory_reset_line = extract_line_after_header(
            r"\*\*\* === For Factory Reset.*==="
        )

        if configured_line:
            restore_commands["configured"] = configured_line
            checksum_match = re.search(r"\?CHK([A-Fa-f0-9]{8})$", configured_line)
            logger.debug(
                f"Found configured restore section, checksum: "
                f"{checksum_match.group(1) if checksum_match else 'unknown'}"
            )

        if factory_reset_line:
            restore_commands["factory_reset"] = factory_reset_line
            checksum_match = re.search(r"\?CHK([A-Fa-f0-9]{8})$", factory_reset_line)
            logger.debug(
                f"Found factory_reset restore section, checksum: "
                f"{checksum_match.group(1) if checksum_match else 'unknown'}"
            )

        # If only one section found, use it for both
        if configured_line and not factory_reset_line:
            restore_commands["factory_reset"] = configured_line
        elif factory_reset_line and not configured_line:
            restore_commands["configured"] = factory_reset_line

        # Parse individual lines from the backup (for readable format)
        lines = raw_backup.split("\n")

        for line in lines:
            line = line.strip()
            if not line or line.startswith("***") or line.startswith("-"):
                continue

            # Skip concatenated restore lines (they contain ^?CHK at the end)
            # These lines have ALL commands joined by ^, which would create
            # duplicate/truncated entries if we parse them here.
            # We only want to parse the individual command lines above them.
            if "^?CHK" in line:
                continue

            # IMPORTANT: ?CS commands can contain ^ as delimiters in their values
            # e.g., ?CSalarm,<CA0010>^*** Play Sound^4T03^...
            # These should NOT be split by ^ - the entire line is one command
            if line.startswith("?CS"):
                self._parse_command(line, parsed)
            elif "^" in line:
                # Lines may contain multiple ^-delimited commands (e.g., ?HW24^?WCB1^?BR1,9600)
                # But NOT stored commands - those should only come from individual lines
                for cmd in line.split("^"):
                    cmd = cmd.strip()
                    if not cmd or cmd.startswith("?CHK") or cmd.startswith("?CS"):
                        continue
                    self._parse_command(cmd, parsed)
            else:
                # Single command per line
                self._parse_command(line, parsed)

        # If we found stored commands from individual lines but no restore commands,
        # try to extract from long concatenated line
        if not parsed.stored_commands and restore_commands.get("configured"):
            # Split at ^ only when followed by ? (command boundary)
            # This preserves ^ inside ?CS command values
            # e.g., "?HW24^?CSalarm,<CA0010>^*** Play^4T03^?WCB1" splits correctly
            commands = re.split(r"\^(?=\?)", restore_commands["configured"])
            for cmd in commands:
                cmd = cmd.strip()
                if not cmd or cmd.startswith("?CHK") or cmd.startswith("***"):
                    continue
                self._parse_command(cmd, parsed)

        if parsed.stored_commands or parsed.hw_version:
            return parsed, restore_commands

        logger.warning("Could not parse any commands from backup")
        return None, {}

    def _parse_command(self, cmd: str, parsed: ParsedBackup):
        """Parse individual WCB command and update ParsedBackup."""
        # Hardware version: ?HW24
        if cmd.startswith("?HW"):
            parsed.hw_version = cmd[3:]

        # WCB number: ?WCB1
        elif cmd.startswith("?WCB") and not cmd.startswith("?WCBQ"):
            parsed.wcb_number = cmd[4:]

        # WCB quantity: ?WCBQ3
        elif cmd.startswith("?WCBQ"):
            parsed.wcb_quantity = cmd[5:]

        # MAC octets: ?MAC222,33 (combined format) or ?M222/?M355 (separate format)
        # Separate format: ?M<octet_num><value> e.g., ?M222 = octet 2, value 22
        elif cmd.startswith("?MAC"):
            mac_parts = cmd[4:].split(",")
            if len(mac_parts) >= 2:
                parsed.mac_octet2 = mac_parts[0]
                parsed.mac_octet3 = mac_parts[1]
        elif cmd.startswith("?M") and len(cmd) >= 3 and cmd[2].isdigit():
            # Format: ?M<octet><value> - e.g., ?M222 means octet 2, value 22
            octet_num = cmd[2]
            value = cmd[3:] if len(cmd) > 3 else ""
            if octet_num == "2":
                parsed.mac_octet2 = value
            elif octet_num == "3":
                parsed.mac_octet3 = value

        # ESP-NOW password: ?EPASS<password> (firmware outputs ?EPASS, extracts from position 6)
        elif cmd.startswith("?EPASS"):
            parsed.esp_now_password = cmd[6:]

        # Command delimiter: ?D^ (single character after ?D)
        elif cmd.startswith("?D") and len(cmd) == 3:
            parsed.command_delimiter = cmd[2]

        # Local function identifier: ?LF? or ?LF; (single character after ?LF)
        elif cmd.startswith("?LF") and len(cmd) == 4:
            parsed.local_function_id = cmd[3]

        # Command character: ?CC; or ?CC? (single character after ?CC)
        elif cmd.startswith("?CC") and len(cmd) == 4:
            parsed.command_character = cmd[3]

        # Baud rate: ?BR1,9600
        elif cmd.startswith("?BR"):
            match = re.match(r"\?BR(\d),(\d+)", cmd)
            if match:
                port = match.group(1)
                baud = int(match.group(2))
                parsed.baud_rates[port] = baud

        # Broadcast enable: ?BC1,1 (legacy format)
        elif cmd.startswith("?BC"):
            match = re.match(r"\?BC(\d),(\d)", cmd)
            if match:
                port = match.group(1)
                enabled = match.group(2) == "1"
                parsed.broadcast_enabled[port] = enabled

        # Broadcast OUTPUT: ?SBOx0/1 (WCB v5.6+ format)
        # Format: ?SBO<port><0|1> e.g., ?SBO11 = Serial1 broadcast output ON
        elif cmd.startswith("?SBO"):
            match = re.match(r"\?SBO(\d)([01])", cmd)
            if match:
                port = match.group(1)
                enabled = match.group(2) == "1"
                parsed.broadcast_output[port] = enabled

        # Broadcast INPUT: ?SBIx0/1 (WCB v5.6+ format)
        # Format: ?SBI<port><0|1> e.g., ?SBI11 = Serial1 broadcast input ON
        elif cmd.startswith("?SBI"):
            match = re.match(r"\?SBI(\d)([01])", cmd)
            if match:
                port = match.group(1)
                enabled = match.group(2) == "1"
                parsed.broadcast_input[port] = enabled

        # Legacy broadcast output: ?Sx0/1 (deprecated, maps to broadcast_output)
        # Format: ?S<port><0|1> e.g., ?S11 = Serial1 broadcast output ON
        # Note: Must check this AFTER ?SBO/?SBI to avoid false matches
        elif cmd.startswith("?S") and len(cmd) == 4 and cmd[2].isdigit() and cmd[3] in "01":
            port = cmd[2]
            enabled = cmd[3] == "1"
            parsed.broadcast_output[port] = enabled
            # Also set legacy field for backward compatibility
            parsed.broadcast_enabled[port] = enabled

        # Serial label: ?SL1,Body
        elif cmd.startswith("?SL"):
            match = re.match(r"\?SL(\d),(.+)", cmd)
            if match:
                port = match.group(1)
                label = match.group(2)
                parsed.serial_labels[port] = label

        # Serial monitor mapping: ?SM1,S2,W3S4 (WCB v5.3+ HCR_Port_Mirror)
        # Format: ?SM<input_port>,<output1>,<output2>,...
        # Output format: S<port> (local) or W<wcb>S<port> (remote)
        elif cmd.startswith("?SM") and not cmd.startswith("?SMR") and not cmd.startswith("?SMLIST") and not cmd.startswith("?SMCLEAR"):
            parts = cmd[3:].split(",")  # Skip "?SM"
            if len(parts) >= 2:
                input_port = parts[0]
                outputs = parts[1:]  # Rest are output destinations
                parsed.serial_monitor_mappings.append({
                    "input_port": input_port,
                    "outputs": outputs
                })

        # PWM output port: ?PO5 (GPIO pin for PWM output)
        elif cmd.startswith("?PO") and not cmd.startswith("?POW"):
            port = cmd[3:]  # Skip "?PO"
            if port.isdigit():
                # Can have multiple PWM output ports, store as list
                if not parsed.pwm_output_port:
                    parsed.pwm_output_port = port
                else:
                    # Append additional ports with comma
                    parsed.pwm_output_port += f",{port}"

        # PWM port mapping: ?PMS1,S2,W3S4 (similar format to serial monitor)
        elif cmd.startswith("?PMS"):
            parts = cmd[4:].split(",")  # Skip "?PMS"
            if len(parts) >= 2:
                input_port = parts[0]
                outputs = parts[1:]
                parsed.pwm_port_mappings.append({
                    "input_port": input_port,
                    "outputs": outputs
                })

        # Stored command: ?CSCMD1,POWER_ON
        elif cmd.startswith("?CS"):
            match = re.match(r"\?CS([^,]+),(.+)", cmd)
            if match:
                key = match.group(1)
                value = match.group(2)
                parsed.stored_commands.append({"key": key, "value": value})

        # PWM mapping: ?PWM1,2,3,4
        elif cmd.startswith("?PWM"):
            match = re.match(r"\?PWM(\d+),(\d+),(\d+),(\d+)", cmd)
            if match:
                parsed.pwm_mappings.append(
                    {
                        "channel": int(match.group(1)),
                        "pin": int(match.group(2)),
                        "min": int(match.group(3)),
                        "max": int(match.group(4)),
                    }
                )

        # Kyber settings: ?KYBER_LOCAL, ?KYBER_REMOTE, ?KYBER_CLEAR
        elif cmd.startswith("?KYBER_LOCAL"):
            parsed.kyber_settings["status"] = "local"
        elif cmd.startswith("?KYBER_REMOTE"):
            parsed.kyber_settings["status"] = "remote"
        elif cmd.startswith("?KYBER_CLEAR"):
            parsed.kyber_settings["status"] = "clear"
        # Legacy Kyber format support (in case older backups used this)
        elif cmd.startswith("?KYBE"):
            # Old format: ?KYBE1 or ?KYBE0
            parsed.kyber_settings["enabled"] = cmd[5:] == "1"
            # Map to new status format for compatibility
            if cmd[5:] == "1":
                parsed.kyber_settings["status"] = "local"
            else:
                parsed.kyber_settings["status"] = "clear"

    def extract_checksum(self, raw_backup: str) -> Optional[str]:
        """
        Extract checksum from backup output.

        Args:
            raw_backup: Raw backup output

        Returns:
            8-character hex checksum or None
        """
        # Look for ?CHK followed by 8 hex characters
        match = re.search(r"\?CHK([A-Fa-f0-9]{8})", raw_backup)
        if match:
            return match.group(1).upper()
        return None

    # ─────────────────────────────────────────────────────────────────
    # Change Detection
    # ─────────────────────────────────────────────────────────────────

    def detect_changes(
        self, current: ParsedBackup, previous: Optional[ParsedBackup]
    ) -> BackupChanges:
        """
        Detect changes between current and previous backup.

        Args:
            current: Current parsed backup
            previous: Previous parsed backup (or None for initial)

        Returns:
            BackupChanges with added/removed commands and config changes
        """
        changes = BackupChanges()

        if previous is None:
            # Initial backup - mark as initial so summary shows "Initial backup"
            changes.is_initial = True
            return changes

        # Compare stored commands
        curr_cmds = {c["key"]: c["value"] for c in current.stored_commands}
        prev_cmds = {c["key"]: c["value"] for c in previous.stored_commands}

        for key, value in curr_cmds.items():
            if key not in prev_cmds:
                changes.commands_added.append({"key": key, "value": value})
            elif prev_cmds[key] != value:
                changes.config_changes.append(
                    {
                        "setting": f"command.{key}",
                        "old": prev_cmds[key],
                        "new": value,
                    }
                )

        for key, value in prev_cmds.items():
            if key not in curr_cmds:
                changes.commands_removed.append({"key": key, "value": value})

        # Compare config settings
        config_fields = [
            ("hw_version", "Hardware Version"),
            ("wcb_number", "WCB Number"),
            ("wcb_quantity", "WCB Quantity"),
            ("mac_octet2", "MAC Octet 2"),
            ("mac_octet3", "MAC Octet 3"),
            ("esp_now_password", "ESP-NOW Password"),
            ("command_delimiter", "Command Delimiter"),
            ("local_function_id", "Local Function ID"),
            ("command_character", "Command Character"),
            ("pwm_output_port", "PWM Output Port"),
        ]

        for field_name, display_name in config_fields:
            curr_val = getattr(current, field_name, "")
            prev_val = getattr(previous, field_name, "")
            if curr_val != prev_val:
                changes.config_changes.append(
                    {"setting": display_name, "old": str(prev_val), "new": str(curr_val)}
                )

        # Compare baud rates
        for port in set(current.baud_rates.keys()) | set(previous.baud_rates.keys()):
            curr_baud = current.baud_rates.get(port)
            prev_baud = previous.baud_rates.get(port)
            if curr_baud != prev_baud:
                changes.config_changes.append(
                    {
                        "setting": f"Serial {port} Baud Rate",
                        "old": str(prev_baud) if prev_baud else "N/A",
                        "new": str(curr_baud) if curr_baud else "N/A",
                    }
                )

        # Compare broadcast enabled (legacy field)
        for port in set(current.broadcast_enabled.keys()) | set(
            previous.broadcast_enabled.keys()
        ):
            curr_bc = current.broadcast_enabled.get(port)
            prev_bc = previous.broadcast_enabled.get(port)
            if curr_bc != prev_bc:
                changes.config_changes.append(
                    {
                        "setting": f"Serial {port} Broadcast",
                        "old": "Enabled" if prev_bc else "Disabled",
                        "new": "Enabled" if curr_bc else "Disabled",
                    }
                )

        # Compare broadcast output (WCB v5.6+ ?SBO)
        for port in set(current.broadcast_output.keys()) | set(
            previous.broadcast_output.keys()
        ):
            curr_bo = current.broadcast_output.get(port)
            prev_bo = previous.broadcast_output.get(port)
            if curr_bo != prev_bo:
                changes.config_changes.append(
                    {
                        "setting": f"Serial {port} Broadcast Output",
                        "old": "Enabled" if prev_bo else "Disabled",
                        "new": "Enabled" if curr_bo else "Disabled",
                    }
                )

        # Compare broadcast input (WCB v5.6+ ?SBI)
        for port in set(current.broadcast_input.keys()) | set(
            previous.broadcast_input.keys()
        ):
            curr_bi = current.broadcast_input.get(port)
            prev_bi = previous.broadcast_input.get(port)
            if curr_bi != prev_bi:
                changes.config_changes.append(
                    {
                        "setting": f"Serial {port} Broadcast Input",
                        "old": "Enabled" if prev_bi else "Disabled",
                        "new": "Enabled" if curr_bi else "Disabled",
                    }
                )

        # Compare serial labels
        for port in set(current.serial_labels.keys()) | set(
            previous.serial_labels.keys()
        ):
            curr_label = current.serial_labels.get(port, "")
            prev_label = previous.serial_labels.get(port, "")
            if curr_label != prev_label:
                changes.config_changes.append(
                    {
                        "setting": f"Serial {port} Label",
                        "old": prev_label or "(none)",
                        "new": curr_label or "(none)",
                    }
                )

        # Compare serial monitor mappings
        curr_sm = {m["input_port"]: m["outputs"] for m in current.serial_monitor_mappings}
        prev_sm = {m["input_port"]: m["outputs"] for m in previous.serial_monitor_mappings}
        for port in set(curr_sm.keys()) | set(prev_sm.keys()):
            curr_outputs = curr_sm.get(port, [])
            prev_outputs = prev_sm.get(port, [])
            if curr_outputs != prev_outputs:
                changes.config_changes.append(
                    {
                        "setting": f"Serial Monitor {port}",
                        "old": ",".join(prev_outputs) if prev_outputs else "(none)",
                        "new": ",".join(curr_outputs) if curr_outputs else "(none)",
                    }
                )

        # Compare PWM port mappings
        curr_pwm = {m["input_port"]: m["outputs"] for m in current.pwm_port_mappings}
        prev_pwm = {m["input_port"]: m["outputs"] for m in previous.pwm_port_mappings}
        for port in set(curr_pwm.keys()) | set(prev_pwm.keys()):
            curr_outputs = curr_pwm.get(port, [])
            prev_outputs = prev_pwm.get(port, [])
            if curr_outputs != prev_outputs:
                changes.config_changes.append(
                    {
                        "setting": f"PWM Mapping {port}",
                        "old": ",".join(prev_outputs) if prev_outputs else "(none)",
                        "new": ",".join(curr_outputs) if curr_outputs else "(none)",
                    }
                )

        return changes

    # ─────────────────────────────────────────────────────────────────
    # Backup Storage
    # ─────────────────────────────────────────────────────────────────

    def _get_previous_backup(self, device_id: str) -> Optional[Dict]:
        """Get the most recent backup for a device."""
        history = load_json_config(self.history_path, defaults={"entries": []})

        for entry in reversed(history.get("entries", [])):
            if (
                entry.get("device_id") == device_id
                and entry.get("status") == "success"
            ):
                backup_file = entry.get("backup_file")
                if backup_file:
                    backup_path = self.backup_dir / backup_file
                    if backup_path.exists():
                        return load_json_config(str(backup_path), defaults=None)
        return None

    @staticmethod
    def _validate_device_id(device_id: str) -> bool:
        """Validate device_id format to prevent injection attacks."""
        if not device_id or len(device_id) > 100:
            return False
        # Allow alphanumeric, dash, underscore, colon, period (typical USB device IDs)
        allowed_chars = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_:.")
        return all(c in allowed_chars for c in device_id)

    def save_backup(
        self,
        device_id: str,
        port: str,
        raw_backup: str,
        trigger: str = "manual",
    ) -> Tuple[bool, str]:
        """
        Process and save a backup.

        Args:
            device_id: Unique device identifier
            port: Serial port path
            raw_backup: Raw backup output from WCB
            trigger: What triggered the backup (manual/scheduled/passive)

        Returns:
            Tuple of (success, message)
        """
        # Validate device_id to prevent injection in filenames
        if not self._validate_device_id(device_id):
            logger.warning(f"Invalid device_id format: {device_id!r}")
            return False, "Invalid device_id format"

        timestamp = datetime.now().timestamp()

        # Extract checksum from backup
        checksum = self.extract_checksum(raw_backup)
        if not checksum:
            self._record_error(device_id, port, "No checksum found in backup", trigger)
            return False, "No checksum found in backup"

        # Verify CRC32 using the configured board section
        if not self.verify_checksum(raw_backup, checksum):
            self._record_error(
                device_id,
                port,
                f"CRC32 verification failed for checksum {checksum}",
                trigger,
            )
            return False, "CRC32 verification failed"

        # Check for delta - if same checksum, skip unless save_all_backups is enabled
        if not self.config.save_all_backups:
            if device_id in self._last_checksums:
                if self._last_checksums[device_id] == checksum:
                    logger.debug(f"Backup unchanged for {device_id}, skipping")
                    return True, "No changes detected"

        # Parse backup
        parsed, restore_commands = self.parse_backup(raw_backup)
        if parsed is None:
            self._record_error(device_id, port, "Failed to parse backup", trigger)
            return False, "Failed to parse backup"

        # Get previous backup for change detection
        prev_backup = self._get_previous_backup(device_id)
        prev_parsed = None
        if prev_backup:
            prev_parsed = self._dict_to_parsed_backup(prev_backup.get("parsed_config"))

        # Detect changes
        changes = self.detect_changes(parsed, prev_parsed)

        # Generate filename
        timestamp_str = datetime.fromtimestamp(timestamp).strftime("%Y%m%d%H%M%S")
        filename = f"{device_id}_{timestamp_str}.json"

        # Extract both checksums to detect if board uses custom delimiter
        checksum_matches = list(re.finditer(r"\?CHK([A-Fa-f0-9]{8})", raw_backup))
        configured_checksum = checksum_matches[0].group(1) if checksum_matches else checksum
        factory_reset_checksum = (
            checksum_matches[1].group(1)
            if len(checksum_matches) >= 2
            else configured_checksum
        )

        # If checksums match, board uses default '^' delimiter - either restore mode works
        # If different, board uses custom delimiter - must choose correct mode for target
        uses_default_delimiter = configured_checksum.upper() == factory_reset_checksum.upper()

        # Build backup data
        backup_data = {
            "device_id": device_id,
            "port": port,
            "timestamp": timestamp,
            "checksum": checksum,
            "factory_reset_checksum": factory_reset_checksum,
            "checksum_verified": True,
            "uses_default_delimiter": uses_default_delimiter,
            "restore_commands": restore_commands,
            "parsed_config": self._parsed_backup_to_dict(parsed),
            "changes_from_previous": changes.to_dict(),
            "raw_backup": raw_backup,
        }

        # Save backup file
        backup_path = self.backup_dir / filename
        if not save_json_config(str(backup_path), backup_data):
            self._record_error(device_id, port, "Failed to save backup file", trigger)
            return False, "Failed to save backup file"

        # Update history
        self._record_success(
            device_id,
            port,
            checksum,
            filename,
            trigger,
            changes.generate_summary(),
            parsed.wcb_number,
            parsed.mac_octet2,
            parsed.mac_octet3,
        )

        # Update last checksum
        self._last_checksums[device_id] = checksum

        # Clean old backups
        self._cleanup_old_backups()

        logger.info(f"Saved backup for {device_id}: {filename}")
        return True, f"Backup saved: {changes.generate_summary()}"

    def _parsed_backup_to_dict(self, parsed: ParsedBackup) -> Dict:
        """Convert ParsedBackup to dictionary."""
        return {
            "hw_version": parsed.hw_version,
            "wcb_number": parsed.wcb_number,
            "wcb_quantity": parsed.wcb_quantity,
            "mac_octet2": parsed.mac_octet2,
            "mac_octet3": parsed.mac_octet3,
            "esp_now_password": parsed.esp_now_password,
            "command_delimiter": parsed.command_delimiter,  # ?D
            "local_function_id": parsed.local_function_id,  # ?LF
            "command_character": parsed.command_character,  # ?CC
            "baud_rates": parsed.baud_rates,
            "broadcast_enabled": parsed.broadcast_enabled,  # Legacy field
            "broadcast_output": parsed.broadcast_output,  # WCB v5.6+ ?SBO
            "broadcast_input": parsed.broadcast_input,  # WCB v5.6+ ?SBI
            "serial_labels": parsed.serial_labels,
            "serial_monitor_mappings": parsed.serial_monitor_mappings,  # ?SM
            "stored_commands": parsed.stored_commands,
            "pwm_output_port": parsed.pwm_output_port,  # ?PO
            "pwm_port_mappings": parsed.pwm_port_mappings,  # ?PMS
            "pwm_mappings": parsed.pwm_mappings,  # Legacy ?PWM
            "kyber_settings": parsed.kyber_settings,
        }

    def _dict_to_parsed_backup(self, data: Optional[Dict]) -> Optional[ParsedBackup]:
        """Convert dictionary to ParsedBackup."""
        if not data:
            return None

        parsed = ParsedBackup()
        parsed.hw_version = data.get("hw_version", "")
        parsed.wcb_number = data.get("wcb_number", "")
        parsed.wcb_quantity = data.get("wcb_quantity", "")
        parsed.mac_octet2 = data.get("mac_octet2", "")
        parsed.mac_octet3 = data.get("mac_octet3", "")
        parsed.esp_now_password = data.get("esp_now_password", "")
        parsed.command_delimiter = data.get("command_delimiter", "")
        parsed.local_function_id = data.get("local_function_id", "")
        parsed.command_character = data.get("command_character", "")
        parsed.baud_rates = data.get("baud_rates", {})
        parsed.broadcast_enabled = data.get("broadcast_enabled", {})
        parsed.broadcast_output = data.get("broadcast_output", {})
        parsed.broadcast_input = data.get("broadcast_input", {})
        parsed.serial_labels = data.get("serial_labels", {})
        parsed.serial_monitor_mappings = data.get("serial_monitor_mappings", [])
        parsed.stored_commands = data.get("stored_commands", [])
        parsed.pwm_output_port = data.get("pwm_output_port", "")
        parsed.pwm_port_mappings = data.get("pwm_port_mappings", [])
        parsed.pwm_mappings = data.get("pwm_mappings", [])
        parsed.kyber_settings = data.get("kyber_settings", {})

        # Backward compatibility: if no broadcast_output but has broadcast_enabled,
        # use broadcast_enabled as broadcast_output (old backups used this for output)
        if not parsed.broadcast_output and parsed.broadcast_enabled:
            parsed.broadcast_output = parsed.broadcast_enabled.copy()

        return parsed

    def _record_success(
        self,
        device_id: str,
        port: str,
        checksum: str,
        filename: str,
        trigger: str,
        change_summary: str,
        wcb_number: str = "",
        mac_octet2: str = "",
        mac_octet3: str = "",
    ):
        """Record successful backup in history."""
        history = load_json_config(self.history_path, defaults={"entries": []})

        # Format MAC octets as combined string (e.g., "222,33")
        mac_octets = f"{mac_octet2},{mac_octet3}" if mac_octet2 and mac_octet3 else ""

        history["entries"].append(
            {
                "device_id": device_id,
                "wcb_number": wcb_number,
                "mac_octets": mac_octets,
                "port": port,
                "timestamp": datetime.now().timestamp(),
                "status": "success",
                "checksum": checksum,
                "backup_file": filename,
                "trigger": trigger,
                "change_summary": change_summary,
            }
        )

        save_json_config(self.history_path, history)

    def _record_error(self, device_id: str, port: str, error: str, trigger: str):
        """Record backup error in history and emit event."""
        history = load_json_config(self.history_path, defaults={"entries": []})

        history["entries"].append(
            {
                "device_id": device_id,
                "port": port,
                "timestamp": datetime.now().timestamp(),
                "status": "error",
                "error": error,
                "trigger": trigger,
            }
        )

        save_json_config(self.history_path, history)

        # Emit error event for toast notification
        self._emit_event(
            "backup_error", {"device_id": device_id, "port": port, "error": error}
        )

        logger.error(f"Backup error for {device_id}: {error}")

    def _cleanup_old_backups(self):
        """Remove backups beyond the max_backups limit (keeps newest N backups)."""
        max_backups = self.config.max_backups

        # Get all backup files with their timestamps
        backup_files = []
        for backup_file in self.backup_dir.glob("*.json"):
            try:
                data = load_json_config(str(backup_file), defaults={})
                timestamp = data.get("timestamp", 0)
                backup_files.append((backup_file, timestamp))
            except Exception as e:
                logger.error(f"Error reading backup {backup_file}: {e}")

        # Sort by timestamp descending (newest first)
        backup_files.sort(key=lambda x: x[1], reverse=True)

        # Delete backups beyond the limit
        files_to_keep = set()
        for backup_file, _ in backup_files[:max_backups]:
            files_to_keep.add(backup_file.name)

        for backup_file, _ in backup_files[max_backups:]:
            try:
                backup_file.unlink()
                logger.debug(f"Deleted old backup: {backup_file.name}")
            except Exception as e:
                logger.error(f"Error deleting backup {backup_file}: {e}")

        # Clean history entries that no longer have backup files
        history = load_json_config(self.history_path, defaults={"entries": []})
        history["entries"] = [
            e
            for e in history["entries"]
            if e.get("status") != "success" or e.get("backup_file") in files_to_keep
        ]
        save_json_config(self.history_path, history)

    # ─────────────────────────────────────────────────────────────────
    # Passive Capture
    # ─────────────────────────────────────────────────────────────────

    # Maximum lines to buffer for passive capture (prevents memory exhaustion)
    MAX_CAPTURE_BUFFER_LINES = 500

    async def on_serial_data(
        self, port: str, device_id: str, line: str, timestamp: float
    ):
        """
        Process serial data for passive backup capture.

        Called by WCBListener for each line received.
        """
        # Check for backup start marker
        if "WCB Configuration Backup" in line:
            self._capture_active[device_id] = True
            self._capture_buffers[device_id] = [line]
            self._capture_start_times[device_id] = timestamp
            logger.debug(f"Started passive backup capture for {device_id}")
            return

        # If capturing, buffer the line
        if self._capture_active.get(device_id):
            # Check buffer size limit
            if len(self._capture_buffers[device_id]) >= self.MAX_CAPTURE_BUFFER_LINES:
                logger.warning(
                    f"Passive capture buffer exceeded {self.MAX_CAPTURE_BUFFER_LINES} lines "
                    f"for {device_id}, aborting capture"
                )
                self._capture_active[device_id] = False
                self._capture_buffers[device_id] = []
                self._capture_start_times.pop(device_id, None)
                return

            # Check capture timeout (30 seconds max)
            start_time = self._capture_start_times.get(device_id, timestamp)
            if timestamp - start_time > 30.0:
                logger.warning(
                    f"Passive capture timeout for {device_id} after 30s, aborting"
                )
                self._capture_active[device_id] = False
                self._capture_buffers[device_id] = []
                self._capture_start_times.pop(device_id, None)
                return

            self._capture_buffers[device_id].append(line)

            # Check for end marker
            if "End of Backup" in line:
                self._capture_active[device_id] = False
                raw_backup = "\n".join(self._capture_buffers[device_id])
                self._capture_buffers[device_id] = []
                self._capture_start_times.pop(device_id, None)

                logger.info(f"Passive backup capture complete for {device_id}")

                # Process the backup
                success, message = self.save_backup(
                    device_id=device_id,
                    port=port,
                    raw_backup=raw_backup,
                    trigger="passive",
                )

                if not success and "No changes" not in message:
                    logger.warning(f"Passive backup failed: {message}")

    # ─────────────────────────────────────────────────────────────────
    # Scheduled Backups
    # ─────────────────────────────────────────────────────────────────

    async def start_scheduler(self):
        """Start the backup scheduler."""
        if self._scheduler_running:
            return

        self._scheduler_running = True
        self._scheduler_task = asyncio.create_task(self._scheduler_loop())
        logger.info("Backup scheduler started")

    async def stop_scheduler(self):
        """Stop the backup scheduler."""
        self._scheduler_running = False
        if self._scheduler_task:
            self._scheduler_task.cancel()
            try:
                await self._scheduler_task
            except asyncio.CancelledError:
                pass
        logger.info("Backup scheduler stopped")

    async def _scheduler_loop(self):
        """Main scheduler loop."""
        while self._scheduler_running:
            try:
                # Wait for configured interval
                interval_seconds = self.config.backup_interval_hours * 3600
                await asyncio.sleep(interval_seconds)

                if not self.config.enabled:
                    continue

                # Trigger backup for all active WCB devices
                await self._run_scheduled_backups()

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Scheduler error: {e}")
                await asyncio.sleep(60)  # Wait before retry

    async def _run_scheduled_backups(self):
        """Run scheduled backup for all active WCB devices."""
        if not self.serial_port_manager:
            logger.warning("SerialPortManager not set, skipping scheduled backup")
            return

        # Get all WCB devices in always-on mode
        try:
            active_ports = self.serial_port_manager.get_always_on_ports()
        except Exception as e:
            logger.error(f"Failed to get always-on ports: {e}")
            return

        for port_info in active_ports:
            port = port_info.get("port")
            device_id = port_info.get("device_id")

            if not port or not device_id:
                continue

            try:
                await self._trigger_backup(port, device_id, "scheduled")
            except Exception as e:
                logger.error(f"Scheduled backup failed for {device_id}: {e}")

    async def _trigger_backup(self, port: str, device_id: str, trigger: str):
        """
        Trigger a backup for a specific device.

        Sends ?BACKUP command and waits for response.
        """
        if not self.serial_port_manager:
            raise RuntimeError("SerialPortManager not set")

        handler = self.serial_port_manager.get_handler(port)
        if not handler:
            raise RuntimeError(f"No handler for port {port}")

        # Send ?BACKUP command
        await handler.write("?BACKUP")

        # Response will be captured via on_serial_data passive capture
        # The WCB will respond with the full backup output

    async def trigger_manual_backup(
        self, port: str, device_id: str
    ) -> Tuple[bool, str]:
        """
        Trigger a manual backup for a device.

        Returns:
            Tuple of (success, message)
        """
        try:
            await self._trigger_backup(port, device_id, "manual")
            return True, "Backup triggered"
        except Exception as e:
            return False, str(e)

    # ─────────────────────────────────────────────────────────────────
    # Event Handling
    # ─────────────────────────────────────────────────────────────────

    def register_event_handler(self, event_type: str, handler: Callable):
        """Register handler for backup events."""
        if event_type not in self._event_handlers:
            self._event_handlers[event_type] = []
        self._event_handlers[event_type].append(handler)

    def _emit_event(self, event_type: str, data: Dict):
        """Emit event to registered handlers."""
        if event_type in self._event_handlers:
            for handler in self._event_handlers[event_type]:
                try:
                    # Handle both sync and async handlers
                    result = handler(data)
                    if asyncio.iscoroutine(result):
                        asyncio.create_task(result)
                except Exception as e:
                    logger.error(f"Error in event handler: {e}")

    # ─────────────────────────────────────────────────────────────────
    # Query Methods
    # ─────────────────────────────────────────────────────────────────

    def get_backup_list(
        self, device_id: Optional[str] = None, page: int = 1, page_size: int = 20
    ) -> Dict:
        """
        Get paginated list of backups.

        Args:
            device_id: Filter by device (optional)
            page: Page number (1-indexed)
            page_size: Items per page

        Returns:
            Dict with backups list and pagination info
        """
        history = load_json_config(self.history_path, defaults={"entries": []})
        entries = history.get("entries", [])

        # Filter by device if specified
        if device_id:
            entries = [e for e in entries if e.get("device_id") == device_id]

        # Filter to successful backups only (errors shown in history view)
        backup_entries = [e for e in entries if e.get("status") == "success"]

        # Sort by timestamp descending (newest first)
        backup_entries.sort(key=lambda x: x.get("timestamp", 0), reverse=True)

        # Paginate
        total = len(backup_entries)
        start = (page - 1) * page_size
        end = start + page_size
        page_entries = backup_entries[start:end]

        return {
            "backups": page_entries,
            "total": total,
            "page": page,
            "page_size": page_size,
            "total_pages": (total + page_size - 1) // page_size,
        }

    def get_backup_history(
        self, device_id: Optional[str] = None, page: int = 1, page_size: int = 50
    ) -> Dict:
        """
        Get paginated backup history (including errors).

        Args:
            device_id: Filter by device (optional)
            page: Page number (1-indexed)
            page_size: Items per page

        Returns:
            Dict with history entries and pagination info
        """
        history = load_json_config(self.history_path, defaults={"entries": []})
        entries = history.get("entries", [])

        # Filter by device if specified
        if device_id:
            entries = [e for e in entries if e.get("device_id") == device_id]

        # Sort by timestamp descending
        entries.sort(key=lambda x: x.get("timestamp", 0), reverse=True)

        # Paginate
        total = len(entries)
        start = (page - 1) * page_size
        end = start + page_size
        page_entries = entries[start:end]

        return {
            "entries": page_entries,
            "total": total,
            "page": page,
            "page_size": page_size,
            "total_pages": (total + page_size - 1) // page_size,
        }

    def get_backup_content(self, filename: str) -> Optional[Dict]:
        """
        Get full content of a backup file.

        Args:
            filename: Backup filename

        Returns:
            Backup data dict or None
        """
        # Validate filename to prevent path traversal
        if (
            "/" in filename
            or ".." in filename
            or "\\" in filename
            or "\x00" in filename
            or len(filename) > 255
        ):
            logger.warning(f"Invalid backup filename: {filename}")
            return None

        backup_path = (self.backup_dir / filename).resolve()

        # Verify resolved path is within backup directory
        if not str(backup_path).startswith(str(self.backup_dir.resolve())):
            logger.warning(f"Path traversal attempt detected: {filename}")
            return None

        if not backup_path.exists():
            return None

        return load_json_config(str(backup_path), defaults=None)

    def delete_backup(self, filename: str) -> bool:
        """
        Delete a backup file and its history entry.

        Args:
            filename: Backup filename

        Returns:
            True if deleted successfully, False otherwise
        """
        # Validate filename to prevent path traversal
        if (
            "/" in filename
            or ".." in filename
            or "\\" in filename
            or "\x00" in filename
            or len(filename) > 255
        ):
            logger.warning(f"Invalid backup filename for delete: {filename}")
            return False

        backup_path = (self.backup_dir / filename).resolve()

        # Verify resolved path is within backup directory
        if not str(backup_path).startswith(str(self.backup_dir.resolve())):
            logger.warning(f"Path traversal attempt detected: {filename}")
            return False

        # Delete the backup file
        if backup_path.exists():
            try:
                backup_path.unlink()
                logger.info(f"Deleted backup file: {filename}")
            except Exception as e:
                logger.error(f"Failed to delete backup file {filename}: {e}")
                return False

        # Remove entry from history
        history = load_json_config(self.history_path, defaults={"entries": []})
        original_count = len(history.get("entries", []))
        history["entries"] = [
            entry
            for entry in history.get("entries", [])
            if entry.get("backup_file") != filename
        ]
        new_count = len(history["entries"])

        if new_count < original_count:
            save_json_config(self.history_path, history)
            logger.info(f"Removed {original_count - new_count} history entries for {filename}")

        return True

    def clear_all_backups(self) -> Dict[str, Any]:
        """
        Delete all backup files and clear history.

        Returns:
            Dict with success status and count of deleted files
        """
        deleted_count = 0
        errors = []

        # Delete all backup files in the directory
        try:
            for backup_file in self.backup_dir.glob("*.json"):
                try:
                    backup_file.unlink()
                    deleted_count += 1
                except Exception as e:
                    errors.append(f"Failed to delete {backup_file.name}: {e}")
                    logger.error(f"Failed to delete backup file {backup_file.name}: {e}")
        except Exception as e:
            logger.error(f"Error listing backup directory: {e}")
            return {"success": False, "error": str(e)}

        # Clear the history file
        try:
            save_json_config(self.history_path, {"entries": []})
            logger.info("Cleared backup history")
        except Exception as e:
            errors.append(f"Failed to clear history: {e}")
            logger.error(f"Failed to clear backup history: {e}")

        # Clear last checksums cache
        self._last_checksums.clear()

        if errors:
            return {
                "success": False,
                "deleted_count": deleted_count,
                "errors": errors,
                "error": f"Deleted {deleted_count} files but encountered errors",
            }

        logger.info(f"Cleared all backups: {deleted_count} files deleted")
        return {"success": True, "deleted_count": deleted_count}

    def get_restore_commands(self, filename: str, mode: str = "configured") -> Optional[str]:
        """
        Get restore commands from a backup.

        Args:
            filename: Backup filename
            mode: "configured" or "factory_reset"

        Returns:
            Restore command string or None
        """
        backup = self.get_backup_content(filename)
        if not backup:
            return None

        restore = backup.get("restore_commands", {})
        return restore.get(mode)

    def get_restore_info(self, filename: str) -> Optional[Dict]:
        """
        Get restore information and recommendations for a backup.

        Returns info about which restore mode to use based on the backup's
        delimiter configuration.

        Args:
            filename: Backup filename

        Returns:
            Dict with restore info or None if backup not found
        """
        backup = self.get_backup_content(filename)
        if not backup:
            return None

        uses_default = backup.get("uses_default_delimiter", True)
        restore_commands = backup.get("restore_commands", {})

        if uses_default:
            # Board used default '^' delimiter - either mode works
            return {
                "uses_default_delimiter": True,
                "recommended_mode": "factory_reset",
                "reason": "Board uses default delimiter - either mode works",
                "modes_available": ["factory_reset", "configured"],
                "configured_checksum": backup.get("checksum"),
                "factory_reset_checksum": backup.get("factory_reset_checksum"),
                "has_configured": bool(restore_commands.get("configured")),
                "has_factory_reset": bool(restore_commands.get("factory_reset")),
            }
        else:
            # Board used custom delimiter - mode selection matters
            return {
                "uses_default_delimiter": False,
                "recommended_mode": None,  # User must choose
                "reason": (
                    "Board uses custom delimiter. Use 'factory_reset' for fresh/reset "
                    "boards, or 'configured' for boards already using this delimiter."
                ),
                "modes_available": ["factory_reset", "configured"],
                "configured_checksum": backup.get("checksum"),
                "factory_reset_checksum": backup.get("factory_reset_checksum"),
                "has_configured": bool(restore_commands.get("configured")),
                "has_factory_reset": bool(restore_commands.get("factory_reset")),
                "mode_descriptions": {
                    "factory_reset": (
                        "Use for fresh/factory-reset boards. Commands use default '^' "
                        "delimiter and will set custom delimiter during restore."
                    ),
                    "configured": (
                        "Use for boards already configured with this custom delimiter. "
                        "Commands use the custom delimiter throughout."
                    ),
                },
            }

    def compare_backups(self, file1: str, file2: str) -> Optional[Dict]:
        """
        Compare two backup files.

        Args:
            file1: First backup filename
            file2: Second backup filename

        Returns:
            Comparison dict or None
        """
        backup1 = self.get_backup_content(file1)
        backup2 = self.get_backup_content(file2)

        if not backup1 or not backup2:
            return None

        parsed1 = self._dict_to_parsed_backup(backup1.get("parsed_config"))
        parsed2 = self._dict_to_parsed_backup(backup2.get("parsed_config"))

        if not parsed1 or not parsed2:
            return None

        changes = self.detect_changes(parsed2, parsed1)  # older to newer

        return {
            "file1": file1,
            "file2": file2,
            "timestamp1": backup1.get("timestamp"),
            "timestamp2": backup2.get("timestamp"),
            "checksum1": backup1.get("checksum"),
            "checksum2": backup2.get("checksum"),
            "changes": changes.to_dict(),
            "change_summary": changes.generate_summary(),
        }


# Singleton accessor
def get_backup_manager() -> WCBBackupManager:
    """Get the singleton WCBBackupManager instance."""
    return WCBBackupManager()
