#!/usr/bin/env python3
"""
Test script for the enhanced firmware flasher
Tests file type detection and basic functionality
"""

import os
import sys
import tempfile

# Add scripts directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from firmware_flasher import (
        detect_file_type,
        MCU_SIGNATURES,
        BOARD_CONFIGS,
        ESP32_CONFIGS,
    )

    print("✓ Successfully imported firmware_flasher module")
except ImportError as e:
    print(f"✗ Failed to import firmware_flasher: {e}")
    sys.exit(1)


def test_file_type_detection():
    """Test file type detection"""
    print("\n=== Testing File Type Detection ===")

    # Create test files
    with tempfile.NamedTemporaryFile(suffix=".hex", delete=False) as f:
        # Intel HEX format starts with ':'
        f.write(b":020000040000FA\n:00000001FF\n")
        hex_file = f.name

    with tempfile.NamedTemporaryFile(suffix=".bin", delete=False) as f:
        # ESP32 binary starts with 0xE9
        f.write(b"\xe9\x04\x02\x20\xf4\x00\x00\x00")
        bin_file = f.name

    try:
        # Test hex file
        hex_type = detect_file_type(hex_file)
        print(f"HEX file detected as: {hex_type}")
        assert hex_type == "hex", f"Expected 'hex', got '{hex_type}'"
        print("✓ HEX file detection passed")

        # Test bin file
        bin_type = detect_file_type(bin_file)
        print(f"BIN file detected as: {bin_type}")
        assert bin_type == "esp32", f"Expected 'esp32', got '{bin_type}'"
        print("✓ BIN file detection passed")

    finally:
        # Clean up
        os.unlink(hex_file)
        os.unlink(bin_file)


def test_configurations():
    """Test configuration availability"""
    print("\n=== Testing Configurations ===")

    print(f"Arduino boards available: {list(BOARD_CONFIGS.keys())}")
    print(f"ESP32 chips available: {list(ESP32_CONFIGS.keys())}")
    print(f"MCU signatures loaded: {len(MCU_SIGNATURES)}")

    # Test signature lookup
    test_sig = "1e9516"  # ATmega328P
    if test_sig in MCU_SIGNATURES:
        sig_info = MCU_SIGNATURES[test_sig]
        print(f"✓ Signature {test_sig} maps to: {sig_info}")
    else:
        print(f"✗ Signature {test_sig} not found")


def test_esp32_detection():
    """Test ESP32 configuration"""
    print("\n=== Testing ESP32 Configuration ===")

    # Check if esptool is available
    try:
        import subprocess

        result = subprocess.run(["which", "esptool.py"], capture_output=True)
        if result.returncode == 0:
            print("✓ esptool.py is available")
            # Get version
            version_result = subprocess.run(
                ["esptool.py", "version"], capture_output=True, text=True
            )
            if version_result.returncode == 0:
                print(f"  Version: {version_result.stdout.strip()}")
        else:
            print("✗ esptool.py not found - ESP32 flashing will not work")
            print("  Install with: pip3 install esptool")
    except Exception as e:
        print(f"✗ Error checking esptool: {e}")


def main():
    print("DroidNet Firmware Flasher Test Suite")
    print("====================================")

    test_file_type_detection()
    test_configurations()
    test_esp32_detection()

    print("\n=== Test Summary ===")
    print("All basic tests completed.")
    print("\nTo test actual flashing:")
    print("1. Arduino: python3 firmware_flasher.py firmware.hex /dev/ttyUSB0")
    print("2. ESP32: python3 firmware_flasher.py firmware.bin /dev/ttyUSB0")
    print("3. Auto-detect: python3 firmware_flasher.py firmware.hex /dev/ttyUSB0 -d")


if __name__ == "__main__":
    main()
