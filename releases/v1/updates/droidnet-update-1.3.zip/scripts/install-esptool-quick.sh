#!/bin/bash
# Quick installation of esptool v5.0.0 for ARMv6 devices
# This script installs esptool without compiling heavy dependencies

set -e

echo "Installing esptool v5.0.0 (quick method)..."

# Create a temporary virtual environment
python3 -m venv /tmp/esptool-venv

# Activate and install with pre-built wheels where possible
source /tmp/esptool-venv/bin/activate

# First, download and install pre-built wheels from piwheels
pip install --index-url https://www.piwheels.org/simple cryptography==44.0.2
pip install --index-url https://www.piwheels.org/simple cffi pycparser

# Now install esptool with no-deps to avoid recompiling
pip install --no-deps esptool==5.0.0

# Install remaining pure Python dependencies
pip install bitstring reedsolo intelhex PyYAML rich_click

# Create system-wide symlinks
ln -sf /tmp/esptool-venv/bin/esptool /usr/local/bin/esptool
ln -sf /tmp/esptool-venv/bin/esptool /usr/local/bin/esptool.py

# Test installation
/usr/local/bin/esptool version

echo "esptool v5.0.0 installed successfully!"