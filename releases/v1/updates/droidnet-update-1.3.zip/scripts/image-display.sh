#!/bin/bash
# Image Display Script for DroidNet Display Feature
# Manages HDMI display power and static image display

set -e

# Configuration
IMAGE_DIR="/opt/droidnet/images"
LOG_FILE="/var/log/droidnet/image-display.log"
PID_FILE="/var/run/droidnet-image.pid"
SUPPORTED_MODELS="Pi Zero 2|Pi 3|Pi 4"

# Logging function
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

# Error logging function
log_error() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ERROR: $1" | tee -a "$LOG_FILE" >&2
}

# Check if Pi model is supported
check_pi_model() {
    if ! grep -qE "$SUPPORTED_MODELS" /proc/cpuinfo; then
        log_error "Unsupported Pi model. Display feature requires Pi Zero 2W, Pi 3, or Pi 4."
        exit 1
    fi
}

# Control HDMI display power
hdmi_power() {
    local state=$1  # 0=off, 1=on

    if command -v vcgencmd &> /dev/null; then
        vcgencmd display_power $state &>> "$LOG_FILE"
        log "HDMI power set to: $state"
    else
        log "vcgencmd not available, HDMI power control unavailable"
    fi
}

# Cleanup function called on exit
cleanup() {
    log "Cleanup: turning off HDMI and removing PID file"
    hdmi_power 0 2>/dev/null || true
    rm -f "$PID_FILE"
}

# Check if image file exists
check_image() {
    local image_path=$1

    if [[ ! -f "$image_path" ]]; then
        log_error "Image file not found: $image_path"
        return 1
    fi

    return 0
}

# Validate image format
validate_image_format() {
    local image_path=$1
    local extension="${image_path##*.}"
    extension=$(echo "$extension" | tr '[:upper:]' '[:lower:]')

    case "$extension" in
        jpg|jpeg|png|gif|bmp|webp)
            log "Valid image format: $extension"
            return 0
            ;;
        *)
            log_error "Unsupported image format: $extension (supported: jpg, jpeg, png, gif, bmp, webp)"
            return 1
            ;;
    esac
}

# Display image on framebuffer
display_image() {
    local image_path=$1

    # Check image exists
    if ! check_image "$image_path"; then
        return 1
    fi

    # Validate format
    if ! validate_image_format "$image_path"; then
        return 1
    fi

    log "Displaying image: $image_path"

    # Turn on HDMI
    hdmi_power 1
    sleep 1  # Give display time to initialize

    # Get framebuffer resolution
    local fb_resolution=$(cat /sys/class/graphics/fb0/virtual_size 2>/dev/null || echo "720,576")
    local fb_width=$(echo "$fb_resolution" | cut -d',' -f1)
    local fb_height=$(echo "$fb_resolution" | cut -d',' -f2)

    log "Framebuffer resolution: ${fb_width}x${fb_height}"

    # Setup cleanup trap
    trap cleanup EXIT INT TERM

    # Use ffmpeg to display image directly to framebuffer
    if ! command -v ffmpeg &> /dev/null; then
        log_error "ffmpeg not found (required for image display)"
        hdmi_power 0
        return 1
    fi

    log "Using ffmpeg for image display"
    # ffmpeg with:
    # - Loop mode (-loop 1) to keep image displayed
    # - Scale to fit within screen while maintaining aspect ratio
    # - Pad to fill screen with black bars if needed (handles both portrait and landscape)
    # - Fast bilinear scaling for better performance
    # - Direct framebuffer output (no X11 needed)
    # - Lower priority
    # Detect framebuffer pixel format (default to rgb565le for Pi)
    local fb_bits=$(cat /sys/class/graphics/fb0/bits_per_pixel 2>/dev/null || echo "16")
    local pix_fmt="rgb565le"
    if [[ "$fb_bits" == "32" ]]; then
        pix_fmt="bgra"
    fi
    log "Using pixel format: $pix_fmt (${fb_bits}bpp)"

    nice -n 10 ionice -c 2 -n 7 ffmpeg \
        -loop 1 \
        -i "$image_path" \
        -vf "scale=${fb_width}:${fb_height}:force_original_aspect_ratio=decrease,pad=${fb_width}:${fb_height}:(ow-iw)/2:(oh-ih)/2:black" \
        -sws_flags fast_bilinear \
        -pix_fmt "$pix_fmt" \
        -f fbdev /dev/fb0 \
        &>> "$LOG_FILE" 2>&1 &

    # Save PID for control
    local player_pid=$!
    echo "$player_pid" > "$PID_FILE"
    log "Started ffmpeg (PID: $player_pid)"

    # Wait for process to complete (or be stopped)
    wait "$player_pid"
    local exit_code=$?

    if [[ $exit_code -eq 0 ]]; then
        log "Image display completed successfully"
    elif [[ $exit_code -eq 143 ]] || [[ $exit_code -eq 130 ]]; then
        log "Image display stopped by signal"
    else
        log_error "Image display failed with exit code: $exit_code"
    fi

    # Turn off HDMI
    sleep 0.5
    hdmi_power 0

    # Cleanup
    rm -f "$PID_FILE"

    return 0
}

# Main function
main() {
    local image_name=$1

    if [[ -z "$image_name" ]]; then
        log_error "No image name provided"
        echo "Usage: $0 <image_name>"
        exit 1
    fi

    # Check Pi model support
    check_pi_model

    # Construct full path
    local image_path="${IMAGE_DIR}/${image_name}"

    # Add common extensions if no extension provided
    if [[ ! "$image_name" =~ \. ]]; then
        if [[ -f "${image_path}.jpg" ]]; then
            image_path="${image_path}.jpg"
        elif [[ -f "${image_path}.jpeg" ]]; then
            image_path="${image_path}.jpeg"
        elif [[ -f "${image_path}.png" ]]; then
            image_path="${image_path}.png"
        elif [[ -f "${image_path}.gif" ]]; then
            image_path="${image_path}.gif"
        elif [[ -f "${image_path}.bmp" ]]; then
            image_path="${image_path}.bmp"
        elif [[ -f "${image_path}.webp" ]]; then
            image_path="${image_path}.webp"
        fi
    fi

    # Display the image
    display_image "$image_path"

    exit $?
}

# Run main function
main "$@"
