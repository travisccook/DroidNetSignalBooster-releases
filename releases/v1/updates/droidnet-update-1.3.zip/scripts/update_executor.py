#!/usr/bin/env python3
"""
DroidNet Update Executor
Standalone script to handle system updates independent of the web server process.
This ensures updates can complete even when the web service restarts.
"""

import os
import sys
import json
import signal
import logging
import time
from pathlib import Path

# Add scripts directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from update_manager import UpdateManager  # noqa: E402

# Configuration
LOG_DIR = "/var/log/droidnet"
LOG_FILE = "update-executor.log"
STATUS_DIR = "/var/lib/droidnet"

# Global logger instance
logger = None


def setup_logging():
    """Configure logging for the update executor"""
    Path(LOG_DIR).mkdir(parents=True, exist_ok=True)
    log_file_path = os.path.join(LOG_DIR, LOG_FILE)

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
        handlers=[
            logging.FileHandler(log_file_path),
            logging.StreamHandler(sys.stdout),
        ],
    )
    return logging.getLogger(__name__)


def signal_handler(signum, frame):
    """Handle signals gracefully - ignore HUP to survive parent death"""
    logger.info(f"Received signal {signum}, continuing update process...")


def update_status_file(status_data):
    """Update the status file atomically"""
    status_file = os.path.join(STATUS_DIR, "update-status.json")
    temp_file = status_file + ".tmp"

    try:
        with open(temp_file, "w") as f:
            json.dump(status_data, f)
        os.replace(temp_file, status_file)
    except Exception as e:
        logger.error(f"Failed to update status file: {e}")


def write_completion_marker(version, success=True):
    """Write a persistent completion marker"""
    marker_file = os.path.join(STATUS_DIR, "last-update-completed.json")
    marker_data = {
        "version": version,
        "timestamp": time.time(),
        "success": success,
        "executor_pid": os.getpid(),
    }

    try:
        with open(marker_file, "w") as f:
            json.dump(marker_data, f)
        logger.info(f"Wrote completion marker for version {version}")
    except Exception as e:
        logger.error(f"Failed to write completion marker: {e}")


def main():
    """Main update executor process"""
    global logger
    logger = setup_logging()

    logger.info("=" * 60)
    logger.info(f"Update Executor Started - PID: {os.getpid()}")
    logger.info("=" * 60)

    # Set up signal handling to survive parent process death
    signal.signal(signal.SIGHUP, signal.SIG_IGN)  # Ignore hangup signal
    signal.signal(signal.SIGINT, signal_handler)  # Handle interrupt gracefully
    signal.signal(signal.SIGTERM, signal_handler)  # Handle terminate gracefully

    # Get job file from command line
    if len(sys.argv) < 2:
        logger.error("Usage: update_executor.py <job_file>")
        sys.exit(1)

    job_file = sys.argv[1]

    try:
        # Read job details
        with open(job_file, "r") as f:
            job_data = json.load(f)

        logger.info(f"Processing update job: {job_data}")

        package_path = job_data["package_path"]
        filename = job_data["filename"]
        start_time = job_data["start_time"]

        # Update status to show we're processing
        status_data = {
            "status": "processing",
            "filename": filename,
            "start_time": start_time,
            "executor_pid": os.getpid(),
            "progress": "Update executor started",
        }
        update_status_file(status_data)

        # Create UpdateManager and apply update
        logger.info(f"Starting update from {package_path}")
        with UpdateManager() as manager:
            # The UpdateManager will handle all status updates during the process
            result = manager.apply_update_package(package_path)

        logger.info(f"Update completed with result: {result}")

        # Update final status
        if result["success"]:
            status_data.update(
                {
                    "status": "completed",
                    "end_time": time.time(),
                    "result": result,
                    "new_version": result.get("version"),
                }
            )

            # Write completion marker that persists
            write_completion_marker(result.get("version"), success=True)
        else:
            status_data.update(
                {
                    "status": "failed",
                    "end_time": time.time(),
                    "result": result,
                    "error": result.get("error", "Unknown error"),
                }
            )

            write_completion_marker("failed", success=False)

        update_status_file(status_data)

        # Clean up job file
        try:
            os.unlink(job_file)
            logger.info(f"Cleaned up job file: {job_file}")
        except Exception as e:
            logger.warning(f"Failed to clean up job file: {e}")

        # Clean up package file if it's a temp file
        if package_path.startswith("/tmp/"):
            try:
                os.unlink(package_path)
                logger.info(f"Cleaned up package file: {package_path}")
            except Exception as e:
                logger.warning(f"Failed to clean up package file: {e}")

        logger.info("Update executor completed successfully")
        sys.exit(0 if result["success"] else 1)

    except Exception as e:
        logger.error(f"Update executor failed with error: {e}", exc_info=True)

        # Try to update status to failed
        try:
            status_data = {
                "status": "failed",
                "end_time": time.time(),
                "error": str(e),
                "executor_error": True,
            }
            update_status_file(status_data)
            write_completion_marker("error", success=False)
        except Exception:
            pass

        sys.exit(1)


if __name__ == "__main__":
    main()
