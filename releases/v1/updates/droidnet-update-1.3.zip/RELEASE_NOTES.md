## DroidNet Signal Booster v1.3

### Bug Fixes

**GitHub Update Download**
- Fixed "Update Now" button failing immediately with "Connection to server lost"
- The download endpoint now correctly responds to GET requests (required by EventSource)

### New Features

**Force Reinstall Updates**
- Added ability to re-apply updates even when already on the latest version
- Useful for troubleshooting or ensuring a clean installation
- API: `/api/system/download-update?force=true`
